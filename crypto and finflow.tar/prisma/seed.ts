import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

function daysAgo(days: number): Date {
  const d = new Date()
  d.setDate(d.getDate() - days)
  d.setHours(Math.floor(Math.random() * 12) + 7, Math.floor(Math.random() * 60), 0, 0)
  return d
}

function randomBetween(min: number, max: number): number {
  return Math.round((Math.random() * (max - min) + min) * 100) / 100
}

const TXN_TYPES = ['transfer', 'payment', 'deposit', 'withdrawal', 'escrow', 'refund', 'commission', 'chargeback', 'split_payment', 'international_transfer', 'bill'] as const
const TXN_STATUSES = ['completed', 'completed', 'completed', 'completed', 'completed', 'completed', 'completed', 'pending', 'failed', 'cancelled'] as const
const PAYMENT_METHODS = ['digital_wallet', 'bank_account', 'mobile_money', 'debit_card', 'credit_card'] as const

async function main() {
  console.log('🌱 Seeding database...')

  // Clear existing data (order matters for FK constraints)
  await prisma.cryptoSecurityEvent.deleteMany()
  await prisma.blockchainTransaction.deleteMany()
  await prisma.cryptoTransaction.deleteMany()
  await prisma.cryptoExchangeRate.deleteMany()
  await prisma.cryptoWallet.deleteMany()
  await prisma.auditLog.deleteMany()
  await prisma.dispute.deleteMany()
  await prisma.settlement.deleteMany()
  await prisma.notification.deleteMany()
  await prisma.commission.deleteMany()
  await prisma.splitPayment.deleteMany()
  await prisma.escrowPayment.deleteMany()
  await prisma.transaction.deleteMany()
  await prisma.bankAccount.deleteMany()
  await prisma.wallet.deleteMany()
  await prisma.transactionLimit.deleteMany()
  await prisma.feeConfig.deleteMany()
  await prisma.currency.deleteMany()
  await prisma.user.deleteMany()

  console.log('  🗑️  Cleared existing data')

  // ==================== CURRENCIES ====================
  await prisma.currency.createMany({
    data: [
      { code: 'ETB', name: 'Ethiopian Birr', symbol: 'Br', exchangeRate: 1, isActive: true },
      { code: 'USD', name: 'US Dollar', symbol: '$', exchangeRate: 57.5, isActive: true },
      { code: 'EUR', name: 'Euro', symbol: '€', exchangeRate: 62.3, isActive: true },
      { code: 'GBP', name: 'British Pound', symbol: '£', exchangeRate: 72.8, isActive: true },
      { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', exchangeRate: 15.65, isActive: true },
      { code: 'SAR', name: 'Saudi Riyal', symbol: '﷼', exchangeRate: 15.33, isActive: true },
      { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', exchangeRate: 41.8, isActive: true },
      { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', exchangeRate: 37.2, isActive: true },
      { code: 'JPY', name: 'Japanese Yen', symbol: '¥', exchangeRate: 0.37, isActive: true },
      { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', exchangeRate: 7.9, isActive: true },
      { code: 'INR', name: 'Indian Rupee', symbol: '₹', exchangeRate: 0.69, isActive: true },
    ],
  })
  console.log('  💰 Created 11 currencies')

  // ==================== USERS (only 3) ====================
  // Index 0 = Yismaw Alemayehu (super_admin)
  // Index 1 = Yismaw Gashu (administrator)
  // Index 2 = Temesgen Alemayehu (user)
  const userData = [
    { email: 'yismaw@finflow.com', username: 'yismaw', name: 'Yismaw Alemayehu', phone: '+251911000001', country: 'Ethiopia', role: 'super_admin' as const, kycStatus: 'verified' as const, twoFactorEnabled: true, isVerified: true, riskLevel: 'low' as const, status: 'active' as const, daysAgo: 90 },
    { email: 'yismawg@finflow.com', username: 'yismaw_gashu', name: 'Yismaw Gashu', phone: '+251920000001', country: 'Ethiopia', role: 'administrator' as const, kycStatus: 'verified' as const, twoFactorEnabled: true, isVerified: true, riskLevel: 'low' as const, status: 'active' as const, daysAgo: 30 },
    { email: 'temesgen@finflow.com', username: 'temesgen_a', name: 'Temesgen Alemayehu', phone: '+251922000001', country: 'Ethiopia', role: 'user' as const, kycStatus: 'pending' as const, twoFactorEnabled: false, isVerified: false, riskLevel: 'low' as const, status: 'active' as const, daysAgo: 10 },
  ]

  const users: { id: string; role: string }[] = []
  for (const u of userData) {
    const created = await prisma.user.create({
      data: {
        email: u.email,
        username: u.username,
        name: u.name,
        phone: u.phone,
        country: u.country,
        password: '$2b$12$x6Ucoogaq299o/qqIRKYXu2u5m/lLbKURWHRF2Wu501f1EtBwiBZu', // hashed 'Yismaw@2026'
        role: u.role,
        kycStatus: u.kycStatus,
        kycSubmittedAt: u.kycStatus !== 'pending' ? daysAgo(u.daysAgo - 5) : null,
        twoFactorEnabled: u.twoFactorEnabled,
        isVerified: u.isVerified,
        riskLevel: u.riskLevel,
        status: u.status,
        lastLoginAt: u.status === 'active' ? daysAgo(Math.floor(Math.random() * 3)) : null,
        createdAt: daysAgo(u.daysAgo),
      },
    })
    users.push({ id: created.id, role: created.role })
  }
  console.log(`  👤 Created ${users.length} users`)

  // ==================== WALLETS ====================
  const walletData = [
    { userIdx: 0, currency: 'ETB', balance: 5000000, frozen: 200000 },
    { userIdx: 0, currency: 'USD', balance: 25000, frozen: 1000 },
    { userIdx: 1, currency: 'ETB', balance: 1200000, frozen: 50000 },
    { userIdx: 1, currency: 'USD', balance: 5000, frozen: 200 },
    { userIdx: 2, currency: 'ETB', balance: 350000, frozen: 15000 },
  ]

  const wallets: { id: string; userIdx: number; currency: string }[] = []
  for (const w of walletData) {
    const created = await prisma.wallet.create({
      data: {
        userId: users[w.userIdx].id,
        currency: w.currency,
        balance: w.balance,
        frozenBalance: w.frozen,
        availableBalance: w.balance - w.frozen,
        type: 'digital',
        status: 'active',
        createdAt: daysAgo(85),
      },
    })
    wallets.push({ id: created.id, userIdx: w.userIdx, currency: w.currency })
  }
  console.log(`  💼 Created ${wallets.length} wallets`)

  // ==================== BANK ACCOUNTS ====================
  const bankAccounts = [
    { userIdx: 0, bankName: 'Awash Bank', accountNumber: '0987654321', accountName: 'Yismaw Alemayehu', accountType: 'checking', swiftCode: 'AWABETAA' },
    { userIdx: 0, bankName: 'Commercial Bank of Ethiopia', accountNumber: '1000234567890', accountName: 'FinFlow Operations', accountType: 'corporate', swiftCode: 'CBETETAA' },
    { userIdx: 1, bankName: 'Bank of Abyssinia', accountNumber: '7645001234', accountName: 'Yismaw Gashu', accountType: 'savings', swiftCode: 'ABYSETAA' },
  ]

  for (const ba of bankAccounts) {
    await prisma.bankAccount.create({
      data: {
        userId: users[ba.userIdx].id,
        bankName: ba.bankName,
        accountNumber: ba.accountNumber,
        accountName: ba.accountName,
        accountType: ba.accountType,
        swiftCode: ba.swiftCode,
        currency: 'ETB',
        isVerified: true,
        isDefault: ba.userIdx === 0,
        status: 'active',
        createdAt: daysAgo(80),
      },
    })
  }
  console.log(`  🏦 Created ${bankAccounts.length} bank accounts`)

  // ==================== FEE CONFIGS ====================
  await prisma.feeConfig.createMany({
    data: [
      { transactionType: 'deposit', paymentMethod: 'bank_account', feeType: 'flat', feeValue: 0, minFee: 0, maxFee: 0, currency: 'ETB', isActive: true },
      { transactionType: 'deposit', paymentMethod: 'mobile_money', feeType: 'flat', feeValue: 5, minFee: 0, maxFee: 25, currency: 'ETB', isActive: true },
      { transactionType: 'withdrawal', paymentMethod: 'bank_account', feeType: 'percentage', feeValue: 0.05, minFee: 15, maxFee: 500, currency: 'ETB', isActive: true },
      { transactionType: 'withdrawal', paymentMethod: 'mobile_money', feeType: 'flat', feeValue: 10, minFee: 0, maxFee: 50, currency: 'ETB', isActive: true },
      { transactionType: 'transfer', paymentMethod: 'digital_wallet', feeType: 'percentage', feeValue: 0.05, minFee: 2.5, maxFee: 100, currency: 'ETB', isActive: true },
      { transactionType: 'payment', paymentMethod: 'digital_wallet', feeType: 'percentage', feeValue: 0.5, minFee: 5, maxFee: 1000, currency: 'ETB', isActive: true },
      { transactionType: 'payment', paymentMethod: 'debit_card', feeType: 'percentage', feeValue: 0.75, minFee: 10, maxFee: 2000, currency: 'ETB', isActive: true },
      { transactionType: 'payment', paymentMethod: 'credit_card', feeType: 'percentage', feeValue: 1.5, minFee: 15, maxFee: 3000, currency: 'ETB', isActive: true },
      { transactionType: 'escrow', paymentMethod: null, feeType: 'percentage', feeValue: 0.5, minFee: 50, maxFee: 5000, currency: 'ETB', isActive: true },
      { transactionType: 'refund', paymentMethod: null, feeType: 'flat', feeValue: 0, minFee: 0, maxFee: 0, currency: 'ETB', isActive: true },
      { transactionType: 'international_transfer', paymentMethod: 'bank_account', feeType: 'percentage', feeValue: 0.15, minFee: 100, maxFee: 10000, currency: 'ETB', isActive: true },
      { transactionType: 'bill', paymentMethod: 'digital_wallet', feeType: 'flat', feeValue: 5, minFee: 0, maxFee: 30, currency: 'ETB', isActive: true },
    ],
  })
  console.log('  💵 Created 12 fee configs')

  // ==================== TRANSACTION LIMITS ====================
  await prisma.transactionLimit.createMany({
    data: [
      { userRole: 'user', transactionType: 'transfer', dailyLimit: 200000, monthlyLimit: 2000000, singleMax: 50000, currency: 'ETB', isActive: true },
      { userRole: 'user', transactionType: 'withdrawal', dailyLimit: 100000, monthlyLimit: 1000000, singleMax: 50000, currency: 'ETB', isActive: true },
      { userRole: 'user', transactionType: 'payment', dailyLimit: 500000, monthlyLimit: 5000000, singleMax: 200000, currency: 'ETB', isActive: true },
      { userRole: 'merchant', transactionType: 'payment', dailyLimit: 5000000, monthlyLimit: 50000000, singleMax: 1000000, currency: 'ETB', isActive: true },
      { userRole: 'merchant', transactionType: 'withdrawal', dailyLimit: 2000000, monthlyLimit: 20000000, singleMax: 500000, currency: 'ETB', isActive: true },
      { userRole: 'admin', transactionType: 'transfer', dailyLimit: 10000000, monthlyLimit: 100000000, singleMax: 5000000, currency: 'ETB', isActive: true },
    ],
  })
  console.log('  📋 Created 6 transaction limits')

  // ==================== TRANSACTIONS ====================
  const transactionTemplates = [
    // Recent 7 days
    ...Array.from({ length: 15 }, (_, i) => ({ dayOffset: i, type: 'transfer' as const, status: 'completed' as const, amountRange: [5000, 150000] as [number, number] })),
    ...Array.from({ length: 10 }, (_, i) => ({ dayOffset: i, type: 'payment' as const, status: 'completed' as const, amountRange: [2000, 80000] as [number, number] })),
    ...Array.from({ length: 5 }, (_, i) => ({ dayOffset: i, type: 'deposit' as const, status: 'completed' as const, amountRange: [10000, 500000] as [number, number] })),
    ...Array.from({ length: 3 }, (_, i) => ({ dayOffset: i, type: 'withdrawal' as const, status: 'completed' as const, amountRange: [5000, 100000] as [number, number] })),
    ...Array.from({ length: 2 }, (_, i) => ({ dayOffset: i, type: 'escrow' as const, status: 'completed' as const, amountRange: [20000, 200000] as [number, number] })),
    ...Array.from({ length: 2 }, (_, i) => ({ dayOffset: i, type: 'international_transfer' as const, status: 'completed' as const, amountRange: [50000, 500000] as [number, number] })),
    // Some pending/failed
    ...Array.from({ length: 2 }, (_, i) => ({ dayOffset: i, type: 'transfer' as const, status: 'pending' as const, amountRange: [3000, 50000] as [number, number] })),
    ...Array.from({ length: 1 }, (_, i) => ({ dayOffset: i, type: 'payment' as const, status: 'failed' as const, amountRange: [1000, 25000] as [number, number] })),
    // Older transactions (8-30 days)
    ...Array.from({ length: 20 }, (_, i) => ({ dayOffset: 8 + i * 2, type: 'transfer' as const, status: 'completed' as const, amountRange: [3000, 120000] as [number, number] })),
    ...Array.from({ length: 12 }, (_, i) => ({ dayOffset: 10 + i * 2, type: 'payment' as const, status: 'completed' as const, amountRange: [5000, 200000] as [number, number] })),
    ...Array.from({ length: 5 }, (_, i) => ({ dayOffset: 12 + i * 3, type: 'deposit' as const, status: 'completed' as const, amountRange: [10000, 300000] as [number, number] })),
    ...Array.from({ length: 3 }, (_, i) => ({ dayOffset: 15 + i * 3, type: 'refund' as const, status: 'completed' as const, amountRange: [1000, 30000] as [number, number] })),
    ...Array.from({ length: 2 }, (_, i) => ({ dayOffset: 20 + i * 2, type: 'commission' as const, status: 'completed' as const, amountRange: [500, 5000] as [number, number] })),
    // Even older (31-90 days)
    ...Array.from({ length: 15 }, (_, i) => ({ dayOffset: 31 + i * 4, type: 'transfer' as const, status: 'completed' as const, amountRange: [2000, 80000] as [number, number] })),
    ...Array.from({ length: 10 }, (_, i) => ({ dayOffset: 35 + i * 5, type: 'payment' as const, status: 'completed' as const, amountRange: [3000, 150000] as [number, number] })),
    ...Array.from({ length: 5 }, (_, i) => ({ dayOffset: 40 + i * 8, type: 'withdrawal' as const, status: 'completed' as const, amountRange: [5000, 75000] as [number, number] })),
    ...Array.from({ length: 3 }, (_, i) => ({ dayOffset: 50 + i * 10, type: 'split_payment' as const, status: 'completed' as const, amountRange: [10000, 100000] as [number, number] })),
    ...Array.from({ length: 2 }, (_, i) => ({ dayOffset: 60 + i * 15, type: 'chargeback' as const, status: 'completed' as const, amountRange: [5000, 40000] as [number, number] })),
  ]

  const activeUserIndices = [0, 1, 2]
  let txnCount = 0
  for (const tmpl of transactionTemplates) {
    const amount = randomBetween(tmpl.amountRange[0], tmpl.amountRange[1])
    const fee = Math.round(amount * 0.005 * 100) / 100
    const initiatorIdx = activeUserIndices[Math.floor(Math.random() * activeUserIndices.length)]
    let recipientIdx = activeUserIndices[Math.floor(Math.random() * activeUserIndices.length)]
    while (recipientIdx === initiatorIdx) recipientIdx = activeUserIndices[Math.floor(Math.random() * activeUserIndices.length)]

    const ref = `FIN-${String(Date.now()).slice(-8)}-${String(txnCount).padStart(4, '0')}`
    const pm = PAYMENT_METHODS[Math.floor(Math.random() * PAYMENT_METHODS.length)]

    const completedAt = tmpl.status === 'completed' ? daysAgo(tmpl.dayOffset) : null

    await prisma.transaction.create({
      data: {
        reference: ref,
        type: tmpl.type,
        subType: null,
        status: tmpl.status,
        amount,
        fee,
        currency: 'ETB',
        description: `${tmpl.type.replace('_', ' ')} from ${users[initiatorIdx]?.name || 'User'}`,
        initiatorId: users[initiatorIdx].id,
        recipientId: users[recipientIdx].id,
        recipientName: users[recipientIdx]?.name || 'Unknown',
        sourceWalletId: wallets.find(w => w.userIdx === initiatorIdx)?.id || null,
        destinationWalletId: wallets.find(w => w.userIdx === recipientIdx)?.id || null,
        paymentMethod: pm,
        completedAt,
        createdAt: daysAgo(tmpl.dayOffset),
      },
    })
    txnCount++
  }
  console.log(`  📊 Created ${txnCount} transactions`)

  // ==================== NOTIFICATIONS ====================
  const notifTemplates = [
    { type: 'security', title: 'Login Detected', message: 'New login from Addis Ababa, Ethiopia', channel: 'in_app', daysAgo: 0, isRead: false },
    { type: 'transaction', title: 'Transfer Completed', message: 'ETB 45,000 transferred to Yismaw Gashu', channel: 'in_app', daysAgo: 0, isRead: false },
    { type: 'transaction', title: 'Payment Received', message: 'ETB 12,500 received from Temesgen Alemayehu', channel: 'in_app', daysAgo: 0, isRead: false },
    { type: 'system', title: 'System Update', message: 'FinFlow platform maintenance scheduled for Sunday 2:00 AM', channel: 'in_app', daysAgo: 1, isRead: false },
    { type: 'transaction', title: 'Withdrawal Processed', message: 'ETB 25,000 withdrawn to Awash Bank', channel: 'in_app', daysAgo: 1, isRead: true },
    { type: 'security', title: 'KYC Verified', message: 'Your identity verification has been approved', channel: 'in_app', daysAgo: 2, isRead: true },
    { type: 'transaction', title: 'Escrow Released', message: 'ETB 85,000 escrow released to Temesgen Alemayehu', channel: 'in_app', daysAgo: 3, isRead: true },
    { type: 'system', title: 'New Feature', message: 'International transfers are now available for verified users', channel: 'in_app', daysAgo: 4, isRead: true },
    { type: 'transaction', title: 'Deposit Confirmed', message: 'ETB 200,000 deposited from CBE account', channel: 'in_app', daysAgo: 5, isRead: true },
    { type: 'security', title: 'Password Changed', message: 'Your account password was successfully updated', channel: 'in_app', daysAgo: 7, isRead: true },
    { type: 'transaction', title: 'Fee Refund', message: 'ETB 150 fee refunded for failed transaction', channel: 'in_app', daysAgo: 10, isRead: true },
    { type: 'system', title: 'Compliance Alert', message: 'Monthly compliance report is ready for review', channel: 'in_app', daysAgo: 14, isRead: true },
  ]

  for (const n of notifTemplates) {
    await prisma.notification.create({
      data: {
        userId: users[0].id,
        type: n.type,
        title: n.title,
        message: n.message,
        channel: n.channel,
        isRead: n.isRead,
        createdAt: daysAgo(n.daysAgo),
      },
    })
  }
  console.log(`  🔔 Created ${notifTemplates.length} notifications`)

  // ==================== CRYPTO WALLETS ====================
  const cryptoCurrencies = [
    { currency: 'BTC', network: 'mainnet', balance: 0.4521, available: 0.4521 },
    { currency: 'ETH', network: 'erc20', balance: 3.2847, available: 3.2847 },
    { currency: 'USDT', network: 'trc20', balance: 5420.50, available: 5420.50 },
    { currency: 'USDC', network: 'erc20', balance: 3200.00, available: 3200.00 },
    { currency: 'XRP', network: 'mainnet', balance: 8450.00, available: 8450.00 },
    { currency: 'SOL', network: 'solana', balance: 28.5, available: 28.5 },
    { currency: 'DOGE', network: 'mainnet', balance: 25000, available: 25000 },
    { currency: 'ADA', network: 'mainnet', balance: 12000, available: 12000 },
  ]

  function genAddress(currency: string, network: string): string {
    const prefixes: Record<string, string> = {
      BTC: 'bc1q', ETH: '0x', USDT: 'T', USDC: '0x', XRP: 'r', SOL: 'So1', DOGE: 'D', ADA: 'addr1'
    }
    const prefix = prefixes[currency] || '0x'
    const len = currency === 'BTC' ? 40 : (currency === 'ETH' || currency === 'USDC') ? 40 : 34
    const chars = '0123456789abcdef'
    let addr = prefix
    for (let i = 0; i < len; i++) addr += chars[Math.floor(Math.random() * 16)]
    return addr
  }

  const cryptoWalletData = [
    { userIdx: 0, currencies: [0, 1, 2, 3, 4, 5, 6, 7] }, // Yismaw Alemayehu gets all
    { userIdx: 1, currencies: [0, 1, 2, 3, 4, 5] },         // Yismaw Gashu gets 6
    { userIdx: 2, currencies: [2, 3, 4, 5] },                 // Temesgen Alemayehu gets 4
  ]

  const cryptoWallets: { id: string; userIdx: number; currency: string }[] = []
  for (const entry of cryptoWalletData) {
    for (const cIdx of entry.currencies) {
      const cc = cryptoCurrencies[cIdx]
      const created = await prisma.cryptoWallet.create({
        data: {
          userId: users[entry.userIdx].id,
          currency: cc.currency,
          balance: cc.balance * (0.5 + Math.random()),
          availableBalance: cc.available * (0.5 + Math.random()),
          frozenBalance: 0,
          depositAddress: genAddress(cc.currency, cc.network),
          network: cc.network,
          walletType: Math.random() > 0.8 ? 'cold' : 'hot',
          status: 'active',
          createdAt: daysAgo(60),
        },
      })
      cryptoWallets.push({ id: created.id, userIdx: entry.userIdx, currency: cc.currency })
    }
  }
  console.log(`  🐻 Created ${cryptoWallets.length} crypto wallets`)

  // ==================== CRYPTO EXCHANGE RATES ====================
  const etbBaseRates: Record<string, number> = { BTC: 57.5 * 104500, ETH: 57.5 * 3850, USDT: 57.5, USDC: 57.5, XRP: 57.5 * 2.35, SOL: 57.5 * 172, DOGE: 57.5 * 0.38, ADA: 57.5 * 0.72 }
  const cryptoList = Object.keys(etbBaseRates)
  for (const from of cryptoList) {
    await prisma.cryptoExchangeRate.create({ data: { fromCurrency: from, toCurrency: 'ETB', rate: etbBaseRates[from], fee: 0.5, feeType: 'percentage', minAmount: 0.0001, maxAmount: 10, isActive: true } })
    await prisma.cryptoExchangeRate.create({ data: { fromCurrency: 'ETB', toCurrency: from, rate: 1 / etbBaseRates[from], fee: 0.75, feeType: 'percentage', minAmount: 500, maxAmount: 50000000, isActive: true } })
  }
  for (const from of cryptoList) {
    for (const to of cryptoList) {
      if (from === to) continue
      const rate = etbBaseRates[from] / etbBaseRates[to]
      await prisma.cryptoExchangeRate.create({ data: { fromCurrency: from, toCurrency: to, rate, fee: 0.3, feeType: 'percentage', minAmount: 0.0001, maxAmount: 100, isActive: true } })
    }
  }
  console.log(`  📈 Created crypto exchange rates`)

  // ==================== CRYPTO TRANSACTIONS ====================
  const cryptoTxTypes = ['deposit', 'withdrawal', 'send', 'receive', 'exchange'] as const
  const cryptoTxStatuses = ['completed', 'completed', 'completed', 'completed', 'completed', 'pending', 'processing', 'failed'] as const
  let cryptoTxCount = 0
  for (let i = 0; i < 25; i++) {
    const cw = cryptoWallets[Math.floor(Math.random() * cryptoWallets.length)]
    const cc = cryptoCurrencies.find(c => c.currency === cw.currency)!
    const type = cryptoTxTypes[Math.floor(Math.random() * cryptoTxTypes.length)]
    const status = cryptoTxStatuses[Math.floor(Math.random() * cryptoTxStatuses.length)]
    const amount = randomBetween(0.0001, cc.balance * 0.1)
    const fee = type === 'exchange' ? randomBetween(0.1, 5) : randomBetween(0.00001, 0.001)
    const ref = `CRX-${String(Date.now()).slice(-8)}-${String(cryptoTxCount).padStart(4, '0')}`
    await prisma.cryptoTransaction.create({
      data: {
        reference: ref,
        type,
        status,
        amount,
        fee,
        feeCurrency: cw.currency,
        currency: cw.currency,
        fromCurrency: type === 'exchange' ? cw.currency : null,
        toCurrency: type === 'exchange' ? cryptoList.filter(c => c !== cw.currency)[Math.floor(Math.random() * (cryptoList.length - 1))] : null,
        exchangeRate: type === 'exchange' ? randomBetween(0.5, 2) : null,
        description: `Crypto ${type} - ${cw.currency}`,
        userId: users[cw.userIdx].id,
        walletId: cw.id,
        txHash: `0x${Array.from({length: 64}, () => '0123456789abcdef'[Math.floor(Math.random()*16)]).join('')}`,
        network: cc.network,
        networkFee: randomBetween(0.0001, 0.01),
        confirmations: status === 'completed' ? 6 : (status === 'processing' ? 2 : 0),
        requiredConfirmations: 3,
        riskScore: Math.random() * 10,
        completedAt: status === 'completed' ? daysAgo(Math.floor(Math.random() * 30)) : null,
        createdAt: daysAgo(Math.floor(Math.random() * 30)),
      },
    })
    cryptoTxCount++
  }
  console.log(`  💰 Created ${cryptoTxCount} crypto transactions`)

  // ==================== BLOCKCHAIN TRANSACTIONS ====================
  let btxCount = 0
  for (const cw of cryptoWallets.slice(0, 10)) {
    const cc = cryptoCurrencies.find(c => c.currency === cw.currency)!
    await prisma.blockchainTransaction.create({
      data: {
        txHash: `0x${Array.from({length: 64}, () => '0123456789abcdef'[Math.floor(Math.random()*16)]).join('')}`,
        network: cc.network,
        fromAddress: genAddress(cw.currency, cc.network),
        toAddress: genAddress(cw.currency, cc.network),
        amount: randomBetween(0.0001, cc.balance * 0.05),
        currency: cw.currency,
        blockNumber: 19000000 + btxCount * 12,
        confirmations: Math.random() > 0.3 ? 6 + Math.floor(Math.random() * 10) : Math.floor(Math.random() * 3),
        requiredConfs: 3,
        gasUsed: randomBetween(21000, 200000),
        gasPrice: randomBetween(10, 80),
        networkFee: randomBetween(0.0001, 0.01),
        status: Math.random() > 0.2 ? 'confirmed' : 'pending',
        detectedAt: daysAgo(Math.floor(Math.random() * 14)),
        confirmedAt: Math.random() > 0.3 ? daysAgo(Math.floor(Math.random() * 10)) : null,
      },
    })
    btxCount++
  }
  console.log(`  🔗 Created ${btxCount} blockchain transactions`)

  // ==================== CRYPTO SECURITY EVENTS ====================
  const securityEvents = [
    { eventType: 'kyc_check', severity: 'info', title: 'KYC Verification Passed', description: 'User identity verified successfully', userIdx: 0 },
    { eventType: 'aml_screen', severity: 'info', title: 'AML Screening Clear', description: 'No sanctions or adverse media found', userIdx: 0 },
    { eventType: '2fa_toggle', severity: 'info', title: '2FA Enabled', description: 'Two-factor authentication activated via TOTP', userIdx: 0 },
    { eventType: 'withdrawal_approval', severity: 'warning', title: 'Large Withdrawal Approval', description: 'Withdrawal of 0.5 BTC requires manual approval', userIdx: 0 },
    { eventType: 'fraud_alert', severity: 'critical', title: 'Suspicious Activity Detected', description: 'Multiple rapid transactions flagged for review', userIdx: 1 },
    { eventType: 'limit_change', severity: 'warning', title: 'Transaction Limit Updated', description: 'Daily withdrawal limit increased to 5 BTC', userIdx: 0 },
    { eventType: 'cold_wallet_transfer', severity: 'info', title: 'Cold Wallet Transfer', description: 'Funds moved from hot to cold wallet for security', userIdx: 0 },
    { eventType: 'audit_log', severity: 'info', title: 'Monthly Audit Completed', description: 'All crypto wallets reconciled and verified', userIdx: 0 },
    { eventType: 'fraud_alert', severity: 'critical', title: 'High-Risk Transaction Blocked', description: 'Transaction exceeding risk threshold was auto-blocked', userIdx: 2 },
    { eventType: 'kyc_check', severity: 'warning', title: 'KYC Re-verification Required', description: 'User KYC documents expiring soon', userIdx: 2 },
  ]
  for (const evt of securityEvents) {
    await prisma.cryptoSecurityEvent.create({
      data: {
        userId: users[evt.userIdx].id,
        eventType: evt.eventType,
        severity: evt.severity,
        title: evt.title,
        description: evt.description,
        ipAddress: `192.168.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`,
        createdAt: daysAgo(Math.floor(Math.random() * 30)),
      },
    })
  }
  console.log(`  🛡️ Created ${securityEvents.length} security events`)

  console.log('\n✅ Seed completed successfully!')
  console.log(`  - ${users.length} Users`)
  console.log(`  - ${wallets.length} Wallets`)
  console.log(`  - ${bankAccounts.length} Bank accounts`)
  console.log(`  - ${txnCount} Transactions`)
  console.log(`  - ${notifTemplates.length} Notifications`)
  console.log(`  - ${cryptoWallets.length} Crypto wallets`)
  console.log(`  - ${cryptoTxCount} Crypto transactions`)
  console.log(`  - ${btxCount} Blockchain transactions`)
  console.log(`  - ${securityEvents.length} Security events`)
  console.log('  - 11 Currencies')
  console.log('  - 12 Fee configurations')
  console.log('  - 6 Transaction limits')
}

main()
  .then(async () => { await prisma.$disconnect() })
  .catch(async (e) => {
    console.error('❌ Seed failed:', e)
    await prisma.$disconnect()
    process.exit(1)
  })
