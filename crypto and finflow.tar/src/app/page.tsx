'use client';

import { useEffect } from 'react';
import { ThemeProvider } from 'next-themes';
import { Toaster } from 'sonner';
import { AppSidebar } from '@/components/financial/app-sidebar';
import { AppHeader } from '@/components/financial/app-header';
import LoginScreen from '@/components/financial/login-screen';
import { useAppStore, type ViewId } from '@/lib/store';
import { apiFetch } from '@/lib/api-fetch';
import { I18nProvider, useT } from '@/lib/i18n';
import { AnimatePresence, motion } from 'framer-motion';

// Lazy-load all views to keep initial bundle small
import dynamic from 'next/dynamic';

// ── Main ──────────────────────────────────────────────────
const DashboardView = dynamic(() => import('@/components/financial/dashboard-view'), { ssr: false });
const ActivityCenterView = dynamic(() => import('@/components/financial/activity-center-view'), { ssr: false });
const NotificationsView = dynamic(() => import('@/components/financial/notifications-view'), { ssr: false });

// ── Wallet & Accounts ──────────────────────────────────────
const WalletsView = dynamic(() => import('@/components/financial/wallets-view'), { ssr: false });
const TransfersView = dynamic(() => import('@/components/financial/transfers-view'), { ssr: false });
const CryptoView = dynamic(() => import('@/components/financial/crypto-view'), { ssr: false });

// ── Transactions ───────────────────────────────────────────
const TransactionsView = dynamic(() => import('@/components/financial/transactions-view'), { ssr: false });

// ── Banking ────────────────────────────────────────────────
const BankingView = dynamic(() => import('@/components/financial/banking-view'), { ssr: false });

// ── Currencies & FX ───────────────────────────────────────
const CurrenciesView = dynamic(() => import('@/components/financial/currencies-view'), { ssr: false });

// ── Send & Receive ─────────────────────────────────────────
const SendReceiveView = dynamic(() => import('@/components/financial/send-receive-view'), { ssr: false });

// ── Payments & Commerce ────────────────────────────────────
const PaymentsView = dynamic(() => import('@/components/financial/payments-view'), { ssr: false });
const MerchantsView = dynamic(() => import('@/components/financial/merchants-view'), { ssr: false });
const CustomersView = dynamic(() => import('@/components/financial/customers-view'), { ssr: false });

// ── Security & Compliance ──────────────────────────────────
const SecurityView = dynamic(() => import('@/components/financial/security-view'), { ssr: false });
const ComplianceView = dynamic(() => import('@/components/financial/compliance-view'), { ssr: false });

// ── Administration ─────────────────────────────────────────
const AdminView = dynamic(() => import('@/components/financial/admin-view'), { ssr: false });
const ApprovalsView = dynamic(() => import('@/components/financial/approvals-view'), { ssr: false });
const IntegrationsView = dynamic(() => import('@/components/financial/integrations-view'), { ssr: false });

// ── Reports & Analytics ────────────────────────────────────
const ReportsView = dynamic(() => import('@/components/financial/reports-view'), { ssr: false });

// ── AI & Automation ────────────────────────────────────────
const AIAssistantView = dynamic(() => import('@/components/financial/ai-assistant-view'), { ssr: false });

// ── Audit & Ledger ─────────────────────────────────────────
const LedgerView = dynamic(() => import('@/components/financial/ledger-view'), { ssr: false });

// ── Settings ───────────────────────────────────────────────
const SettingsView = dynamic(() => import('@/components/financial/settings-view'), { ssr: false });

function ViewRouter() {
  const { activeView } = useAppStore();

  const views: Record<ViewId, React.ReactNode> = {
    // Main
    dashboard: <DashboardView />,
    'activity-center': <ActivityCenterView />,
    notifications: <NotificationsView />,
    // Wallet & Accounts
    wallets: <WalletsView />,
    transfers: <TransfersView />,
    crypto: <CryptoView />,
    // Transactions
    transactions: <TransactionsView />,
    // Banking
    banking: <BankingView />,
    // Currencies & FX
    currencies: <CurrenciesView />,
    // Send & Receive
    'send-receive': <SendReceiveView />,
    // Payments & Commerce
    payments: <PaymentsView />,
    merchants: <MerchantsView />,
    customers: <CustomersView />,
    // Security & Compliance
    security: <SecurityView />,
    compliance: <ComplianceView />,
    // Administration
    admin: <AdminView />,
    approvals: <ApprovalsView />,
    integrations: <IntegrationsView />,
    // Reports & Analytics
    reports: <ReportsView />,
    // AI & Automation
    'ai-assistant': <AIAssistantView />,
    // Audit & Ledger
    ledger: <LedgerView />,
    // Settings
    settings: <SettingsView />,
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={activeView}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.2, ease: 'easeInOut' }}
      >
        {views[activeView]}
      </motion.div>
    </AnimatePresence>
  );
}

function AppShell() {
  return (
    <div className="flex h-screen overflow-hidden">
      <AppSidebar />
      <div className="flex flex-1 flex-col min-w-0">
        <AppHeader />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-muted/30">
          <ViewRouter />
        </main>
        <FooterBar />
      </div>
    </div>
  );
}

function FooterBar() {
  const t = useT();
  return (
    <footer className="border-t bg-background px-4 py-2 flex items-center justify-between text-[11px] text-muted-foreground mt-auto">
      <span>© 2026 {t('footer.rights')}</span>
      <div className="flex items-center gap-3">
        <span>Enterprise Edition v1.0</span>
        <span className="hidden sm:inline">|</span>
        <span className="hidden sm:inline">{t('footer.regulated')}</span>
      </div>
    </footer>
  );
}

function AuthGate() {
  const { user, authLoading, setUser, setToken, setAuthLoading } = useAppStore();

  useEffect(() => {
    apiFetch('/api/auth/session')
      .then((res) => res.json())
      .then((data) => {
        if (data.user) {
          if (data.token) setToken(data.token);
          setUser(data.user);
        } else {
          setAuthLoading(false);
        }
      })
      .catch(() => {
        setAuthLoading(false);
      });
  }, [setUser, setToken, setAuthLoading]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-emerald-600 flex items-center justify-center animate-pulse">
            <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
            </svg>
          </div>
          <span className="text-sm text-muted-foreground">Loading...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  return <AppShell />;
}

export default function HomePage() {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      disableTransitionOnChange
    >
      <I18nProvider>
        <AuthGate />
        <Toaster position="top-right" richColors />
      </I18nProvider>
    </ThemeProvider>
  );
}
