import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FinFlow - Enterprise Financial Transaction Platform",
  description:
    "Secure, scalable, enterprise-grade financial transaction platform supporting domestic and international payments, banking integration, and regulatory compliance.",
  keywords: [
    "FinFlow",
    "Financial Platform",
    "Payments",
    "Wallet",
    "Banking",
    "Ethiopia",
    "ETB",
  ],
  authors: [{ name: "FinFlow Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
      </body>
    </html>
  );
}
