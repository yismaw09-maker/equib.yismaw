import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const userRole = searchParams.get('userRole')
    const isActive = searchParams.get('isActive')

    const where: Record<string, unknown> = {}
    if (userRole) where.userRole = userRole
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true'
    }

    const limits = await db.transactionLimit.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(limits)
  } catch (error) {
    console.error('Transaction limits error:', error)
    return NextResponse.json({ error: 'Failed to load transaction limits' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { userRole, transactionType, dailyLimit, monthlyLimit, singleMax, currency } = body

    if (!userRole || !transactionType) {
      return NextResponse.json(
        { error: 'Missing required fields: userRole, transactionType' },
        { status: 400 },
      )
    }

    const limit = await db.transactionLimit.create({
      data: {
        userRole,
        transactionType,
        dailyLimit: dailyLimit ?? 0,
        monthlyLimit: monthlyLimit ?? 0,
        singleMax: singleMax ?? 0,
        currency: currency ?? 'ETB',
        isActive: true,
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'transaction_limit',
      resourceId: limit.id,
      details: `Created transaction limit for ${userRole}/${transactionType}`,
      request,
    })

    return NextResponse.json(limit, { status: 201 })
  } catch (error) {
    console.error('Transaction limit create error:', error)
    return NextResponse.json({ error: 'Failed to create transaction limit' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, dailyLimit, monthlyLimit, singleMax, isActive } = body

    if (!id) {
      return NextResponse.json({ error: 'Transaction limit ID is required' }, { status: 400 })
    }

    const existing = await db.transactionLimit.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Transaction limit not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {}
    if (dailyLimit !== undefined) updateData.dailyLimit = dailyLimit
    if (monthlyLimit !== undefined) updateData.monthlyLimit = monthlyLimit
    if (singleMax !== undefined) updateData.singleMax = singleMax
    if (isActive !== undefined) updateData.isActive = isActive

    const limit = await db.transactionLimit.update({
      where: { id },
      data: updateData,
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'transaction_limit',
      resourceId: id,
      details: `Updated transaction limit ${id}: ${JSON.stringify(updateData)}`,
      request,
    })

    return NextResponse.json(limit)
  } catch (error) {
    console.error('Transaction limit update error:', error)
    return NextResponse.json({ error: 'Failed to update transaction limit' }, { status: 500 })
  }
}
