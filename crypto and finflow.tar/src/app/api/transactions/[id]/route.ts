import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog, getRoleLevel } from '@/lib/auth-helpers'

// ── GET /api/transactions/[id] ──────────────────────────────────
// Users can see transactions where they are initiator or recipient.
// Admin (level>=45) can see any transaction.
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45

    const { id } = await params
    const transaction = await db.transaction.findUnique({
      where: { id },
      include: {
        initiator: { select: { id: true, name: true, email: true, phone: true } },
        recipient: { select: { id: true, name: true, email: true, phone: true } },
        sourceWallet: { select: { id: true, currency: true, userId: true } },
        destinationWallet: { select: { id: true, currency: true, userId: true } },
      },
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Authorization: user must be initiator, recipient, or admin
    if (
      !isAdmin &&
      transaction.initiatorId !== user.id &&
      transaction.recipientId !== user.id
    ) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // For non-admins, redact PII of other users
    if (!isAdmin) {
      if (transaction.initiator && transaction.initiatorId !== user.id) {
        delete (transaction.initiator as Record<string, unknown>).email
        delete (transaction.initiator as Record<string, unknown>).phone
      }
      if (transaction.recipient && transaction.recipientId !== user.id) {
        delete (transaction.recipient as Record<string, unknown>).email
        delete (transaction.recipient as Record<string, unknown>).phone
      }
    }

    return NextResponse.json(transaction)
  } catch (error) {
    console.error('Transaction detail error:', error)
    return NextResponse.json({ error: 'Failed to load transaction' }, { status: 500 })
  }
}

// ── PATCH /api/transactions/[id] ─────────────────────────────────
// Admin only (level>=60). Handles status changes with real wallet
// balance movement for completed/reversed/failed/cancelled.
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { id } = await params
    const body = await request.json()
    const { status } = body

    if (!status || !['completed', 'failed', 'cancelled', 'reversed'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be one of: completed, failed, cancelled, reversed' },
        { status: 400 }
      )
    }

    const existing = await db.transaction.findUnique({
      where: { id },
      include: {
        sourceWallet: true,
        destinationWallet: true,
      },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Prevent re-processing already completed transactions with 'completed'
    if (status === 'completed' && existing.status === 'completed') {
      return NextResponse.json({ error: 'Transaction is already completed' }, { status: 400 })
    }

    // Prevent re-reversing already reversed transactions
    if (status === 'reversed' && existing.status === 'reversed') {
      return NextResponse.json({ error: 'Transaction is already reversed' }, { status: 400 })
    }

    // Prevent re-failing or re-cancelling already in terminal state
    const terminalStates = ['failed', 'cancelled', 'reversed']
    if (terminalStates.includes(status) && terminalStates.includes(existing.status)) {
      return NextResponse.json({ error: `Transaction is already ${existing.status}` }, { status: 400 })
    }

    // ── STATUS: completed ───────────────────────────────────────
    // Perform actual wallet balance movement if not already done.
    if (status === 'completed') {
      // If it was previously in a terminal state with balances already reversed,
      // we cannot re-complete. Only allow pending/processing -> completed.
      if (terminalStates.includes(existing.status)) {
        return NextResponse.json(
          { error: `Cannot complete a ${existing.status} transaction` },
          { status: 400 }
        )
      }

      const totalDeduction = existing.amount + existing.fee

      // If source wallet exists, verify and deduct
      if (existing.sourceWalletId) {
        const sourceWallet = await db.wallet.findUnique({ where: { id: existing.sourceWalletId } })
        if (!sourceWallet) {
          return NextResponse.json({ error: 'Source wallet not found' }, { status: 404 })
        }
        if (sourceWallet.availableBalance < totalDeduction) {
          return NextResponse.json({ error: 'Insufficient balance in source wallet' }, { status: 400 })
        }
      }

      // If destination wallet exists, verify it exists
      if (existing.destinationWalletId) {
        const destWallet = await db.wallet.findUnique({ where: { id: existing.destinationWalletId } })
        if (!destWallet) {
          return NextResponse.json({ error: 'Destination wallet not found' }, { status: 404 })
        }
      }

      // Atomic balance movement + status update
      const transaction = await db.$transaction(async (tx) => {
        const ops: unknown[] = []

        // Deduct from source
        if (existing.sourceWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: existing.sourceWalletId },
              data: {
                balance: { decrement: totalDeduction },
                availableBalance: { decrement: totalDeduction },
              },
            })
          )
        }

        // Add to destination
        if (existing.destinationWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: existing.destinationWalletId },
              data: {
                balance: { increment: existing.amount },
                availableBalance: { increment: existing.amount },
              },
            })
          )
        }

        // Update transaction status
        ops.push(
          tx.transaction.update({
            where: { id },
            data: { status: 'completed', completedAt: new Date() },
            include: {
              initiator: { select: { id: true, name: true, email: true } },
              recipient: { select: { id: true, name: true, email: true } },
            },
          })
        )

        const results = await Promise.all(ops)
        return results[results.length - 1]
      })

      await createAuditLog({
        userId: user.id,
        action: 'complete_transaction',
        resource: 'transaction',
        resourceId: id,
        details: `Completed transaction ${existing.reference} (${existing.amount} ${existing.currency}) with balance movement`,
        request,
      })

      return NextResponse.json(transaction)
    }

    // ── STATUS: reversed ─────────────────────────────────────────
    // Reverse the previous balance movement (undo the completed state).
    if (status === 'reversed') {
      // Only reverse completed transactions
      if (existing.status !== 'completed') {
        return NextResponse.json(
          { error: 'Only completed transactions can be reversed' },
          { status: 400 }
        )
      }

      const totalDeduction = existing.amount + existing.fee

      const transaction = await db.$transaction(async (tx) => {
        const ops: unknown[] = []

        // Restore to source wallet (money was taken from here)
        if (existing.sourceWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: existing.sourceWalletId },
              data: {
                balance: { increment: totalDeduction },
                availableBalance: { increment: totalDeduction },
              },
            })
          )
        }

        // Deduct from destination wallet (money was added here)
        if (existing.destinationWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: existing.destinationWalletId },
              data: {
                balance: { decrement: existing.amount },
                availableBalance: { decrement: existing.amount },
              },
            })
          )
        }

        // Update transaction status
        ops.push(
          tx.transaction.update({
            where: { id },
            data: { status: 'reversed' },
            include: {
              initiator: { select: { id: true, name: true, email: true } },
              recipient: { select: { id: true, name: true, email: true } },
            },
          })
        )

        const results = await Promise.all(ops)
        return results[results.length - 1]
      })

      await createAuditLog({
        userId: user.id,
        action: 'reverse_transaction',
        resource: 'transaction',
        resourceId: id,
        details: `Reversed transaction ${existing.reference} (${existing.amount} ${existing.currency}) — balances restored`,
        request,
      })

      return NextResponse.json(transaction)
    }

    // ── STATUS: failed / cancelled ───────────────────────────────
    // If previously completed, reverse balances first.
    if (status === 'failed' || status === 'cancelled') {
      const wasCompleted = existing.status === 'completed'
      const totalDeduction = existing.amount + existing.fee

      const transaction = await db.$transaction(async (tx) => {
        const ops: unknown[] = []

        // If it was completed, reverse the balance movement
        if (wasCompleted) {
          // Restore to source
          if (existing.sourceWalletId) {
            ops.push(
              tx.wallet.update({
                where: { id: existing.sourceWalletId },
                data: {
                  balance: { increment: totalDeduction },
                  availableBalance: { increment: totalDeduction },
                },
              })
            )
          }

          // Deduct from destination
          if (existing.destinationWalletId) {
            ops.push(
              tx.wallet.update({
                where: { id: existing.destinationWalletId },
                data: {
                  balance: { decrement: existing.amount },
                  availableBalance: { decrement: existing.amount },
                },
              })
            )
          }
        }

        // Update transaction status
        ops.push(
          tx.transaction.update({
            where: { id },
            data: { status },
            include: {
              initiator: { select: { id: true, name: true, email: true } },
              recipient: { select: { id: true, name: true, email: true } },
            },
          })
        )

        const results = await Promise.all(ops)
        return results[results.length - 1]
      })

      await createAuditLog({
        userId: user.id,
        action: `${status}_transaction`,
        resource: 'transaction',
        resourceId: id,
        details: `Marked transaction ${existing.reference} as ${status}${wasCompleted ? ' (balances reversed)' : ''}`,
        request,
      })

      return NextResponse.json(transaction)
    }

    // Should not reach here, but satisfy TypeScript
    return NextResponse.json({ error: 'Invalid status transition' }, { status: 400 })
  } catch (error) {
    console.error('Transaction update error:', error)
    return NextResponse.json({ error: 'Failed to update transaction' }, { status: 500 })
  }
}
