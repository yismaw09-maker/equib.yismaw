import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, parsePagination, createAuditLog, getRoleLevel } from '@/lib/auth-helpers'

// ── GET /api/transactions ────────────────────────────────────────
// Authenticated users see their own transactions.
// Admin (level>=45) can see all with full filters.
export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const userId = searchParams.get('userId')
    const currency = searchParams.get('currency')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const search = searchParams.get('search')
    const sort = searchParams.get('sort') ?? 'createdAt'
    const order = searchParams.get('order') ?? 'desc'
    const { page, limit, skip } = parsePagination(searchParams)

    const where: Record<string, unknown> = {}

    // Non-admins can only see their own transactions
    if (!isAdmin) {
      where.OR = [
        { initiatorId: user.id },
        { recipientId: user.id },
      ]
    }

    if (type) where.type = type
    if (status) where.status = status
    if (currency) where.currency = currency

    // Only admins can filter by userId
    if (isAdmin && userId) {
      const userFilter = {
        OR: [
          { initiatorId: userId },
          { recipientId: userId },
        ],
      }
      if (where.OR) {
        // We already have an OR from above (shouldn't happen for admins, but be safe)
        // For admins, if userId is specified, use it as the primary filter
        delete where.OR
        where.OR = userFilter.OR
      } else {
        where.OR = userFilter.OR
      }
    }

    if (search) {
      const searchClause = {
        OR: [
          { reference: { contains: search } },
          { description: { contains: search } },
          { recipientName: { contains: search } },
        ],
      }
      if (where.OR) {
        // Merge with existing OR
        const existingOr = Array.isArray(where.OR) ? where.OR : [where.OR]
        // Use AND between the user filter and search filter
        const userOrClause = { OR: existingOr }
        where.AND = [userOrClause, searchClause]
        delete where.OR
      } else {
        where.OR = searchClause.OR
      }
    }

    if (startDate || endDate) {
      const dateFilter: Record<string, unknown> = {}
      if (startDate) dateFilter.gte = new Date(startDate)
      if (endDate) dateFilter.lte = new Date(endDate)
      where.createdAt = dateFilter
    }

    // Validate sort field
    const allowedSortFields = ['createdAt', 'amount', 'fee', 'type', 'status', 'reference']
    const sortField = allowedSortFields.includes(sort) ? sort : 'createdAt'
    const sortOrder = order === 'asc' ? 'asc' : 'desc'

    const [transactions, total, summaryResult] = await Promise.all([
      db.transaction.findMany({
        where,
        include: {
          initiator: { select: { id: true, name: true, email: true } },
          recipient: { select: { id: true, name: true, email: true } },
          sourceWallet: { select: { id: true, currency: true } },
          destinationWallet: { select: { id: true, currency: true } },
        },
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
      }),
      db.transaction.count({ where }),
      db.transaction.groupBy({
        by: ['status'],
        where,
        _sum: { amount: true },
        _count: true,
      }),
    ])

    // Build summary from groupBy results
    const summary = {
      totalAmount: 0,
      totalFee: 0,
      completedCount: 0,
      completedAmount: 0,
      pendingCount: 0,
      pendingAmount: 0,
      processingCount: 0,
      processingAmount: 0,
      failedCount: 0,
      failedAmount: 0,
      cancelledCount: 0,
      cancelledAmount: 0,
      reversedCount: 0,
      reversedAmount: 0,
    }

    for (const row of summaryResult) {
      const countKey = `${row.status}Count` as keyof typeof summary
      const amountKey = `${row.status}Amount` as keyof typeof summary
      summary.totalAmount += row._sum.amount ?? 0
      if (countKey in summary && typeof summary[countKey] === 'number') {
        (summary as Record<string, unknown>)[countKey] = row._count
      }
      if (amountKey in summary && typeof summary[amountKey] === 'number') {
        (summary as Record<string, unknown>)[amountKey] = row._sum.amount ?? 0
      }
    }

    return NextResponse.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      summary,
    })
  } catch (error) {
    console.error('Transactions list error:', error)
    return NextResponse.json({ error: 'Failed to load transactions' }, { status: 500 })
  }
}

// ── POST /api/transactions ───────────────────────────────────────
// Creates a transaction with real wallet balance movement for
// transfer, deposit, withdrawal, and payment types.
// Accepts multiple field-name conventions (sourceWallet / sourceWalletId, etc.)
export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const {
      type,
      amount,
      currency,
      description,
      recipientId,
      recipientName,
      sourceWalletId,
      destinationWalletId,
      sourceBankId,
      destinationBankId,
      paymentMethod,
      category,
      subType,
      senderAddress,
      receiverAddress,
      // Aliases from send-receive-view (legacy field names)
      sourceWallet,
      destinationWallet,
      sourceBank,
      sourceAccount,
      destBank,
      destAccount,
      accountName,
      // Extra fields from international transfers
      swiftCode,
      recipientEmail,
      recipientPhone,
    } = body

    if (!type || amount == null || amount <= 0) {
      return NextResponse.json({ error: 'Missing required fields: type, amount (positive number)' }, { status: 400 })
    }

    const isAdmin = getRoleLevel(user.role) >= 45
    const txnCurrency = currency ?? 'ETB'
    const totalDebit = amount

    // ── Resolve source/destination IDs from aliases ───────────
    const resolvedSourceWalletId = sourceWalletId || sourceWallet || null
    const resolvedDestWalletId = destinationWalletId || destinationWallet || null

    // Resolve bank account IDs or use raw strings
    let resolvedSourceBankId = sourceBankId || null
    let resolvedDestBankId = destinationBankId || null
    let resolvedBankName: string | null = body.bankName || destBank || sourceBank || null
    let resolvedAccountNumber: string | null = body.accountNumber || destAccount || sourceAccount || null

    // If a sourceBank (name) was provided but no sourceBankId, try to look up the bank account
    if (!resolvedSourceBankId && sourceBank && sourceAccount) {
      const match = await db.bankAccount.findFirst({
        where: { userId: user.id, bankName: sourceBank, accountNumber: sourceAccount },
      })
      if (match) resolvedSourceBankId = match.id
    }
    // If destBank/destAccount were provided but no destinationBankId, try to look up
    if (!resolvedDestBankId && destBank && destAccount) {
      const match = await db.bankAccount.findFirst({
        where: { userId: user.id, bankName: destBank, accountNumber: destAccount },
      })
      if (match) resolvedDestBankId = match.id
    }
    // Also check body.bankName + body.accountNumber for destination bank lookup
    if (!resolvedDestBankId && !resolvedSourceBankId && body.bankName && body.accountNumber) {
      const match = await db.bankAccount.findFirst({
        where: { userId: user.id, bankName: body.bankName, accountNumber: body.accountNumber },
      })
      if (match) resolvedDestBankId = match.id
    }

    // Generate unique reference
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    const rand = String(Math.floor(Math.random() * 100000)).padStart(5, '0')
    const reference = `TXN-${y}${m}${d}-${rand}`

    // Get fee config
    const feeConfig = await db.feeConfig.findFirst({
      where: {
        transactionType: type,
        paymentMethod: paymentMethod ?? null,
        isActive: true,
      },
    })

    let fee = 0
    if (feeConfig) {
      if (feeConfig.feeType === 'flat') {
        fee = feeConfig.feeValue
      } else if (feeConfig.feeType === 'percentage') {
        fee = (amount * feeConfig.feeValue) / 100
        if (feeConfig.minFee && fee < feeConfig.minFee) fee = feeConfig.minFee
        if (feeConfig.maxFee && fee > feeConfig.maxFee) fee = feeConfig.maxFee
      }
    }

    // Types that can move money atomically at creation time
    const balanceMovingTypes = ['transfer', 'payment', 'deposit', 'withdrawal']
    const requiresSource = ['transfer', 'payment', 'withdrawal'].includes(type)
    const requiresDest = ['transfer', 'payment', 'deposit'].includes(type)

    // Source: wallet ID, bank ID, bank name+account, or nothing (e.g. international)
    const hasSource = resolvedSourceWalletId || resolvedSourceBankId || (sourceBank && sourceAccount)
    // Destination: wallet ID, bank ID, bank name+account, or recipient info
    const hasDestination = resolvedDestWalletId || resolvedDestBankId || (destBank && destAccount) || (body.bankName && body.accountNumber) || recipientId || recipientName

    if (requiresSource && !hasSource) {
      return NextResponse.json({ error: `${type} transactions require a source (wallet or bank account)` }, { status: 400 })
    }
    if (requiresDest && !hasDestination) {
      return NextResponse.json({ error: `${type} transactions require a destination (wallet, bank account, or recipient)` }, { status: 400 })
    }

    // Determine if we can do actual wallet balance movement
    const hasWalletSource = !!resolvedSourceWalletId
    const hasWalletDest = !!resolvedDestWalletId
    const canMoveBalance = hasWalletSource || hasWalletDest

    // ── Build common transaction data ─────────────────────────
    const txnData: Record<string, unknown> = {
      reference,
      type,
      subType: subType ?? null,
      amount,
      fee,
      currency: txnCurrency,
      description: description ?? null,
      initiatorId: user.id,
      recipientId: recipientId ?? null,
      recipientName: recipientName ?? accountName ?? null,
      sourceWalletId: resolvedSourceWalletId,
      destinationWalletId: resolvedDestWalletId,
      sourceBankId: resolvedSourceBankId,
      destinationBankId: resolvedDestBankId,
      bankName: resolvedBankName ?? null,
      accountNumber: resolvedAccountNumber ?? null,
      paymentMethod: paymentMethod ?? null,
      category: category ?? null,
      senderAddress: senderAddress ?? null,
      receiverAddress: receiverAddress ?? null,
      ipAddress: request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? null,
      riskScore: 0.1,
      otpVerified: false,
      twoFactorVerified: false,
    }

    // Store extra info in metadata for international / manual-bank transfers
    const metadataObj: Record<string, unknown> = {}
    if (swiftCode) metadataObj.swiftCode = swiftCode
    if (recipientEmail) metadataObj.recipientEmail = recipientEmail
    if (recipientPhone) metadataObj.recipientPhone = recipientPhone
    if (body.sourceCurrency) metadataObj.sourceCurrency = body.sourceCurrency
    if (body.destCurrency) metadataObj.destCurrency = body.destCurrency
    if (Object.keys(metadataObj).length > 0) {
      txnData.metadata = JSON.stringify(metadataObj)
    }

    // ── Balance-moving types with wallet IDs ──────────────────
    if (balanceMovingTypes.includes(type) && canMoveBalance) {
      // Validate source wallet only when a wallet is used as source
      if (requiresSource && resolvedSourceWalletId) {
        const sourceWallet = await db.wallet.findUnique({ where: { id: resolvedSourceWalletId } })
        if (!sourceWallet) {
          return NextResponse.json({ error: 'Source wallet not found' }, { status: 404 })
        }
        if (sourceWallet.status !== 'active') {
          return NextResponse.json({ error: 'Source wallet is not active' }, { status: 400 })
        }
        if (!isAdmin && sourceWallet.userId !== user.id) {
          return NextResponse.json({ error: 'You do not own the source wallet' }, { status: 403 })
        }
        if (sourceWallet.currency !== txnCurrency) {
          return NextResponse.json({ error: 'Currency mismatch on source wallet' }, { status: 400 })
        }
        const totalDeduction = totalDebit + fee
        if (sourceWallet.availableBalance < totalDeduction) {
          return NextResponse.json({ error: 'Insufficient balance in source wallet' }, { status: 400 })
        }
      }

      // Validate destination wallet only when a wallet is used as destination
      if (requiresDest && resolvedDestWalletId) {
        const destWallet = await db.wallet.findUnique({ where: { id: resolvedDestWalletId } })
        if (!destWallet) {
          return NextResponse.json({ error: 'Destination wallet not found' }, { status: 404 })
        }
        if (destWallet.status !== 'active') {
          return NextResponse.json({ error: 'Destination wallet is not active' }, { status: 400 })
        }
        if (destWallet.currency !== txnCurrency) {
          return NextResponse.json({ error: 'Currency mismatch on destination wallet' }, { status: 400 })
        }
      }

      // Atomic balance movement + transaction creation
      const transaction = await db.$transaction(async (tx) => {
        const ops: unknown[] = []

        // Deduct from source wallet (only if wallet source)
        if (requiresSource && resolvedSourceWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: resolvedSourceWalletId },
              data: {
                balance: { decrement: totalDebit + fee },
                availableBalance: { decrement: totalDebit + fee },
              },
            })
          )
        }

        // Add to destination wallet (only if wallet destination)
        if (requiresDest && resolvedDestWalletId) {
          ops.push(
            tx.wallet.update({
              where: { id: resolvedDestWalletId },
              data: {
                balance: { increment: totalDebit },
                availableBalance: { increment: totalDebit },
              },
            })
          )
        }

        // Create the transaction record
        txnData.status = 'completed'
        txnData.completedAt = new Date()
        ops.push(
          tx.transaction.create({
            data: txnData as Parameters<typeof tx.transaction.create>[0]['data'],
            include: {
              initiator: { select: { id: true, name: true, email: true } },
              recipient: { select: { id: true, name: true, email: true } },
            },
          })
        )

        const results = await Promise.all(ops)
        return results[results.length - 1]
      })

      await createAuditLog({
        userId: user.id,
        action: 'create_transaction',
        resource: 'transaction',
        resourceId: (transaction as { id: string }).id,
        details: `Created ${type} transaction ${reference} for ${amount} ${txnCurrency}`,
        request,
      })

      return NextResponse.json(transaction, { status: 201 })
    }

    // ── All other cases: just create the record (no balance movement) ──
    // This covers: non-balance-moving types, bank_to_bank, international, bank_to_wallet (bank source)
    txnData.status = 'pending'

    const transaction = await db.transaction.create({
      data: txnData as Parameters<typeof db.transaction.create>[0]['data'],
      include: {
        initiator: { select: { id: true, name: true, email: true } },
        recipient: { select: { id: true, name: true, email: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create_transaction',
      resource: 'transaction',
      resourceId: transaction.id,
      details: `Created ${type} transaction ${reference} for ${amount} ${txnCurrency} (pending)`,
      request,
    })

    return NextResponse.json(transaction, { status: 201 })
  } catch (error) {
    console.error('Transaction create error:', error)
    return NextResponse.json({ error: 'Failed to create transaction' }, { status: 500 })
  }
}

// ── DELETE /api/transactions ─────────────────────────────────────
// Admin only (level>=60). Supports single ?id=xxx or bulk { ids: [...] }
export async function DELETE(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (id) {
      const existing = await db.transaction.findUnique({ where: { id } })
      if (!existing) {
        return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
      }
      await db.transaction.delete({ where: { id } })
      await createAuditLog({
        userId: user.id,
        action: 'delete_transaction',
        resource: 'transaction',
        resourceId: id,
        details: `Deleted transaction ${existing.reference}`,
        request,
      })
      return NextResponse.json({ success: true })
    }

    // Bulk delete by IDs from body
    const body = await request.json().catch(() => ({}))
    const { ids } = body

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'Transaction IDs are required' }, { status: 400 })
    }

    if (ids.length > 100) {
      return NextResponse.json({ error: 'Cannot delete more than 100 transactions at once' }, { status: 400 })
    }

    const result = await db.transaction.deleteMany({
      where: { id: { in: ids } },
    })

    await createAuditLog({
      userId: user.id,
      action: 'bulk_delete_transactions',
      resource: 'transaction',
      details: `Bulk deleted ${result.count} transactions: ${ids.join(', ')}`,
      request,
    })

    return NextResponse.json({ deleted: result.count })
  } catch (error) {
    console.error('Transaction delete error:', error)
    return NextResponse.json({ error: 'Failed to delete transactions' }, { status: 500 })
  }
}
