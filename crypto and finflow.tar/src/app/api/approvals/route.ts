import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, parsePagination, createAuditLog, getRoleLevel } from '@/lib/auth-helpers'
import { isValidApprovalType, isValidApprovalStatus, isNonEmptyString } from '@/lib/shared/validators'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)

    const status = searchParams.get('status')
    const type = searchParams.get('type')

    const isAdmin = getRoleLevel(user.role) >= 45
    const where: Record<string, unknown> = {}

    if (!isAdmin) {
      // Non-admin users only see their own requests
      where.requesterId = user.id
    }

    if (status && isValidApprovalStatus(status)) {
      where.status = status
    }
    if (type && isValidApprovalType(type)) {
      where.type = type
    }

    const [requests, total] = await Promise.all([
      db.approvalRequest.findMany({
        where,
        include: {
          requester: { select: { id: true, name: true, email: true, role: true } },
          approver: { select: { id: true, name: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.approvalRequest.count({ where }),
    ])

    await createAuditLog({
      userId: user.id,
      action: 'view',
      resource: 'approval_request',
      details: isAdmin ? 'Viewed all approval requests' : 'Viewed own approval requests',
      request,
    })

    return NextResponse.json({
      requests,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Approval requests list error:', error)
    return NextResponse.json({ error: 'Failed to load approval requests' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { type, title, description, metadata, approverId } = body

    if (!isNonEmptyString(type) || !isValidApprovalType(type)) {
      return NextResponse.json({ error: 'Valid approval type is required' }, { status: 400 })
    }
    if (!isNonEmptyString(title)) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    // If no approver specified, auto-assign to an available admin (level >= 45)
    let assignedApproverId = approverId || null
    if (!assignedApproverId) {
      const admin = await db.user.findFirst({
        where: { role: { in: ['super_admin', 'administrator', 'compliance_auditor'] }, status: 'active' },
        orderBy: { lastLoginAt: 'desc' },
      })
      if (admin) {
        assignedApproverId = admin.id
      }
    }

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)

    const approvalRequest = await db.approvalRequest.create({
      data: {
        type,
        title,
        description: description || null,
        metadata: typeof metadata === 'string' ? metadata : metadata ? JSON.stringify(metadata) : null,
        requesterId: user.id,
        approverId: assignedApproverId,
        status: 'pending',
        expiresAt,
      },
      include: {
        requester: { select: { id: true, name: true, email: true, role: true } },
        approver: { select: { id: true, name: true, email: true, role: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'approval_request',
      resourceId: approvalRequest.id,
      details: `Created approval request: ${title} (${type})`,
      request,
    })

    return NextResponse.json({ request: approvalRequest }, { status: 201 })
  } catch (error) {
    console.error('Approval request create error:', error)
    return NextResponse.json({ error: 'Failed to create approval request' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, action, comment } = body

    if (!id || !isNonEmptyString(id)) {
      return NextResponse.json({ error: 'Request ID is required' }, { status: 400 })
    }
    if (action !== 'approved' && action !== 'rejected') {
      return NextResponse.json({ error: 'Action must be "approved" or "rejected"' }, { status: 400 })
    }

    const existingRequest = await db.approvalRequest.findUnique({
      where: { id },
    })

    if (!existingRequest) {
      return NextResponse.json({ error: 'Approval request not found' }, { status: 404 })
    }

    if (existingRequest.status !== 'pending') {
      return NextResponse.json({ error: `Cannot ${action} a request that is already ${existingRequest.status}` }, { status: 400 })
    }

    // Only the assigned approver can approve/reject
    if (existingRequest.approverId !== user.id) {
      return NextResponse.json({ error: 'Only the assigned approver can perform this action' }, { status: 403 })
    }

    // Create the approval action and update the request in a transaction
    const [updatedRequest] = await db.$transaction([
      db.approvalAction.create({
        data: {
          requestId: id,
          userId: user.id,
          action,
          comment: comment || null,
        },
      }),
      db.approvalRequest.update({
        where: { id },
        data: { status: action },
        include: {
          requester: { select: { id: true, name: true, email: true, role: true } },
          approver: { select: { id: true, name: true, email: true, role: true } },
        },
      }),
    ])

    await createAuditLog({
      userId: user.id,
      action,
      resource: 'approval_request',
      resourceId: id,
      details: `${action === 'approved' ? 'Approved' : 'Rejected'} approval request: ${existingRequest.title}${comment ? ` - ${comment}` : ''}`,
      request,
    })

    return NextResponse.json({ request: updatedRequest })
  } catch (error) {
    console.error('Approval request update error:', error)
    return NextResponse.json({ error: 'Failed to update approval request' }, { status: 500 })
  }
}
