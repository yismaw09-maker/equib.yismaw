import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  const auth = requireAuth(request)
  if (isErrorResponse(auth)) return auth

  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') ?? 'daily'
    const startDateStr = searchParams.get('startDate')
    const endDateStr = searchParams.get('endDate')

    const endDate = endDateStr ? new Date(endDateStr) : new Date()
    const startDate = startDateStr
      ? new Date(startDateStr)
      : getDefaultStartDate(type, endDate)

    const where = {
      createdAt: { gte: startDate, lte: endDate },
    }

    switch (type) {
      case 'daily':
        return dailyReport(where, startDate, endDate)
      case 'weekly':
        return weeklyReport(where, startDate, endDate)
      case 'monthly':
        return monthlyReport(where, startDate, endDate)
      case 'quarterly':
        return quarterlyReport(where, startDate, endDate)
      case 'annual':
        return annualReport(where, startDate, endDate)
      case 'transaction':
        return transactionReport(where)
      case 'deposit':
        return typeReport(where, 'deposit')
      case 'withdrawal':
        return typeReport(where, 'withdrawal')
      case 'wallet':
        // Wallet report requires admin level
        const walletAuth = requireMinLevel(request, 45)
        if (isErrorResponse(walletAuth)) return walletAuth
        return walletReport()
      case 'revenue':
        return revenueReport(where)
      case 'commission':
        return commissionReport(where)
      case 'tax':
        return taxReport(where)
      default:
        return NextResponse.json({ error: 'Unknown report type' }, { status: 400 })
    }
  } catch (error) {
    console.error('Report error:', error)
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 })
  }
}

function getDefaultStartDate(type: string, endDate: Date): Date {
  const d = new Date(endDate)
  switch (type) {
    case 'daily': d.setDate(d.getDate() - 1); break
    case 'weekly': d.setDate(d.getDate() - 7); break
    case 'monthly': d.setMonth(d.getMonth() - 1); break
    case 'quarterly': d.setMonth(d.getMonth() - 3); break
    case 'annual': d.setFullYear(d.getFullYear() - 1); break
    default: d.setDate(d.getDate() - 7)
  }
  return d
}

async function dailyReport(where: Record<string, unknown>, startDate: Date, endDate: Date) {
  const transactions = await db.transaction.findMany({
    where,
    select: { amount: true, fee: true, type: true, status: true, currency: true, createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  const grouped = new Map<string, { count: number; volume: number; fees: number; deposits: number; withdrawals: number; transfers: number; payments: number }>()
  for (const tx of transactions) {
    const day = tx.createdAt.toISOString().split('T')[0]
    const current = grouped.get(day) ?? { count: 0, volume: 0, fees: 0, deposits: 0, withdrawals: 0, transfers: 0, payments: 0 }
    current.count++
    current.volume += tx.amount
    current.fees += tx.fee
    if (tx.type === 'deposit') current.deposits += tx.amount
    if (tx.type === 'withdrawal') current.withdrawals += tx.amount
    if (tx.type === 'transfer') current.transfers += tx.amount
    if (tx.type === 'payment') current.payments += tx.amount
    grouped.set(day, current)
  }

  const data = Array.from(grouped.entries()).map(([date, metrics]) => ({ date, ...metrics }))

  const summary = {
    totalTransactions: transactions.length,
    totalVolume: transactions.reduce((s, t) => s + t.amount, 0),
    totalFees: transactions.reduce((s, t) => s + t.fee, 0),
    completed: transactions.filter((t) => t.status === 'completed').length,
    failed: transactions.filter((t) => t.status === 'failed').length,
    pending: transactions.filter((t) => t.status === 'pending' || t.status === 'processing').length,
  }

  return NextResponse.json({ type: 'daily', period: { start: startDate, end: endDate }, data, summary })
}

async function weeklyReport(where: Record<string, unknown>, startDate: Date, endDate: Date) {
  const transactions = await db.transaction.findMany({
    where,
    select: { amount: true, fee: true, type: true, status: true, createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  const grouped = new Map<string, { weekStart: string; count: number; volume: number; fees: number }>()
  for (const tx of transactions) {
    const d = new Date(tx.createdAt)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1)
    const monday = new Date(d.setDate(diff))
    const weekKey = monday.toISOString().split('T')[0]
    const current = grouped.get(weekKey) ?? { weekStart: weekKey, count: 0, volume: 0, fees: 0 }
    current.count++
    current.volume += tx.amount
    current.fees += tx.fee
    grouped.set(weekKey, current)
  }

  const data = Array.from(grouped.values())
  const summary = {
    totalTransactions: transactions.length,
    totalVolume: transactions.reduce((s, t) => s + t.amount, 0),
    totalFees: transactions.reduce((s, t) => s + t.fee, 0),
    avgDailyVolume: transactions.length > 0
      ? transactions.reduce((s, t) => s + t.amount, 0) / Math.max(1, Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)))
      : 0,
  }

  return NextResponse.json({ type: 'weekly', period: { start: startDate, end: endDate }, data, summary })
}

async function monthlyReport(where: Record<string, unknown>, startDate: Date, endDate: Date) {
  const transactions = await db.transaction.findMany({
    where,
    select: { amount: true, fee: true, type: true, status: true, currency: true, createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  const grouped = new Map<string, { count: number; volume: number; fees: number; byType: Record<string, number> }>()
  for (const tx of transactions) {
    const monthKey = `${tx.createdAt.getFullYear()}-${String(tx.createdAt.getMonth() + 1).padStart(2, '0')}`
    const current = grouped.get(monthKey) ?? { count: 0, volume: 0, fees: 0, byType: {} }
    current.count++
    current.volume += tx.amount
    current.fees += tx.fee
    current.byType[tx.type] = (current.byType[tx.type] ?? 0) + tx.amount
    grouped.set(monthKey, current)
  }

  const data = Array.from(grouped.entries()).map(([month, metrics]) => ({ month, ...metrics }))

  return NextResponse.json({ type: 'monthly', period: { start: startDate, end: endDate }, data })
}

async function quarterlyReport(where: Record<string, unknown>, startDate: Date, endDate: Date) {
  const transactions = await db.transaction.findMany({
    where,
    select: { amount: true, fee: true, type: true, status: true, createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  const grouped = new Map<string, { quarter: string; count: number; volume: number; fees: number; completed: number; failed: number }>()
  for (const tx of transactions) {
    const m = tx.createdAt.getMonth()
    const q = Math.floor(m / 3) + 1
    const qKey = `${tx.createdAt.getFullYear()}-Q${q}`
    const current = grouped.get(qKey) ?? { quarter: qKey, count: 0, volume: 0, fees: 0, completed: 0, failed: 0 }
    current.count++
    current.volume += tx.amount
    current.fees += tx.fee
    if (tx.status === 'completed') current.completed++
    if (tx.status === 'failed') current.failed++
    grouped.set(qKey, current)
  }

  const data = Array.from(grouped.values())

  return NextResponse.json({ type: 'quarterly', period: { start: startDate, end: endDate }, data })
}

async function annualReport(where: Record<string, unknown>, startDate: Date, endDate: Date) {
  const transactions = await db.transaction.findMany({
    where,
    select: { amount: true, fee: true, type: true, status: true, currency: true, createdAt: true },
    orderBy: { createdAt: 'asc' },
  })

  const grouped = new Map<number, { year: number; count: number; volume: number; fees: number; byCurrency: Record<string, number> }>()
  for (const tx of transactions) {
    const year = tx.createdAt.getFullYear()
    const current = grouped.get(year) ?? { year, count: 0, volume: 0, fees: 0, byCurrency: {} }
    current.count++
    current.volume += tx.amount
    current.fees += tx.fee
    current.byCurrency[tx.currency] = (current.byCurrency[tx.currency] ?? 0) + tx.amount
    grouped.set(year, current)
  }

  const data = Array.from(grouped.values())

  return NextResponse.json({ type: 'annual', period: { start: startDate, end: endDate }, data })
}

async function transactionReport(where: Record<string, unknown>) {
  const transactions = await db.transaction.findMany({
    where,
    include: {
      initiator: { select: { name: true, email: true } },
      recipient: { select: { name: true, email: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  const summary = {
    total: transactions.length,
    totalVolume: transactions.reduce((s, t) => s + t.amount, 0),
    totalFees: transactions.reduce((s, t) => s + t.fee, 0),
    byStatus: {} as Record<string, number>,
    byType: {} as Record<string, number>,
    avgAmount: transactions.length > 0 ? transactions.reduce((s, t) => s + t.amount, 0) / transactions.length : 0,
  }

  for (const tx of transactions) {
    summary.byStatus[tx.status] = (summary.byStatus[tx.status] ?? 0) + 1
    summary.byType[tx.type] = (summary.byType[tx.type] ?? 0) + 1
  }

  return NextResponse.json({ type: 'transaction', data: transactions, summary })
}

async function typeReport(where: Record<string, unknown>, txType: string) {
  const typeWhere = { ...where, type: txType } as Record<string, unknown>
  const transactions = await db.transaction.findMany({
    where: typeWhere,
    include: {
      initiator: { select: { name: true } },
      recipient: { select: { name: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  const summary = {
    total: transactions.length,
    totalAmount: transactions.reduce((s, t) => s + t.amount, 0),
    totalFees: transactions.reduce((s, t) => s + t.fee, 0),
    completed: transactions.filter((t) => t.status === 'completed').length,
    pending: transactions.filter((t) => t.status === 'pending' || t.status === 'processing').length,
    failed: transactions.filter((t) => t.status === 'failed').length,
    avgAmount: transactions.length > 0 ? transactions.reduce((s, t) => s + t.amount, 0) / transactions.length : 0,
  }

  return NextResponse.json({ type: txType, data: transactions, summary })
}

async function walletReport() {
  const wallets = await db.wallet.findMany({
    include: {
      user: { select: { name: true, email: true, role: true } },
    },
    orderBy: { balance: 'desc' },
  })

  const summary = {
    totalWallets: wallets.length,
    totalBalance: wallets.reduce((s, w) => s + w.balance, 0),
    totalFrozen: wallets.reduce((s, w) => s + w.frozenBalance, 0),
    totalAvailable: wallets.reduce((s, w) => s + w.availableBalance, 0),
    byCurrency: {} as Record<string, { count: number; balance: number }>,
    byType: {} as Record<string, { count: number; balance: number }>,
  }

  for (const w of wallets) {
    if (!summary.byCurrency[w.currency]) summary.byCurrency[w.currency] = { count: 0, balance: 0 }
    summary.byCurrency[w.currency].count++
    summary.byCurrency[w.currency].balance += w.balance

    if (!summary.byType[w.type]) summary.byType[w.type] = { count: 0, balance: 0 }
    summary.byType[w.type].count++
    summary.byType[w.type].balance += w.balance
  }

  return NextResponse.json({ type: 'wallet', data: wallets, summary })
}

async function revenueReport(where: Record<string, unknown>) {
  const transactions = await db.transaction.findMany({
    where,
    select: { fee: true, type: true, status: true, currency: true, createdAt: true },
  })

  const completed = transactions.filter((t) => t.status === 'completed')

  const byType: Record<string, number> = {}
  for (const tx of completed) {
    byType[tx.type] = (byType[tx.type] ?? 0) + tx.fee
  }

  const monthly = new Map<string, number>()
  for (const tx of completed) {
    const monthKey = `${tx.createdAt.getFullYear()}-${String(tx.createdAt.getMonth() + 1).padStart(2, '0')}`
    monthly.set(monthKey, (monthly.get(monthKey) ?? 0) + tx.fee)
  }

  const summary = {
    totalFees: completed.reduce((s, t) => s + t.fee, 0),
    totalTransactions: completed.length,
    avgFeePerTx: completed.length > 0 ? completed.reduce((s, t) => s + t.fee, 0) / completed.length : 0,
    byType,
    monthly: Object.fromEntries(monthly),
  }

  return NextResponse.json({ type: 'revenue', summary })
}

async function commissionReport(where: Record<string, unknown>) {
  const commissions = await db.commission.findMany({
    where: {
      createdAt: where.createdAt as { gte: Date; lte: Date } | undefined,
    },
    include: {
      user: { select: { name: true, email: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  const summary = {
    total: commissions.length,
    totalAmount: commissions.reduce((s, c) => s + c.amount, 0),
    paid: commissions.filter((c) => c.status === 'paid').reduce((s, c) => s + c.amount, 0),
    pending: commissions.filter((c) => c.status === 'pending').reduce((s, c) => s + c.amount, 0),
    byType: {} as Record<string, { count: number; amount: number }>,
  }

  for (const c of commissions) {
    if (!summary.byType[c.type]) summary.byType[c.type] = { count: 0, amount: 0 }
    summary.byType[c.type].count++
    summary.byType[c.type].amount += c.amount
  }

  return NextResponse.json({ type: 'commission', data: commissions, summary })
}

async function taxReport(where: Record<string, unknown>) {
  const transactions = await db.transaction.findMany({
    where,
    select: { fee: true, amount: true, type: true, status: true, currency: true, createdAt: true },
  })

  const completed = transactions.filter((t) => t.status === 'completed')
  const taxRate = 0.15 // 15% VAT on fees
  const totalFees = completed.reduce((s, t) => s + t.fee, 0)
  const estimatedTax = totalFees * taxRate

  const monthlyTax = new Map<string, number>()
  for (const tx of completed) {
    const monthKey = `${tx.createdAt.getFullYear()}-${String(tx.createdAt.getMonth() + 1).padStart(2, '0')}`
    monthlyTax.set(monthKey, (monthlyTax.get(monthKey) ?? 0) + tx.fee * taxRate)
  }

  const summary = {
    totalFees,
    taxRate,
    estimatedTax,
    taxableTransactions: completed.length,
    byMonth: Object.fromEntries(monthlyTax),
  }

  return NextResponse.json({ type: 'tax', summary })
}
