import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isErrorResponse, getRoleLevel } from '@/lib/auth-helpers'

const ETHIOPIAN_BANKS = [
  { bankName: 'Commercial Bank of Ethiopia', shortName: 'CBE', bankCode: 'CBE001', swiftCode: 'CBETETAA', bankType: 'government', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1942, headOffice: 'Addis Ababa' },
  { bankName: 'Awash Bank', shortName: 'Awash', bankCode: 'AWA001', swiftCode: 'AWSHETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1994, headOffice: 'Addis Ababa' },
  { bankName: 'Bank of Abyssinia', shortName: 'BOA', bankCode: 'BOA001', swiftCode: 'ABYSETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1997, headOffice: 'Addis Ababa' },
  { bankName: 'Dashen Bank', shortName: 'Dashen', bankCode: 'DAS001', swiftCode: 'DSHNETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1995, headOffice: 'Addis Ababa' },
  { bankName: 'Wegagen Bank', shortName: 'Wegagen', bankCode: 'WEG001', swiftCode: 'WGGNETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 1997, headOffice: 'Addis Ababa' },
  { bankName: 'United Bank', shortName: 'United', bankCode: 'UNB001', swiftCode: 'UBNKETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1985, headOffice: 'Addis Ababa' },
  { bankName: 'Nib International Bank', shortName: 'NIB', bankCode: 'NIB001', swiftCode: 'NIBCETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 1999, headOffice: 'Addis Ababa' },
  { bankName: 'Oromia Bank', shortName: 'Oromia', bankCode: 'ORB001', swiftCode: 'ORIBETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2008, headOffice: 'Addis Ababa' },
  { bankName: 'Bunna Bank', shortName: 'Bunna', bankCode: 'BUN001', swiftCode: 'BUNAETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2009, headOffice: 'Addis Ababa' },
  { bankName: 'Hibret Bank', shortName: 'Hibret', bankCode: 'HIB001', swiftCode: 'HBREETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2021, headOffice: 'Addis Ababa' },
  { bankName: 'Siinqee Bank', shortName: 'Siinqee', bankCode: 'SIQ001', swiftCode: 'SIQNETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2022, headOffice: 'Addis Ababa' },
  { bankName: 'Abay Bank', shortName: 'Abay', bankCode: 'ABY001', swiftCode: 'ABAYETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2010, headOffice: 'Addis Ababa' },
  { bankName: 'Addis Bank', shortName: 'Addis', bankCode: 'ADS001', swiftCode: 'ADSNETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2022, headOffice: 'Addis Ababa' },
  { bankName: 'Ahadu Bank', shortName: 'Ahadu', bankCode: 'AHD001', swiftCode: 'AHDUETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2022, headOffice: 'Addis Ababa' },
  { bankName: 'Amhara Bank', shortName: 'Amhara', bankCode: 'AMB001', swiftCode: 'AMHBETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2022, headOffice: 'Bahir Dar' },
  { bankName: 'Berhan Bank', shortName: 'Berhan', bankCode: 'BRH001', swiftCode: 'BRHNETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2009, headOffice: 'Addis Ababa' },
  { bankName: 'Cooperative Bank of Oromia', shortName: 'CBO', bankCode: 'CBO001', swiftCode: 'CBOOETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2005, headOffice: 'Addis Ababa' },
  { bankName: 'Enat Bank', shortName: 'Enat', bankCode: 'ENA001', swiftCode: 'ENATETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2011, headOffice: 'Addis Ababa' },
  { bankName: 'Gadaa Bank', shortName: 'Gadaa', bankCode: 'GAD001', swiftCode: 'GADAETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Goh Betoch Bank', shortName: 'Goh Betoch', bankCode: 'GOH001', swiftCode: 'GOHBETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2021, headOffice: 'Addis Ababa' },
  { bankName: 'Global Bank Ethiopia', shortName: 'Global', bankCode: 'GBE001', swiftCode: 'GBLKETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Hijra Bank', shortName: 'Hijra', bankCode: 'HIJ001', swiftCode: 'HIJRETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Lion International Bank', shortName: 'Lion', bankCode: 'LIO001', swiftCode: 'LIONETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2007, headOffice: 'Addis Ababa' },
  { bankName: 'Omo Bank', shortName: 'Omo', bankCode: 'OMO001', swiftCode: 'OMOBETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2014, headOffice: 'Addis Ababa' },
  { bankName: 'Rammis Bank', shortName: 'Rammis', bankCode: 'RAM001', swiftCode: 'RAMIETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Shabelle Bank', shortName: 'Shabelle', bankCode: 'SHA001', swiftCode: 'SHLBETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Sidama Bank', shortName: 'Sidama', bankCode: 'SID001', swiftCode: 'SIDAETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Hawassa' },
  { bankName: 'Siket Bank', shortName: 'Siket', bankCode: 'SIK001', swiftCode: 'SIKETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2024, headOffice: 'Addis Ababa' },
  { bankName: 'Tsehay Bank', shortName: 'Tsehay', bankCode: 'TSE001', swiftCode: 'TSHYETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'Tsedey Bank', shortName: 'Tsedey', bankCode: 'TSD001', swiftCode: 'TSDEETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2023, headOffice: 'Addis Ababa' },
  { bankName: 'ZamZam Bank', shortName: 'ZamZam', bankCode: 'ZAM001', swiftCode: 'ZAMZETAA', bankType: 'private', supportsIfb: true, supportsFx: false, supportsTransfer: true, foundedYear: 2022, headOffice: 'Addis Ababa' },
  { bankName: 'Zemen Bank', shortName: 'Zemen', bankCode: 'ZEM001', swiftCode: 'ZMNBETAA', bankType: 'private', supportsIfb: true, supportsFx: true, supportsTransfer: true, foundedYear: 2008, headOffice: 'Addis Ababa' },
]

export async function POST(request: Request) {
  try {
    const auth = requireAuth(request as unknown as Parameters<typeof requireAuth>[0])
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    if (getRoleLevel(user.role) < 45) {
      return NextResponse.json({ error: 'Admin only' }, { status: 403 })
    }

    const count = await db.masterBank.count()
    if (count > 0) {
      return NextResponse.json({ message: `Already seeded with ${count} banks` })
    }

    for (const bank of ETHIOPIAN_BANKS) {
      await db.masterBank.create({ data: bank })
    }

    // Link existing bank accounts to master banks
    const existingAccounts = await db.bankAccount.findMany({ where: { masterBankId: null } })
    for (const acc of existingAccounts) {
      const master = await db.masterBank.findFirst({
        where: {
          OR: [
            { bankName: { contains: acc.bankName.replace(' (CBE)', '').trim() } },
            { shortName: acc.bankName.split(' ')[0] },
          ],
        },
      })
      if (master) {
        await db.bankAccount.update({ where: { id: acc.id }, data: { masterBankId: master.id } })
      }
    }

    const total = await db.masterBank.count()
    return NextResponse.json({ message: `Seeded ${total} Ethiopian banks successfully` })
  } catch (error) {
    console.error('Seed master banks error:', error)
    return NextResponse.json({ error: 'Failed to seed banks' }, { status: 500 })
  }
}
