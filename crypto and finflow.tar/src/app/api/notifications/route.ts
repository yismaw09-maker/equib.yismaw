import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, requireSuperAdmin, isErrorResponse, getRoleLevel, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const isAdmin = getRoleLevel(user.role) >= 45

    const where: Record<string, unknown> = {}
    if (isAdmin) {
      // Admin can optionally filter by userId
      const userIdParam = searchParams.get('userId')
      if (userIdParam) where.userId = userIdParam
    } else {
      // Non-admin users can only see their own notifications
      where.userId = user.id
    }

    const type = searchParams.get('type')
    const isRead = searchParams.get('isRead')
    if (type) where.type = type
    if (isRead !== null && isRead !== undefined && isRead !== '') {
      where.isRead = isRead === 'true'
    }

    const notifications = await db.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    const unreadCount = await db.notification.count({
      where: {
        ...where,
        isRead: false,
      },
    })

    return NextResponse.json({ notifications, unreadCount })
  } catch (error) {
    console.error('Notifications error:', error)
    return NextResponse.json({ error: 'Failed to load notifications' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45
    const body = await request.json()
    const { ids, userId, markAll } = body

    if (markAll && userId) {
      // Non-admin can only mark their own; admin can mark anyone's
      if (!isAdmin && userId !== user.id) {
        return NextResponse.json({ error: 'You can only mark your own notifications as read' }, { status: 403 })
      }

      const result = await db.notification.updateMany({
        where: { userId, isRead: false },
        data: { isRead: true },
      })
      return NextResponse.json({ updated: result.count })
    }

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'Notification IDs are required' }, { status: 400 })
    }

    // Non-admin: verify all notifications belong to the user
    if (!isAdmin) {
      const ownNotifications = await db.notification.findMany({
        where: { id: { in: ids }, userId: user.id },
        select: { id: true },
      })
      const ownIds = ownNotifications.map((n: { id: string }) => n.id)
      if (ownIds.length === 0) {
        return NextResponse.json({ error: 'No matching notifications found for your account' }, { status: 404 })
      }

      const result = await db.notification.updateMany({
        where: { id: { in: ownIds } },
        data: { isRead: true },
      })
      return NextResponse.json({ updated: result.count })
    }

    // Admin can mark any notifications
    const result = await db.notification.updateMany({
      where: { id: { in: ids } },
      data: { isRead: true },
    })

    return NextResponse.json({ updated: result.count })
  } catch (error) {
    console.error('Notification update error:', error)
    return NextResponse.json({ error: 'Failed to update notifications' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const deleteAll = searchParams.get('deleteAll')

    // deleteAll=true requires super_admin (level>=100)
    if (deleteAll === 'true') {
      const auth = requireSuperAdmin(request)
      if (isErrorResponse(auth)) return auth
      const { user } = auth

      const result = await db.notification.deleteMany({})
      await createAuditLog({
        userId: user.id,
        action: 'delete_all',
        resource: 'notification',
        details: 'Deleted all notifications',
        request,
      })
      return NextResponse.json({ deleted: result.count })
    }

    // Single/bulk delete requires admin (level>=60)
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const id = searchParams.get('id')

    if (id) {
      await db.notification.delete({ where: { id } })
      await createAuditLog({
        userId: user.id,
        action: 'delete',
        resource: 'notification',
        resourceId: id,
        details: 'Deleted single notification',
        request,
      })
      return NextResponse.json({ success: true })
    }

    // Bulk delete by IDs from body
    const body = await request.json().catch(() => ({}))
    const { ids } = body

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'Notification IDs are required' }, { status: 400 })
    }

    const result = await db.notification.deleteMany({
      where: { id: { in: ids } },
    })
    await createAuditLog({
      userId: user.id,
      action: 'delete_bulk',
      resource: 'notification',
      details: `Deleted ${result.count} notifications`,
      request,
    })
    return NextResponse.json({ deleted: result.count })
  } catch (error) {
    console.error('Notification delete error:', error)
    return NextResponse.json({ error: 'Failed to delete notifications' }, { status: 500 })
  }
}
