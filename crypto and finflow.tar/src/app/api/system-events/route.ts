import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, parsePagination, createAuditLog } from '@/lib/auth-helpers'
import { isNonEmptyString } from '@/lib/shared/validators'

const VALID_EVENT_TYPES = [
  'system_startup', 'config_change', 'backup', 'maintenance', 'error', 'deployment',
]

const VALID_SEVERITIES = ['info', 'warning', 'error', 'critical']

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 55)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)

    const eventType = searchParams.get('eventType')
    const severity = searchParams.get('severity')
    const source = searchParams.get('source')

    const where: Record<string, unknown> = {}
    if (eventType && VALID_EVENT_TYPES.includes(eventType)) {
      where.eventType = eventType
    }
    if (severity && VALID_SEVERITIES.includes(severity)) {
      where.severity = severity
    }
    if (source) {
      where.source = source
    }

    const [events, total] = await Promise.all([
      db.systemEvent.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.systemEvent.count({ where }),
    ])

    await createAuditLog({
      userId: user.id,
      action: 'view',
      resource: 'system_event',
      details: 'Viewed system events',
      request,
    })

    return NextResponse.json({
      events,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('System events list error:', error)
    return NextResponse.json({ error: 'Failed to load system events' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { eventType, severity, title, description, metadata, source } = body

    if (!isNonEmptyString(eventType) || !VALID_EVENT_TYPES.includes(eventType)) {
      return NextResponse.json({ error: 'Valid event type is required' }, { status: 400 })
    }
    if (!isNonEmptyString(severity) || !VALID_SEVERITIES.includes(severity)) {
      return NextResponse.json({ error: 'Valid severity is required' }, { status: 400 })
    }
    if (!isNonEmptyString(title)) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    const event = await db.systemEvent.create({
      data: {
        eventType,
        severity,
        title,
        description: description || null,
        metadata: typeof metadata === 'string' ? metadata : metadata ? JSON.stringify(metadata) : null,
        source: source || null,
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'system_event',
      resourceId: event.id,
      details: `Created system event: ${title} (${eventType})`,
      request,
    })

    return NextResponse.json({ event }, { status: 201 })
  } catch (error) {
    console.error('System event create error:', error)
    return NextResponse.json({ error: 'Failed to create system event' }, { status: 500 })
  }
}
