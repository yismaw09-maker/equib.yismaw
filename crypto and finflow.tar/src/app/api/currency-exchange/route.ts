import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers';

function generateRef(prefix: string) {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `FX-${prefix}-${ts}-${rand}`;
}

// GET /api/currency-exchange?type=transactions | stats
export async function GET(request: NextRequest) {
  const auth = requireAuth(request);
  if (isErrorResponse(auth)) return auth;

  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    if (type === 'transactions') {
      const page = parseInt(searchParams.get('page') || '1');
      const limit = parseInt(searchParams.get('limit') || '20');
      const txType = searchParams.get('txType') || '';
      const status = searchParams.get('status') || '';
      const skip = (page - 1) * limit;

      const where: Record<string, unknown> = {};
      if (txType) where.type = txType;
      if (status) where.status = status;

      const [transactions, total] = await Promise.all([
        db.forexTransaction.findMany({
          where,
          include: {
            initiator: { select: { id: true, name: true, email: true } },
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
        }),
        db.forexTransaction.count({ where }),
      ]);

      // Aggregate stats
      const stats = await db.forexTransaction.aggregate({
        _count: true,
        _sum: { fromAmount: true, toAmount: true, fee: true },
      });

      const byStatus = await db.forexTransaction.groupBy({
        by: ['status'],
        _count: true,
      });

      const byType = await db.forexTransaction.groupBy({
    by: ['type'],
    _count: true,
    _sum: { fromAmount: true },
  });

      return NextResponse.json({
        transactions,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
        stats: {
          total: stats._count,
          totalVolume: stats._sum.fromAmount || 0,
          totalFees: stats._sum.fee || 0,
          byStatus: Object.fromEntries(byStatus.map((s) => [s.status, s._count])),
          byType: Object.fromEntries(byType.map((t) => [t.type, { count: t._count, volume: t._sum.fromAmount || 0 }])),
        },
      });
    }

    if (type === 'stats') {
      const total = await db.forexTransaction.count();
      const completed = await db.forexTransaction.count({ where: { status: 'completed' } });
      const pending = await db.forexTransaction.count({ where: { status: 'pending' } });

      const buyVol = await db.forexTransaction.aggregate({
        where: { type: 'buy', status: 'completed' },
        _sum: { fromAmount: true },
      });
      const sellVol = await db.forexTransaction.aggregate({
        where: { type: 'sell', status: 'completed' },
        _sum: { fromAmount: true },
      });
      const sendVol = await db.forexTransaction.aggregate({
        where: { type: 'send', status: 'completed' },
        _sum: { fromAmount: true },
      });
      const receiveVol = await db.forexTransaction.aggregate({
        where: { type: 'receive', status: 'completed' },
        _sum: { toAmount: true },
      });

      const totalFees = await db.forexTransaction.aggregate({
        _sum: { fee: true },
      });

      return NextResponse.json({
        total,
        completed,
        pending,
        buyVolume: buyVol._sum.fromAmount || 0,
        sellVolume: sellVol._sum.fromAmount || 0,
        sendVolume: sendVol._sum.fromAmount || 0,
        receiveVolume: receiveVol._sum.toAmount || 0,
        totalFees: totalFees._sum.fee || 0,
      });
    }

    // Default: return recent transactions
    const recent = await db.forexTransaction.findMany({
      include: {
        initiator: { select: { id: true, name: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    return NextResponse.json({ transactions: recent });
  } catch (error) {
    console.error('Currency exchange GET error:', error);
    return NextResponse.json({ error: 'Failed to load currency exchange data' }, { status: 500 });
  }
}

// POST /api/currency-exchange - Create a forex transaction (buy/sell/send/receive)
export async function POST(request: NextRequest) {
  const auth = requireAuth(request);
  if (isErrorResponse(auth)) return auth;

  try {
    const body = await request.json();
    const {
      type, // buy, sell, send, receive
      fromCurrency,
      toCurrency,
      fromAmount,
      initiatorId,
      recipientName,
      recipientPhone,
      recipientEmail,
      recipientWallet,
      sourceWalletId,
      destWalletId,
      description,
    } = body;

    // Validation
    if (!type || !['buy', 'sell', 'send', 'receive'].includes(type)) {
      return NextResponse.json({ error: 'Valid type is required (buy, sell, send, receive)' }, { status: 400 });
    }
    if (!fromCurrency || !toCurrency) {
      return NextResponse.json({ error: 'Both fromCurrency and toCurrency are required' }, { status: 400 });
    }
    if (!fromAmount || fromAmount <= 0) {
      return NextResponse.json({ error: 'Valid fromAmount is required' }, { status: 400 });
    }
    if (fromCurrency === toCurrency) {
      return NextResponse.json({ error: 'Source and destination currencies must be different' }, { status: 400 });
    }

    // Get exchange rates
    const fromCurr = await db.currency.findUnique({ where: { code: fromCurrency } });
    const toCurr = await db.currency.findUnique({ where: { code: toCurrency } });
    if (!fromCurr || !toCurr) {
      return NextResponse.json({ error: 'One or both currencies not found' }, { status: 404 });
    }

    // Calculate exchange rate and amounts
    // All rates are relative to ETB, so: fromAmount_in_ETB = fromAmount * fromCurr.exchangeRate
    // toAmount = fromAmount_in_ETB / toCurr.exchangeRate
    const fromAmountInETB = fromAmount * fromCurr.exchangeRate;
    const rate = fromCurr.exchangeRate / toCurr.exchangeRate;
    let toAmount = fromAmountInETB / toCurr.exchangeRate;

    // For buy: user buys foreign currency with ETB (from=ETB, to=foreign) - add small markup
    // For sell: user sells foreign currency for ETB (from=foreign, to=ETB) - small spread
    // For send: sending currency abroad - fee applies
    // For receive: receiving currency - minimal fee

    let fee = 0;
    let feeCurrency = 'ETB';

    switch (type) {
      case 'buy': {
        // Buying foreign currency: pay ETB, receive foreign
        // Apply 0.5% buy markup
        const markup = 1.005;
        toAmount = (fromAmountInETB / toCurr.exchangeRate) / markup;
        fee = fromAmount * 0.002; // 0.2% fee
        feeCurrency = fromCurrency;
        break;
      }
      case 'sell': {
        // Selling foreign currency: pay foreign, receive ETB
        // Apply 0.3% sell discount
        const discount = 0.997;
        toAmount = fromAmountInETB * discount / toCurr.exchangeRate;
        fee = toAmount * 0.001; // 0.1% fee
        feeCurrency = toCurrency;
        break;
      }
      case 'send': {
        // Sending currency: pay fee on source
        fee = fromAmount * 0.005; // 0.5% send fee
        feeCurrency = fromCurrency;
        toAmount = fromAmountInETB / toCurr.exchangeRate;
        break;
      }
      case 'receive': {
        // Receiving currency: minimal fee
        fee = fromAmount * 0.001; // 0.1% receive fee
        feeCurrency = fromCurrency;
        toAmount = fromAmountInETB / toCurr.exchangeRate;
        break;
      }
    }

    const reference = generateRef(type.toUpperCase().substring(0, 2));

    const transaction = await db.forexTransaction.create({
      data: {
        reference,
        type,
        fromCurrency,
        toCurrency,
        fromAmount: Math.round(fromAmount * 100) / 100,
        toAmount: Math.round(toAmount * 100) / 100,
        exchangeRate: Math.round(rate * 10000) / 10000,
        fee: Math.round(fee * 100) / 100,
        feeCurrency,
        status: 'completed',
        initiatorId: auth.user.id,
        recipientName: recipientName || null,
        recipientPhone: recipientPhone || null,
        recipientEmail: recipientEmail || null,
        recipientWallet: recipientWallet || null,
        sourceWalletId: sourceWalletId || null,
        destWalletId: destWalletId || null,
        description: description || null,
        completedAt: new Date(),
      },
      include: {
        initiator: { select: { id: true, name: true, email: true } },
      },
    });

    return NextResponse.json(transaction, { status: 201 });
  } catch (error) {
    console.error('Currency exchange POST error:', error);
    return NextResponse.json({ error: 'Failed to create currency exchange transaction' }, { status: 500 });
  }
}

// PATCH /api/currency-exchange - Update transaction status
export async function PATCH(request: NextRequest) {
  const auth = requireMinLevel(request, 60);
  if (isErrorResponse(auth)) return auth;

  try {
    const body = await request.json();
    const { id, status } = body;

    if (!id) {
      return NextResponse.json({ error: 'Transaction ID is required' }, { status: 400 });
    }

    const existing = await db.forexTransaction.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    const validStatuses = ['pending', 'processing', 'completed', 'failed', 'cancelled'];
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` }, { status: 400 });
    }

    const updateData: Record<string, unknown> = {};
    if (status) {
      updateData.status = status;
      if (status === 'completed') updateData.completedAt = new Date();
    }

    const transaction = await db.forexTransaction.update({
      where: { id },
      data: updateData,
      include: {
        initiator: { select: { id: true, name: true, email: true } },
      },
    });

    return NextResponse.json(transaction);
  } catch (error) {
    console.error('Currency exchange PATCH error:', error);
    return NextResponse.json({ error: 'Failed to update transaction' }, { status: 500 });
  }
}

// DELETE /api/currency-exchange
export async function DELETE(request: NextRequest) {
  const auth = requireMinLevel(request, 60);
  if (isErrorResponse(auth)) return auth;

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Transaction ID is required' }, { status: 400 });
    }

    const existing = await db.forexTransaction.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    await db.forexTransaction.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Currency exchange DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete transaction' }, { status: 500 });
  }
}
