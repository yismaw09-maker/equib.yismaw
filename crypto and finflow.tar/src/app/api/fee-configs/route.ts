import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const transactionType = searchParams.get('transactionType')
    const isActive = searchParams.get('isActive')

    const where: Record<string, unknown> = {}
    if (transactionType) where.transactionType = transactionType
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true'
    }

    const feeConfigs = await db.feeConfig.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(feeConfigs)
  } catch (error) {
    console.error('Fee configs error:', error)
    return NextResponse.json({ error: 'Failed to load fee configs' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { transactionType, paymentMethod, feeType, feeValue, minFee, maxFee, currency } = body

    if (!transactionType || feeType === undefined || feeValue === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields: transactionType, feeType, feeValue' },
        { status: 400 },
      )
    }

    if (!['flat', 'percentage', 'tiered'].includes(feeType)) {
      return NextResponse.json({ error: 'Invalid feeType. Must be: flat, percentage, tiered' }, { status: 400 })
    }

    const feeConfig = await db.feeConfig.create({
      data: {
        transactionType,
        paymentMethod: paymentMethod ?? null,
        feeType,
        feeValue,
        minFee: minFee ?? 0,
        maxFee: maxFee ?? null,
        currency: currency ?? 'ETB',
        isActive: true,
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'fee_config',
      resourceId: feeConfig.id,
      details: `Created fee config for ${transactionType}: ${feeType} ${feeValue}`,
      request,
    })

    return NextResponse.json(feeConfig, { status: 201 })
  } catch (error) {
    console.error('Fee config create error:', error)
    return NextResponse.json({ error: 'Failed to create fee config' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, feeType, feeValue, minFee, maxFee, isActive, paymentMethod } = body

    if (!id) {
      return NextResponse.json({ error: 'Fee config ID is required' }, { status: 400 })
    }

    const existing = await db.feeConfig.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Fee config not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {}
    if (feeType !== undefined) updateData.feeType = feeType
    if (feeValue !== undefined) updateData.feeValue = feeValue
    if (minFee !== undefined) updateData.minFee = minFee
    if (maxFee !== undefined) updateData.maxFee = maxFee
    if (isActive !== undefined) updateData.isActive = isActive
    if (paymentMethod !== undefined) updateData.paymentMethod = paymentMethod

    const feeConfig = await db.feeConfig.update({
      where: { id },
      data: updateData,
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'fee_config',
      resourceId: id,
      details: `Updated fee config ${id}: ${JSON.stringify(updateData)}`,
      request,
    })

    return NextResponse.json(feeConfig)
  } catch (error) {
    console.error('Fee config update error:', error)
    return NextResponse.json({ error: 'Failed to update fee config' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Fee config ID is required' }, { status: 400 })
    }

    const existing = await db.feeConfig.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Fee config not found' }, { status: 404 })
    }

    await db.feeConfig.delete({ where: { id } })

    await createAuditLog({
      userId: user.id,
      action: 'delete',
      resource: 'fee_config',
      resourceId: id,
      details: `Deleted fee config ${id} for ${existing.transactionType}`,
      request,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Fee config delete error:', error)
    return NextResponse.json({ error: 'Failed to delete fee config' }, { status: 500 })
  }
}
