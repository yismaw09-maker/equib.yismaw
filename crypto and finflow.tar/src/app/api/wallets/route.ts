import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  requireAuth,
  requireAdmin,
  isErrorResponse,
  createAuditLog,
} from '@/lib/auth-helpers';
import { getRoleLevel } from '@/lib/role-permissions';

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request);
    if (isErrorResponse(auth)) return auth;

    const { user: session } = auth;
    const { searchParams } = new URL(request.url);
    const isAdmin = getRoleLevel(session.role) >= 45;

    // Non-admin users can only see their own wallets
    if (!isAdmin) {
      const queryUserId = searchParams.get('userId');
      // If userId is provided, it must match the session user
      if (queryUserId && queryUserId !== session.id) {
        return NextResponse.json({ error: 'You can only view your own wallets' }, { status: 403 });
      }

      const where: Record<string, unknown> = { userId: session.id };
      const currency = searchParams.get('currency');
      const status = searchParams.get('status');
      if (currency) where.currency = currency;
      if (status) where.status = status;

      const wallets = await db.wallet.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
      });

      return NextResponse.json(wallets);
    }

    // Admin: can list all wallets with optional filters
    const userId = searchParams.get('userId');
    const currency = searchParams.get('currency');
    const status = searchParams.get('status');

    const where: Record<string, unknown> = {};
    if (userId) where.userId = userId;
    if (currency) where.currency = currency;
    if (status) where.status = status;

    const wallets = await db.wallet.findMany({
      where,
      include: {
        user: { select: { id: true, name: true, email: true, role: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    await createAuditLog({
      userId: session.id,
      action: 'list_wallets',
      resource: 'wallet',
      details: `Listed wallets with filters: userId=${userId ?? 'all'}, currency=${currency ?? 'all'}, status=${status ?? 'all'}`,
      request,
    });

    return NextResponse.json(wallets);
  } catch (error) {
    console.error('Wallets error:', error);
    return NextResponse.json({ error: 'Failed to load wallets' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireAdmin(request);
    if (isErrorResponse(auth)) return auth;

    const { user: session } = auth;

    const body = await request.json();
    const { userId, currency, type, initialBalance } = body;

    if (!userId || !currency) {
      return NextResponse.json({ error: 'Missing required fields: userId, currency' }, { status: 400 });
    }

    const validTypes = ['digital', 'merchant', 'escrow'];
    if (type && !validTypes.includes(type)) {
      return NextResponse.json({ error: 'Invalid wallet type. Must be one of: digital, merchant, escrow' }, { status: 400 });
    }

    // Validate initialBalance is non-negative
    if (initialBalance !== undefined && initialBalance !== null) {
      if (typeof initialBalance !== 'number' || isNaN(initialBalance) || initialBalance < 0) {
        return NextResponse.json({ error: 'initialBalance must be a non-negative number' }, { status: 400 });
      }
    }

    // Verify the target user exists
    const targetUser = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, status: true },
    });
    if (!targetUser) {
      return NextResponse.json({ error: 'Target user not found' }, { status: 404 });
    }

    const balance = typeof initialBalance === 'number' ? initialBalance : 0;

    const wallet = await db.wallet.create({
      data: {
        userId,
        currency: currency.toUpperCase(),
        type: type ?? 'digital',
        balance,
        availableBalance: balance,
        frozenBalance: 0,
        status: 'active',
      },
      include: {
        user: { select: { id: true, name: true, email: true, role: true } },
      },
    });

    await createAuditLog({
      userId: session.id,
      action: 'create_wallet',
      resource: 'wallet',
      resourceId: wallet.id,
      details: `Created ${wallet.type} wallet (${wallet.currency}) for user ${targetUser.name} (${userId}) with initial balance ${balance}`,
      request,
    });

    return NextResponse.json(wallet, { status: 201 });
  } catch (error) {
    console.error('Wallet create error:', error);
    return NextResponse.json({ error: 'Failed to create wallet' }, { status: 500 });
  }
}
