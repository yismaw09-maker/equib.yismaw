import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, parsePagination, createAuditLog } from '@/lib/auth-helpers'
import { isNonEmptyString, isPositiveNumber, isValidCurrencyCode } from '@/lib/shared/validators'

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)

    const accountId = searchParams.get('accountId')
    const entryType = searchParams.get('entryType')
    const currency = searchParams.get('currency')

    const where: Record<string, unknown> = {}
    if (accountId) where.accountId = accountId
    if (entryType && (entryType === 'debit' || entryType === 'credit')) {
      where.entryType = entryType
    }
    if (currency && isValidCurrencyCode(currency)) {
      where.currency = currency.toUpperCase()
    }

    const [entries, total] = await Promise.all([
      db.ledgerEntry.findMany({
        where,
        include: {
          transaction: {
            select: { id: true, type: true, status: true, amount: true, currency: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.ledgerEntry.count({ where }),
    ])

    // Summary: total debits, credits, and net
    const debitResult = await db.ledgerEntry.aggregate({
      where: { ...where, entryType: 'debit' },
      _sum: { amount: true },
    })

    const creditResult = await db.ledgerEntry.aggregate({
      where: { ...where, entryType: 'credit' },
      _sum: { amount: true },
    })

    const totalDebits = debitResult._sum.amount || 0
    const totalCredits = creditResult._sum.amount || 0
    const net = totalDebits - totalCredits

    await createAuditLog({
      userId: user.id,
      action: 'view',
      resource: 'ledger_entry',
      details: 'Viewed ledger entries',
      request,
    })

    return NextResponse.json({
      entries,
      summary: {
        totalDebits,
        totalCredits,
        net,
      },
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Ledger entries list error:', error)
    return NextResponse.json({ error: 'Failed to load ledger entries' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { transactionId, accountId, entryType, amount, currency, description } = body

    if (!isNonEmptyString(accountId)) {
      return NextResponse.json({ error: 'Account ID is required' }, { status: 400 })
    }
    if (entryType !== 'debit' && entryType !== 'credit') {
      return NextResponse.json({ error: 'Entry type must be "debit" or "credit"' }, { status: 400 })
    }
    if (!isPositiveNumber(amount)) {
      return NextResponse.json({ error: 'A positive amount is required' }, { status: 400 })
    }
    const currencyCode = currency || 'ETB'
    if (!isValidCurrencyCode(currencyCode)) {
      return NextResponse.json({ error: 'Invalid currency code' }, { status: 400 })
    }

    const entry = await db.ledgerEntry.create({
      data: {
        transactionId: transactionId || null,
        accountId,
        entryType,
        amount,
        currency: currencyCode.toUpperCase(),
        description: description || null,
      },
      include: {
        transaction: {
          select: { id: true, type: true, status: true, amount: true, currency: true },
        },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'ledger_entry',
      resourceId: entry.id,
      details: `Created ${entryType} ledger entry: ${amount} ${currencyCode.toUpperCase()} on ${accountId}`,
      request,
    })

    return NextResponse.json({ entry }, { status: 201 })
  } catch (error) {
    console.error('Ledger entry create error:', error)
    return NextResponse.json({ error: 'Failed to create ledger entry' }, { status: 500 })
  }
}
