import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireSuperAdmin, isErrorResponse } from '@/lib/auth-helpers';

export async function POST(request: NextRequest) {
  const auth = requireSuperAdmin(request);
  if (isErrorResponse(auth)) return auth;
  try {
    // Check if seed data already exists
    const existingCount = await db.forexTransaction.count();
    if (existingCount > 0) {
      return NextResponse.json({ message: 'Forex seed data already exists', count: existingCount });
    }

    // Get a user for initiator
    const users = await db.user.findMany({ take: 3, select: { id: true, name: true } });
    const userId = users[0]?.id || null;

    const now = new Date();
    const dayMs = 86400000;

    const transactions = [
      // Buy transactions
      {
        reference: generateRef('BY'),
        type: 'buy',
        fromCurrency: 'ETB',
        toCurrency: 'USD',
        fromAmount: 57500,
        toAmount: 500,
        exchangeRate: 0.0087,
        fee: 115,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Buy USD for business travel',
        completedAt: new Date(now.getTime() - dayMs * 6),
        createdAt: new Date(now.getTime() - dayMs * 6),
      },
      {
        reference: generateRef('BY'),
        type: 'buy',
        fromCurrency: 'ETB',
        toCurrency: 'EUR',
        fromAmount: 130000,
        toAmount: 1000,
        exchangeRate: 0.0077,
        fee: 260,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Buy EUR for supplier payment',
        completedAt: new Date(now.getTime() - dayMs * 5),
        createdAt: new Date(now.getTime() - dayMs * 5),
      },
      {
        reference: generateRef('BY'),
        type: 'buy',
        fromCurrency: 'ETB',
        toCurrency: 'GBP',
        fromAmount: 160000,
        toAmount: 1000,
        exchangeRate: 0.00625,
        fee: 320,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Buy GBP for UK partner',
        completedAt: new Date(now.getTime() - dayMs * 3),
        createdAt: new Date(now.getTime() - dayMs * 3),
      },
      // Sell transactions
      {
        reference: generateRef('SL'),
        type: 'sell',
        fromCurrency: 'USD',
        toCurrency: 'ETB',
        fromAmount: 2000,
        toAmount: 230000,
        exchangeRate: 115,
        fee: 230,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Sell USD received from export',
        completedAt: new Date(now.getTime() - dayMs * 4),
        createdAt: new Date(now.getTime() - dayMs * 4),
      },
      {
        reference: generateRef('SL'),
        type: 'sell',
        fromCurrency: 'EUR',
        toCurrency: 'ETB',
        fromAmount: 500,
        toAmount: 64500,
        exchangeRate: 129,
        fee: 64.5,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Sell EUR from travel refund',
        completedAt: new Date(now.getTime() - dayMs * 2),
        createdAt: new Date(now.getTime() - dayMs * 2),
      },
      {
        reference: generateRef('SL'),
        type: 'sell',
        fromCurrency: 'AED',
        toCurrency: 'ETB',
        fromAmount: 3000,
        toAmount: 234000,
        exchangeRate: 78,
        fee: 234,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        description: 'Sell AED from Dubai trip',
        completedAt: new Date(now.getTime() - dayMs * 1),
        createdAt: new Date(now.getTime() - dayMs * 1),
      },
      // Send transactions
      {
        reference: generateRef('SN'),
        type: 'send',
        fromCurrency: 'ETB',
        toCurrency: 'USD',
        fromAmount: 115000,
        toAmount: 1000,
        exchangeRate: 0.0087,
        fee: 575,
        feeCurrency: 'ETB',
        status: 'completed',
        initiatorId: userId,
        recipientName: 'John Smith',
        recipientEmail: 'john@example.com',
        recipientPhone: '+12025551234',
        description: 'Send USD to US supplier',
        completedAt: new Date(now.getTime() - dayMs * 5),
        createdAt: new Date(now.getTime() - dayMs * 5),
      },
      {
        reference: generateRef('SN'),
        type: 'send',
        fromCurrency: 'USD',
        toCurrency: 'CNY',
        fromAmount: 1500,
        toAmount: 10800,
        exchangeRate: 7.2,
        fee: 7.5,
        feeCurrency: 'USD',
        status: 'completed',
        initiatorId: userId,
        recipientName: 'Li Wei Trading Co.',
        recipientEmail: 'liwei@trading.cn',
        description: 'Send payment to Chinese supplier',
        completedAt: new Date(now.getTime() - dayMs * 3),
        createdAt: new Date(now.getTime() - dayMs * 3),
      },
      {
        reference: generateRef('SN'),
        type: 'send',
        fromCurrency: 'ETB',
        toCurrency: 'EUR',
        fromAmount: 65000,
        toAmount: 500,
        exchangeRate: 0.0077,
        fee: 325,
        feeCurrency: 'ETB',
        status: 'pending',
        initiatorId: userId,
        recipientName: 'Marie Dupont',
        recipientEmail: 'marie.d@company.fr',
        description: 'Send EUR to French partner',
        createdAt: new Date(now.getTime() - dayMs * 1),
      },
      // Receive transactions
      {
        reference: generateRef('RC'),
        type: 'receive',
        fromCurrency: 'USD',
        toCurrency: 'ETB',
        fromAmount: 5000,
        toAmount: 575000,
        exchangeRate: 115,
        fee: 5,
        feeCurrency: 'USD',
        status: 'completed',
        initiatorId: userId,
        recipientName: 'Temesgen Alemayehu',
        recipientPhone: '+251920509047',
        description: 'Receive USD from diaspora',
        completedAt: new Date(now.getTime() - dayMs * 4),
        createdAt: new Date(now.getTime() - dayMs * 4),
      },
      {
        reference: generateRef('RC'),
        type: 'receive',
        fromCurrency: 'GBP',
        toCurrency: 'ETB',
        fromAmount: 2000,
        toAmount: 320000,
        exchangeRate: 160,
        fee: 2,
        feeCurrency: 'GBP',
        status: 'completed',
        initiatorId: userId,
        recipientName: 'Tigist Haile',
        recipientPhone: '+251922334455',
        description: 'Receive GBP from UK client',
        completedAt: new Date(now.getTime() - dayMs * 2),
        createdAt: new Date(now.getTime() - dayMs * 2),
      },
      {
        reference: generateRef('RC'),
        type: 'receive',
        fromCurrency: 'SAR',
        toCurrency: 'ETB',
        fromAmount: 10000,
        toAmount: 307000,
        exchangeRate: 30.7,
        fee: 10,
        feeCurrency: 'SAR',
        status: 'completed',
        initiatorId: userId,
        recipientName: 'Mohammed Ali',
        recipientPhone: '+251933445566',
        description: 'Receive SAR from Saudi client',
        completedAt: new Date(now.getTime() - dayMs * 1),
        createdAt: new Date(now.getTime() - dayMs * 1),
      },
    ];

    const result = await db.forexTransaction.createMany({ data: transactions });
    return NextResponse.json({
      message: `Successfully seeded ${result.count} forex transactions`,
      count: result.count,
    });
  } catch (error) {
    console.error('Seed currency exchange error:', error);
    return NextResponse.json({ error: 'Failed to seed currency exchange data' }, { status: 500 });
  }
}

function generateRef(prefix: string) {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `FX-${prefix}-${ts}-${rand}`;
}
