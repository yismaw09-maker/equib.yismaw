import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isErrorResponse } from '@/lib/auth-helpers'

export async function GET(request: Request) {
  try {
    const auth = requireAuth(request as unknown as Parameters<typeof requireAuth>[0])
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') || 'active'
    const bankType = searchParams.get('bankType')
    const search = searchParams.get('search')
    const supportsTransfer = searchParams.get('supportsTransfer')

    const where: Record<string, unknown> = { status }
    if (bankType) where.bankType = bankType
    if (search) {
      where.OR = [
        { bankName: { contains: search } },
        { shortName: { contains: search } },
        { bankCode: { contains: search } },
      ]
    }
    if (supportsTransfer !== null && supportsTransfer !== undefined) {
      where.supportsTransfer = supportsTransfer === 'true'
    }

    const banks = await db.masterBank.findMany({
      where,
      orderBy: [{ bankType: 'asc' }, { bankName: 'asc' }],
      include: {
        _count: { select: { bankAccounts: true } },
      },
    })

    return NextResponse.json(banks)
  } catch (error) {
    console.error('Master banks error:', error)
    return NextResponse.json({ error: 'Failed to load banks' }, { status: 500 })
  }
}
