import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { signSession, createAuditLog } from '@/lib/auth-helpers';

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email/Username and password are required' }, { status: 400 });
    }

    const loginId = email.trim();

    // Rate-limiting hint: in production, use Redis-backed rate limiter here
    const user = await db.user.findFirst({
      where: {
        OR: [
          { email: loginId.toLowerCase() },
          { username: loginId },
        ],
      },
    });

    if (!user || !user.password) {
      // Don't reveal whether user exists (timing-safe with bcrypt)
      await bcrypt.compare(password, '$2b$12$dummyhashfordummyhash00000000000000000000000000000000');
      return NextResponse.json({ error: 'Invalid email/username or password' }, { status: 401 });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return NextResponse.json({ error: 'Invalid email/username or password' }, { status: 401 });
    }

    // Check account status
    if (user.status === 'blocked' || user.status === 'closed') {
      return NextResponse.json({ error: 'Your account has been blocked. Contact support.' }, { status: 403 });
    }
    if (user.status === 'suspended' || user.status === 'frozen') {
      return NextResponse.json({ error: 'Your account is currently unavailable.' }, { status: 403 });
    }

    // Update last login
    await db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    // Create HMAC-signed session token
    const sessionUser = {
      id: user.id,
      email: user.email,
      name: user.name,
      username: user.username,
      phone: user.phone,
      country: user.country,
      role: user.role,
      status: user.status,
    };
    const token = signSession(sessionUser);

    // Audit log
    await createAuditLog({
      userId: user.id,
      action: 'login',
      resource: 'auth',
      request,
    });

    const response = NextResponse.json({
      success: true,
      token,
      user: sessionUser,
    });

    response.cookies.set('finflow-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'Login failed' }, { status: 500 });
  }
}
