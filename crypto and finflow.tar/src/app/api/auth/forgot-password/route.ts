import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    const user = await db.user.findUnique({ where: { email: email.toLowerCase().trim() } });

    if (!user) {
      // Don't reveal whether email exists
      return NextResponse.json({ success: true, message: 'If the email exists, a reset code has been sent.' });
    }

    // Generate a cryptographically secure 6-digit code
    const resetCode = String(crypto.randomInt(100000, 999999));
    // Hash it for storage
    const hashedCode = crypto.createHash('sha256').update(resetCode).digest('hex');
    const codeExpiry = new Date(Date.now() + 15 * 60 * 1000); // 15 min

    await db.user.update({
      where: { id: user.id },
      data: { twoFactorCode: hashedCode, resetCodeExpiry: codeExpiry },
    });

    // In production, send via email/SMS. For demo, return the code.
    return NextResponse.json({
      success: true,
      message: 'Reset code sent to your email',
      _devCode: resetCode, // TODO: remove in production
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    return NextResponse.json({ error: 'Failed to send reset code' }, { status: 500 });
  }
}
