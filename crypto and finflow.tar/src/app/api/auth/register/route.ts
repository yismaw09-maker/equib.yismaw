import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

const VALID_ROLES = [
  'super_admin', 'administrator', 'finance_manager', 'compliance_auditor',
  'merchant', 'buyer', 'agent', 'customer_support', 'warehouse_manager', 'delivery', 'user',
];

export async function POST(request: NextRequest) {
  try {
    const { name, username, email, phone, country, password } = await request.json();

    // Validate required fields
    if (!name || !email || !password) {
      return NextResponse.json({ error: 'Name, email, and password are required' }, { status: 400 });
    }

    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: 'Invalid email format' }, { status: 400 });
    }

    // Check uniqueness
    const existing = await db.user.findFirst({
      where: {
        OR: [
          { email: email.toLowerCase().trim() },
          ...(username ? [{ username }] : []),
        ],
      },
    });

    if (existing) {
      if (existing.email === email.toLowerCase().trim()) {
        return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
      }
      if (username && existing.username === username) {
        return NextResponse.json({ error: 'Username already taken' }, { status: 409 });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await db.user.create({
      data: {
        name: name.trim(),
        username: username?.trim() || null,
        email: email.toLowerCase().trim(),
        phone: phone?.trim() || null,
        country: country?.trim() || 'Ethiopia',
        password: hashedPassword,
        role: 'user',
        status: 'pending', // New registrations need admin approval
      },
      select: {
        id: true, email: true, name: true, username: true, phone: true,
        country: true, role: true, status: true, createdAt: true,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Registration successful. Your account is pending admin approval.',
      user,
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json({ error: 'Registration failed' }, { status: 500 });
  }
}
