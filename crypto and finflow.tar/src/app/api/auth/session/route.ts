import { NextRequest, NextResponse } from 'next/server';
import { getSession, extractToken, signSession } from '@/lib/auth-helpers';

export async function GET(request: NextRequest) {
  try {
    const user = getSession(request);
    if (!user) {
      return NextResponse.json({ user: null, token: null });
    }
    // Return the token so the client can restore it in Zustand on page refresh
    const token = extractToken(request) ?? signSession(user);
    return NextResponse.json({ user, token });
  } catch {
    return NextResponse.json({ user: null, token: null });
  }
}

export async function POST() {
  const response = NextResponse.json({ success: true });
  response.cookies.set('finflow-token', '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  });
  return response;
}
