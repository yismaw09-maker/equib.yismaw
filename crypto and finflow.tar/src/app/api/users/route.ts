import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  requireAuth,
  isErrorResponse,
  parsePagination,
  createAuditLog,
} from '@/lib/auth-helpers';
import { canManageRole, getRoleLevel } from '@/lib/role-permissions';

const VALID_STATUSES = ['pending', 'approved', 'active', 'blocked', 'inactive', 'suspended', 'frozen', 'closed'];
const VALID_ROLES = ['super_admin', 'administrator', 'finance_manager', 'compliance_auditor', 'merchant', 'buyer', 'agent', 'customer_support', 'warehouse_manager', 'delivery', 'user', 'seller'];

// Fields a non-admin user is allowed to edit on their own profile
const SELF_EDITABLE_FIELDS = new Set(['name', 'phone', 'country']);

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request);
    if (isErrorResponse(auth)) return auth;

    const { user: session } = auth;
    const isAdmin = getRoleLevel(session.role) >= 45;

    // Non-admin users can only see their own profile
    if (!isAdmin) {
      const self = await db.user.findUnique({
        where: { id: session.id },
        select: {
          id: true, email: true, username: true, name: true, phone: true,
          country: true, role: true, kycStatus: true, kycSubmittedAt: true,
          twoFactorEnabled: true, isVerified: true, riskLevel: true,
          status: true, lastLoginAt: true, createdAt: true,
          _count: { select: { wallets: true, transactions: true } },
        },
      });

      if (!self) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }

      return NextResponse.json({
        users: [self],
        pagination: { page: 1, limit: 1, total: 1, totalPages: 1 },
      });
    }

    // Admin: full listing with filters
    const { searchParams } = new URL(request.url);
    const role = searchParams.get('role');
    const kycStatus = searchParams.get('kycStatus');
    const status = searchParams.get('status');
    const country = searchParams.get('country');
    const search = searchParams.get('search');
    const { page, limit, skip } = parsePagination(searchParams);

    const where: Record<string, unknown> = {};
    if (role) where.role = role;
    if (kycStatus) where.kycStatus = kycStatus;
    if (status) where.status = status;
    if (country) where.country = country;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
        { username: { contains: search } },
        { country: { contains: search } },
      ];
    }

    const [users, total] = await Promise.all([
      db.user.findMany({
        where,
        select: {
          id: true, email: true, username: true, name: true, phone: true,
          country: true, role: true, kycStatus: true, kycSubmittedAt: true,
          twoFactorEnabled: true, isVerified: true, riskLevel: true,
          status: true, lastLoginAt: true, createdAt: true,
          _count: { select: { wallets: true, transactions: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.user.count({ where }),
    ]);

    await createAuditLog({
      userId: session.id,
      action: 'list_users',
      resource: 'user',
      details: `Listed users (page=${page}, limit=${limit}, total=${total})`,
      request,
    });

    return NextResponse.json({
      users,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Users list error:', error);
    return NextResponse.json({ error: 'Failed to load users' }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireAuth(request);
    if (isErrorResponse(auth)) return auth;

    const { user: session } = auth;
    const sessionLevel = getRoleLevel(session.role);
    const isAdmin = sessionLevel >= 45;
    const isSuperAdmin = sessionLevel >= 100;

    const body = await request.json();
    const { id, kycStatus, role, status, name, email, phone, username, country, twoFactorEnabled } = body;

    if (!id) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const existing = await db.user.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Determine which fields are being requested
    const requestedFields = Object.keys(body).filter((k) => k !== 'id' && body[k] !== undefined);
    const isRoleChange = role !== undefined && role !== existing.role;
    const adminOnlyFields = requestedFields.filter((f) => !SELF_EDITABLE_FIELDS.has(f) && f !== 'role');

    // --- Permission checks ---

    // 1. Role changes require super_admin (level>=100)
    if (isRoleChange) {
      if (!isSuperAdmin) {
        return NextResponse.json({ error: 'Only super admins can change roles' }, { status: 403 });
      }
      if (!canManageRole(session.role, role)) {
        return NextResponse.json({ error: 'You do not have permission to assign this role' }, { status: 403 });
      }
      const targetLevel = getRoleLevel(role);
      if (targetLevel >= sessionLevel) {
        return NextResponse.json({ error: 'Cannot promote a user to your level or above' }, { status: 403 });
      }
    }

    // 2. Non-role admin fields (status, kycStatus, email, username, twoFactorEnabled, etc.)
    //    require admin (level>=45), OR the user editing their own self-editable fields
    if (adminOnlyFields.length > 0) {
      // If the user is not an admin, they cannot modify admin-only fields
      if (!isAdmin) {
        return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 });
      }
      // If the user is admin but not super_admin, they cannot modify other admins' admin-only fields
      // (super_admin is handled above for role changes; here we check status/KYC on higher-level users)
      if (!isSuperAdmin && id !== session.id) {
        const targetLevel = getRoleLevel(existing.role);
        if (targetLevel >= sessionLevel) {
          return NextResponse.json({ error: 'Cannot modify a user at or above your level' }, { status: 403 });
        }
      }
    }

    // 3. Self-editable fields (name, phone, country) — non-admin users can only edit their own
    if (!isAdmin && requestedFields.some((f) => SELF_EDITABLE_FIELDS.has(f))) {
      if (id !== session.id) {
        return NextResponse.json({ error: 'You can only edit your own profile' }, { status: 403 });
      }
    }

    // 4. Non-admin users can only edit their own profile at all
    if (!isAdmin && id !== session.id) {
      return NextResponse.json({ error: 'You can only edit your own profile' }, { status: 403 });
    }

    // --- Build update data ---

    const updateData: Record<string, unknown> = {};

    if (name !== undefined) updateData.name = name;
    if (email !== undefined) {
      if (!isAdmin) {
        return NextResponse.json({ error: 'Only admins can change email' }, { status: 403 });
      }
      if (email !== existing.email) {
        const emailTaken = await db.user.findFirst({ where: { email, id: { not: id } } });
        if (emailTaken) return NextResponse.json({ error: 'Email already taken' }, { status: 409 });
      }
      updateData.email = email;
    }
    if (phone !== undefined) updateData.phone = phone;
    if (username !== undefined) {
      if (!isAdmin) {
        return NextResponse.json({ error: 'Only admins can change username' }, { status: 403 });
      }
      if (username && username !== existing.username) {
        const usernameTaken = await db.user.findFirst({ where: { username, id: { not: id } } });
        if (usernameTaken) return NextResponse.json({ error: 'Username already taken' }, { status: 409 });
      }
      updateData.username = username || null;
    }
    if (country !== undefined) updateData.country = country;

    if (kycStatus !== undefined) {
      if (!isAdmin) {
        return NextResponse.json({ error: 'Only admins can change KYC status' }, { status: 403 });
      }
      if (!['pending', 'verified', 'rejected'].includes(kycStatus)) {
        return NextResponse.json({ error: 'Invalid KYC status' }, { status: 400 });
      }
      updateData.kycStatus = kycStatus;
      if (kycStatus === 'verified') {
        updateData.isVerified = true;
        updateData.kycSubmittedAt = existing.kycSubmittedAt ?? new Date();
      }
    }
    if (role !== undefined) {
      if (!VALID_ROLES.includes(role)) {
        return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
      }
      updateData.role = role;
    }
    if (status !== undefined) {
      if (!isAdmin) {
        return NextResponse.json({ error: 'Only admins can change user status' }, { status: 403 });
      }
      if (!VALID_STATUSES.includes(status)) {
        return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
      }
      updateData.status = status;
    }
    if (twoFactorEnabled !== undefined) {
      if (!isAdmin) {
        return NextResponse.json({ error: 'Only admins can change two-factor settings' }, { status: 403 });
      }
      updateData.twoFactorEnabled = Boolean(twoFactorEnabled);
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ error: 'No valid fields to update' }, { status: 400 });
    }

    const user = await db.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true, email: true, username: true, name: true, phone: true,
        country: true, role: true, kycStatus: true, isVerified: true,
        riskLevel: true, status: true, lastLoginAt: true, createdAt: true,
      },
    });

    await createAuditLog({
      userId: session.id,
      action: 'update_user',
      resource: 'user',
      resourceId: id,
      details: `Updated user fields: ${Object.keys(updateData).join(', ')}`,
      request,
    });

    return NextResponse.json(user);
  } catch (error) {
    console.error('User update error:', error);
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 });
  }
}
