import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, parsePagination, createAuditLog, getRoleLevel } from '@/lib/auth-helpers'
import { isValidComplianceCaseType, isValidComplianceCaseSeverity, isValidComplianceCaseStatus, isNonEmptyString } from '@/lib/shared/validators'

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 55)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)

    const type = searchParams.get('type')
    const severity = searchParams.get('severity')
    const status = searchParams.get('status')
    const search = searchParams.get('search')

    const where: Record<string, unknown> = {}

    if (type && isValidComplianceCaseType(type)) {
      where.type = type
    }
    if (severity && isValidComplianceCaseSeverity(severity)) {
      where.severity = severity
    }
    if (status && isValidComplianceCaseStatus(status)) {
      where.status = status
    }
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { caseNumber: { contains: search } },
      ]
    }

    const [cases, total] = await Promise.all([
      db.complianceCase.findMany({
        where,
        include: {
          assignedTo: { select: { id: true, name: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.complianceCase.count({ where }),
    ])

    await createAuditLog({
      userId: user.id,
      action: 'view',
      resource: 'compliance_case',
      details: 'Viewed compliance cases',
      request,
    })

    return NextResponse.json({
      cases,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Compliance cases list error:', error)
    return NextResponse.json({ error: 'Failed to load compliance cases' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 55)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { type, severity, title, description, userId, transactionId } = body

    if (!isNonEmptyString(type) || !isValidComplianceCaseType(type)) {
      return NextResponse.json({ error: 'Valid case type is required' }, { status: 400 })
    }
    if (!isNonEmptyString(severity) || !isValidComplianceCaseSeverity(severity)) {
      return NextResponse.json({ error: 'Valid severity is required' }, { status: 400 })
    }
    if (!isNonEmptyString(title)) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    // Generate case number: CC-YYYYMMDD-XXXXX
    const now = new Date()
    const dateStr = now.getFullYear().toString() +
      String(now.getMonth() + 1).padStart(2, '0') +
      String(now.getDate()).padStart(2, '0')

    // Find the highest sequence number for today
    const prefix = `CC-${dateStr}-`
    const todayCases = await db.complianceCase.findMany({
      where: { caseNumber: { startsWith: prefix } },
      orderBy: { caseNumber: 'desc' },
      take: 1,
    })

    let seq = 1
    if (todayCases.length > 0) {
      const lastNum = todayCases[0].caseNumber.slice(prefix.length)
      seq = (parseInt(lastNum, 10) || 0) + 1
    }
    const caseNumber = `${prefix}${String(seq).padStart(5, '0')}`

    const complianceCase = await db.complianceCase.create({
      data: {
        caseNumber,
        type,
        severity,
        title,
        description: description || null,
        userId: userId || null,
        transactionId: transactionId || null,
      },
      include: {
        assignedTo: { select: { id: true, name: true, email: true, role: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'compliance_case',
      resourceId: complianceCase.id,
      details: `Created compliance case ${caseNumber}: ${title}`,
      request,
    })

    return NextResponse.json({ case: complianceCase }, { status: 201 })
  } catch (error) {
    console.error('Compliance case create error:', error)
    return NextResponse.json({ error: 'Failed to create compliance case' }, { status: 500 })
  }
}
