import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isErrorResponse, getRoleLevel } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45

    const now = new Date()
    const sevenDaysAgo = new Date(now)
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const sixMonthsAgo = new Date(now)
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

    if (isAdmin) {
      // Full admin dashboard
      const [totalUsers, totalTransactions, activeWallets, completedVolumeResult] =
        await Promise.all([
          db.user.count(),
          db.transaction.count(),
          db.wallet.count({ where: { status: 'active' } }),
          db.transaction.aggregate({
            where: { status: 'completed' },
            _sum: { amount: true },
          }),
        ])

      const totalVolume = completedVolumeResult._sum.amount ?? 0

      // Recent transactions (last 10)
      const recentTransactions = await db.transaction.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          initiator: { select: { id: true, name: true, email: true } },
          recipient: { select: { id: true, name: true, email: true } },
        },
      })

      // Daily volume for last 7 days
      const dailyVolume = await db.transaction.groupBy({
        by: ['createdAt'],
        where: {
          status: 'completed',
          createdAt: { gte: sevenDaysAgo },
        },
        _sum: { amount: true },
      })

      // Group by date string
      const dailyVolumeMap = new Map<string, number>()
      for (const dv of dailyVolume) {
        const dateStr = dv.createdAt.toISOString().split('T')[0]
        const current = dailyVolumeMap.get(dateStr) ?? 0
        dailyVolumeMap.set(dateStr, current + (dv._sum.amount ?? 0))
      }

      const dailyVolumeArray: { date: string; volume: number }[] = []
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now)
        d.setDate(d.getDate() - i)
        const dateStr = d.toISOString().split('T')[0]
        dailyVolumeArray.push({
          date: dateStr,
          volume: dailyVolumeMap.get(dateStr) ?? 0,
        })
      }

      // Transaction type breakdown
      const typeBreakdown = await db.transaction.groupBy({
        by: ['type'],
        _count: { id: true },
      })
      const transactionTypeBreakdown = typeBreakdown.map((t) => ({
        type: t.type,
        count: t._count.id,
      }))

      // Monthly revenue for last 6 months
      const monthlyTxns = await db.transaction.findMany({
        where: {
          status: 'completed',
          createdAt: { gte: sixMonthsAgo },
        },
        select: { amount: true, fee: true, createdAt: true },
      })

      const monthlyRevenueMap = new Map<string, { volume: number; fees: number }>()
      for (const tx of monthlyTxns) {
        const monthKey = `${tx.createdAt.getFullYear()}-${String(tx.createdAt.getMonth() + 1).padStart(2, '0')}`
        const current = monthlyRevenueMap.get(monthKey) ?? { volume: 0, fees: 0 }
        current.volume += tx.amount
        current.fees += tx.fee
        monthlyRevenueMap.set(monthKey, current)
      }

      const monthlyRevenue: { month: string; volume: number; fees: number }[] = []
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now)
        d.setMonth(d.getMonth() - i)
        const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
        const data = monthlyRevenueMap.get(monthKey)
        monthlyRevenue.push({
          month: monthKey,
          volume: data?.volume ?? 0,
          fees: data?.fees ?? 0,
        })
      }

      return NextResponse.json({
        totalUsers,
        totalTransactions,
        totalVolume,
        activeWallets,
        recentTransactions,
        dailyVolume: dailyVolumeArray,
        transactionTypeBreakdown,
        monthlyRevenue,
      })
    }

    // Non-admin: limited dashboard with only user's own data
    const [totalTransactions, activeWallets, completedVolumeResult] =
      await Promise.all([
        db.transaction.count({
          where: {
            OR: [{ initiatorId: user.id }, { recipientId: user.id }],
          },
        }),
        db.wallet.count({
          where: { userId: user.id, status: 'active' },
        }),
        db.transaction.aggregate({
          where: {
            status: 'completed',
            OR: [{ initiatorId: user.id }, { recipientId: user.id }],
          },
          _sum: { amount: true },
        }),
      ])

    const totalVolume = completedVolumeResult._sum.amount ?? 0

    // Recent transactions for this user only
    const recentTransactions = await db.transaction.findMany({
      where: {
        OR: [{ initiatorId: user.id }, { recipientId: user.id }],
      },
      take: 10,
      orderBy: { createdAt: 'desc' },
      include: {
        initiator: { select: { id: true, name: true, email: true } },
        recipient: { select: { id: true, name: true, email: true } },
      },
    })

    return NextResponse.json({
      totalUsers: 0,
      totalTransactions,
      totalVolume,
      activeWallets,
      recentTransactions,
      dailyVolume: [],
      transactionTypeBreakdown: [],
      monthlyRevenue: [],
    })
  } catch (error) {
    console.error('Dashboard error:', error)
    return NextResponse.json({ error: 'Failed to load dashboard data' }, { status: 500 })
  }
}
