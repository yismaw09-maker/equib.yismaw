import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, getRoleLevel, parsePagination, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)
    const isAdmin = getRoleLevel(user.role) >= 45

    const where: Record<string, unknown> = {}
    if (isAdmin) {
      // Admin can optionally filter by userId
      const userIdParam = searchParams.get('userId')
      if (userIdParam) where.userId = userIdParam
    } else {
      // Non-admin users can only see their own settlements
      where.userId = user.id
    }

    const status = searchParams.get('status')
    if (status) where.status = status

    const [settlements, total] = await Promise.all([
      db.settlement.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.settlement.count({ where }),
    ])

    return NextResponse.json({
      settlements,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error('Settlements error:', error)
    return NextResponse.json({ error: 'Failed to load settlements' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, status } = body

    if (!id || !status) {
      return NextResponse.json({ error: 'Settlement ID and status are required' }, { status: 400 })
    }

    if (!['processing', 'completed', 'failed'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be: processing, completed, failed' },
        { status: 400 }
      )
    }

    const existing = await db.settlement.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Settlement not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = { status }
    if (status === 'completed') {
      updateData.settledAt = new Date()
    }

    const settlement = await db.settlement.update({
      where: { id },
      data: updateData,
      include: {
        user: { select: { id: true, name: true, email: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'settlement',
      resourceId: id,
      details: `Updated settlement ${id} status to ${status}`,
      request,
    })

    return NextResponse.json(settlement)
  } catch (error) {
    console.error('Settlement update error:', error)
    return NextResponse.json({ error: 'Failed to update settlement' }, { status: 500 })
  }
}
