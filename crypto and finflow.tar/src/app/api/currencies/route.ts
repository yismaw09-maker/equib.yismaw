import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth

    const currencies = await db.currency.findMany({
      orderBy: { code: 'asc' },
    })
    return NextResponse.json(currencies)
  } catch (error) {
    console.error('Currencies error:', error)
    return NextResponse.json({ error: 'Failed to load currencies' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, exchangeRate, isActive } = body

    if (!id) {
      return NextResponse.json({ error: 'Currency ID is required' }, { status: 400 })
    }

    const existing = await db.currency.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Currency not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {}
    if (exchangeRate !== undefined) updateData.exchangeRate = exchangeRate
    if (isActive !== undefined) updateData.isActive = isActive

    const currency = await db.currency.update({
      where: { id },
      data: updateData,
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'currency',
      resourceId: id,
      details: `Updated currency ${existing.code}: ${JSON.stringify(updateData)}`,
      request,
    })

    return NextResponse.json(currency)
  } catch (error) {
    console.error('Currency update error:', error)
    return NextResponse.json({ error: 'Failed to update currency' }, { status: 500 })
  }
}
