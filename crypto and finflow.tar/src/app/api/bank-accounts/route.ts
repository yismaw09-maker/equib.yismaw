import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isErrorResponse, getRoleLevel, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const isAdmin = getRoleLevel(user.role) >= 45

    const where: Record<string, unknown> = {}
    if (isAdmin) {
      // Admin can optionally filter by userId
      const userIdParam = searchParams.get('userId')
      if (userIdParam) where.userId = userIdParam
    } else {
      // Non-admin users can only see their own bank accounts
      where.userId = user.id
    }

    const isVerified = searchParams.get('isVerified')
    if (isVerified !== null && isVerified !== undefined && isVerified !== '') {
      where.isVerified = isVerified === 'true'
    }

    const bankAccounts = await db.bankAccount.findMany({
      where,
      include: {
        user: { select: { id: true, name: true, email: true } },
        masterBank: { select: { id: true, shortName: true, bankCode: true, swiftCode: true, bankType: true, supportsIfb: true, supportsFx: true, supportsTransfer: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(bankAccounts)
  } catch (error) {
    console.error('Bank accounts error:', error)
    return NextResponse.json({ error: 'Failed to load bank accounts' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45
    const body = await request.json()
    const { userId, bankName, accountNumber, accountName, accountType, branch, swiftCode, currency } = body

    // Non-admin users can only create bank accounts for themselves
    const effectiveUserId = isAdmin ? userId : user.id

    if (!effectiveUserId || !bankName || !accountNumber || !accountName || !accountType) {
      return NextResponse.json(
        { error: 'Missing required fields: bankName, accountNumber, accountName, accountType' },
        { status: 400 }
      )
    }

    // Auto-link to master bank
    let masterBankId: string | null = null
    if (bankName) {
      const master = await db.masterBank.findFirst({
        where: {
          OR: [
            { bankName: { contains: bankName.replace(' (CBE)', '').trim() } },
            { shortName: bankName.split(' ')[0] },
          ],
        },
      })
      if (master) masterBankId = master.id
    }

    const bankAccount = await db.bankAccount.create({
      data: {
        userId: effectiveUserId,
        bankName,
        masterBankId,
        accountNumber,
        accountName,
        accountType,
        branch: branch ?? null,
        swiftCode: swiftCode ?? null,
        currency: currency ?? 'ETB',
        isVerified: false,
        isDefault: false,
        status: 'active',
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
        masterBank: { select: { id: true, shortName: true, bankCode: true, swiftCode: true, bankType: true, supportsIfb: true, supportsFx: true, supportsTransfer: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'bank_account',
      resourceId: bankAccount.id,
      details: `Created bank account for user ${effectiveUserId} at ${bankName}`,
      request,
    })

    return NextResponse.json(bankAccount, { status: 201 })
  } catch (error) {
    console.error('Bank account create error:', error)
    return NextResponse.json({ error: 'Failed to create bank account' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const isAdmin = getRoleLevel(user.role) >= 45
    const body = await request.json()
    const { id, isVerified, isDefault, status } = body

    if (!id) {
      return NextResponse.json({ error: 'Bank account ID is required' }, { status: 400 })
    }

    const existing = await db.bankAccount.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Bank account not found' }, { status: 404 })
    }

    // Non-admin users can only update their own bank accounts
    if (!isAdmin && existing.userId !== user.id) {
      return NextResponse.json({ error: 'You can only update your own bank accounts' }, { status: 403 })
    }

    // Non-admin users cannot set isVerified (that's an admin action)
    if (!isAdmin && isVerified !== undefined) {
      return NextResponse.json({ error: 'You cannot verify bank accounts' }, { status: 403 })
    }

    const updateData: Record<string, unknown> = {}
    if (isVerified !== undefined) updateData.isVerified = isVerified
    if (status !== undefined) {
      if (!['active', 'inactive', 'suspended'].includes(status)) {
        return NextResponse.json({ error: 'Invalid status. Must be active, inactive, or suspended' }, { status: 400 })
      }
      updateData.status = status
    }

    if (isDefault !== undefined && isDefault === true) {
      await db.bankAccount.updateMany({
        where: { userId: existing.userId, isDefault: true, id: { not: id } },
        data: { isDefault: false },
      })
      updateData.isDefault = true
    } else if (isDefault === false) {
      updateData.isDefault = false
    }

    const bankAccount = await db.bankAccount.update({
      where: { id },
      data: updateData,
      include: {
        user: { select: { id: true, name: true, email: true } },
        masterBank: { select: { id: true, shortName: true, bankCode: true, swiftCode: true, bankType: true, supportsIfb: true, supportsFx: true, supportsTransfer: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'bank_account',
      resourceId: id,
      details: `Updated bank account ${id}: ${JSON.stringify(updateData)}`,
      request,
    })

    return NextResponse.json(bankAccount)
  } catch (error) {
    console.error('Bank account update error:', error)
    return NextResponse.json({ error: 'Failed to update bank account' }, { status: 500 })
  }
}
