import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, getRoleLevel, parsePagination, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)
    const isAdmin = getRoleLevel(user.role) >= 45

    const where: Record<string, unknown> = {}
    if (isAdmin) {
      // Admin can optionally filter by userId
      const userIdParam = searchParams.get('userId')
      if (userIdParam) where.userId = userIdParam
    } else {
      // Non-admin users can only see their own disputes
      where.userId = user.id
    }

    const status = searchParams.get('status')
    if (status) where.status = status

    const [disputes, total] = await Promise.all([
      db.dispute.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.dispute.count({ where }),
    ])

    return NextResponse.json({
      disputes,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error('Disputes error:', error)
    return NextResponse.json({ error: 'Failed to load disputes' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { transactionId, userId, reason } = body

    // Users create disputes for themselves only
    const effectiveUserId = user.id

    if (!transactionId || !reason) {
      return NextResponse.json(
        { error: 'Missing required fields: transactionId, reason' },
        { status: 400 }
      )
    }

    // Verify transaction exists and belongs to the user
    const transaction = await db.transaction.findUnique({ where: { id: transactionId } })
    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Only allow disputes on own transactions (unless admin)
    const isAdmin = getRoleLevel(user.role) >= 45
    if (!isAdmin && transaction.initiatorId !== user.id && transaction.recipientId !== user.id) {
      return NextResponse.json({ error: 'You can only dispute your own transactions' }, { status: 403 })
    }

    const dispute = await db.dispute.create({
      data: {
        transactionId,
        userId: effectiveUserId,
        reason,
        status: 'open',
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'dispute',
      resourceId: dispute.id,
      details: `Created dispute for transaction ${transactionId}: ${reason}`,
      request,
    })

    return NextResponse.json(dispute, { status: 201 })
  } catch (error) {
    console.error('Dispute create error:', error)
    return NextResponse.json({ error: 'Failed to create dispute' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 45)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, status, resolution } = body

    if (!id || !status) {
      return NextResponse.json({ error: 'Dispute ID and status are required' }, { status: 400 })
    }

    if (!['under_review', 'resolved', 'closed'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be: under_review, resolved, closed' },
        { status: 400 }
      )
    }

    const existing = await db.dispute.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Dispute not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = { status }
    if (resolution) updateData.resolution = resolution

    const dispute = await db.dispute.update({
      where: { id },
      data: updateData,
      include: {
        user: { select: { id: true, name: true, email: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'update',
      resource: 'dispute',
      resourceId: id,
      details: `Updated dispute ${id} status to ${status}${resolution ? `: ${resolution}` : ''}`,
      request,
    })

    return NextResponse.json(dispute)
  } catch (error) {
    console.error('Dispute update error:', error)
    return NextResponse.json({ error: 'Failed to update dispute' }, { status: 500 })
  }
}
