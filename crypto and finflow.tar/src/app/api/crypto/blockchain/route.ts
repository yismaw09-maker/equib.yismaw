import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

const REQUIRED_CONFS_MAP: Record<string, number> = {
  BTC: 3,
  ETH: 12,
  USDT: 6,
  USDC: 6,
  XRP: 3,
  SOL: 12,
  DOGE: 6,
  ADA: 15,
}

const NETWORK_FEE_MAP: Record<string, number> = {
  BTC: 0.0001,
  ETH: 0.003,
  USDT: 1.0,
  USDC: 1.0,
  XRP: 0.0002,
  SOL: 0.00001,
  DOGE: 1.0,
  ADA: 0.2,
}

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 55)
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const network = searchParams.get('network')
    const currency = searchParams.get('currency')
    const status = searchParams.get('status')
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1') || 1)
    const limit = Math.min(200, Math.max(1, parseInt(searchParams.get('limit') ?? '20') || 20))

    const where: Record<string, unknown> = {}
    if (network) where.network = network
    if (currency) where.currency = currency
    if (status) where.status = status

    const [transactions, total] = await Promise.all([
      db.blockchainTransaction.findMany({
        where,
        orderBy: { detectedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.blockchainTransaction.count({ where }),
    ])

    return NextResponse.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Blockchain transactions list error:', error)
    return NextResponse.json({ error: 'Failed to load blockchain transactions' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { walletId, amount, currency, txHash } = body

    if (!walletId || !amount || !currency || !txHash) {
      return NextResponse.json({ error: 'Missing required fields: walletId, amount, currency, txHash' }, { status: 400 })
    }

    if (typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json({ error: 'Amount must be a positive number' }, { status: 400 })
    }

    const upperCurrency = currency.toUpperCase()

    // Verify wallet exists
    const wallet = await db.cryptoWallet.findFirst({
      where: { id: walletId },
    })

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet not found' }, { status: 404 })
    }

    // Check for duplicate txHash
    const existingBcTx = await db.blockchainTransaction.findFirst({
      where: { txHash },
    })

    if (existingBcTx) {
      return NextResponse.json({ error: 'Blockchain transaction with this hash already exists' }, { status: 400 })
    }

    const requiredConfs = REQUIRED_CONFS_MAP[upperCurrency] ?? 3
    const networkFee = NETWORK_FEE_MAP[upperCurrency] ?? 0

    // Generate deposit reference
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    const seg1 = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    const seg2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    const reference = `CRX-${seg1}-${seg2}`

    // Create blockchain transaction record and associated crypto transaction atomically
    const result = await db.$transaction(async (tx) => {
      const bcTx = await tx.blockchainTransaction.create({
        data: {
          txHash,
          network: wallet.network,
          toAddress: wallet.depositAddress,
          amount,
          currency: upperCurrency,
          confirmations: 0,
          requiredConfs,
          gasUsed: Math.floor(Math.random() * 50000) + 21000,
          gasPrice: upperCurrency === 'ETH' || upperCurrency === 'USDC' ? 0.00000002 : 0,
          networkFee,
          status: 'pending',
        },
      })

      // Create associated crypto transaction (deposit)
      const cryptoTx = await tx.cryptoTransaction.create({
        data: {
          reference,
          type: 'deposit',
          status: 'pending',
          amount,
          fee: 0,
          feeCurrency: upperCurrency,
          currency: upperCurrency,
          description: `Deposit detected on chain: ${txHash.slice(0, 16)}...`,
          userId: wallet.userId,
          walletId,
          toAddress: wallet.depositAddress,
          txHash,
          network: wallet.network,
          networkFee,
          confirmations: 0,
          requiredConfirmations: requiredConfs,
        },
      })

      // Link blockchain tx to crypto tx
      const linkedBcTx = await tx.blockchainTransaction.update({
        where: { id: bcTx.id },
        data: { cryptoTxId: cryptoTx.id },
      })

      return { blockchainTransaction: linkedBcTx, cryptoTransaction: cryptoTx }
    })

    await createAuditLog({
      userId: user.id,
      action: 'detect_blockchain_deposit',
      resource: 'blockchain_transaction',
      resourceId: result.blockchainTransaction.id,
      details: `Detected ${upperCurrency} deposit of ${amount} via ${txHash.slice(0, 16)}... for wallet ${walletId}`,
      request,
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    console.error('Blockchain deposit detection error:', error)
    return NextResponse.json({ error: 'Failed to detect blockchain deposit' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { txHash, confirmations } = body

    if (!txHash || confirmations === undefined || confirmations === null) {
      return NextResponse.json({ error: 'Missing required fields: txHash, confirmations' }, { status: 400 })
    }

    if (typeof confirmations !== 'number' || confirmations < 0) {
      return NextResponse.json({ error: 'Confirmations must be a non-negative number' }, { status: 400 })
    }

    // Find the blockchain transaction
    const bcTx = await db.blockchainTransaction.findFirst({
      where: { txHash },
    })

    if (!bcTx) {
      return NextResponse.json({ error: 'Blockchain transaction not found' }, { status: 404 })
    }

    const isConfirmed = confirmations >= bcTx.requiredConfs

    // If confirming, use a transaction for atomicity
    if (isConfirmed && bcTx.cryptoTxId) {
      const cryptoTxId = bcTx.cryptoTxId
      const result = await db.$transaction(async (tx) => {
        const updatedBcTx = await tx.blockchainTransaction.update({
          where: { id: bcTx.id },
          data: {
            confirmations,
            status: 'confirmed',
            confirmedAt: new Date(),
          },
        })

        const cryptoTx = await tx.cryptoTransaction.findFirst({
          where: { id: cryptoTxId },
        })

        if (cryptoTx && cryptoTx.status !== 'completed') {
          await tx.cryptoTransaction.update({
            where: { id: cryptoTx.id },
            data: {
              status: 'completed',
              confirmations,
              completedAt: new Date(),
            },
          })

          // Credit the wallet balance
          if (cryptoTx.walletId) {
            await tx.cryptoWallet.update({
              where: { id: cryptoTx.walletId },
              data: {
                balance: { increment: bcTx.amount },
                availableBalance: { increment: bcTx.amount },
              },
            })
          }
        }

        return updatedBcTx
      })

      await createAuditLog({
        userId: user.id,
        action: 'confirm_blockchain_transaction',
        resource: 'blockchain_transaction',
        resourceId: bcTx.id,
        details: `Confirmed blockchain tx ${txHash.slice(0, 16)}... (${confirmations} confirmations)`,
        request,
      })

      return NextResponse.json(result)
    }

    // Not yet confirmed — just update confirmation count
    const updateData: Record<string, unknown> = {
      confirmations,
    }

    const updatedBcTx = await db.blockchainTransaction.update({
      where: { id: bcTx.id },
      data: updateData,
    })

    return NextResponse.json(updatedBcTx)
  } catch (error) {
    console.error('Blockchain confirmation update error:', error)
    return NextResponse.json({ error: 'Failed to update blockchain confirmation' }, { status: 500 })
  }
}
