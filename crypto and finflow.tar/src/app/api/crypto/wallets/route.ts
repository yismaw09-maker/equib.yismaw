import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, getRoleLevel, createAuditLog } from '@/lib/auth-helpers'
import crypto from 'crypto'

const NETWORK_MAP: Record<string, string> = {
  BTC: 'mainnet',
  ETH: 'erc20',
  USDT: 'trc20',
  USDC: 'erc20',
  XRP: 'mainnet',
  SOL: 'solana',
  DOGE: 'mainnet',
  ADA: 'mainnet',
}

function generateDepositAddress(currency: string): string {
  const prefixMap: Record<string, string> = {
    BTC: 'bc1q',
    ETH: '0x',
    USDT: 'T',
    USDC: '0x',
    XRP: 'r',
    SOL: '',
    DOGE: 'D',
    ADA: 'addr1',
  }

  const prefix = prefixMap[currency.toUpperCase()] ?? '0x'
  const randomBytes = crypto.randomBytes(32)
  const hex = randomBytes.toString('hex').slice(0, 40)
  return `${prefix}${hex}`
}

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const currency = searchParams.get('currency')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}

    // Non-admin users can only see their own wallets
    const userLevel = getRoleLevel(user.role)
    if (userLevel < 45) {
      where.userId = user.id
    }

    // Admin can filter by userId
    if (userId && userLevel >= 45) {
      where.userId = userId
    }
    if (currency) where.currency = currency
    if (status) where.status = status

    const wallets = await db.cryptoWallet.findMany({
      where,
      include: {
        user: { select: { id: true, name: true, email: true, role: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(wallets)
  } catch (error) {
    console.error('Crypto wallets list error:', error)
    return NextResponse.json({ error: 'Failed to load crypto wallets' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    // Validate user exists in database
    const dbUser = await db.user.findUnique({
      where: { id: user.id },
      select: { id: true, status: true },
    })

    if (!dbUser || dbUser.status !== 'active') {
      return NextResponse.json({ error: 'User account is not active or does not exist' }, { status: 403 })
    }

    const body = await request.json()
    const { currency, network, walletType, userId: targetUserId } = body

    if (!currency) {
      return NextResponse.json({ error: 'Missing required field: currency' }, { status: 400 })
    }

    const upperCurrency = currency.toUpperCase()
    const resolvedNetwork = network ?? NETWORK_MAP[upperCurrency] ?? 'mainnet'
    const resolvedWalletType = walletType ?? 'hot'

    const validWalletTypes = ['hot', 'cold']
    if (!validWalletTypes.includes(resolvedWalletType)) {
      return NextResponse.json({ error: 'Invalid wallet type. Must be one of: hot, cold' }, { status: 400 })
    }

    // Determine target user — admin can create for others, otherwise self
    const finalUserId = targetUserId && getRoleLevel(user.role) >= 80 ? targetUserId : user.id

    // Validate target user exists if creating for someone else
    if (finalUserId !== user.id) {
      const targetUser = await db.user.findUnique({
        where: { id: finalUserId },
        select: { id: true, status: true },
      })
      if (!targetUser || targetUser.status !== 'active') {
        return NextResponse.json({ error: 'Target user does not exist or is not active' }, { status: 404 })
      }
    }

    // Check if user already has a wallet for this currency
    const existing = await db.cryptoWallet.findFirst({
      where: { userId: finalUserId, currency: upperCurrency },
    })

    if (existing) {
      return NextResponse.json({ error: `User already has a ${upperCurrency} wallet` }, { status: 400 })
    }

    const depositAddress = generateDepositAddress(upperCurrency)

    const wallet = await db.cryptoWallet.create({
      data: {
        userId: finalUserId,
        currency: upperCurrency,
        balance: 0,
        availableBalance: 0,
        frozenBalance: 0,
        depositAddress,
        network: resolvedNetwork,
        walletType: resolvedWalletType,
        status: 'active',
      },
      include: {
        user: { select: { id: true, name: true, email: true, role: true } },
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create_crypto_wallet',
      resource: 'crypto_wallet',
      resourceId: wallet.id,
      details: `Created ${upperCurrency} wallet for user ${finalUserId}`,
      request,
    })

    return NextResponse.json(wallet, { status: 201 })
  } catch (error) {
    console.error('Crypto wallet create error:', error)
    return NextResponse.json({ error: 'Failed to create crypto wallet' }, { status: 500 })
  }
}
