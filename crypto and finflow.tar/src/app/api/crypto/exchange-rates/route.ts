import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    const where: Record<string, unknown> = { isActive: true }

    if (from && to) {
      where.fromCurrency = from.toUpperCase()
      where.toCurrency = to.toUpperCase()
    } else if (from) {
      where.fromCurrency = from.toUpperCase()
    } else if (to) {
      where.toCurrency = to.toUpperCase()
    }

    const rates = await db.cryptoExchangeRate.findMany({
      where,
      orderBy: { lastUpdated: 'desc' },
    })

    return NextResponse.json(rates)
  } catch (error) {
    console.error('Exchange rates list error:', error)
    return NextResponse.json({ error: 'Failed to load exchange rates' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { fromCurrency, toCurrency } = body

    if (!fromCurrency || !toCurrency) {
      return NextResponse.json({ error: 'Missing required fields: fromCurrency, toCurrency' }, { status: 400 })
    }

    const upperFrom = fromCurrency.toUpperCase()
    const upperTo = toCurrency.toUpperCase()

    // Find the active rate for this pair
    const rate = await db.cryptoExchangeRate.findFirst({
      where: {
        fromCurrency: upperFrom,
        toCurrency: upperTo,
        isActive: true,
      },
    })

    if (!rate) {
      return NextResponse.json({ error: 'No active exchange rate found for this pair' }, { status: 404 })
    }

    // Lock the rate for 30 seconds
    const lockExpiry = new Date(Date.now() + 30000)

    const lockedRate = await db.cryptoExchangeRate.update({
      where: { id: rate.id },
      data: {
        rateLocked: true,
        rateLockExpiry: lockExpiry,
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'lock_exchange_rate',
      resource: 'crypto_exchange_rate',
      resourceId: rate.id,
      details: `Locked ${upperFrom}/${upperTo} rate for 30s`,
      request,
    })

    return NextResponse.json(lockedRate, { status: 201 })
  } catch (error) {
    console.error('Exchange rate lock error:', error)
    return NextResponse.json({ error: 'Failed to lock exchange rate' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { id, rate, fee, feeType, isActive, minAmount, maxAmount } = body

    if (!id) {
      return NextResponse.json({ error: 'Missing required field: id' }, { status: 400 })
    }

    const existing = await db.cryptoExchangeRate.findUnique({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Exchange rate not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = { lastUpdated: new Date() }

    if (rate !== undefined) {
      if (typeof rate !== 'number' || rate <= 0) {
        return NextResponse.json({ error: 'Rate must be a positive number' }, { status: 400 })
      }
      updateData.rate = rate
    }
    if (fee !== undefined) {
      if (typeof fee !== 'number' || fee < 0) {
        return NextResponse.json({ error: 'Fee must be a non-negative number' }, { status: 400 })
      }
      updateData.fee = fee
    }
    if (feeType !== undefined) {
      if (!['percentage', 'fixed'].includes(feeType)) {
        return NextResponse.json({ error: 'feeType must be one of: percentage, fixed' }, { status: 400 })
      }
      updateData.feeType = feeType
    }
    if (isActive !== undefined) {
      updateData.isActive = Boolean(isActive)
    }
    if (minAmount !== undefined) {
      if (typeof minAmount !== 'number' || minAmount < 0) {
        return NextResponse.json({ error: 'minAmount must be a non-negative number' }, { status: 400 })
      }
      updateData.minAmount = minAmount
    }
    if (maxAmount !== undefined) {
      if (typeof maxAmount !== 'number' || maxAmount < 0) {
        return NextResponse.json({ error: 'maxAmount must be a non-negative number' }, { status: 400 })
      }
      updateData.maxAmount = maxAmount
    }

    const updated = await db.cryptoExchangeRate.update({
      where: { id },
      data: updateData,
    })

    await createAuditLog({
      userId: user.id,
      action: 'update_exchange_rate',
      resource: 'crypto_exchange_rate',
      resourceId: id,
      details: `Updated ${existing.fromCurrency}/${existing.toCurrency} exchange rate`,
      request,
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error('Exchange rate update error:', error)
    return NextResponse.json({ error: 'Failed to update exchange rate' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 100)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Missing required query parameter: id' }, { status: 400 })
    }

    const existing = await db.cryptoExchangeRate.findUnique({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Exchange rate not found' }, { status: 404 })
    }

    // Soft-delete by deactivating
    const deactivated = await db.cryptoExchangeRate.update({
      where: { id },
      data: { isActive: false, rateLocked: false, rateLockExpiry: null },
    })

    await createAuditLog({
      userId: user.id,
      action: 'delete_exchange_rate',
      resource: 'crypto_exchange_rate',
      resourceId: id,
      details: `Deactivated ${existing.fromCurrency}/${existing.toCurrency} exchange rate`,
      request,
    })

    return NextResponse.json({ message: 'Exchange rate deactivated successfully', rate: deactivated })
  } catch (error) {
    console.error('Exchange rate delete error:', error)
    return NextResponse.json({ error: 'Failed to delete exchange rate' }, { status: 500 })
  }
}
