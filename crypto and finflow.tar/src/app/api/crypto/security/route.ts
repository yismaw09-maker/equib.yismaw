import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, createAuditLog } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 55)
    if (isErrorResponse(auth)) return auth

    const { searchParams } = new URL(request.url)
    const eventType = searchParams.get('eventType')
    const severity = searchParams.get('severity')
    const userId = searchParams.get('userId')

    const where: Record<string, unknown> = {}
    if (eventType) where.eventType = eventType
    if (severity) where.severity = severity
    if (userId) where.userId = userId

    const events = await db.cryptoSecurityEvent.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(events)
  } catch (error) {
    console.error('Security events list error:', error)
    return NextResponse.json({ error: 'Failed to load security events' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { eventType, severity, title, description, userId: targetUserId } = body

    if (!eventType || !title) {
      return NextResponse.json({ error: 'Missing required fields: eventType, title' }, { status: 400 })
    }

    const validEventTypes = ['kyc_check', 'aml_screen', '2fa_toggle', 'withdrawal_approval', 'limit_change', 'fraud_alert', 'cold_wallet_transfer', 'audit_log']
    if (!validEventTypes.includes(eventType)) {
      return NextResponse.json({ error: `Invalid eventType. Must be one of: ${validEventTypes.join(', ')}` }, { status: 400 })
    }

    const validSeverities = ['info', 'warning', 'critical']
    const resolvedSeverity = severity ?? 'info'
    if (!validSeverities.includes(resolvedSeverity)) {
      return NextResponse.json({ error: 'Invalid severity. Must be one of: info, warning, critical' }, { status: 400 })
    }

    // Only allow specifying a target userId for admin+ roles
    const resolvedUserId = targetUserId ?? user.id

    const event = await db.cryptoSecurityEvent.create({
      data: {
        userId: resolvedUserId,
        eventType,
        severity: resolvedSeverity,
        title,
        description: description ?? null,
        metadata: null,
        createdAt: new Date(),
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create_security_event',
      resource: 'crypto_security_event',
      resourceId: event.id,
      details: `Created ${eventType} security event (${resolvedSeverity}) for user ${resolvedUserId}`,
      request,
    })

    return NextResponse.json(event, { status: 201 })
  } catch (error) {
    console.error('Security event create error:', error)
    return NextResponse.json({ error: 'Failed to create security event' }, { status: 500 })
  }
}
