import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isErrorResponse, getRoleLevel, createAuditLog } from '@/lib/auth-helpers'
import crypto from 'crypto'

function generateReference(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  const seg1 = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
  const seg2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
  return `CRX-${seg1}-${seg2}`
}

const NETWORK_FEE_MAP: Record<string, number> = {
  BTC: 0.0001,
  ETH: 0.003,
  USDT: 1.0,
  USDC: 1.0,
  XRP: 0.0002,
  SOL: 0.00001,
  DOGE: 1.0,
  ADA: 0.2,
}

const REQUIRED_CONFS_MAP: Record<string, number> = {
  BTC: 3,
  ETH: 12,
  USDT: 6,
  USDC: 6,
  XRP: 3,
  SOL: 12,
  DOGE: 6,
  ADA: 15,
}

export async function GET(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const currency = searchParams.get('currency')
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1') || 1)
    const limit = Math.min(200, Math.max(1, parseInt(searchParams.get('limit') ?? '20') || 20))

    const where: Record<string, unknown> = {}

    // Non-admin users can only see their own transactions
    const userLevel = getRoleLevel(user.role)
    if (userLevel < 45) {
      where.userId = user.id
    } else if (userId) {
      where.userId = userId
    }

    if (currency) where.currency = currency
    if (type) where.type = type
    if (status) where.status = status

    const [transactions, total, summaryResult] = await Promise.all([
      db.cryptoTransaction.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true, role: true } },
          wallet: { select: { id: true, currency: true, network: true, depositAddress: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.cryptoTransaction.count({ where }),
      db.cryptoTransaction.aggregate({
        where,
        _sum: { amount: true, fee: true },
        _count: true,
      }),
    ])

    const pendingCount = await db.cryptoTransaction.count({
      where: { ...where, status: 'pending' },
    })

    return NextResponse.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      summary: {
        totalVolume: summaryResult._sum.amount ?? 0,
        totalFees: summaryResult._sum.fee ?? 0,
        pendingCount,
      },
    })
  } catch (error) {
    console.error('Crypto transactions list error:', error)
    return NextResponse.json({ error: 'Failed to load crypto transactions' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { type, currency, amount, walletId, toAddress, toCurrency, description } = body

    if (!type || !currency || !amount || !walletId) {
      return NextResponse.json({ error: 'Missing required fields: type, currency, amount, walletId' }, { status: 400 })
    }

    if (typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json({ error: 'Amount must be a positive number' }, { status: 400 })
    }

    const validTypes = ['deposit', 'withdrawal', 'send', 'exchange']
    if (!validTypes.includes(type)) {
      return NextResponse.json({ error: 'Invalid transaction type. Must be one of: deposit, withdrawal, send, exchange' }, { status: 400 })
    }

    const upperCurrency = currency.toUpperCase()
    const networkFee = NETWORK_FEE_MAP[upperCurrency] ?? 0
    const reference = generateReference()

    // Validate wallet exists and belongs to user
    const wallet = await db.cryptoWallet.findFirst({
      where: { id: walletId, userId: user.id, currency: upperCurrency },
    })

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet not found or currency mismatch' }, { status: 404 })
    }

    // ── SEND / WITHDRAWAL: validate balance and deduct atomically ──
    if (type === 'withdrawal' || type === 'send') {
      if (!toAddress) {
        return NextResponse.json({ error: 'toAddress is required for withdrawal and send transactions' }, { status: 400 })
      }

      // Atomic balance check + deduction inside a transaction
      const result = await db.$transaction(async (tx) => {
        // Re-read wallet with row lock (Prisma doesn't have SELECT FOR UPDATE,
        // but the transaction serializes the operations)
        const freshWallet = await tx.cryptoWallet.findFirst({
          where: { id: walletId, userId: user.id },
        })

        if (!freshWallet || freshWallet.availableBalance < amount) {
          throw new Error('INSUFFICIENT_BALANCE')
        }

        const [updatedWallet, transaction] = await Promise.all([
          tx.cryptoWallet.update({
            where: { id: walletId },
            data: {
              balance: { decrement: amount },
              availableBalance: { decrement: amount },
            },
          }),
          tx.cryptoTransaction.create({
            data: {
              reference,
              type,
              status: 'pending',
              amount,
              fee: networkFee,
              feeCurrency: upperCurrency,
              currency: upperCurrency,
              description: description ?? null,
              userId: user.id,
              walletId,
              toAddress,
              fromAddress: wallet.depositAddress,
              network: wallet.network,
              networkFee,
              confirmations: 0,
              requiredConfirmations: REQUIRED_CONFS_MAP[upperCurrency] ?? 6,
            },
            include: {
              user: { select: { id: true, name: true, email: true, role: true } },
              wallet: { select: { id: true, currency: true, network: true, depositAddress: true } },
            },
          }),
        ])

        return { updatedWallet, transaction }
      })

      await createAuditLog({
        userId: user.id,
        action: `crypto_${type}`,
        resource: 'crypto_transaction',
        resourceId: result.transaction.id,
        details: `${type} ${amount} ${upperCurrency} to ${toAddress.slice(0, 16)}...`,
        request,
      })

      return NextResponse.json(result.transaction, { status: 201 })
    }

    // ── DEPOSIT: add amount to wallet atomically ──
    if (type === 'deposit') {
      const result = await db.$transaction(async (tx) => {
        const [updatedWallet, transaction] = await Promise.all([
          tx.cryptoWallet.update({
            where: { id: walletId },
            data: {
              balance: { increment: amount },
              availableBalance: { increment: amount },
            },
          }),
          tx.cryptoTransaction.create({
            data: {
              reference,
              type: 'deposit',
              status: 'completed',
              amount,
              fee: 0,
              feeCurrency: upperCurrency,
              currency: upperCurrency,
              description: description ?? null,
              userId: user.id,
              walletId,
              toAddress: toAddress ?? wallet.depositAddress,
              fromAddress: wallet.depositAddress,
              network: wallet.network,
              networkFee,
              confirmations: 0,
              requiredConfirmations: REQUIRED_CONFS_MAP[upperCurrency] ?? 6,
              completedAt: new Date(),
            },
            include: {
              user: { select: { id: true, name: true, email: true, role: true } },
              wallet: { select: { id: true, currency: true, network: true, depositAddress: true } },
            },
          }),
        ])

        return { updatedWallet, transaction }
      })

      await createAuditLog({
        userId: user.id,
        action: 'crypto_deposit',
        resource: 'crypto_transaction',
        resourceId: result.transaction.id,
        details: `Deposit ${amount} ${upperCurrency} to wallet ${walletId}`,
        request,
      })

      return NextResponse.json(result.transaction, { status: 201 })
    }

    // ── EXCHANGE: validate both wallets, atomic swap ──
    if (type === 'exchange') {
      if (!toCurrency) {
        return NextResponse.json({ error: 'toCurrency is required for exchange transactions' }, { status: 400 })
      }

      const upperToCurrency = toCurrency.toUpperCase()

      // Get exchange rate
      const exchangeRateRecord = await db.cryptoExchangeRate.findFirst({
        where: {
          fromCurrency: upperCurrency,
          toCurrency: upperToCurrency,
          isActive: true,
        },
      })

      if (!exchangeRateRecord) {
        return NextResponse.json({ error: 'No active exchange rate found for this pair' }, { status: 400 })
      }

      const exchangeRate = exchangeRateRecord.rate
      const fee = exchangeRateRecord.feeType === 'percentage'
        ? (amount * exchangeRateRecord.fee) / 100
        : exchangeRateRecord.fee
      const toAmount = (amount - fee) * exchangeRate

      // Check min/max amounts
      if (exchangeRateRecord.minAmount && amount < exchangeRateRecord.minAmount) {
        return NextResponse.json({ error: `Minimum exchange amount is ${exchangeRateRecord.minAmount} ${upperCurrency}` }, { status: 400 })
      }
      if (exchangeRateRecord.maxAmount && amount > exchangeRateRecord.maxAmount) {
        return NextResponse.json({ error: `Maximum exchange amount is ${exchangeRateRecord.maxAmount} ${upperCurrency}` }, { status: 400 })
      }

      // Atomic swap inside a transaction
      const result = await db.$transaction(async (tx) => {
        // Re-validate source wallet balance inside transaction
        const freshSourceWallet = await tx.cryptoWallet.findFirst({
          where: { id: walletId, userId: user.id },
        })

        if (!freshSourceWallet || freshSourceWallet.availableBalance < amount) {
          throw new Error('INSUFFICIENT_BALANCE')
        }

        // Find or create destination wallet
        let destWallet = await tx.cryptoWallet.findFirst({
          where: { userId: user.id, currency: upperToCurrency },
        })

        if (!destWallet) {
          const prefixMap: Record<string, string> = {
            BTC: 'bc1q', ETH: '0x', USDT: 'T', USDC: '0x', XRP: 'r', SOL: '', DOGE: 'D', ADA: 'addr1',
          }
          const prefix = prefixMap[upperToCurrency] ?? '0x'
          const randomBytes = crypto.randomBytes(32)
          const hex = randomBytes.toString('hex').slice(0, 40)
          const depositAddress = `${prefix}${hex}`

          const networkMap: Record<string, string> = {
            BTC: 'mainnet', ETH: 'erc20', USDT: 'trc20', USDC: 'erc20', XRP: 'mainnet', SOL: 'solana', DOGE: 'mainnet', ADA: 'mainnet',
          }

          destWallet = await tx.cryptoWallet.create({
            data: {
              userId: user.id,
              currency: upperToCurrency,
              balance: 0,
              availableBalance: 0,
              frozenBalance: 0,
              depositAddress,
              network: networkMap[upperToCurrency] ?? 'mainnet',
              walletType: 'hot',
              status: 'active',
            },
          })
        }

        // Debit source, credit destination, create transaction record — all atomically
        const [updatedSource, updatedDest, transaction] = await Promise.all([
          tx.cryptoWallet.update({
            where: { id: walletId },
            data: {
              balance: { decrement: amount },
              availableBalance: { decrement: amount },
            },
          }),
          tx.cryptoWallet.update({
            where: { id: destWallet.id },
            data: {
              balance: { increment: toAmount },
              availableBalance: { increment: toAmount },
            },
          }),
          tx.cryptoTransaction.create({
            data: {
              reference,
              type: 'exchange',
              status: 'completed',
              amount,
              fee,
              feeCurrency: upperCurrency,
              currency: upperCurrency,
              fromCurrency: upperCurrency,
              toCurrency: upperToCurrency,
              exchangeRate,
              description: description ?? `Exchange ${upperCurrency} to ${upperToCurrency}`,
              userId: user.id,
              walletId,
              toWalletId: destWallet.id,
              network: wallet.network,
              networkFee,
              confirmations: 0,
              requiredConfirmations: 1,
              completedAt: new Date(),
            },
            include: {
              user: { select: { id: true, name: true, email: true, role: true } },
              wallet: { select: { id: true, currency: true, network: true } },
            },
          }),
        ])

        return { updatedSource, updatedDest, transaction }
      })

      await createAuditLog({
        userId: user.id,
        action: 'crypto_exchange',
        resource: 'crypto_transaction',
        resourceId: result.transaction.id,
        details: `Exchange ${amount} ${upperCurrency} to ${toAmount} ${upperToCurrency} (rate: ${exchangeRate})`,
        request,
      })

      return NextResponse.json(result.transaction, { status: 201 })
    }

    // Fallback (should not reach here)
    return NextResponse.json({ error: 'Invalid transaction type' }, { status: 400 })
  } catch (error) {
    if (error instanceof Error && error.message === 'INSUFFICIENT_BALANCE') {
      return NextResponse.json({ error: 'Insufficient available balance' }, { status: 400 })
    }
    console.error('Crypto transaction create error:', error)
    return NextResponse.json({ error: 'Failed to create crypto transaction' }, { status: 500 })
  }
}
