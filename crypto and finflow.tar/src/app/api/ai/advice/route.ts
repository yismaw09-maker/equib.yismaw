import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const SYSTEM_PROMPT = `You are FinFlow's AI Financial Advisor for Ethiopian businesses and individuals. Analyze the transaction and provide structured advice.

You MUST respond with valid JSON only (no markdown, no code fences, no extra text). The JSON must have this exact structure:
{
  "summary": "One sentence summary of the transaction",
  "riskLevel": "low" | "medium" | "high",
  "riskNotes": "Brief explanation of risk assessment",
  "insights": ["Insight 1", "Insight 2"],
  "recommendations": ["Recommendation 1", "Recommendation 2"],
  "regulatoryNote": "Any NBE or Ethiopian banking regulation note if applicable, or null"
}

Consider:
- Transaction amount relative to typical Ethiopian transaction volumes
- Risk indicators (unusual amounts, new recipients, high-frequency transfers)
- NBE (National Bank of Ethiopia) guidelines and foreign exchange rules
- Currency considerations (ETB, USD, EUR)
- Business context, time of transaction, and patterns
- Fee optimization suggestions
- Cash flow and budgeting advice

Keep all text concise (1-2 sentences each). Be practical and specific to Ethiopian banking.`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { transactions, context, transaction } = body;

    // Support single transaction object (new format) or array (legacy format)
    const txns = transaction
      ? [transaction]
      : transactions;

    if (!txns || !Array.isArray(txns) || txns.length === 0) {
      return NextResponse.json({ error: 'Transaction(s) required' }, { status: 400 });
    }

    const txnSummary = txns.map((t: Record<string, unknown>) => {
      const parts = [
        `Ref: ${t.reference || 'N/A'}`,
        `Type: ${t.type || 'N/A'}`,
        `Amount: ${t.currency || 'ETB'} ${Number(t.amount || 0).toLocaleString()}`,
        `Fee: ${t.fee != null ? Number(t.fee).toLocaleString() : 'N/A'}`,
        `Status: ${t.status || 'N/A'}`,
      ];
      if (t.riskScore) parts.push(`Risk Score: ${(Number(t.riskScore) * 100).toFixed(1)}%`);
      if (t.fraudFlag) parts.push('⚠️ FRAUD FLAGGED');
      if (t.initiatorName) parts.push(`By: ${t.initiatorName}`);
      if (t.recipientName) parts.push(`To: ${t.recipientName}`);
      if (t.bankName) parts.push(`Bank: ${t.bankName}`);
      if (t.description) parts.push(`Desc: ${t.description}`);
      if (t.paymentMethod) parts.push(`Method: ${t.paymentMethod}`);
      return parts.join(' | ');
    }).join('\n');

    const userMessage = context
      ? `Context: ${context}\n\nTransactions:\n${txnSummary}\n\nProvide structured JSON advice.`
      : `Analyze these transactions and provide structured JSON advice:\n\n${txnSummary}`;

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ],
      thinking: { type: 'disabled' },
    });

    const raw = completion.choices?.[0]?.message?.content || '';

    // Parse the JSON response
    let parsed;
    try {
      // Handle potential markdown code fences
      const cleaned = raw.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
      parsed = JSON.parse(cleaned);
    } catch {
      // Fallback: wrap raw text in the structure
      parsed = {
        summary: raw,
        riskLevel: 'low',
        riskNotes: null,
        insights: [],
        recommendations: [],
        regulatoryNote: null,
      };
    }

    return NextResponse.json({ success: true, advice: parsed, rawText: raw });
  } catch (error) {
    console.error('AI advice error:', error);
    return NextResponse.json(
      { success: false, advice: null, error: 'Failed to generate AI advice. Please try again later.' },
      { status: 500 }
    );
  }
}
