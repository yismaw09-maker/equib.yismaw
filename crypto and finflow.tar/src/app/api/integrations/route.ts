import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireMinLevel, isErrorResponse, parsePagination, createAuditLog } from '@/lib/auth-helpers'
import { isNonEmptyString } from '@/lib/shared/validators'

export async function GET(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 60)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)

    const type = searchParams.get('type')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}
    if (type) where.type = type
    if (status) where.status = status

    const [integrations, total] = await Promise.all([
      db.integration.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.integration.count({ where }),
    ])

    await createAuditLog({
      userId: user.id,
      action: 'view',
      resource: 'integration',
      details: 'Viewed integrations',
      request,
    })

    return NextResponse.json({
      integrations,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Integrations list error:', error)
    return NextResponse.json({ error: 'Failed to load integrations' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = requireMinLevel(request, 80)
    if (isErrorResponse(auth)) return auth
    const { user } = auth

    const body = await request.json()
    const { name, type, provider, description, config } = body

    if (!isNonEmptyString(name)) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }
    if (!isNonEmptyString(type)) {
      return NextResponse.json({ error: 'Type is required' }, { status: 400 })
    }
    if (!isNonEmptyString(provider)) {
      return NextResponse.json({ error: 'Provider is required' }, { status: 400 })
    }

    const integration = await db.integration.create({
      data: {
        name,
        type,
        provider,
        description: description || null,
        config: typeof config === 'string' ? config : config ? JSON.stringify(config) : null,
      },
    })

    await createAuditLog({
      userId: user.id,
      action: 'create',
      resource: 'integration',
      resourceId: integration.id,
      details: `Created integration: ${name} (${type} - ${provider})`,
      request,
    })

    return NextResponse.json({ integration }, { status: 201 })
  } catch (error) {
    console.error('Integration create error:', error)
    return NextResponse.json({ error: 'Failed to create integration' }, { status: 500 })
  }
}
