import { useCallback } from 'react';
import { useI18n } from '@/lib/i18n';

export function useFormattedDate() {
  const { locale } = useI18n();

  const formatDate = useCallback(
    (date: string | Date, options?: Intl.DateTimeFormatOptions) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(d.getTime())) return '—';
      const localeStr = locale === 'am' ? 'am-ET' : 'en-US';
      const defaults: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        ...options,
      };
      return new Intl.DateTimeFormat(localeStr, defaults).format(d);
    },
    [locale]
  );

  const formatTime = useCallback(
    (date: string | Date) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(d.getTime())) return '—';
      const localeStr = locale === 'am' ? 'am-ET' : 'en-US';
      return new Intl.DateTimeFormat(localeStr, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }).format(d);
    },
    [locale]
  );

  const formatDateTime = useCallback(
    (date: string | Date) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(d.getTime())) return '—';
      const localeStr = locale === 'am' ? 'am-ET' : 'en-US';
      return new Intl.DateTimeFormat(localeStr, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      }).format(d);
    },
    [locale]
  );

  const formatRelative = useCallback(
    (date: string | Date) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(d.getTime())) return '—';
      const now = new Date();
      const diffMs = now.getTime() - d.getTime();
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffSecs < 60) return locale === 'am' ? 'አሁን' : 'Just now';
      if (diffMins < 60) return locale === 'am' ? `ከ${diffMins} ደቂት በፊት` : `${diffMins}m ago`;
      if (diffHours < 24) return locale === 'am' ? `ከ${diffHours} ሰዓት በፊት` : `${diffHours}h ago`;
      if (diffDays < 7) return locale === 'am' ? `ከ${diffDays} ቀናት በፊት` : `${diffDays}d ago`;
      return formatDate(d);
    },
    [locale, formatDate]
  );

  return { formatDate, formatTime, formatDateTime, formatRelative };
}
