'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  RefreshCw,
  ArrowRightLeft,
  Wallet,
  TrendingUp,
  TrendingDown,
  Edit2,
  Check,
  Loader2,
  Power,
  Database,
  Send,
  Download,
  ArrowDownLeft,
  ArrowUpRight,
  MoreHorizontal,
  Eye,
  Globe,
  ArrowRightLeftIcon,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Line, LineChart, XAxis, YAxis } from 'recharts';
import { cn } from '@/lib/utils';
import { getCurrencyFlag } from '@/lib/currency-flags';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface Currency {
  id: string;
  code: string;
  name: string;
  symbol: string;
  exchangeRate: number;
  isActive: boolean;
  lastUpdated: string;
  createdAt: string;
}

interface WalletItem {
  id: string;
  userId: string;
  currency: string;
  balance: number;
  availableBalance: number;
  frozenBalance: number;
  type: string;
  status: string;
  user: { id: string; name: string; email: string; role: string };
}

interface ForexTransaction {
  id: string;
  reference: string;
  type: string;
  fromCurrency: string;
  toCurrency: string;
  fromAmount: number;
  toAmount: number;
  exchangeRate: number;
  fee: number;
  feeCurrency: string;
  status: string;
  initiatorId: string | null;
  recipientName: string | null;
  recipientPhone: string | null;
  recipientEmail: string | null;
  recipientWallet: string | null;
  description: string | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
  initiator?: { id: string; name: string; email: string } | null;
}

interface CurrencyAgg {
  currency: string;
  totalBalance: number;
  totalAvailable: number;
  totalFrozen: number;
  walletCount: number;
  etbEquivalent: number;
}

interface ExchangeStats {
  totalTransactions: number;
  buyVolume: number;
  sellVolume: number;
  sendReceiveVolume: number;
}

// --- Constants ---


const trendChartConfig = {
  rate: { label: 'Exchange Rate', color: 'hsl(160, 84%, 39%)' },
};

function seededRandom(seed: number) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

const generateTrendData = (baseRate: number, currencyCode: string): { date: string; rate: number }[] => {
  const data: { date: string; rate: number }[] = [];
  const now = new Date();
  let seed = currencyCode.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
  for (let i = 6; i >= 0; i--) {
    seed += 1;
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    const variation = (seededRandom(seed) - 0.5) * baseRate * 0.04;
    data.push({
      date: format(date, 'MMM d'),
      rate: parseFloat((baseRate + variation).toFixed(4)),
    });
  }
  return data;
};

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

// --- Helper Functions ---

function formatRate(rate: number): string {
  if (rate === 1) return '1.0000';
  if (rate < 1) return rate.toFixed(4);
  return rate.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function formatCurrency(amount: number, code: string): string {
  return `${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${code}`;
}

function getTypeBadgeColor(type: string): string {
  switch (type) {
    case 'buy': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400';
    case 'sell': return 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-400';
    case 'send': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400';
    case 'receive': return 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-400';
    default: return 'bg-gray-100 text-gray-700 dark:bg-gray-900/40 dark:text-gray-400';
  }
}

function getStatusBadgeColor(status: string): string {
  switch (status) {
    case 'completed': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400';
    case 'pending': return 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400';
    case 'failed': return 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400';
    case 'processing': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400';
    case 'cancelled': return 'bg-gray-100 text-gray-700 dark:bg-gray-900/40 dark:text-gray-400';
    default: return 'bg-gray-100 text-gray-700 dark:bg-gray-900/40 dark:text-gray-400';
  }
}

const FEE_RATE = 0.005;
const ITEMS_PER_PAGE = 10;

// --- Main Component ---

export default function CurrenciesView() {
  const { formatDateTime } = useFormattedDate();
  // Core data
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [wallets, setWallets] = useState<WalletItem[]>([]);
  const [forexTransactions, setForexTransactions] = useState<ForexTransaction[]>([]);
  const [stats, setStats] = useState<ExchangeStats | null>(null);

  // Loading states
  const [currenciesLoading, setCurrenciesLoading] = useState(true);
  const [walletsLoading, setWalletsLoading] = useState(true);
  const [transactionsLoading, setTransactionsLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [updatingRates, setUpdatingRates] = useState(false);
  const [seedingData, setSeedingData] = useState(false);

  // Edit dialog
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingCurrency, setEditingCurrency] = useState<Currency | null>(null);
  const [newRate, setNewRate] = useState('');
  const [savingRate, setSavingRate] = useState(false);

  // Toggle loading state
  const [togglingId, setTogglingId] = useState<string | null>(null);

  // Transaction detail dialog
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<ForexTransaction | null>(null);

  // Trend chart
  const [trendData, setTrendData] = useState<{ date: string; rate: number }[]>([]);
  const [trendCurrency, setTrendCurrency] = useState('USD');

  // Transaction filters & pagination
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);

  // Buy form state
  const [buyCurrency, setBuyCurrency] = useState('');
  const [buyAmount, setBuyAmount] = useState('');
  const [buyLoading, setBuyLoading] = useState(false);

  // Sell form state
  const [sellCurrency, setSellCurrency] = useState('');
  const [sellAmount, setSellAmount] = useState('');
  const [sellLoading, setSellLoading] = useState(false);

  // Send form state
  const [sendFromCurrency, setSendFromCurrency] = useState('');
  const [sendToCurrency, setSendToCurrency] = useState('');
  const [sendAmount, setSendAmount] = useState('');
  const [sendRecipientName, setSendRecipientName] = useState('');
  const [sendRecipientEmail, setSendRecipientEmail] = useState('');
  const [sendRecipientPhone, setSendRecipientPhone] = useState('');
  const [sendDescription, setSendDescription] = useState('');
  const [sendLoading, setSendLoading] = useState(false);

  // Receive form state
  const [receiveFromCurrency, setReceiveFromCurrency] = useState('');
  const [receiveToCurrency, setReceiveToCurrency] = useState('ETB');
  const [receiveAmount, setReceiveAmount] = useState('');
  const [receiveSenderName, setReceiveSenderName] = useState('');
  const [receiveDescription, setReceiveDescription] = useState('');
  const [receiveLoading, setReceiveLoading] = useState(false);

  // Action loading on transaction
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // --- Data Fetching ---

  const fetchCurrencies = useCallback(async () => {
    try {
      const res = await apiFetch('/api/currencies');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setCurrencies(data);
      const nonEtb = data.find((c: Currency) => c.code !== 'ETB' && c.isActive);
      if (nonEtb) {
        setTrendCurrency(nonEtb.code);
        setTrendData(generateTrendData(nonEtb.exchangeRate, nonEtb.code));
      }
    } catch {
      toast.error('Failed to load currencies');
    } finally {
      setCurrenciesLoading(false);
    }
  }, []);

  const fetchWallets = useCallback(async () => {
    try {
      const res = await apiFetch('/api/wallets');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setWallets(data);
    } catch {
      toast.error('Failed to load wallets');
    } finally {
      setWalletsLoading(false);
    }
  }, []);

  const fetchTransactions = useCallback(async () => {
    try {
      const res = await apiFetch('/api/currency-exchange');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setForexTransactions(Array.isArray(data) ? data : data.transactions || []);
    } catch {
      toast.error('Failed to load transactions');
    } finally {
      setTransactionsLoading(false);
    }
  }, []);

  const fetchStats = useCallback(async () => {
    try {
      const res = await apiFetch('/api/currency-exchange?type=stats');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setStats(data);
    } catch {
      toast.error('Failed to load stats');
    } finally {
      setStatsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCurrencies();
    fetchWallets();
    fetchTransactions();
    fetchStats();
  }, [fetchCurrencies, fetchWallets, fetchTransactions, fetchStats]);

  // --- Derived Data ---

  const currencyMap = useMemo(() => {
    const map: Record<string, Currency> = {};
    currencies.forEach((c) => { map[c.code] = c; });
    return map;
  }, [currencies]);

  const activeCurrencies = useMemo(() => currencies.filter((c) => c.isActive), [currencies]);
  const activeNonEtb = useMemo(() => activeCurrencies.filter((c) => c.code !== 'ETB'), [activeCurrencies]);

  const currencySummary = useMemo((): CurrencyAgg[] => {
    const agg: Record<string, { totalBalance: number; totalAvailable: number; totalFrozen: number; walletCount: number }> = {};
    wallets.forEach((w) => {
      if (!agg[w.currency]) {
        agg[w.currency] = { totalBalance: 0, totalAvailable: 0, totalFrozen: 0, walletCount: 0 };
      }
      agg[w.currency].totalBalance += w.balance;
      agg[w.currency].totalAvailable += w.availableBalance;
      agg[w.currency].totalFrozen += w.frozenBalance;
      agg[w.currency].walletCount += 1;
    });
    return Object.entries(agg)
      .map(([currency, data]) => ({
        currency,
        ...data,
        etbEquivalent:
          currency === 'ETB'
            ? data.totalBalance
            : data.totalBalance * (currencyMap[currency]?.exchangeRate || 1),
      }))
      .sort((a, b) => b.etbEquivalent - a.etbEquivalent);
  }, [wallets, currencyMap]);

  const totalEtbEquivalent = currencySummary.reduce((sum, c) => sum + c.etbEquivalent, 0);

  // Filtered & paginated transactions
  const filteredTransactions = useMemo(() => {
    return forexTransactions.filter((t) => {
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (typeFilter !== 'all' && t.type !== typeFilter) return false;
      return true;
    });
  }, [forexTransactions, statusFilter, typeFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredTransactions.length / ITEMS_PER_PAGE));
  const paginatedTransactions = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredTransactions.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredTransactions, currentPage]);

  // Buy calculations
  const buyRate = useMemo(() => {
    return currencyMap[buyCurrency]?.exchangeRate || 0;
  }, [buyCurrency, currencyMap]);
  const buyPayAmount = useMemo(() => {
    const amt = parseFloat(buyAmount) || 0;
    return amt * buyRate;
  }, [buyAmount, buyRate]);
  const buyFee = useMemo(() => buyPayAmount * FEE_RATE, [buyPayAmount]);

  // Sell calculations
  const sellRate = useMemo(() => {
    return currencyMap[sellCurrency]?.exchangeRate || 0;
  }, [sellCurrency, currencyMap]);
  const sellReceiveAmount = useMemo(() => {
    const amt = parseFloat(sellAmount) || 0;
    return amt * sellRate;
  }, [sellAmount, sellRate]);
  const sellFee = useMemo(() => sellReceiveAmount * FEE_RATE, [sellReceiveAmount]);

  // Send calculations
  const sendRate = useMemo(() => {
    if (!sendFromCurrency || !sendToCurrency) return 0;
    if (sendFromCurrency === sendToCurrency) return 1;
    const fromRate = currencyMap[sendFromCurrency]?.exchangeRate || 1;
    const toRate = currencyMap[sendToCurrency]?.exchangeRate || 1;
    return fromRate / toRate;
  }, [sendFromCurrency, sendToCurrency, currencyMap]);
  const sendRecipientGets = useMemo(() => {
    const amt = parseFloat(sendAmount) || 0;
    const converted = amt * sendRate;
    const fee = converted * FEE_RATE;
    return Math.max(0, converted - fee);
  }, [sendAmount, sendRate]);
  const sendFee = useMemo(() => {
    const amt = parseFloat(sendAmount) || 0;
    return (amt * sendRate) * FEE_RATE;
  }, [sendAmount, sendRate]);

  // Receive calculations
  const receiveRate = useMemo(() => {
    if (!receiveFromCurrency || !receiveToCurrency) return 0;
    if (receiveFromCurrency === receiveToCurrency) return 1;
    const fromRate = currencyMap[receiveFromCurrency]?.exchangeRate || 1;
    const toRate = currencyMap[receiveToCurrency]?.exchangeRate || 1;
    return fromRate / toRate;
  }, [receiveFromCurrency, receiveToCurrency, currencyMap]);
  const receiveConverted = useMemo(() => {
    const amt = parseFloat(receiveAmount) || 0;
    return amt * receiveRate;
  }, [receiveAmount, receiveRate]);
  const receiveFee = useMemo(() => receiveConverted * FEE_RATE, [receiveConverted]);

  // --- Handlers ---

  const handleSeedData = async () => {
    setSeedingData(true);
    try {
      const res = await apiFetch('/api/seed-currency-exchange', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to seed');
      toast.success('Sample currency exchange data seeded successfully');
      fetchTransactions();
      fetchStats();
    } catch {
      toast.error('Failed to seed exchange data');
    } finally {
      setSeedingData(false);
    }
  };

  const handleUpdateRates = async () => {
    setUpdatingRates(true);
    try {
      for (const currency of currencies) {
        if (currency.code !== 'ETB') {
          const variation = (Math.random() - 0.5) * currency.exchangeRate * 0.02;
          await apiFetch('/api/currencies', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: currency.id,
              exchangeRate: parseFloat((currency.exchangeRate + variation).toFixed(4)),
            }),
          });
        }
      }
      toast.success('Exchange rates updated successfully');
      fetchCurrencies();
    } catch {
      toast.error('Failed to update exchange rates');
    } finally {
      setUpdatingRates(false);
    }
  };

  const openEditDialog = (currency: Currency) => {
    setEditingCurrency(currency);
    setNewRate(currency.exchangeRate.toString());
    setEditDialogOpen(true);
  };

  const handleSaveRate = async () => {
    if (!editingCurrency || !newRate) return;
    const rate = parseFloat(newRate);
    if (isNaN(rate) || rate <= 0) {
      toast.error('Please enter a valid positive exchange rate');
      return;
    }
    setSavingRate(true);
    try {
      const res = await apiFetch('/api/currencies', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingCurrency.id, exchangeRate: rate }),
      });
      if (!res.ok) throw new Error('Failed to update');
      toast.success(`${editingCurrency.code} rate updated to ${rate}`);
      setEditDialogOpen(false);
      fetchCurrencies();
    } catch {
      toast.error('Failed to update exchange rate');
    } finally {
      setSavingRate(false);
    }
  };

  const handleToggleActive = async (currency: Currency) => {
    setTogglingId(currency.id);
    try {
      const res = await apiFetch('/api/currencies', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: currency.id, isActive: !currency.isActive }),
      });
      if (!res.ok) throw new Error('Failed to toggle');
      toast.success(`${currency.code} ${!currency.isActive ? 'activated' : 'deactivated'} successfully`);
      fetchCurrencies();
    } catch {
      toast.error(`Failed to toggle ${currency.code} status`);
    } finally {
      setTogglingId(null);
    }
  };

  const handleTrendCurrencyChange = (code: string) => {
    setTrendCurrency(code);
    const c = currencyMap[code];
    if (c) {
      setTrendData(generateTrendData(c.exchangeRate, c.code));
    }
  };

  // Buy handler
  const handleBuy = async () => {
    if (!buyCurrency) { toast.error('Please select a currency to buy'); return; }
    const amt = parseFloat(buyAmount);
    if (!amt || amt <= 0) { toast.error('Please enter a valid amount to buy'); return; }
    setBuyLoading(true);
    try {
      const res = await apiFetch('/api/currency-exchange', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'buy',
          fromCurrency: 'ETB',
          toCurrency: buyCurrency,
          fromAmount: buyPayAmount + buyFee,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(`Successfully bought ${formatCurrency(amt, buyCurrency)}`);
      setBuyCurrency('');
      setBuyAmount('');
      fetchTransactions();
      fetchStats();
      fetchWallets();
    } catch {
      toast.error('Failed to complete buy transaction');
    } finally {
      setBuyLoading(false);
    }
  };

  // Sell handler
  const handleSell = async () => {
    if (!sellCurrency) { toast.error('Please select a currency to sell'); return; }
    const amt = parseFloat(sellAmount);
    if (!amt || amt <= 0) { toast.error('Please enter a valid amount to sell'); return; }
    setSellLoading(true);
    try {
      const res = await apiFetch('/api/currency-exchange', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'sell',
          fromCurrency: sellCurrency,
          toCurrency: 'ETB',
          fromAmount: amt,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(`Successfully sold ${formatCurrency(amt, sellCurrency)}`);
      setSellCurrency('');
      setSellAmount('');
      fetchTransactions();
      fetchStats();
      fetchWallets();
    } catch {
      toast.error('Failed to complete sell transaction');
    } finally {
      setSellLoading(false);
    }
  };

  // Send handler
  const handleSend = async () => {
    if (!sendFromCurrency) { toast.error('Please select a send currency'); return; }
    if (!sendToCurrency) { toast.error('Please select a receive currency'); return; }
    if (sendFromCurrency === sendToCurrency) { toast.error('Send and receive currencies must be different'); return; }
    const amt = parseFloat(sendAmount);
    if (!amt || amt <= 0) { toast.error('Please enter a valid amount to send'); return; }
    if (!sendRecipientName.trim()) { toast.error('Recipient name is required'); return; }
    setSendLoading(true);
    try {
      const res = await apiFetch('/api/currency-exchange', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'send',
          fromCurrency: sendFromCurrency,
          toCurrency: sendToCurrency,
          fromAmount: amt,
          recipientName: sendRecipientName.trim(),
          recipientEmail: sendRecipientEmail.trim() || null,
          recipientPhone: sendRecipientPhone.trim() || null,
          description: sendDescription.trim() || null,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(`Successfully sent ${formatCurrency(amt, sendFromCurrency)} to ${sendRecipientName}`);
      setSendFromCurrency('');
      setSendToCurrency('');
      setSendAmount('');
      setSendRecipientName('');
      setSendRecipientEmail('');
      setSendRecipientPhone('');
      setSendDescription('');
      fetchTransactions();
      fetchStats();
      fetchWallets();
    } catch {
      toast.error('Failed to complete send transaction');
    } finally {
      setSendLoading(false);
    }
  };

  // Receive handler
  const handleReceive = async () => {
    if (!receiveFromCurrency) { toast.error('Please select a source currency'); return; }
    if (!receiveToCurrency) { toast.error('Please select a receive-as currency'); return; }
    const amt = parseFloat(receiveAmount);
    if (!amt || amt <= 0) { toast.error('Please enter a valid amount to receive'); return; }
    if (!receiveSenderName.trim()) { toast.error('Sender name is required'); return; }
    setReceiveLoading(true);
    try {
      const res = await apiFetch('/api/currency-exchange', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'receive',
          fromCurrency: receiveFromCurrency,
          toCurrency: receiveToCurrency,
          fromAmount: amt,
          recipientName: receiveSenderName.trim(),
          description: receiveDescription.trim() || null,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(`Receive request generated for ${formatCurrency(amt, receiveFromCurrency)}`);
      setReceiveFromCurrency('');
      setReceiveToCurrency('ETB');
      setReceiveAmount('');
      setReceiveSenderName('');
      setReceiveDescription('');
      fetchTransactions();
      fetchStats();
      fetchWallets();
    } catch {
      toast.error('Failed to generate receive request');
    } finally {
      setReceiveLoading(false);
    }
  };

  // Transaction status update
  const handleUpdateTransactionStatus = async (txId: string, newStatus: string) => {
    setActionLoadingId(txId);
    try {
      const res = await apiFetch('/api/currency-exchange', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: txId, status: newStatus }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(`Transaction marked as ${newStatus}`);
      fetchTransactions();
      fetchStats();
    } catch {
      toast.error(`Failed to update transaction status`);
    } finally {
      setActionLoadingId(null);
    }
  };

  const openTransactionDetail = (tx: ForexTransaction) => {
    setSelectedTransaction(tx);
    setDetailDialogOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* ===== Header ===== */}
      <motion.div {...fadeIn} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-pink-500 shadow-md">
            <Globe className="h-5 w-5 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Exchange</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              Buy, sell, send, and receive foreign currencies with live exchange rates.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 btn-responsive-group">
          <Button
            variant="outline"
            className="btn-responsive"
            onClick={handleSeedData}
            disabled={seedingData}
          >
            <Database className={`h-4 w-4 mr-2 ${seedingData ? 'animate-pulse' : ''}`} />
            <span className="btn-label">Seed Data</span>
          </Button>
          <Button
            className="btn-responsive bg-gradient-to-r from-fuchsia-500 to-pink-500 hover:from-fuchsia-600 hover:to-pink-600 text-white shadow-sm"
            onClick={handleUpdateRates}
            disabled={updatingRates || currenciesLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${updatingRates ? 'animate-spin' : ''}`} />
            <span className="btn-label">Update Rates</span>
          </Button>
        </div>
      </motion.div>

      {/* ===== Stats Cards ===== */}
      <motion.div {...fadeIn} transition={{ delay: 0.05 }} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {statsLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-11 w-11 rounded-xl" />
                  <div className="space-y-2">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-6 w-24" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 shadow-md">
                    <ArrowRightLeft className="h-5 w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Total Transactions</p>
                    <p className="text-xl font-bold tracking-tight truncate">{(stats?.totalTransactions || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-blue-500 shadow-md">
                    <TrendingUp className="h-5 w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Buy Volume</p>
                    <p className="text-xl font-bold tracking-tight truncate">{(stats?.buyVolume || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-500 shadow-md">
                    <TrendingDown className="h-5 w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Sell Volume</p>
                    <p className="text-xl font-bold tracking-tight truncate">{(stats?.sellVolume || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-500 shadow-md">
                    <Send className="h-5 w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Send/Receive</p>
                    <p className="text-xl font-bold tracking-tight truncate">{(stats?.sendReceiveVolume || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </motion.div>

      {/* ===== Tabs Section ===== */}
      <motion.div {...fadeIn} transition={{ delay: 0.1 }}>
        <Tabs defaultValue="rates" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
            <TabsTrigger value="rates" className="gap-1.5">
              <Globe className="h-3.5 w-3.5 hidden sm:block" />
              <span className="btn-label">Exchange Rates</span>
            </TabsTrigger>
            <TabsTrigger value="buysell" className="gap-1.5">
              <ArrowRightLeft className="h-3.5 w-3.5 hidden sm:block" />
              <span className="btn-label">Buy & Sell</span>
            </TabsTrigger>
            <TabsTrigger value="sendreceive" className="gap-1.5">
              <Send className="h-3.5 w-3.5 hidden sm:block" />
              <span className="btn-label">Send & Receive</span>
            </TabsTrigger>
            <TabsTrigger value="transactions" className="gap-1.5">
              <ArrowRightLeftIcon className="h-3.5 w-3.5 hidden sm:block" />
              <span className="btn-label">Transactions</span>
            </TabsTrigger>
          </TabsList>

          {/* --- Tab 1: Exchange Rates --- */}
          <TabsContent value="rates">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base font-semibold">
                  <Globe className="h-4 w-4 text-fuchsia-500" />
                  Exchange Rates
                </CardTitle>
                <CardDescription>
                  All rates are relative to the Ethiopian Birr (ETB). Last updated rates are shown below.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-[500px] overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent">
                  <Table>
                    <TableHeader>
                      <TableRow className="sticky top-0 bg-gradient-to-r from-fuchsia-50 via-purple-50/50 to-pink-50 dark:from-fuchsia-950/30 dark:via-purple-950/20 dark:to-pink-950/30 z-10 hover:bg-transparent">
                        <TableHead className="font-semibold w-12">Flag</TableHead>
                        <TableHead className="font-semibold">Currency</TableHead>
                        <TableHead className="text-right font-semibold">Rate to ETB</TableHead>
                        <TableHead className="hidden sm:table-cell">Status</TableHead>
                        <TableHead className="text-right hidden sm:table-cell">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currenciesLoading ? (
                        Array.from({ length: 8 }).map((_, i) => (
                          <TableRow key={i}>
                            <TableCell><Skeleton className="h-9 w-9 rounded-lg" /></TableCell>
                            <TableCell><Skeleton className="h-4 w-36" /></TableCell>
                            <TableCell className="text-right"><Skeleton className="h-5 w-20 ml-auto" /></TableCell>
                            <TableCell className="hidden sm:table-cell"><Skeleton className="h-5 w-16" /></TableCell>
                            <TableCell className="text-right hidden sm:table-cell"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                          </TableRow>
                        ))
                      ) : (
                        currencies.map((currency, idx) => (
                          <TableRow
                            key={currency.id}
                            className={cn(
                              'transition-colors hover:bg-fuchsia-50/30 dark:hover:bg-fuchsia-950/10',
                              currency.code === 'ETB' ? 'bg-fuchsia-50/40 dark:bg-fuchsia-950/20' : '',
                              idx % 2 === 1 && currency.code !== 'ETB' ? 'bg-muted/30' : ''
                            )}
                          >
                            <TableCell>
                              <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-50 to-pink-50 dark:from-fuchsia-950/50 dark:to-pink-950/50 text-xl">
                                {getCurrencyFlag(currency.code)}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="font-semibold text-sm">{currency.name}</span>
                                <span className="text-xs text-muted-foreground">{currency.symbol} <span className="font-mono font-medium text-foreground/60">{currency.code}</span></span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <span className="font-mono text-lg font-bold tracking-tight">
                                {formatRate(currency.exchangeRate)}
                              </span>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell">
                              <Badge
                                variant="outline"
                                className={`text-xs ${
                                  currency.isActive
                                    ? 'text-emerald-600 border-emerald-300 bg-emerald-50'
                                    : 'text-rose-600 border-rose-300 bg-rose-50'
                                }`}
                              >
                                {currency.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right hidden sm:table-cell">
                              <div className="flex items-center justify-end gap-1">
                                {currency.code !== 'ETB' && (
                                  <>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => openEditDialog(currency)}
                                      className="h-8 w-8 p-0 text-fuchsia-600 hover:text-fuchsia-700 hover:bg-fuchsia-50 rounded-lg"
                                    >
                                      <Edit2 className="h-3.5 w-3.5" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleToggleActive(currency)}
                                      disabled={togglingId === currency.id}
                                      className={`h-8 w-8 p-0 rounded-lg ${
                                        currency.isActive
                                          ? 'text-rose-600 hover:text-rose-700 hover:bg-rose-50'
                                          : 'text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50'
                                      }`}
                                    >
                                      {togglingId === currency.id ? (
                                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                      ) : (
                                        <Power className="h-3.5 w-3.5" />
                                      )}
                                    </Button>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* --- Tab 2: Buy & Sell --- */}
          <TabsContent value="buysell">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Buy Card */}
              <Card className="rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowDownLeft className="h-5 w-5 text-emerald-600" />
                    Buy Foreign Currency
                  </CardTitle>
                  <CardDescription>Purchase foreign currency using ETB</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Currency to Buy</Label>
                    <Select value={buyCurrency} onValueChange={setBuyCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeNonEtb.map((c) => (
                          <SelectItem key={c.code} value={c.code}>
                            {getCurrencyFlag(c.code)} {c.code} - {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount to Buy</Label>
                    <Input
                      type="number"
                      value={buyAmount}
                      onChange={(e) => setBuyAmount(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Pay With</Label>
                    <Input value="ETB - Ethiopian Birr" disabled />
                  </div>
                  <div className="bg-emerald-50 dark:bg-emerald-950/30 rounded-lg p-3 space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Exchange Rate</span>
                      <span className="font-mono">1 {buyCurrency || '???'} = {buyRate ? formatRate(buyRate) : '0'} ETB</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">You Pay</span>
                      <span className="font-mono font-semibold">{formatCurrency(buyPayAmount, 'ETB')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Fee (0.5%)</span>
                      <span className="font-mono">{formatCurrency(buyFee, 'ETB')}</span>
                    </div>
                  </div>
                  <Button
                    className="btn-responsive w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={handleBuy}
                    disabled={buyLoading || !buyCurrency || !buyAmount}
                  >
                    {buyLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                    Buy Now
                  </Button>
                </CardContent>
              </Card>

              {/* Sell Card */}
              <Card className="rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowUpRight className="h-5 w-5 text-rose-600" />
                    Sell Foreign Currency
                  </CardTitle>
                  <CardDescription>Convert foreign currency to ETB</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Currency to Sell</Label>
                    <Select value={sellCurrency} onValueChange={setSellCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeNonEtb.map((c) => (
                          <SelectItem key={c.code} value={c.code}>
                            {getCurrencyFlag(c.code)} {c.code} - {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount to Sell</Label>
                    <Input
                      type="number"
                      value={sellAmount}
                      onChange={(e) => setSellAmount(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Receive In</Label>
                    <Input value="ETB - Ethiopian Birr" disabled />
                  </div>
                  <div className="bg-rose-50 dark:bg-rose-950/30 rounded-lg p-3 space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Exchange Rate</span>
                      <span className="font-mono">1 {sellCurrency || '???'} = {sellRate ? formatRate(sellRate) : '0'} ETB</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">You Receive</span>
                      <span className="font-mono font-semibold">{formatCurrency(sellReceiveAmount - sellFee, 'ETB')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Fee (0.5%)</span>
                      <span className="font-mono">{formatCurrency(sellFee, 'ETB')}</span>
                    </div>
                  </div>
                  <Button
                    className="btn-responsive w-full bg-rose-600 hover:bg-rose-700 text-white"
                    onClick={handleSell}
                    disabled={sellLoading || !sellCurrency || !sellAmount}
                  >
                    {sellLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                    Sell Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* --- Tab 3: Send & Receive --- */}
          <TabsContent value="sendreceive">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Send Card */}
              <Card className="rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="h-5 w-5 text-emerald-600" />
                    Send Currency
                  </CardTitle>
                  <CardDescription>Send foreign currency to recipients</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Send Currency</Label>
                    <Select value={sendFromCurrency} onValueChange={setSendFromCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeCurrencies.map((c) => (
                          <SelectItem key={c.code} value={c.code}>
                            {getCurrencyFlag(c.code)} {c.code} - {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Receive Currency</Label>
                    <Select value={sendToCurrency} onValueChange={setSendToCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeCurrencies
                          .filter((c) => c.code !== sendFromCurrency)
                          .map((c) => (
                            <SelectItem key={c.code} value={c.code}>
                              {getCurrencyFlag(c.code)} {c.code} - {c.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount</Label>
                    <Input
                      type="number"
                      value={sendAmount}
                      onChange={(e) => setSendAmount(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Recipient Name *</Label>
                    <Input
                      value={sendRecipientName}
                      onChange={(e) => setSendRecipientName(e.target.value)}
                      placeholder="Full name"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>Recipient Email</Label>
                      <Input
                        type="email"
                        value={sendRecipientEmail}
                        onChange={(e) => setSendRecipientEmail(e.target.value)}
                        placeholder="email@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Recipient Phone</Label>
                      <Input
                        value={sendRecipientPhone}
                        onChange={(e) => setSendRecipientPhone(e.target.value)}
                        placeholder="+251..."
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      value={sendDescription}
                      onChange={(e) => setSendDescription(e.target.value)}
                      placeholder="Optional description"
                    />
                  </div>
                  {sendFromCurrency && sendToCurrency && sendAmount && (
                    <div className="bg-emerald-50 dark:bg-emerald-950/30 rounded-lg p-3 space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Exchange Rate</span>
                        <span className="font-mono">1 {sendFromCurrency} = {formatRate(sendRate)} {sendToCurrency}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Recipient Gets</span>
                        <span className="font-mono font-semibold">{formatCurrency(sendRecipientGets, sendToCurrency)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fee (0.5%)</span>
                        <span className="font-mono">{formatCurrency(sendFee, sendToCurrency)}</span>
                      </div>
                    </div>
                  )}
                  <Button
                    className="btn-responsive w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={handleSend}
                    disabled={sendLoading || !sendFromCurrency || !sendToCurrency || !sendAmount || !sendRecipientName}
                  >
                    {sendLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                    Send Now
                  </Button>
                </CardContent>
              </Card>

              {/* Receive Card */}
              <Card className="rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-5 w-5 text-blue-600" />
                    Receive Currency
                  </CardTitle>
                  <CardDescription>Receive foreign currency from senders</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Source Currency</Label>
                    <Select value={receiveFromCurrency} onValueChange={setReceiveFromCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeCurrencies.map((c) => (
                          <SelectItem key={c.code} value={c.code}>
                            {getCurrencyFlag(c.code)} {c.code} - {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Receive As</Label>
                    <Select value={receiveToCurrency} onValueChange={setReceiveToCurrency}>
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        {activeCurrencies
                          .filter((c) => c.code !== receiveFromCurrency)
                          .map((c) => (
                            <SelectItem key={c.code} value={c.code}>
                              {getCurrencyFlag(c.code)} {c.code} - {c.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount to Receive</Label>
                    <Input
                      type="number"
                      value={receiveAmount}
                      onChange={(e) => setReceiveAmount(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Sender Name *</Label>
                    <Input
                      value={receiveSenderName}
                      onChange={(e) => setReceiveSenderName(e.target.value)}
                      placeholder="Sender full name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      value={receiveDescription}
                      onChange={(e) => setReceiveDescription(e.target.value)}
                      placeholder="Optional description"
                    />
                  </div>
                  {receiveFromCurrency && receiveToCurrency && receiveAmount && (
                    <div className="bg-blue-50 dark:bg-blue-950/30 rounded-lg p-3 space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Exchange Rate</span>
                        <span className="font-mono">1 {receiveFromCurrency} = {formatRate(receiveRate)} {receiveToCurrency}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">You Receive</span>
                        <span className="font-mono font-semibold">{formatCurrency(receiveConverted - receiveFee, receiveToCurrency)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fee (0.5%)</span>
                        <span className="font-mono">{formatCurrency(receiveFee, receiveToCurrency)}</span>
                      </div>
                    </div>
                  )}
                  <Button
                    className="btn-responsive w-full bg-[#0F4C81] hover:bg-[#0d3d6a] text-white"
                    onClick={handleReceive}
                    disabled={receiveLoading || !receiveFromCurrency || !receiveToCurrency || !receiveAmount || !receiveSenderName}
                  >
                    {receiveLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                    Generate Receive Request
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* --- Tab 4: Transactions --- */}
          <TabsContent value="transactions">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <CardTitle>Transaction History</CardTitle>
                    <CardDescription>View and manage all currency exchange transactions.</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1); }}>
                      <SelectTrigger className="w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="processing">Processing</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setCurrentPage(1); }}>
                      <SelectTrigger className="w-[140px]"><SelectValue placeholder="Type" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="buy">Buy</SelectItem>
                        <SelectItem value="sell">Sell</SelectItem>
                        <SelectItem value="send">Send</SelectItem>
                        <SelectItem value="receive">Receive</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="icon" onClick={() => { fetchTransactions(); fetchStats(); }}>
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-[500px] overflow-y-auto custom-scroll">
                  <Table>
                    <TableHeader>
                      <TableRow className="sticky top-0 bg-background z-10">
                        <TableHead>Reference</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden md:table-cell">From</TableHead>
                        <TableHead className="hidden md:table-cell">To</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead className="hidden lg:table-cell text-right">Rate</TableHead>
                        <TableHead className="hidden lg:table-cell text-right">Fee</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden sm:table-cell">Date</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactionsLoading ? (
                        Array.from({ length: 6 }).map((_, i) => (
                          <TableRow key={i}>
                            <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                            <TableCell><Skeleton className="h-5 w-14" /></TableCell>
                            <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-12" /></TableCell>
                            <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-12" /></TableCell>
                            <TableCell className="text-right"><Skeleton className="h-4 w-20 ml-auto" /></TableCell>
                            <TableCell className="hidden lg:table-cell text-right"><Skeleton className="h-4 w-16 ml-auto" /></TableCell>
                            <TableCell className="hidden lg:table-cell text-right"><Skeleton className="h-4 w-14 ml-auto" /></TableCell>
                            <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                            <TableCell className="hidden sm:table-cell"><Skeleton className="h-4 w-20" /></TableCell>
                            <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                          </TableRow>
                        ))
                      ) : paginatedTransactions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={10} className="text-center py-8 text-muted-foreground">
                            No transactions found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        paginatedTransactions.map((tx) => (
                          <TableRow key={tx.id} className="cursor-pointer" onClick={() => openTransactionDetail(tx)}>
                            <TableCell className="font-mono text-xs">{tx.reference.slice(0, 12)}...</TableCell>
                            <TableCell>
                              <Badge className={`text-xs ${getTypeBadgeColor(tx.type)}`}>
                                {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell font-mono text-sm">{tx.fromCurrency}</TableCell>
                            <TableCell className="hidden md:table-cell font-mono text-sm">{tx.toCurrency}</TableCell>
                            <TableCell className="text-right font-mono text-sm">
                              {formatCurrency(tx.fromAmount, tx.fromCurrency)}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-right font-mono text-sm">
                              {formatRate(tx.exchangeRate)}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-right font-mono text-sm">
                              {formatCurrency(tx.fee, tx.feeCurrency)}
                            </TableCell>
                            <TableCell>
                              <Badge className={`text-xs ${getStatusBadgeColor(tx.status)}`}>
                                {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                              <span className="datetime-badge full">{formatDateTime(tx.createdAt)}</span>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); openTransactionDetail(tx); }}>
                                    <Eye className="h-4 w-4 mr-2" /> View Details
                                  </DropdownMenuItem>
                                  {tx.status === 'pending' && (
                                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleUpdateTransactionStatus(tx.id, 'completed'); }}>
                                      <Check className="h-4 w-4 mr-2" /> Mark Completed
                                    </DropdownMenuItem>
                                  )}
                                  {(tx.status === 'pending' || tx.status === 'processing') && (
                                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleUpdateTransactionStatus(tx.id, 'failed'); }}>
                                      Mark Failed
                                    </DropdownMenuItem>
                                  )}
                                  {(tx.status === 'pending' || tx.status === 'processing') && (
                                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleUpdateTransactionStatus(tx.id, 'cancelled'); }}>
                                      Cancel
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between px-4 py-3 border-t">
                    <p className="text-sm text-muted-foreground">
                      Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filteredTransactions.length)} of {filteredTransactions.length}
                    </p>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      >
                        Prev
                      </Button>
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                        .map((p, idx, arr) => {
                          const showEllipsis = idx > 0 && p - arr[idx - 1] > 1;
                          return (
                            <span key={p} className="flex items-center">
                              {showEllipsis && <span className="px-1 text-muted-foreground">...</span>}
                              <Button
                                variant={p === currentPage ? 'default' : 'outline'}
                                size="sm"
                                className="w-9 h-9 p-0"
                                onClick={() => setCurrentPage(p)}
                              >
                                {p}
                              </Button>
                            </span>
                          );
                        })}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>

      {/* ===== Multi-Currency Wallet Summary ===== */}
      <motion.div {...fadeIn} transition={{ delay: 0.15 }}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-teal-600" />
              Multi-Currency Wallet Summary
            </CardTitle>
            <CardDescription>Total balances per currency across all wallets.</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            {walletsLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="rounded-lg border p-4">
                    <Skeleton className="h-4 w-16 mb-2" />
                    <Skeleton className="h-6 w-28 mb-1" />
                    <Skeleton className="h-3 w-36" />
                  </div>
                ))}
              </div>
            ) : currencySummary.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No wallet data available.</p>
            ) : (
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Portfolio Value</p>
                    <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400 font-mono">
                      {totalEtbEquivalent.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-emerald-600" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currencySummary.map((item) => (
                    <div
                      key={item.currency}
                      className="rounded-lg border p-4 hover:shadow-sm transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{getCurrencyFlag(item.currency)}</span>
                          <span className="font-semibold font-mono">{item.currency}</span>
                          <Badge variant="outline" className="text-xs text-muted-foreground">
                            {item.walletCount} {item.walletCount === 1 ? 'wallet' : 'wallets'}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-lg font-bold font-mono">
                        {item.totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        \u2248 {item.etbEquivalent.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB
                        {item.totalFrozen > 0 && (
                          <span className="text-amber-600 ml-2">
                            (Frozen: {item.totalFrozen.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})
                          </span>
                        )}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* ===== Exchange Rate Trend Chart ===== */}
      <motion.div {...fadeIn} transition={{ delay: 0.2 }}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-amber-600" />
                Exchange Rate Trend (7 Days)
              </CardTitle>
              <CardDescription>Historical rate movement for the selected currency.</CardDescription>
            </div>
            <Select value={trendCurrency} onValueChange={handleTrendCurrencyChange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currencies
                  .filter((c) => c.isActive && c.code !== 'ETB')
                  .map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      {getCurrencyFlag(c.code)} {c.code}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            {currenciesLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : trendData.length === 0 ? (
              <p className="text-muted-foreground text-center py-12">
                No active currencies available for trend display.
              </p>
            ) : (
              <ChartContainer config={trendChartConfig} className="h-[300px] w-full">
                <LineChart data={trendData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis
                    domain={['auto', 'auto']}
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(val: number) => val.toLocaleString()}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent
                        formatter={(value: unknown) => [
                          Number(value).toLocaleString('en-US', { minimumFractionDigits: 4 }),
                          `${trendCurrency}/ETB`,
                        ]}
                      />
                    }
                  />
                  <Line
                    type="monotone"
                    dataKey="rate"
                    stroke="var(--color-rate)"
                    strokeWidth={2}
                    dot={{ r: 4, fill: 'var(--color-rate)' }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* ===== Edit Rate Dialog ===== */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Exchange Rate</DialogTitle>
            <DialogDescription>
              Set a new exchange rate for {editingCurrency?.code} ({editingCurrency?.name}) relative to ETB.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>Current Rate</Label>
              <div className="bg-muted/50 rounded-md px-3 py-2 font-mono">
                {editingCurrency?.exchangeRate ? formatRate(editingCurrency.exchangeRate) : '-'} ETB
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="new-rate">New Rate (to ETB)</Label>
              <Input
                id="new-rate"
                type="number"
                step="0.0001"
                min="0.0001"
                value={newRate}
                onChange={(e) => setNewRate(e.target.value)}
                placeholder="Enter new exchange rate"
              />
            </div>
          </div>
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handleSaveRate}
              disabled={savingRate}
            >
              {savingRate ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}
              Save Rate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Transaction Detail Dialog ===== */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Transaction Details</DialogTitle>
            <DialogDescription>Full details for this currency exchange transaction.</DialogDescription>
          </DialogHeader>
          {selectedTransaction && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Reference</p>
                  <p className="font-mono text-sm font-semibold">{selectedTransaction.reference}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Type</p>
                  <Badge className={`text-xs ${getTypeBadgeColor(selectedTransaction.type)}`}>
                    {selectedTransaction.type.charAt(0).toUpperCase() + selectedTransaction.type.slice(1)}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">From</p>
                  <p className="font-mono text-sm">{formatCurrency(selectedTransaction.fromAmount, selectedTransaction.fromCurrency)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">To</p>
                  <p className="font-mono text-sm">{formatCurrency(selectedTransaction.toAmount, selectedTransaction.toCurrency)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Exchange Rate</p>
                  <p className="font-mono text-sm">{formatRate(selectedTransaction.exchangeRate)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Fee</p>
                  <p className="font-mono text-sm">{formatCurrency(selectedTransaction.fee, selectedTransaction.feeCurrency)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <Badge className={`text-xs ${getStatusBadgeColor(selectedTransaction.status)}`}>
                    {selectedTransaction.status.charAt(0).toUpperCase() + selectedTransaction.status.slice(1)}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Created</p>
                  <p className="text-sm"><span className="datetime-badge full">{formatDateTime(selectedTransaction.createdAt)}</span></p>
                </div>
              </div>
              {selectedTransaction.completedAt && (
                <div>
                  <p className="text-xs text-muted-foreground">Completed At</p>
                  <p className="text-sm"><span className="datetime-badge full">{formatDateTime(selectedTransaction.completedAt)}</span></p>
                </div>
              )}
              {selectedTransaction.recipientName && (
                <div className="border-t pt-3">
                  <p className="text-xs text-muted-foreground mb-2">Recipient Information</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Name: </span>
                      <span className="font-medium">{selectedTransaction.recipientName}</span>
                    </div>
                    {selectedTransaction.recipientEmail && (
                      <div>
                        <span className="text-muted-foreground">Email: </span>
                        <span>{selectedTransaction.recipientEmail}</span>
                      </div>
                    )}
                    {selectedTransaction.recipientPhone && (
                      <div>
                        <span className="text-muted-foreground">Phone: </span>
                        <span>{selectedTransaction.recipientPhone}</span>
                      </div>
                    )}
                    {selectedTransaction.recipientWallet && (
                      <div>
                        <span className="text-muted-foreground">Wallet: </span>
                        <span className="font-mono">{selectedTransaction.recipientWallet}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
              {selectedTransaction.description && (
                <div>
                  <p className="text-xs text-muted-foreground">Description</p>
                  <p className="text-sm">{selectedTransaction.description}</p>
                </div>
              )}
              {selectedTransaction.initiator && (
                <div className="border-t pt-3">
                  <p className="text-xs text-muted-foreground mb-1">Initiator</p>
                  <p className="text-sm font-medium">{selectedTransaction.initiator.name}</p>
                  <p className="text-xs text-muted-foreground">{selectedTransaction.initiator.email}</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>
              Close
            </Button>
            {selectedTransaction && selectedTransaction.status === 'pending' && (
              <Button
                className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={() => {
                  handleUpdateTransactionStatus(selectedTransaction.id, 'completed');
                  setDetailDialogOpen(false);
                }}
                disabled={actionLoadingId === selectedTransaction.id}
              >
                {actionLoadingId === selectedTransaction.id ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}
                Mark Completed
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
