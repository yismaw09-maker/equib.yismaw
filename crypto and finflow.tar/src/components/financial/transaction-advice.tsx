'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText,
  Printer,
  Download,
  X,
  CheckCircle2,
  ArrowDownUp,
  Clock,
  Building2,
  Wallet,
  User,
  MapPin,
  Hash,
  Landmark,
  Sparkles,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Lightbulb,
  TrendingUp,
  AlertTriangle,
  Loader2,
  Copy,
  Share2,
  Camera,
  Receipt,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import { numberToWords, formatAmountFigures } from '@/lib/number-to-words';
import { toast } from 'sonner';

/* ── Types ──────────────────────────────────────────────── */

export interface AdviceData {
  // Transaction
  reference: string;
  type: string;
  subType?: string | null;
  amount: number;
  fee: number;
  currency: string;
  description?: string | null;
  status: string;
  createdAt: string;
  completedAt?: string | null;
  paymentMethod?: string | null;
  riskScore?: number | null;
  fraudFlag?: boolean | null;

  // Sender
  senderName: string;
  senderEmail?: string | null;
  senderPhone?: string | null;
  senderAddress?: string | null;
  senderAccountNumber?: string | null;
  senderBankName?: string | null;
  senderWalletId?: string | null;
  senderWalletCurrency?: string | null;

  // Receiver
  receiverName?: string | null;
  receiverEmail?: string | null;
  receiverPhone?: string | null;
  receiverAddress?: string | null;
  receiverAccountNumber?: string | null;
  receiverBankName?: string | null;
  receiverWalletId?: string | null;
  receiverWalletCurrency?: string | null;
}

interface AiAdviceParsed {
  summary?: string;
  riskLevel?: string;
  riskNotes?: string | null;
  insights?: string[];
  recommendations?: string[];
  regulatoryNote?: string | null;
}

interface TransactionAdviceProps {
  data: AdviceData;
  onClose: () => void;
}

/* ── Helpers ────────────────────────────────────────────── */

function formatPaymentMethod(method: string | null | undefined): string {
  if (!method) return 'Digital Wallet';
  const map: Record<string, string> = {
    bank_account: 'Bank Account (MB Transfer)',
    debit_card: 'Debit Card',
    credit_card: 'Credit Card',
    mobile_money: 'Mobile Money',
    qr_code: 'QR Code',
    digital_wallet: 'Digital Wallet',
    crypto: 'Cryptocurrency',
  };
  return map[method] ?? method;
}

function formatTxnType(type: string): string {
  const map: Record<string, string> = {
    deposit: 'Deposit',
    withdrawal: 'Withdrawal',
    transfer: 'Transfer',
    payment: 'Payment',
    refund: 'Refund',
    chargeback: 'Chargeback',
    reversal: 'Reversal',
    escrow: 'Escrow Payment',
    commission: 'Commission',
    split_payment: 'Split Payment',
  };
  return map[type] ?? type;
}

function statusColor(status: string): string {
  switch (status) {
    case 'completed': return 'bg-emerald-500 text-white';
    case 'pending': return 'bg-amber-100 text-amber-700';
    case 'processing': return 'bg-blue-100 text-blue-700';
    case 'failed': return 'bg-rose-100 text-rose-700';
    case 'cancelled': return 'bg-gray-100 text-gray-600';
    case 'reversed': return 'bg-orange-100 text-orange-700';
    default: return 'bg-muted text-muted-foreground';
  }
}

function riskBadge(level: string) {
  if (level === 'high') return { color: 'bg-red-100 text-red-700 border-red-200', icon: ShieldAlert, label: 'High Risk' };
  if (level === 'medium') return { color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Shield, label: 'Medium Risk' };
  return { color: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: ShieldCheck, label: 'Low Risk' };
}

function computeFeeBreakdown(fee: number, amount: number) {
  const vat = fee > 0 ? Math.round(fee * 0.15 * 100) / 100 : 0;
  const disasterRecovery = fee > 0 ? Math.round(fee * 0.05 * 100) / 100 : 0;
  const netFee = fee > 0 ? Math.round((fee - vat - disasterRecovery) * 100) / 100 : 0;
  return { netFee, vat, disasterRecovery, totalDebited: amount + fee };
}

/* ── Print-only stylesheet ───────────────────────────────── */

const PRINT_STYLES = `
  @media print {
    body * { visibility: hidden !important; }
    .advice-print-area, .advice-print-area * { visibility: visible !important; }
    .advice-print-area { position: fixed; left: 0; top: 0; width: 100%; z-index: 99999; background: white; }
    .advice-no-print { display: none !important; }
    .advice-print-area { padding: 20px; box-shadow: none !important; border: none !important; border-radius: 0 !important; }
  }
`;

/* ── Component ─────────────────────────────────────────── */

export default function TransactionAdvice({ data, onClose }: TransactionAdviceProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const { formatDateTime } = useFormattedDate();
  const [aiAdvice, setAiAdvice] = useState<AiAdviceParsed | null>(null);
  const [aiLoading, setAiLoading] = useState(true);
  const [aiRawText, setAiRawText] = useState<string | null>(null);
  const [showAiPanel, setShowAiPanel] = useState(true);

  const amountInWords = numberToWords(data.amount, data.currency);
  const amountInFigures = formatAmountFigures(data.amount, data.currency);
  const fees = computeFeeBreakdown(data.fee, data.amount);
  const totalInFigures = formatAmountFigures(fees.totalDebited, data.currency);
  const isCompleted = data.status === 'completed';

  // Fetch AI advice on mount
  useEffect(() => {
    let cancelled = false;
    async function fetchAdvice() {
      setAiLoading(true);
      try {
        const res = await apiFetch('/api/ai/advice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            transaction: {
              reference: data.reference,
              type: data.type,
              amount: data.amount,
              fee: data.fee,
              currency: data.currency,
              status: data.status,
              riskScore: data.riskScore,
              fraudFlag: data.fraudFlag,
              initiatorName: data.senderName,
              recipientName: data.receiverName,
              bankName: data.senderBankName,
              description: data.description,
              paymentMethod: data.paymentMethod,
            },
            context: `Single transaction advice for FinFlow Ethiopian financial platform. Provide risk assessment, insights, and recommendations.`,
          }),
        });
        if (!res.ok || cancelled) return;
        const json = await res.json();
        if (json.success && json.advice) {
          setAiAdvice(json.advice);
          if (json.rawText) setAiRawText(json.rawText);
        }
      } catch {
        // Silent fail - advice is optional
      } finally {
        if (!cancelled) setAiLoading(false);
      }
    }
    fetchAdvice();
    return () => { cancelled = true; };
  }, [data.reference, data.amount, data.type, data.status, data.senderName, data.receiverName]);

  const handlePrint = () => {
    const styleEl = document.createElement('style');
    styleEl.textContent = PRINT_STYLES;
    document.head.appendChild(styleEl);
    window.print();
    setTimeout(() => document.head.removeChild(styleEl), 1000);
  };

  const handleCopy = () => {
    const text = `FinFlow Transaction Advice\n${'='.repeat(40)}\nReference: ${data.reference}\nType: ${formatTxnType(data.type)}\nAmount: ${amountInFigures}\nStatus: ${data.status}\nSender: ${data.senderName}\nReceiver: ${data.receiverName || 'N/A'}\nDate: ${data.createdAt}\n${aiAdvice ? `\nAI Advice: ${aiAdvice.summary || ''}\n${aiAdvice.recommendations?.join('\n- ') || ''}` : ''}`;
    navigator.clipboard.writeText(text).then(() => toast.success('Copied to clipboard'));
  };

  const risk = aiAdvice?.riskLevel ? riskBadge(aiAdvice.riskLevel) : null;
  const RiskIcon = risk?.icon ?? ShieldCheck;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-white rounded-2xl shadow-2xl"
      >
        {/* ── Success Header (Telebirr style) ──── */}
        <div className="relative bg-gradient-to-r from-emerald-600 to-teal-500 rounded-t-2xl px-6 py-5">
          <button
            onClick={onClose}
            className="advice-no-print absolute top-3 right-3 h-8 w-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
          >
            <X className="h-4 w-4 text-white" />
          </button>
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center ring-2 ring-white/30 flex-shrink-0">
              {isCompleted ? (
                <CheckCircle2 className="h-8 w-8 text-white" />
              ) : (
                <Clock className="h-8 w-8 text-white" />
              )}
            </div>
            <div className="text-white min-w-0">
              <h2 className="text-xl font-bold leading-tight">
                {isCompleted ? 'Transaction Completed Successfully!' : `Transaction ${data.status.charAt(0).toUpperCase() + data.status.slice(1)}`}
              </h2>
              <p className="text-emerald-100 text-sm mt-0.5">
                {data.currency} {data.amount.toLocaleString()} {data.type === 'deposit' || data.type === 'refund' ? 'has been credited' : 'has been debited'} from {data.senderName}
              </p>
            </div>
          </div>
        </div>

        {/* ── Printable content ──── */}
        <div ref={printRef} className="advice-print-area">
          {/* Company Header */}
          <div className="px-6 pt-5 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 rounded-xl bg-emerald-600 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">F</span>
                </div>
                <div>
                  <h1 className="text-base font-bold text-foreground leading-tight">FinFlow</h1>
                  <p className="text-[10px] text-muted-foreground">Enterprise Financial Platform | NBE Licensed</p>
                </div>
              </div>
              <div className="text-right">
                <Badge className={statusColor(data.status)}>
                  {data.status.charAt(0).toUpperCase() + data.status.slice(1)}
                </Badge>
              </div>
            </div>
          </div>

          {/* Transaction Summary */}
          <div className="mx-6 rounded-xl bg-muted/40 border p-4 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground mb-0.5">
                  <Hash className="h-3 w-3" /> Reference
                </div>
                <p className="text-xs font-bold tabular-nums font-mono">{data.reference}</p>
              </div>
              <div>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground mb-0.5">
                  <ArrowDownUp className="h-3 w-3" /> Type
                </div>
                <p className="text-xs font-semibold">{formatTxnType(data.type)}{data.subType ? ` (${data.subType})` : ''}</p>
              </div>
              <div>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground mb-0.5">
                  <Clock className="h-3 w-3" /> Date & Time
                </div>
                <p className="text-xs font-medium">{formatDateTime(data.createdAt)}</p>
              </div>
              <div>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground mb-0.5">
                  <Building2 className="h-3 w-3" /> Method
                </div>
                <p className="text-xs font-medium">{formatPaymentMethod(data.paymentMethod)}</p>
              </div>
            </div>
          </div>

          {/* Sender & Receiver - compact */}
          <div className="px-6 py-3 grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <div className="h-5 w-5 rounded-full bg-emerald-600 flex items-center justify-center">
                  <ArrowDownUp className="h-3 w-3 text-white" style={{ transform: 'rotate(-45deg)' }} />
                </div>
                <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider">Sender</span>
              </div>
              <p className="text-sm font-semibold leading-tight">{data.senderName}</p>
              <div className="text-[10px] text-muted-foreground mt-0.5">
                {data.senderEmail && <p>{data.senderEmail}</p>}
                {(data.senderAccountNumber || data.senderWalletId) && (
                  <p className="font-mono">{data.senderBankName ? `Acct: ${data.senderAccountNumber?.substring(0, 16)}` : `Wallet: ${data.senderWalletId?.substring(0, 16)}`}</p>
                )}
                {data.senderBankName && <p>via {data.senderBankName}</p>}
              </div>
            </div>
            <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <div className="h-5 w-5 rounded-full bg-blue-600 flex items-center justify-center">
                  <ArrowDownUp className="h-3 w-3 text-white" style={{ transform: 'rotate(135deg)' }} />
                </div>
                <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider">Receiver</span>
              </div>
              <p className="text-sm font-semibold leading-tight">{data.receiverName || '—'}</p>
              <div className="text-[10px] text-muted-foreground mt-0.5">
                {data.receiverEmail && <p>{data.receiverEmail}</p>}
                {(data.receiverAccountNumber || data.receiverWalletId) && (
                  <p className="font-mono">{data.receiverBankName ? `Acct: ${data.receiverAccountNumber?.substring(0, 16)}` : `Wallet: ${data.receiverWalletId?.substring(0, 16)}`}</p>
                )}
              </div>
            </div>
          </div>

          {/* ── Financial Breakdown ──── */}
          <div className="px-6 pb-3">
            <div className="rounded-xl border bg-white p-4">
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Transaction Amount</h3>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">Amount in Figures:</span>
                <span className="text-xl font-bold text-foreground tabular-nums">{amountInFigures}</span>
              </div>

              {/* Fee breakdown (Telebirr style) - shown first */}
              <div className="border-t pt-3 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Service Charge:</span>
                  <span className="font-medium tabular-nums">{data.fee > 0 ? `${data.currency} ${fees.netFee.toLocaleString()}` : 'ETB 0.00'}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">VAT (15%):</span>
                  <span className="font-medium tabular-nums">{fees.vat > 0 ? `${data.currency} ${fees.vat.toLocaleString()}` : `${data.currency} 0.00`}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Disaster Recovery (5%):</span>
                  <span className="font-medium tabular-nums">{fees.disasterRecovery > 0 ? `${data.currency} ${fees.disasterRecovery.toLocaleString()}` : `${data.currency} 0.00`}</span>
                </div>
                <div className="flex items-center justify-between text-sm font-bold pt-2 border-t border-dashed">
                  <span>Total Amount Debited:</span>
                  <span className="tabular-nums text-emerald-600">{totalInFigures}</span>
                </div>
              </div>
            </div>
          </div>

          {/* ── AI Financial Advice Panel ──── */}
          <div className="px-6 pb-3">
            <div className="rounded-xl border-2 border-teal-200 bg-gradient-to-br from-teal-50/80 to-emerald-50/50 overflow-hidden">
              <button
                onClick={() => setShowAiPanel(!showAiPanel)}
                className="advice-no-print w-full flex items-center justify-between px-4 py-2.5 bg-teal-100/60 hover:bg-teal-100/80 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <div className="h-6 w-6 rounded-lg bg-teal-600 flex items-center justify-center">
                    <Sparkles className="h-3.5 w-3.5 text-white" />
                  </div>
                  <span className="text-xs font-bold text-teal-800">AI Financial Advice</span>
                  {risk && (
                    <Badge className={`text-[10px] ${risk.color}`}>
                      <RiskIcon className="h-3 w-3 mr-1" />
                      {risk.label}
                    </Badge>
                  )}
                </div>
                {showAiPanel ? <ChevronUp className="h-3.5 w-3.5 text-teal-600" /> : <ChevronDown className="h-3.5 w-3.5 text-teal-600" />}
              </button>

              <AnimatePresence>
                {showAiPanel && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-3 pt-2 space-y-2.5">
                      {aiLoading ? (
                        <div className="space-y-2">
                          <Skeleton className="h-3 w-full" />
                          <Skeleton className="h-3 w-3/4" />
                          <Skeleton className="h-3 w-1/2" />
                          <div className="flex items-center gap-2 text-xs text-teal-600">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            <span>Analyzing transaction...</span>
                          </div>
                        </div>
                      ) : aiAdvice ? (
                        <>
                          {aiAdvice.summary && (
                            <div className="flex items-start gap-2">
                              <Lightbulb className="h-3.5 w-3.5 text-teal-600 mt-0.5 flex-shrink-0" />
                              <p className="text-xs text-foreground leading-relaxed">{aiAdvice.summary}</p>
                            </div>
                          )}
                          {aiAdvice.riskNotes && (
                            <div className={`flex items-start gap-2 rounded-lg p-2 ${risk?.color || 'bg-muted'} bg-opacity-10`}>
                              <RiskIcon className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
                              <p className="text-[11px] leading-relaxed">{aiAdvice.riskNotes}</p>
                            </div>
                          )}
                          {aiAdvice.insights && aiAdvice.insights.length > 0 && (
                            <div>
                              <div className="flex items-center gap-1 mb-1">
                                <TrendingUp className="h-3 w-3 text-teal-600" />
                                <span className="text-[10px] font-semibold text-teal-700 uppercase tracking-wider">Insights</span>
                              </div>
                              <ul className="space-y-1">
                                {aiAdvice.insights.map((insight, i) => (
                                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-foreground leading-relaxed">
                                    <span className="text-teal-500 mt-0.5 flex-shrink-0">●</span>
                                    {insight}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {aiAdvice.recommendations && aiAdvice.recommendations.length > 0 && (
                            <div>
                              <div className="flex items-center gap-1 mb-1">
                                <Lightbulb className="h-3 w-3 text-amber-500" />
                                <span className="text-[10px] font-semibold text-amber-700 uppercase tracking-wider">Recommendations</span>
                              </div>
                              <ul className="space-y-1">
                                {aiAdvice.recommendations.map((rec, i) => (
                                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-foreground leading-relaxed">
                                    <span className="text-amber-500 mt-0.5 flex-shrink-0">→</span>
                                    {rec}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {aiAdvice.regulatoryNote && (
                            <div className="flex items-start gap-1.5 rounded-lg bg-amber-50 border border-amber-200 p-2">
                              <AlertTriangle className="h-3 w-3 text-amber-600 mt-0.5 flex-shrink-0" />
                              <p className="text-[10px] text-amber-800 leading-relaxed">{aiAdvice.regulatoryNote}</p>
                            </div>
                          )}
                        </>
                      ) : (
                        <p className="text-[11px] text-muted-foreground">Unable to generate AI advice at this time.</p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Description */}
          {data.description && (
            <div className="px-6 pb-3">
              <div className="rounded-lg bg-muted/30 border p-2.5">
                <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">Description:</span>
                <p className="text-[11px] mt-0.5">{data.description}</p>
              </div>
            </div>
          )}

          {/* Amount in words - at the bottom, collapsible */}
          <div className="px-6 pb-3">
            <details className="group">
              <summary className="flex items-center justify-between cursor-pointer text-[10px] font-medium text-muted-foreground uppercase tracking-wider hover:text-foreground transition-colors">
                <span>Amount in Words</span>
                <ChevronDown className="h-3 w-3 transition-transform group-open:rotate-180" />
              </summary>
              <p className="text-[11px] font-medium text-foreground mt-1 leading-relaxed italic bg-muted/50 rounded-lg p-2.5 border">{amountInWords}</p>
            </details>
          </div>

          {/* ── Footer ──── */}
          <div className="px-6 py-3 bg-muted/30 border-t">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1.5 text-[10px] text-muted-foreground">
              <div>
                <p>This is a system-generated transaction advice. No signature required.</p>
                <p>FinFlow Enterprise Platform | NBE Licensed & Regulated | Addis Ababa, Ethiopia</p>
              </div>
              <div className="text-right">
                <p>Powered by FinFlow Technology</p>
              </div>
            </div>
          </div>
        </div>

        {/* ── Bottom Action Bar (Telebirr style) ──── */}
        <div className="advice-no-print px-6 py-4 border-t flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handlePrint} className="h-9 gap-1.5 text-xs">
              <Receipt className="h-3.5 w-3.5" /> Receipt
            </Button>
            <Button variant="outline" size="sm" onClick={() => {}} className="h-9 gap-1.5 text-xs">
              <Camera className="h-3.5 w-3.5" /> Screenshot
            </Button>
            <Button variant="outline" size="sm" onClick={handleCopy} className="h-9 gap-1.5 text-xs">
              <Share2 className="h-3.5 w-3.5" /> Share
            </Button>
          </div>
          <Button onClick={onClose} className="h-9 px-6 bg-emerald-600 hover:bg-emerald-700 text-sm">
            Close
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
