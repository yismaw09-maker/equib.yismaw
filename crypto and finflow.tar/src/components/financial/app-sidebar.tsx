'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useAppStore, type ViewId } from '@/lib/store';
import { getRoleInfo, getRoleLevel } from '@/lib/role-permissions';
import { useT } from '@/lib/i18n';
import {
  LayoutDashboard,
  Wallet,
  ArrowLeftRight,
  Send,
  Landmark,
  CreditCard,
  Globe,
  Download,
  Store,
  Users,
  Shield,
  Bell,
  Settings,
  FileBarChart,
  ChevronLeft,
  Coins,
  Bitcoin,
  Activity,
  ShieldCheck,
  CheckCircle2,
  Puzzle,
  Bot,
  BookOpen,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

// ── Types ─────────────────────────────────────────────

interface NavItem {
  id: ViewId;
  labelKey: string;
  icon: React.ElementType;
  badge?: string;
  minRoleLevel?: number;
  descriptionKey?: string;
  iconGradient: string;
  iconColor: string;
}

// ── Enterprise Navigation Sections ─────────────────────

const mainNav: NavItem[] = [
  { id: 'dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard, descriptionKey: 'nav.dashboard', iconGradient: 'from-emerald-500 to-teal-500', iconColor: 'text-emerald-500' },
  { id: 'activity-center', labelKey: 'nav.activityCenter', icon: Activity, descriptionKey: 'nav.activityCenter', iconGradient: 'from-teal-500 to-cyan-500', iconColor: 'text-teal-500' },
  { id: 'notifications', labelKey: 'nav.notifications', icon: Bell, descriptionKey: 'nav.notifications', iconGradient: 'from-cyan-500 to-sky-500', iconColor: 'text-cyan-500' },
];

const walletNav: NavItem[] = [
  { id: 'wallets', labelKey: 'nav.wallets', icon: Wallet, descriptionKey: 'nav.wallets', iconGradient: 'from-sky-500 to-blue-500', iconColor: 'text-sky-500' },
  { id: 'transfers', labelKey: 'nav.walletTransfers', icon: Send, descriptionKey: 'nav.walletTransfers', iconGradient: 'from-blue-500 to-indigo-500', iconColor: 'text-blue-500' },
  { id: 'crypto', labelKey: 'nav.crypto', icon: Bitcoin, descriptionKey: 'nav.crypto', iconGradient: 'from-orange-500 to-amber-500', iconColor: 'text-orange-500' },
];

const transactionNav: NavItem[] = [
  { id: 'transactions', labelKey: 'nav.transactions', icon: ArrowLeftRight, descriptionKey: 'nav.transactions', iconGradient: 'from-violet-500 to-purple-500', iconColor: 'text-violet-500' },
];

const bankingNav: NavItem[] = [
  { id: 'banking', labelKey: 'nav.banking', icon: Landmark, descriptionKey: 'nav.banking', iconGradient: 'from-purple-500 to-fuchsia-500', iconColor: 'text-purple-500' },
];

const currencyNav: NavItem[] = [
  { id: 'currencies', labelKey: 'nav.currencies', icon: Globe, descriptionKey: 'nav.currencies', iconGradient: 'from-fuchsia-500 to-pink-500', iconColor: 'text-fuchsia-500' },
];

const sendReceiveNav: NavItem[] = [
  { id: 'send-receive', labelKey: 'nav.sendReceive', icon: Download, descriptionKey: 'nav.sendReceive', iconGradient: 'from-pink-500 to-rose-500', iconColor: 'text-pink-500' },
];

const commerceNav: NavItem[] = [
  { id: 'payments', labelKey: 'nav.payments', icon: CreditCard, descriptionKey: 'nav.payments', iconGradient: 'from-amber-500 to-orange-500', iconColor: 'text-amber-500' },
  { id: 'merchants', labelKey: 'nav.merchants', icon: Store, descriptionKey: 'nav.merchants', minRoleLevel: 30, iconGradient: 'from-orange-500 to-red-500', iconColor: 'text-orange-500' },
  { id: 'customers', labelKey: 'nav.customers', icon: Users, descriptionKey: 'nav.customers', minRoleLevel: 25, iconGradient: 'from-red-500 to-rose-600', iconColor: 'text-red-500' },
];

const securityNav: NavItem[] = [
  { id: 'security', labelKey: 'nav.security', icon: Shield, descriptionKey: 'nav.security', minRoleLevel: 55, iconGradient: 'from-red-600 to-rose-700', iconColor: 'text-red-600' },
  { id: 'compliance', labelKey: 'nav.compliance', icon: ShieldCheck, descriptionKey: 'nav.compliance', minRoleLevel: 55, iconGradient: 'from-rose-600 to-pink-700', iconColor: 'text-rose-600' },
];

const adminNav: NavItem[] = [
  { id: 'admin', labelKey: 'nav.administration', icon: Settings, descriptionKey: 'nav.administration', minRoleLevel: 45, iconGradient: 'from-slate-500 to-gray-600', iconColor: 'text-slate-500' },
  { id: 'approvals', labelKey: 'nav.approvals', icon: CheckCircle2, descriptionKey: 'nav.approvals', minRoleLevel: 45, iconGradient: 'from-emerald-600 to-green-700', iconColor: 'text-emerald-600' },
  { id: 'integrations', labelKey: 'nav.integrations', icon: Puzzle, descriptionKey: 'nav.integrations', minRoleLevel: 60, iconGradient: 'from-violet-600 to-purple-700', iconColor: 'text-violet-600' },
];

const reportsNav: NavItem[] = [
  { id: 'reports', labelKey: 'nav.reports', icon: FileBarChart, descriptionKey: 'nav.reports', minRoleLevel: 45, iconGradient: 'from-cyan-600 to-teal-700', iconColor: 'text-cyan-600' },
];

const aiNav: NavItem[] = [
  { id: 'ai-assistant', labelKey: 'nav.aiAssistant', icon: Bot, descriptionKey: 'nav.aiAssistant', iconGradient: 'from-amber-500 to-yellow-500', iconColor: 'text-amber-500' },
];

const ledgerNav: NavItem[] = [
  { id: 'ledger', labelKey: 'nav.ledger', icon: BookOpen, descriptionKey: 'nav.ledger', minRoleLevel: 60, iconGradient: 'from-stone-500 to-stone-700', iconColor: 'text-stone-500' },
];

const settingsNav: NavItem[] = [
  { id: 'settings', labelKey: 'nav.settings', icon: Settings, descriptionKey: 'nav.settings', minRoleLevel: 80, iconGradient: 'from-gray-500 to-gray-700', iconColor: 'text-gray-500' },
];

// ── Section Definitions ──────────────────────────────────

const sections: { titleKey: string; items: NavItem[]; alwaysShow?: boolean }[] = [
  { titleKey: 'nav.main', items: mainNav, alwaysShow: true },
  { titleKey: 'nav.walletAndAccounts', items: walletNav },
  { titleKey: 'nav.transactions', items: transactionNav },
  { titleKey: 'nav.banking', items: bankingNav },
  { titleKey: 'nav.currenciesAndFx', items: currencyNav },
  { titleKey: 'nav.sendAndReceive', items: sendReceiveNav },
  { titleKey: 'nav.paymentsAndCommerce', items: commerceNav },
  { titleKey: 'nav.securityAndCompliance', items: securityNav },
  { titleKey: 'nav.administration', items: adminNav },
  { titleKey: 'nav.reportsAndAnalytics', items: reportsNav },
  { titleKey: 'nav.aiAndAutomation', items: aiNav },
  { titleKey: 'nav.auditAndLedger', items: ledgerNav },
  { titleKey: 'nav.settings', items: settingsNav },
];

// ── Helpers ────────────────────────────────────────────

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

// ── Nav Section Component ──────────────────────────────

function NavSection({
  titleKey,
  items,
  activeView,
  onSelect,
}: {
  titleKey: string;
  items: NavItem[];
  activeView: ViewId;
  onSelect: (id: ViewId) => void;
}) {
  const t = useT();

  if (items.length === 0) return null;

  return (
    <div className="px-3 py-1.5">
      <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/70">
        {t(titleKey)}
      </p>
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = activeView === item.id;
        return (
          <TooltipProvider key={item.id} delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  id={`nav-item-${item.id}`}
                  className={cn(
                    'sidebar-nav-item w-full flex items-center gap-3 px-3 mb-0.5 h-11 md:h-10 rounded-xl transition-all duration-200 cursor-pointer border-0 bg-transparent text-left group',
                    isActive
                      ? 'bg-gradient-to-r from-primary/10 to-primary/5 text-primary font-medium shadow-sm ring-1 ring-primary/20'
                      : 'hover:bg-accent/80 text-foreground'
                  )}
                  onClick={() => onSelect(item.id)}
                >
                  <div className={cn(
                    'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-all duration-200',
                    isActive
                      ? `bg-gradient-to-br ${item.iconGradient} shadow-md`
                      : `bg-gradient-to-br ${item.iconGradient} opacity-20 group-hover:opacity-40`
                  )}>
                    <Icon className={cn(
                      'h-4 w-4 transition-colors duration-200',
                      isActive ? 'text-white' : item.iconColor
                    )} />
                  </div>
                  <span className="truncate text-[13px]">{t(item.labelKey)}</span>
                  {item.badge && !isActive && (
                    <Badge
                      className="ml-auto h-5 min-w-[20px] justify-center px-1.5 text-[10px] bg-destructive text-white hover:bg-destructive"
                    >
                      {item.badge}
                    </Badge>
                  )}
                  {isActive && (
                    <div className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" />
                  )}
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs">
                {item.descriptionKey ? t(item.descriptionKey) : t(item.labelKey)}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      })}
    </div>
  );
}

// ── Main Sidebar ───────────────────────────────────────

export function AppSidebar() {
  const { activeView, setActiveView, sidebarOpen, setSidebarOpen, user } = useAppStore();
  const t = useT();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showTopShadow, setShowTopShadow] = useState(false);
  const [showBottomShadow, setShowBottomShadow] = useState(false);
  const role = user?.role || 'user';
  const roleInfo = getRoleInfo(role);

  const filterNav = (items: NavItem[]) =>
    items.filter((item) => !item.minRoleLevel || (user && getRoleLevel(role) >= item.minRoleLevel));

  // Build filtered sections, hiding empty ones
  const filteredSections = sections
    .map((s) => ({ ...s, items: s.alwaysShow ? s.items : filterNav(s.items) }))
    .filter((s) => s.items.length > 0);

  const displayName = user?.name || 'User';
  const initials = getInitials(displayName);
  const roleLabel = roleInfo.label;

  const updateShadows = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const { scrollTop, scrollHeight, clientHeight } = el;
    setShowTopShadow(scrollTop > 4);
    setShowBottomShadow(scrollTop + clientHeight < scrollHeight - 4);
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const activeEl = document.getElementById(`nav-item-${activeView}`);
    if (!activeEl) return;

    const elRect = el.getBoundingClientRect();
    const activeRect = activeEl.getBoundingClientRect();

    if (activeRect.top < elRect.top || activeRect.bottom > elRect.bottom) {
      activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [activeView]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    updateShadows();
    el.addEventListener('scroll', updateShadows, { passive: true });
    window.addEventListener('resize', updateShadows, { passive: true });
    return () => {
      el.removeEventListener('scroll', updateShadows);
      window.removeEventListener('resize', updateShadows);
    };
  }, [updateShadows]);

  return (
    <>
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          'fixed top-0 left-0 z-50 flex h-full w-[260px] flex-col border-r bg-card/95 backdrop-blur-md transition-transform duration-300 ease-in-out md:static md:z-auto md:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-14 items-center gap-3 border-b px-4 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-md">
            <Coins className="h-5 w-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight">FinFlow</span>
            <span className="text-[9px] text-muted-foreground leading-none">
              Enterprise Edition v1.0
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto h-9 w-9 md:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>

        <div className="relative flex-1 min-h-0">
          <div
            className={cn(
              'sidebar-scroll-shadow-top pointer-events-none absolute top-0 left-0 right-0 z-10 h-6 transition-opacity duration-200',
              showTopShadow ? 'opacity-100' : 'opacity-0'
            )}
          />
          <div
            className={cn(
              'sidebar-scroll-shadow-bottom pointer-events-none absolute bottom-0 left-0 right-0 z-10 h-6 transition-opacity duration-200',
              showBottomShadow ? 'opacity-100' : 'opacity-0'
            )}
          />

          <div
            ref={scrollRef}
            className="sidebar-nav-scroll h-full overflow-y-auto overflow-x-hidden py-2"
          >
            {filteredSections.map((section, idx) => (
              <div key={section.titleKey}>
                <NavSection
                  titleKey={section.titleKey}
                  items={section.items}
                  activeView={activeView}
                  onSelect={setActiveView}
                />
                {idx < filteredSections.length - 1 && (
                  <Separator className="my-2 mx-4" />
                )}
              </div>
            ))}
            <div className="h-6" />
          </div>
        </div>

        <div className="border-t p-3 shrink-0">
          <div className="flex items-center gap-3 rounded-xl bg-gradient-to-r from-muted/60 to-muted/30 p-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-[11px] font-bold text-white shrink-0 shadow-sm">
              {initials}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-semibold truncate">{displayName}</span>
              <span className="text-[10px] text-muted-foreground truncate">
                {roleLabel}
              </span>
            </div>
            <Badge variant="secondary" className="ml-auto text-[9px] shrink-0">
              {roleInfo.accessLevel}
            </Badge>
          </div>
        </div>
      </aside>
    </>
  );
}
