'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  ShieldCheck,
  Search,
  AlertTriangle,
  FileCheck,
  Eye,
  RefreshCw,
  UserCheck,
  ShieldAlert,
  TrendingUp,
  Fingerprint,
  Gavel,
  Inbox,
  CircleDot,
  CheckCircle2,
  XCircle,
  Clock,
  AlertOctagon,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { PieChart, Pie, Cell } from 'recharts';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface ComplianceCase {
  id: string;
  type: 'kyc' | 'aml' | 'fraud' | 'suspicious' | 'risk';
  status: 'open' | 'pending_review' | 'investigating' | 'resolved' | 'dismissed';
  priority: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  userId: string | null;
  user?: { name: string; email: string } | null;
  createdAt: string;
  updatedAt: string;
  assignedTo?: string | null;
}

interface ComplianceStats {
  openCases: number;
  pendingKYC: number;
  flaggedTransactions: number;
  riskDistribution: { name: string; value: number; color: string }[];
}

// --- Helpers ---

const statusColor: Record<string, string> = {
  open: 'bg-rose-100 text-rose-700 border-rose-200',
  pending_review: 'bg-amber-100 text-amber-700 border-amber-200',
  investigating: 'bg-violet-100 text-violet-700 border-violet-200',
  resolved: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  dismissed: 'bg-gray-100 text-gray-500 border-gray-200',
  verified: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  rejected: 'bg-rose-100 text-rose-700 border-rose-200',
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
};

const priorityColor: Record<string, string> = {
  low: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  medium: 'bg-amber-100 text-amber-700 border-amber-200',
  high: 'bg-orange-100 text-orange-700 border-orange-200',
  critical: 'bg-rose-100 text-rose-700 border-rose-200',
};

const priorityIcon: Record<string, string> = {
  low: 'text-emerald-500',
  medium: 'text-amber-500',
  high: 'text-orange-500',
  critical: 'text-rose-500',
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const MOCK_CASES: ComplianceCase[] = [
  { id: 'c1', type: 'kyc', status: 'pending_review', priority: 'high', title: 'KYC Document Review — Sara Tadesse', description: 'ID document uploaded, requires manual verification', userId: 'u9', user: { name: 'Sara Tadesse', email: 'sara@example.com' }, createdAt: new Date(Date.now() - 1000*60*30).toISOString(), updatedAt: new Date(Date.now() - 1000*60*10).toISOString(), assignedTo: 'Selamawit Fikadu' },
  { id: 'c2', type: 'aml', status: 'investigating', priority: 'critical', title: 'Large Transaction Pattern Detected', description: 'Multiple high-value transfers totaling ETB 850,000 within 24 hours', userId: 'u4', user: { name: 'Helen Mengistu', email: 'helen@example.com' }, createdAt: new Date(Date.now() - 1000*60*120).toISOString(), updatedAt: new Date(Date.now() - 1000*60*20).toISOString() },
  { id: 'c3', type: 'fraud', status: 'open', priority: 'high', title: 'Potential Account Takeover', description: 'Login from new device in different country, followed by withdrawal attempt', userId: 'u3', user: { name: 'Yohannes Girma', email: 'yohannes@example.com' }, createdAt: new Date(Date.now() - 1000*60*60).toISOString(), updatedAt: new Date(Date.now() - 1000*60*45).toISOString() },
  { id: 'c4', type: 'suspicious', status: 'open', priority: 'medium', title: 'Unusual Transfer Activity', description: 'Rapid small transfers to multiple recipients, structuring pattern suspected', userId: 'u5', user: { name: 'Getachew Tesfaye', email: 'getachew@example.com' }, createdAt: new Date(Date.now() - 1000*60*200).toISOString(), updatedAt: new Date(Date.now() - 1000*60*180).toISOString() },
  { id: 'c5', type: 'risk', status: 'pending_review', priority: 'medium', title: 'Risk Score Elevated — Dawit Amare', description: 'Risk score increased from 0.15 to 0.72 due to behavioral changes', userId: 'u2', user: { name: 'Dawit Amare', email: 'dawit@example.com' }, createdAt: new Date(Date.now() - 1000*60*300).toISOString(), updatedAt: new Date(Date.now() - 1000*60*240).toISOString() },
  { id: 'c6', type: 'kyc', status: 'resolved', priority: 'low', title: 'KYC Verified — Tigist Haile', description: 'All documents verified successfully', userId: 'u1', user: { name: 'Tigist Haile', email: 'tigist@example.com' }, createdAt: new Date(Date.now() - 1000*60*400).toISOString(), updatedAt: new Date(Date.now() - 1000*60*380).toISOString() },
  { id: 'c7', type: 'aml', status: 'dismissed', priority: 'low', title: 'False Positive — Legitimate Business Transfers', description: 'Merchant account with verified business profile making regular payments', userId: 'u2', user: { name: 'Merkato Electronics', email: 'merkato@example.com' }, createdAt: new Date(Date.now() - 1000*60*500).toISOString(), updatedAt: new Date(Date.now() - 1000*60*490).toISOString() },
  { id: 'c8', type: 'fraud', status: 'investigating', priority: 'critical', title: 'Chargeback Fraud Ring Suspected', description: '3 linked accounts filing simultaneous chargebacks on same merchant', userId: null, user: null, createdAt: new Date(Date.now() - 1000*60*90).toISOString(), updatedAt: new Date(Date.now() - 1000*60*30).toISOString() },
];

const MOCK_STATS: ComplianceStats = {
  openCases: 4,
  pendingKYC: 3,
  flaggedTransactions: 12,
  riskDistribution: [
    { name: 'Low Risk', value: 68, color: '#10b981' },
    { name: 'Medium Risk', value: 20, color: '#f59e0b' },
    { name: 'High Risk', value: 8, color: '#f97316' },
    { name: 'Critical', value: 4, color: '#f43f5e' },
  ],
};

// --- Component ---

export default function ComplianceView() {
  const { formatDateTime, formatRelative } = useFormattedDate();

  const [cases, setCases] = useState<ComplianceCase[]>([]);
  const [stats, setStats] = useState<ComplianceStats>(MOCK_STATS);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('kyc');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/compliance');
      if (res.ok) {
        const data = await res.json();
        if (data.cases) setCases(data.cases);
        if (data.stats) setStats(data.stats);
      } else {
        setCases(MOCK_CASES);
      }
    } catch {
      setCases(MOCK_CASES);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredCases = useMemo(() => {
    let result = cases;

    // Tab filter by type
    const tabTypeMap: Record<string, string> = {
      kyc: 'kyc',
      aml: 'aml',
      fraud: 'fraud',
      risk: 'risk',
      suspicious: 'suspicious',
      cases: '',
    };
    if (activeTab !== 'cases') {
      result = result.filter((c) => c.type === tabTypeMap[activeTab]);
    }

    if (statusFilter !== 'all') {
      result = result.filter((c) => c.status === statusFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          (c.user?.name || '').toLowerCase().includes(q),
      );
    }

    return result;
  }, [cases, activeTab, statusFilter, searchQuery]);

  const renderStatsCards = () => (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <Card className="border-rose-200/50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Open Cases</p>
              <p className="text-2xl font-bold text-rose-600">{stats.openCases}</p>
            </div>
            <div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center">
              <AlertOctagon className="h-4 w-4 text-rose-600" />
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-amber-200/50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Pending KYC</p>
              <p className="text-2xl font-bold text-amber-600">{stats.pendingKYC}</p>
            </div>
            <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
              <UserCheck className="h-4 w-4 text-amber-600" />
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-orange-200/50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Flagged Transactions</p>
              <p className="text-2xl font-bold text-orange-600">{stats.flaggedTransactions}</p>
            </div>
            <div className="h-9 w-9 rounded-lg bg-orange-100 flex items-center justify-center">
              <ShieldAlert className="h-4 w-4 text-orange-600" />
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-emerald-200/50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Resolved</p>
              <p className="text-2xl font-bold text-emerald-600">{cases.filter((c) => c.status === 'resolved').length}</p>
            </div>
            <div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderRiskChart = () => (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Risk Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-6">
          <div className="w-40 h-40">
            <ChartContainer config={{}} className="h-full w-full">
              <PieChart>
                <Pie
                  data={stats.riskDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={65}
                  dataKey="value"
                  strokeWidth={2}
                >
                  {stats.riskDistribution.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ChartContainer>
          </div>
          <div className="flex-1 space-y-2">
            {stats.riskDistribution.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm">{item.name}</span>
                </div>
                <span className="text-sm font-semibold">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const renderLoadingSkeleton = () => (
    <div className="space-y-3 p-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="space-y-2">
          <Skeleton className="h-5 w-1/2" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/3" />
        </div>
      ))}
    </div>
  );

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Inbox className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium">No cases found</h3>
      <p className="text-sm text-muted-foreground mt-1">No compliance cases match your current filters.</p>
    </div>
  );

  const renderCasesTable = (items: ComplianceCase[]) => (
    <ScrollArea className="max-h-[500px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">Priority</TableHead>
            <TableHead className="min-w-[200px]">Case</TableHead>
            <TableHead>User</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Assigned To</TableHead>
            <TableHead className="w-[120px]">Updated</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((c) => (
            <TableRow key={c.id}>
              <TableCell>
                <Badge variant="outline" className={cn('text-[10px]', priorityColor[c.priority])}>
                  <CircleDot className={cn('h-3 w-3 mr-1', priorityIcon[c.priority])} />
                  {c.priority}
                </Badge>
              </TableCell>
              <TableCell>
                <div>
                  <p className="text-sm font-medium">{c.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{c.description}</p>
                </div>
              </TableCell>
              <TableCell className="text-sm">{c.user?.name || '—'}</TableCell>
              <TableCell>
                <Badge variant="outline" className={statusColor[c.status]}>
                  {c.status.replace(/_/g, ' ')}
                </Badge>
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">{c.assignedTo || '—'}</TableCell>
              <TableCell className="text-xs text-muted-foreground" title={formatDateTime(c.updatedAt)}>
                {formatRelative(c.updatedAt)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <ShieldCheck className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Security & Compliance</h1>
            <p className="text-sm text-muted-foreground">Monitor KYC, AML, fraud detection, and compliance operations</p>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div {...fadeUp}>{renderStatsCards()}</motion.div>

      {/* Risk Chart + Quick Stats */}
      <motion.div {...fadeUp} className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {renderRiskChart()}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Compliance Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>KYC Verification Rate</span>
                  <span className="font-medium text-emerald-600">87%</span>
                </div>
                <Progress value={87} className="h-2" />
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>AML Screening Coverage</span>
                  <span className="font-medium text-teal-600">94%</span>
                </div>
                <Progress value={94} className="h-2" />
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Fraud Detection Accuracy</span>
                  <span className="font-medium text-cyan-600">91%</span>
                </div>
                <Progress value={91} className="h-2" />
              </div>
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Case Resolution Rate</span>
                  <span className="font-medium text-amber-600">72%</span>
                </div>
                <Progress value={72} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search & Filter */}
      <motion.div {...fadeUp} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search cases by title, description, or user..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="pending_review">Pending Review</SelectItem>
            <SelectItem value="investigating">Investigating</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="dismissed">Dismissed</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchData} title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* Main Tabs */}
      <motion.div {...fadeUp}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Compliance Cases</CardTitle>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                {filteredCases.length} cases
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4 flex-wrap h-auto gap-1">
                <TabsTrigger value="cases" className="gap-1.5">
                  <Gavel className="h-3.5 w-3.5" /> All Cases
                </TabsTrigger>
                <TabsTrigger value="kyc" className="gap-1.5">
                  <UserCheck className="h-3.5 w-3.5" /> KYC/KYB
                </TabsTrigger>
                <TabsTrigger value="aml" className="gap-1.5">
                  <ShieldAlert className="h-3.5 w-3.5" /> AML
                </TabsTrigger>
                <TabsTrigger value="fraud" className="gap-1.5">
                  <AlertTriangle className="h-3.5 w-3.5" /> Fraud
                </TabsTrigger>
                <TabsTrigger value="risk" className="gap-1.5">
                  <TrendingUp className="h-3.5 w-3.5" /> Risk
                </TabsTrigger>
                <TabsTrigger value="suspicious" className="gap-1.5">
                  <Eye className="h-3.5 w-3.5" /> Suspicious
                </TabsTrigger>
              </TabsList>

              {['cases', 'kyc', 'aml', 'fraud', 'risk', 'suspicious'].map((tab) => (
                <TabsContent key={tab} value={tab}>
                  {loading ? renderLoadingSkeleton() : filteredCases.length === 0 ? renderEmptyState() : renderCasesTable(filteredCases)}
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
