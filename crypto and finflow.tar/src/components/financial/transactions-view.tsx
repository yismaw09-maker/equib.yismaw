'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Search,
  X,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckCircle2,
  XCircle,
  RotateCcw,
  FileText,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  Filter,
  Loader2,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toast } from 'sonner';
import { useT } from '@/lib/i18n';
import { isAdminRole } from '@/lib/role-permissions';
import TransactionAdvice, { type AdviceData } from '@/components/financial/transaction-advice';
import { useAppStore } from '@/lib/store';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface TransactionItem {
  id: string;
  reference: string;
  type: string;
  subType: string | null;
  status: string;
  amount: number;
  fee: number;
  currency: string;
  description: string | null;
  initiatorId: string | null;
  recipientId: string | null;
  recipientName: string | null;
  sourceWalletId: string | null;
  destinationWalletId: string | null;
  paymentMethod: string | null;
  bankName: string | null;
  accountNumber: string | null;
  senderAddress: string | null;
  receiverAddress: string | null;
  otpVerified: boolean;
  twoFactorVerified: boolean;
  riskScore: number | null;
  fraudFlag: boolean;
  completedAt: string | null;
  createdAt: string;
  initiator?: { id: string; name: string; email: string } | null;
  recipient?: { id: string; name: string; email: string } | null;
}

interface PaginationData {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface SummaryData {
  totalAmount: number;
  completedCount: number;
  completedAmount: number;
  pendingCount: number;
  pendingAmount: number;
  processingCount: number;
  processingAmount: number;
  failedCount: number;
  failedAmount: number;
  cancelledCount: number;
  cancelledAmount: number;
  reversedCount: number;
  reversedAmount: number;
}

// --- Constants ---

const TRANSACTION_TYPES = [
  'All', 'Deposit', 'Withdrawal', 'Transfer', 'Payment', 'Refund', 'Chargeback', 'Reversal', 'Commission', 'Escrow', 'Split Payment',
];

const TRANSACTION_STATUSES = [
  'All', 'Pending', 'Processing', 'Completed', 'Failed', 'Cancelled', 'Reversed',
];

const STATUS_VARIANT: Record<string, string> = {
  completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
  processing: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  failed: 'bg-red-100 text-red-700 border-red-200',
  cancelled: 'bg-gray-100 text-gray-700 border-gray-200',
  reversed: 'bg-purple-100 text-purple-700 border-purple-200',
};

const TYPE_VARIANT: Record<string, string> = {
  deposit: 'bg-emerald-100 text-emerald-700',
  withdrawal: 'bg-rose-100 text-rose-700',
  transfer: 'bg-teal-100 text-teal-700',
  payment: 'bg-amber-100 text-amber-700',
  refund: 'bg-orange-100 text-orange-700',
  chargeback: 'bg-red-100 text-red-700',
  reversal: 'bg-purple-100 text-purple-700',
  commission: 'bg-cyan-100 text-cyan-700',
  escrow: 'bg-sky-100 text-sky-700',
  split_payment: 'bg-fuchsia-100 text-fuchsia-700',
};

function formatCurrency(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency === 'ETB' ? 'ETB' : currency,
      minimumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  }
}

// --- Sort column config ---
type SortField = 'createdAt' | 'amount' | 'fee' | 'type' | 'status' | 'reference';

// --- Component ---

export default function TransactionsView() {
  const t = useT();
  const { formatDateTime } = useFormattedDate();
  const currentUser = useAppStore(s => s.user);
  const isAdmin = currentUser ? isAdminRole(currentUser.role) : false;

  // Filters
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Pagination
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState('20');

  // Sorting
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Data
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [pagination, setPagination] = useState<PaginationData>({ page: 1, limit: 20, total: 0, totalPages: 0 });
  const [summary, setSummary] = useState<SummaryData | null>(null);
  const [loading, setLoading] = useState(true);

  // AI advice state
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [aiAdviceLoading, setAiAdviceLoading] = useState(false);
  const [showAdvicePanel, setShowAdvicePanel] = useState(false);

  // Per-transaction AI advice in detail dialog
  const [detailAiAdvice, setDetailAiAdvice] = useState<string | null>(null);
  const [detailAiLoading, setDetailAiLoading] = useState(false);

  // UI state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [detailTxn, setDetailTxn] = useState<TransactionItem | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [adviceData, setAdviceData] = useState<AdviceData | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const limit = parseInt(pageSize) || 20;

  // Sortable columns defined inside the component to use t()
  const SORTABLE_COLUMNS = useMemo(() => [
    { key: 'reference' as SortField, label: t('common.reference') },
    { key: 'type' as SortField, label: t('common.type') },
    { key: 'amount' as SortField, label: t('common.amount') },
    { key: 'fee' as SortField, label: t('transactions.fee') },
    { key: 'status' as SortField, label: t('common.status') },
    { key: 'createdAt' as SortField, label: t('common.date') },
  ], [t]);

  // Fetch transactions with all filters, sort, and pagination
  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set('search', search.trim());
      if (typeFilter !== 'All') params.set('type', typeFilter.toLowerCase());
      if (statusFilter !== 'All') params.set('status', statusFilter.toLowerCase());
      if (startDate) params.set('startDate', startDate);
      if (endDate) params.set('endDate', endDate);
      params.set('page', String(page));
      params.set('limit', String(limit));
      params.set('sort', sortField);
      params.set('order', sortOrder);

      const res = await apiFetch(`/api/transactions?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setTransactions(data.transactions ?? []);
      setPagination(data.pagination ?? { page: 1, limit, total: 0, totalPages: 0 });
      setSummary(data.summary ?? null);
    } catch {
      toast.error('Failed to load transactions');
    } finally {
      setLoading(false);
    }
  }, [search, typeFilter, statusFilter, startDate, endDate, page, limit, sortField, sortOrder]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [search, typeFilter, statusFilter, startDate, endDate, sortField, sortOrder, pageSize]);

  // Selection helpers
  const allSelected = transactions.length > 0 && transactions.every((t) => selectedIds.has(t.id));

  const toggleAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(transactions.map((t) => t.id)));
    }
  };

  const toggleRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Clear all filters
  const clearFilters = () => {
    setSearch('');
    setTypeFilter('All');
    setStatusFilter('All');
    setStartDate('');
    setEndDate('');
    setSortField('createdAt');
    setSortOrder('desc');
    setPage(1);
    setPageSize('20');
  };

  // Sort handler
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // Action handlers: approve, reject, reverse
  const handleAction = async (txn: TransactionItem, action: string) => {
    setActionLoading(txn.id);
    try {
      const body: Record<string, string> = {};
      if (action === 'approve') body.status = 'completed';
      else if (action === 'reject') body.status = 'failed';
      else if (action === 'reverse') body.status = 'reversed';

      const res = await apiFetch(`/api/transactions/${txn.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error();
      toast.success(`Transaction ${action}d successfully`);
      fetchTransactions();
    } catch {
      toast.error(`Failed to ${action} transaction`);
    } finally {
      setActionLoading(null);
    }
  };

  // Delete selected transactions
  const handleDeleteSelected = async () => {
    if (selectedIds.size === 0) return;
    setDeleteLoading(true);
    try {
      const res = await apiFetch('/api/transactions', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedIds) }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      toast.success(`Deleted ${data.deleted} transaction${data.deleted !== 1 ? 's' : ''}`);
      setSelectedIds(new Set());
      fetchTransactions();
    } catch {
      toast.error('Failed to delete transactions');
    } finally {
      setDeleteLoading(false);
    }
  };

  // View detail with fresh data from API
  const viewDetail = async (txn: TransactionItem) => {
    setDetailTxn(txn);
    setDetailOpen(true);
    setDetailLoading(true);
    try {
      const res = await apiFetch(`/api/transactions/${txn.id}`);
      if (res.ok) {
        const data = await res.json();
        setDetailTxn(data);
      }
    } catch {
      // Use the row data we already have
    } finally {
      setDetailLoading(false);
    }
  };

  // Helper functions
  const getAmountColor = (type: string) => {
    if (['deposit', 'refund', 'commission'].includes(type)) return 'text-emerald-600';
    if (['withdrawal', 'payment', 'chargeback'].includes(type)) return 'text-rose-600';
    return 'text-foreground';
  };

  const getAmountPrefix = (type: string) => {
    if (['deposit', 'refund', 'commission'].includes(type)) return '+';
    if (['withdrawal', 'payment', 'chargeback'].includes(type)) return '-';
    return '';
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-40" />;
    return sortOrder === 'asc'
      ? <ArrowUp className="h-3 w-3 text-emerald-600" />
      : <ArrowDown className="h-3 w-3 text-emerald-600" />;
  };

  const detailField = (label: string, value: React.ReactNode) => {
    let display: React.ReactNode = '-';
    if (value === true) display = t('common.yes');
    else if (value === false) display = t('common.no');
    else if (value != null && value !== '') {
      display = typeof value === 'string' || typeof value === 'number' ? String(value) : value;
    }
    return (
      <div className="flex flex-col gap-1">
        <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</span>
        <span className="text-sm font-medium text-foreground">{display}</span>
      </div>
    );
  };

  const hasActiveFilters = search || typeFilter !== 'All' || statusFilter !== 'All' || startDate || endDate;

  // AI Advice handler for bulk transactions
  const handleAiAdvice = async () => {
    setAiAdviceLoading(true);
    setAiAdvice(null);
    setShowAdvicePanel(true);
    try {
      const visibleTxns = transactions.slice(0, 5);
      const mappedTxns = visibleTxns.map((t) => ({
        reference: t.reference,
        type: t.type,
        amount: t.amount,
        currency: t.currency,
        status: t.status,
        riskScore: t.riskScore,
        fraudFlag: t.fraudFlag,
        initiatorName: t.initiator?.name ?? null,
        recipientName: t.recipient?.name ?? t.recipientName ?? null,
        bankName: t.bankName,
        description: t.description,
      }));
      const res = await apiFetch('/api/ai/advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactions: mappedTxns,
          context: 'FinFlow Ethiopian financial platform - analyze these transactions for risk and provide advice',
        }),
      });
      if (!res.ok) throw new Error('Failed to get advice');
      const data = await res.json();
      if (data.success) {
        setAiAdvice(data.advice);
      } else {
        toast.error(data.error || 'Failed to generate AI advice');
      }
    } catch {
      toast.error('Failed to generate AI advice. Please try again.');
    } finally {
      setAiAdviceLoading(false);
    }
  };

  // Per-transaction AI advice handler
  const handleDetailAiAdvice = async () => {
    if (!detailTxn) return;
    setDetailAiLoading(true);
    setDetailAiAdvice(null);
    try {
      const mappedTxn = {
        reference: detailTxn.reference,
        type: detailTxn.type,
        amount: detailTxn.amount,
        currency: detailTxn.currency,
        status: detailTxn.status,
        riskScore: detailTxn.riskScore,
        fraudFlag: detailTxn.fraudFlag,
        initiatorName: detailTxn.initiator?.name ?? null,
        recipientName: detailTxn.recipient?.name ?? detailTxn.recipientName ?? null,
        bankName: detailTxn.bankName,
        description: detailTxn.description,
      };
      const res = await apiFetch('/api/ai/advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactions: [mappedTxn],
          context: 'FinFlow Ethiopian financial platform - analyze this transaction for risk and provide advice',
        }),
      });
      if (!res.ok) throw new Error('Failed to get advice');
      const data = await res.json();
      if (data.success) {
        setDetailAiAdvice(data.advice);
      } else {
        toast.error(data.error || 'Failed to generate AI advice');
      }
    } catch {
      toast.error('Failed to generate AI advice. Please try again.');
    } finally {
      setDetailAiLoading(false);
    }
  };

  // Reset detail AI advice when dialog closes or txn changes
  useEffect(() => {
    setDetailAiAdvice(null);
  }, [detailOpen, detailTxn?.id]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">{t('transactions.management')}</h2>
        <p className="text-muted-foreground">{t('transactions.viewManage')}</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Filter className="h-4 w-4" />
              {t('transactions.filters')}
              {hasActiveFilters && (
                <Badge variant="outline" className="ml-1 text-emerald-600 border-emerald-200 bg-emerald-50">{t('transactions.active')}</Badge>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-3">
              <div className="relative xl:col-span-2">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={t('transactions.searchPlaceholder')}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={t('common.type')} />
                </SelectTrigger>
                <SelectContent>
                  {TRANSACTION_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={t('common.status')} />
                </SelectTrigger>
                <SelectContent>
                  {TRANSACTION_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                placeholder={t('common.date')}
              />
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                placeholder={t('common.date')}
              />
            </div>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                {selectedIds.size > 0 && (
                  <>
                    <span className="text-xs text-muted-foreground">
                      {selectedIds.size} transaction{selectedIds.size > 1 ? 's' : ''} selected
                    </span>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={handleDeleteSelected}
                      disabled={deleteLoading}
                    >
                      {deleteLoading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Trash2 className="h-3.5 w-3.5 mr-1" />}
                      Delete Selected
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelectedIds(new Set())}>
                      Clear
                    </Button>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAiAdvice}
                  disabled={aiAdviceLoading || transactions.length === 0}
                  className="text-teal-600 border-teal-200 hover:bg-teal-50 hover:text-teal-700"
                >
                  {aiAdviceLoading ? (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4 mr-1" />
                  )}
                  AI Advice
                </Button>
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
                  <X className="h-4 w-4 mr-1" />
                  {t('transactions.clearFilters')}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Advice Panel */}
      <AnimatePresence>
        {showAdvicePanel && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Collapsible open={showAdvicePanel} onOpenChange={setShowAdvicePanel}>
              <Card className="border-l-4 border-l-teal-500 overflow-hidden">
                <CollapsibleTrigger asChild>
                  <button className="w-full text-left">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Sparkles className="h-5 w-5 text-teal-600" />
                          <span className="text-sm font-semibold text-teal-700">AI Financial Advisor</span>
                          {aiAdvice && (
                            <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 text-xs">
                              Analysis Complete
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {showAdvicePanel && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowAdvicePanel(false);
                                setAiAdvice(null);
                              }}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="px-4 pb-4 pt-0">
                    {aiAdviceLoading && !aiAdvice ? (
                      <div className="flex items-center gap-3 py-2">
                        <Loader2 className="h-4 w-4 animate-spin text-teal-600" />
                        <span className="text-sm text-muted-foreground">Analyzing transactions...</span>
                      </div>
                    ) : aiAdvice ? (
                      <p className="text-sm text-foreground leading-relaxed bg-teal-50/50 rounded-lg p-3 border border-teal-100">
                        {aiAdvice}
                      </p>
                    ) : (
                      <p className="text-sm text-muted-foreground py-2">Click "AI Advice" to analyze your recent transactions.</p>
                    )}
                  </div>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats Bar - based on server-side summary */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4"
      >
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="p-4">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-6 w-16" />
            </Card>
          ))
        ) : summary ? (
          <>
            <Card className="p-4">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t('transactions.totalCount')}</div>
              <div className="text-xl font-bold mt-1">{pagination.total.toLocaleString()}</div>
            </Card>
            <Card className="p-4">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t('transactions.totalAmount')}</div>
              <div className="text-xl font-bold mt-1 text-emerald-600">
                {formatCurrency(summary.totalAmount, 'ETB')}
              </div>
            </Card>
            <Card className="p-4">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t('transactions.completed')}</div>
              <div className="text-xl font-bold mt-1 text-emerald-600">{summary.completedCount}</div>
              <div className="text-xs text-muted-foreground">{formatCurrency(summary.completedAmount, 'ETB')}</div>
            </Card>
            <Card className="p-4">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t('transactions.pending')}</div>
              <div className="text-xl font-bold mt-1 text-amber-600">{summary.pendingCount + summary.processingCount}</div>
              <div className="text-xs text-muted-foreground">{formatCurrency(summary.pendingAmount + summary.processingAmount, 'ETB')}</div>
            </Card>
            <Card className="p-4 sm:col-span-1 col-span-2">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t('transactions.failed')}</div>
              <div className="text-xl font-bold mt-1 text-rose-600">{summary.failedCount}</div>
              <div className="text-xs text-muted-foreground">{formatCurrency(summary.failedAmount, 'ETB')}</div>
            </Card>
          </>
        ) : (
          Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="p-4">
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">-</div>
              <div className="text-xl font-bold mt-1">-</div>
            </Card>
          ))
        )}
      </motion.div>

      {/* Transactions Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-4 w-4" />
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-16 ml-auto" />
                </div>
              ))}
            </div>
          ) : (
            <>
              <div className="max-h-[600px] overflow-y-auto">
                <Table>
                  <TableHeader className="sticky top-0 bg-background z-10">
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox checked={allSelected} onCheckedChange={toggleAll} />
                      </TableHead>
                      {SORTABLE_COLUMNS.map((col) => (
                        <TableHead
                          key={col.key}
                          className={`cursor-pointer select-none hover:bg-muted/50 transition-colors ${
                            col.key === 'amount' ? 'text-right' : ''
                          } ${col.key === 'fee' ? 'hidden lg:table-cell text-right' : ''} ${
                            ['createdAt'].includes(col.key) ? '' : ''
                          } ${col.key === 'createdAt' ? '' : ''}`}
                          onClick={() => handleSort(col.key)}
                        >
                          <div className={`flex items-center gap-1 ${col.key === 'amount' ? 'justify-end' : ''}`}>
                            {col.label} {getSortIcon(col.key)}
                          </div>
                        </TableHead>
                      ))}
                      <TableHead className="hidden md:table-cell">{t('transactions.subType')}</TableHead>
                      <TableHead className="hidden xl:table-cell">{t('common.currency')}</TableHead>
                      <TableHead className="hidden lg:table-cell">{t('transactions.initiator')}</TableHead>
                      <TableHead className="hidden xl:table-cell">{t('transactions.recipient')}</TableHead>
                      <TableHead className="hidden xl:table-cell">{t('transactions.paymentMethod')}</TableHead>
                      <TableHead className="w-12">{t('common.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {transactions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={14} className="text-center py-12 text-muted-foreground">
                            {t('transactions.noTransactions')}
                          </TableCell>
                        </TableRow>
                      ) : (
                        transactions.map((txn, idx) => (
                          <motion.tr
                            key={txn.id}
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.15, delay: idx * 0.02 }}
                            className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                          >
                            <TableCell>
                              <Checkbox
                                checked={selectedIds.has(txn.id)}
                                onCheckedChange={() => toggleRow(txn.id)}
                              />
                            </TableCell>
                            <TableCell className="font-mono text-xs">{txn.reference}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={TYPE_VARIANT[txn.type] ?? ''}>
                                {txn.type.replace('_', ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right font-mono font-medium">
                              <span className={getAmountColor(txn.type)}>
                                {getAmountPrefix(txn.type)}{formatCurrency(txn.amount, txn.currency)}
                              </span>
                            </TableCell>
                            <TableCell className="text-right font-mono text-xs text-muted-foreground hidden lg:table-cell">
                              {formatCurrency(txn.fee, txn.currency)}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={STATUS_VARIANT[txn.status] ?? ''}>
                                {txn.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              <span className="datetime-badge full">{formatDateTime(txn.createdAt)}</span>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-xs text-muted-foreground">
                              {txn.subType ? txn.subType.replace(/_/g, ' ') : '-'}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-xs font-medium">
                              {txn.currency}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">
                              {txn.initiator?.name ?? '-'}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm">
                              {txn.recipient?.name ?? txn.recipientName ?? '-'}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-xs text-muted-foreground">
                              {txn.paymentMethod ? txn.paymentMethod.replace(/_/g, ' ') : '-'}
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                    <span className="sr-only">{t('admin.openMenu')}</span>
                                    <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01" />
                                    </svg>
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => viewDetail(txn)}>
                                    <Eye className="mr-2 h-4 w-4" /> {t('transactions.viewDetails')}
                                  </DropdownMenuItem>
                                  {isAdmin && txn.status === 'pending' && (
                                    <>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem
                                        onClick={() => handleAction(txn, 'approve')}
                                        disabled={actionLoading === txn.id}
                                      >
                                        {actionLoading === txn.id ? (
                                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        ) : (
                                          <CheckCircle2 className="mr-2 h-4 w-4 text-emerald-600" />
                                        )}
                                        {t('transactions.approve')}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() => handleAction(txn, 'reject')}
                                        disabled={actionLoading === txn.id}
                                        className="text-rose-600"
                                      >
                                        {actionLoading === txn.id ? (
                                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        ) : (
                                          <XCircle className="mr-2 h-4 w-4" />
                                        )}
                                        {t('transactions.reject')}
                                      </DropdownMenuItem>
                                    </>
                                  )}
                                  {isAdmin && (txn.status === 'completed' || txn.status === 'processing') && (
                                    <DropdownMenuItem
                                      onClick={() => handleAction(txn, 'reverse')}
                                      disabled={actionLoading === txn.id}
                                      className="text-purple-600"
                                    >
                                      {actionLoading === txn.id ? (
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                      ) : (
                                        <RotateCcw className="mr-2 h-4 w-4" />
                                      )}
                                      {t('transactions.reverse')}
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </motion.tr>
                        ))
                      )}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>

              <style>{`
                .max-h-\[600px\]::-webkit-scrollbar { width: 6px; }
                .max-h-\[600px\]::-webkit-scrollbar-track { background: transparent; }
                .max-h-\[600px\]::-webkit-scrollbar-thumb { background: hsl(var(--border)); border-radius: 3px; }
                .max-h-\[600px\]::-webkit-scrollbar-thumb:hover { background: hsl(var(--muted-foreground)); }
              `}</style>

              {/* Pagination */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-t px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground">
                    {t('transactions.showing')} {pagination.total > 0 ? Math.min((page - 1) * limit + 1, pagination.total) : 0} {t('transactions.to')}{' '}
                    {Math.min(page * limit, pagination.total)} {t('transactions.of')} {pagination.total} {t('transactions.entries')}
                  </span>
                  <Select value={pageSize} onValueChange={setPageSize}>
                    <SelectTrigger className="w-[70px] h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(1)}
                    disabled={page <= 1}
                  >
                    {t('transactions.first')}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page <= 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="flex items-center gap-1">
                    {(() => {
                      const total = pagination.totalPages;
                      if (total <= 0) return null;
                      const pages: number[] = [];
                      if (total <= 7) {
                        for (let i = 1; i <= total; i++) pages.push(i);
                      } else {
                        pages.push(1);
                        if (page > 3) pages.push(-1);
                        const start = Math.max(2, page - 1);
                        const end = Math.min(total - 1, page + 1);
                        for (let i = start; i <= end; i++) pages.push(i);
                        if (page < total - 2) pages.push(-1);
                        pages.push(total);
                      }
                      return pages.map((p, i) =>
                        p === -1 ? (
                          <span key={`dots-${i}`} className="px-1 text-muted-foreground">...</span>
                        ) : (
                          <Button
                            key={p}
                            variant={page === p ? 'default' : 'outline'}
                            size="sm"
                            className="w-8 h-8 p-0"
                            onClick={() => setPage(p)}
                          >
                            {p}
                          </Button>
                        )
                      );
                    })()}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.min(pagination.totalPages, p + 1))}
                    disabled={page >= pagination.totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(pagination.totalPages)}
                    disabled={page >= pagination.totalPages}
                  >
                    {t('transactions.last')}
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Transaction Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('transactions.transactionDetails')}</DialogTitle>
          </DialogHeader>
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : detailTxn ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="outline" className={TYPE_VARIANT[detailTxn.type] ?? ''}>
                  {detailTxn.type.replace('_', ' ')}
                </Badge>
                <Badge variant="outline" className={STATUS_VARIANT[detailTxn.status] ?? ''}>
                  {detailTxn.status}
                </Badge>
                <span className="font-mono text-xs text-muted-foreground">{detailTxn.reference}</span>
              </div>

              <div className="rounded-lg bg-muted/50 p-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{t('transactions.amount')}</div>
                <div className={`text-2xl font-bold ${getAmountColor(detailTxn.type)}`}>
                  {getAmountPrefix(detailTxn.type)}{formatCurrency(detailTxn.amount, detailTxn.currency)}
                </div>
                <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                  <span>{t('transactions.fee')}: {formatCurrency(detailTxn.fee, detailTxn.currency)}</span>
                  <span className="text-foreground font-medium">
                    {t('transactions.net')}: {formatCurrency(detailTxn.amount - detailTxn.fee, detailTxn.currency)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {detailField(t('common.reference'), detailTxn.reference)}
                {detailField(t('common.type'), detailTxn.type.replace('_', ' '))}
                {detailField(t('transactions.subType'), detailTxn.subType ? detailTxn.subType.replace(/_/g, ' ') : null)}
                {detailField(t('common.status'), detailTxn.status)}
                {detailField(t('common.currency'), detailTxn.currency)}
                {detailField(t('common.description'), detailTxn.description)}
                {detailField(t('transactions.initiator'), detailTxn.initiator?.name ?? detailTxn.initiatorId)}
                {detailField(t('common.email'), detailTxn.initiator?.email)}
                {detailField(t('transactions.recipient'), detailTxn.recipient?.name ?? detailTxn.recipientName ?? detailTxn.recipientId)}
                {detailField(t('common.email'), detailTxn.recipient?.email)}
                {detailField(t('transactions.paymentMethod'), detailTxn.paymentMethod ? detailTxn.paymentMethod.replace(/_/g, ' ') : null)}
                {detailField(t('transactions.bankName'), detailTxn.bankName)}
                {detailField(t('transactions.accountNumber'), detailTxn.accountNumber)}
                {detailField(t('transactions.sourceWallet'), detailTxn.sourceWalletId)}
                {detailField(t('transactions.destinationWallet'), detailTxn.destinationWalletId)}
                {detailField(t('transactions.created'), <span className="datetime-badge full">{formatDateTime(detailTxn.createdAt)}</span>)}
                {detailField(t('transactions.completedDate'), detailTxn.completedAt ? <span className="datetime-badge full">{formatDateTime(detailTxn.completedAt)}</span> : null)}
                {detailField(t('transactions.riskScore'), detailTxn.riskScore != null ? `${(detailTxn.riskScore * 100).toFixed(0)}%` : null)}
                {detailField(t('transactions.fraudFlag'), detailTxn.fraudFlag)}
                {detailField(t('transactions.otpVerified'), detailTxn.otpVerified)}
                {detailField(t('transactions.2faVerified'), detailTxn.twoFactorVerified)}
              </div>

              {/* Actions in detail dialog - admin only */}
              {isAdmin && (detailTxn.status === 'pending' || detailTxn.status === 'completed' || detailTxn.status === 'processing') && (
                <div className="flex flex-wrap gap-2 pt-4 border-t btn-responsive-group">
                  {detailTxn.status === 'pending' && (
                    <>
                      <Button
                        className="btn-responsive bg-emerald-600 hover:bg-emerald-700"
                        onClick={() => {
                          handleAction(detailTxn, 'approve');
                          setDetailOpen(false);
                        }}
                        disabled={actionLoading === detailTxn.id}
                      >
                        {actionLoading === detailTxn.id ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                        )}
                        {t('transactions.approve')}
                      </Button>
                      <Button
                        className="btn-responsive"
                        variant="destructive"
                        onClick={() => {
                          handleAction(detailTxn, 'reject');
                          setDetailOpen(false);
                        }}
                        disabled={actionLoading === detailTxn.id}
                      >
                        {actionLoading === detailTxn.id ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <XCircle className="mr-2 h-4 w-4" />
                        )}
                        {t('transactions.reject')}
                      </Button>
                    </>
                  )}
                  {(detailTxn.status === 'completed' || detailTxn.status === 'processing') && (
                    <Button
                      className="btn-responsive text-purple-600 border-purple-200 hover:bg-purple-50"
                      variant="outline"
                      onClick={() => {
                        handleAction(detailTxn, 'reverse');
                        setDetailOpen(false);
                      }}
                      disabled={actionLoading === detailTxn.id}
                    >
                      {actionLoading === detailTxn.id ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <RotateCcw className="mr-2 h-4 w-4" />
                      )}
                      {t('transactions.reverse')}
                    </Button>
                  )}
                </div>
              )}

              {/* Generate Transaction Advice */}
              <div className="pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (!detailTxn) return;
                    setAdviceData({
                      reference: detailTxn.reference,
                      type: detailTxn.type,
                      subType: detailTxn.subType,
                      amount: detailTxn.amount,
                      fee: detailTxn.fee,
                      currency: detailTxn.currency,
                      description: detailTxn.description,
                      status: detailTxn.status,
                      createdAt: detailTxn.createdAt,
                      completedAt: detailTxn.completedAt,
                      paymentMethod: detailTxn.paymentMethod,
                      riskScore: detailTxn.riskScore,
                      fraudFlag: detailTxn.fraudFlag,
                      senderName: detailTxn.initiator?.name ?? 'Unknown',
                      senderEmail: detailTxn.initiator?.email ?? null,
                      senderPhone: null,
                      senderAddress: detailTxn.senderAddress ?? null,
                      senderBankName: detailTxn.bankName ?? null,
                      senderAccountNumber: detailTxn.accountNumber ?? null,
                      senderWalletId: detailTxn.sourceWalletId ?? null,
                      senderWalletCurrency: detailTxn.currency,
                      receiverName: detailTxn.recipient?.name ?? detailTxn.recipientName ?? null,
                      receiverEmail: detailTxn.recipient?.email ?? null,
                      receiverPhone: null,
                      receiverAddress: detailTxn.receiverAddress ?? null,
                      receiverBankName: null,
                      receiverAccountNumber: null,
                      receiverWalletId: detailTxn.destinationWalletId ?? null,
                      receiverWalletCurrency: detailTxn.currency,
                    });
                    setDetailOpen(false);
                  }}
                  className="gap-2 text-emerald-600 border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700"
                >
                  <FileText className="h-4 w-4" />
                  View Transaction Advice
                </Button>
              </div>

              {/* AI Advice for single transaction - quick inline view */}
              <div className="pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={handleDetailAiAdvice}
                  disabled={detailAiLoading}
                  className="text-teal-600 border-teal-200 hover:bg-teal-50 hover:text-teal-700"
                >
                  {detailAiLoading ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="mr-2 h-4 w-4" />
                  )}
                  Quick AI Analysis
                </Button>
                {detailAiLoading && (
                  <div className="flex items-center gap-3 mt-3 py-2">
                    <Loader2 className="h-4 w-4 animate-spin text-teal-600" />
                    <span className="text-sm text-muted-foreground">Analyzing transaction...</span>
                  </div>
                )}
                {detailAiAdvice && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-3"
                  >
                    <div className="border-l-4 border-l-teal-500 rounded-r-lg bg-teal-50/50 p-3 border border-t border-r border-b border-teal-100">
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles className="h-4 w-4 text-teal-600" />
                        <span className="text-xs font-semibold text-teal-700">AI Analysis</span>
                      </div>
                      <p className="text-sm text-foreground leading-relaxed">{detailAiAdvice}</p>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Transaction Advice Modal */}
      {adviceData && (
        <TransactionAdvice
          data={adviceData}
          onClose={() => setAdviceData(null)}
        />
      )}
    </motion.div>
  );
}
