'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import {
  Send,
  Download,
  Clock,
  Wallet,
  Landmark,
  QrCode,
  Phone,
  Mail,
  Globe,
  CreditCard,
  ArrowRightLeft,
  Building2,
  DollarSign,
  Users,
  Calendar,
  Loader2,
  ArrowDownLeft,
  ArrowUpRight,
  Eye,
  MapPin,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import TransactionAdvice, { type AdviceData } from '@/components/financial/transaction-advice';

// --- Types ---

type TransferType =
  | 'wallet_to_wallet'
  | 'wallet_to_bank'
  | 'bank_to_wallet'
  | 'bank_to_bank'
  | 'international'
  | 'qr_transfer';

interface Transaction {
  id: string;
  reference?: string;
  type?: string;
  subType?: string;
  amount?: number;
  currency?: string;
  status?: string;
  recipient?: string;
  recipientEmail?: string;
  recipientPhone?: string;
  description?: string;
  sourceBank?: string;
  destBank?: string;
  createdAt?: string;
  updatedAt?: string;
}

// --- Constants ---

const ETHIOPIAN_BANKS = [
  'Commercial Bank of Ethiopia',
  'Awash Bank',
  'Dashen Bank',
  'Bank of Abyssinia',
  'Wegagen Bank',
  'United Bank',
  'Nib International Bank',
  'Oromia International Bank',
  'Bunna International Bank',
  'Hibret Bank',
  'Siinqee Bank',
  'Gozalem Bank',
  'Amhara Bank',
  'Global Bank',
  'Berhan International Bank',
  'Enat Bank',
  'Addis International Bank',
  'Ahadu Bank',
  'Lion International Bank',
  'Cooperative Bank of Oromia',
  'Development Bank of Ethiopia',
  'Gadaa Bank',
  'Goh Betoch Bank',
  'Hijra Bank',
  'Siket Bank',
  'Tsedey Bank',
  'Tsehay Bank',
  'ZamZam Bank',
  'Zemen Bank',
];

const TRANSFER_TYPES: { value: TransferType; label: string; icon: React.ReactNode }[] = [
  { value: 'wallet_to_wallet', label: 'Wallet to Wallet', icon: <Wallet className="h-6 w-6" /> },
  { value: 'wallet_to_bank', label: 'Wallet to Bank', icon: <ArrowRightLeft className="h-6 w-6" /> },
  { value: 'bank_to_wallet', label: 'Bank to Wallet', icon: <Landmark className="h-6 w-6" /> },
  { value: 'bank_to_bank', label: 'Bank to Bank', icon: <Building2 className="h-6 w-6" /> },
  { value: 'international', label: 'International Transfer', icon: <Globe className="h-6 w-6" /> },
  { value: 'qr_transfer', label: 'QR Transfer', icon: <QrCode className="h-6 w-6" /> },
];

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

const STATUS_COLORS: Record<string, string> = {
  completed: 'bg-green-500/15 text-green-700 border-green-500/20',
  pending: 'bg-yellow-500/15 text-yellow-700 border-yellow-500/20',
  failed: 'bg-red-500/15 text-red-700 border-red-500/20',
  processing: 'bg-blue-500/15 text-blue-700 border-blue-500/20',
  cancelled: 'bg-gray-500/15 text-gray-700 border-gray-500/20',
};

// --- Component ---

export default function SendReceiveView() {
  const { formatDate, formatDateTime } = useFormattedDate();

  // Transfer type
  const [transferType, setTransferType] = useState<TransferType>('wallet_to_wallet');

  // Send form
  const [sendForm, setSendForm] = useState<Record<string, string>>({
    amount: '',
    currency: 'ETB',
    description: '',
    sourceWallet: '',
    destination: '',
    sourceBank: '',
    sourceAccount: '',
    destBank: '',
    destAccount: '',
    accountName: '',
    sourceCurrency: 'ETB',
    destCurrency: 'USD',
    recipientName: '',
    recipientPhone: '',
    recipientEmail: '',
    swiftCode: '',
    senderAddress: '',
    receiverAddress: '',
  });

  // Deposit form
  const [depositForm, setDepositForm] = useState({ walletId: '', amount: '', currency: 'ETB' });

  // Request form
  const [requestForm, setRequestForm] = useState({ amount: '', currency: 'ETB', from: '', note: '' });

  // Data
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState({ sent: 0, received: 0, pending: 0, thisMonth: 0 });

  // Loading states
  const [sending, setSending] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [loadingStats, setLoadingStats] = useState(false);

  // Dialog
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [adviceData, setAdviceData] = useState<AdviceData | null>(null);

  // --- Helpers ---

  const updateSendForm = useCallback((field: string, value: string) => {
    setSendForm((prev) => ({ ...prev, [field]: value }));
  }, []);

  const getStatusBadge = (status?: string) => {
    if (!status) return <Badge variant="outline">Unknown</Badge>;
    const colorClass = STATUS_COLORS[status.toLowerCase()] || 'bg-gray-500/15 text-gray-700 border-gray-500/20';
    return (
      <Badge variant="outline" className={`${colorClass} border`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  // --- Data Fetching ---

  const fetchStats = useCallback(async () => {
    setLoadingStats(true);
    try {
      const res = await apiFetch('/api/transactions?limit=100');
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      const data: Transaction[] = Array.isArray(json) ? json : (json.transactions ?? []);
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

      const sent = data.filter((t) => t.type === 'send' || t.type === 'debit').reduce((s, t) => s + (t.amount || 0), 0);
      const received = data.filter((t) => t.type === 'receive' || t.type === 'credit').reduce((s, t) => s + (t.amount || 0), 0);
      const pending = data.filter((t) => t.status === 'pending' || t.status === 'processing').length;
      const thisMonth = data.filter((t) => t.createdAt && t.createdAt >= monthStart).reduce((s, t) => s + (t.amount || 0), 0);

      setStats({ sent, received, pending, thisMonth });
    } catch {
      toast.error('Failed to load statistics');
    } finally {
      setLoadingStats(false);
    }
  }, []);

  const fetchHistory = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const res = await apiFetch('/api/transactions?type=transfer&limit=50');
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      const data = Array.isArray(json) ? json : (json.transactions ?? []);
      setTransactions(data);
    } catch {
      toast.error('Failed to load transfer history');
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // --- Handlers ---

  const handleSend = async () => {
    if (!sendForm.amount || parseFloat(sendForm.amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (transferType === 'wallet_to_wallet' && !sendForm.destination) {
      toast.error('Please enter destination wallet or phone');
      return;
    }
    if (transferType === 'wallet_to_bank' && (!sendForm.destBank || !sendForm.destAccount)) {
      toast.error('Please fill bank and account details');
      return;
    }
    if (transferType === 'bank_to_wallet' && (!sendForm.sourceBank || !sendForm.destination)) {
      toast.error('Please fill source bank and destination');
      return;
    }
    if (transferType === 'bank_to_bank' && (!sendForm.sourceBank || !sendForm.destBank || !sendForm.sourceAccount || !sendForm.destAccount)) {
      toast.error('Please fill all bank account details');
      return;
    }
    if (transferType === 'international' && (!sendForm.recipientName || !sendForm.swiftCode)) {
      toast.error('Please fill recipient name and SWIFT code');
      return;
    }

    setSending(true);
    try {
      const payload = {
        type: 'transfer',
        subType: transferType,
        amount: parseFloat(sendForm.amount),
        currency: sendForm.currency,
        description: sendForm.description,
        senderAddress: sendForm.senderAddress || undefined,
        receiverAddress: sendForm.receiverAddress || undefined,
        ...(transferType === 'wallet_to_wallet' && {
          sourceWallet: sendForm.sourceWallet,
          destinationWallet: sendForm.destination,
        }),
        ...(transferType === 'wallet_to_bank' && {
          sourceWallet: sendForm.sourceWallet,
          bankName: sendForm.destBank,
          accountNumber: sendForm.destAccount,
          accountName: sendForm.accountName,
        }),
        ...(transferType === 'bank_to_wallet' && {
          sourceBank: sendForm.sourceBank,
          sourceAccount: sendForm.sourceAccount,
          destinationWallet: sendForm.destination,
        }),
        ...(transferType === 'bank_to_bank' && {
          sourceBank: sendForm.sourceBank,
          sourceAccount: sendForm.sourceAccount,
          destBank: sendForm.destBank,
          destAccount: sendForm.destAccount,
          accountName: sendForm.accountName,
        }),
        ...(transferType === 'international' && {
          sourceCurrency: sendForm.sourceCurrency,
          destCurrency: sendForm.destCurrency,
          recipientName: sendForm.recipientName,
          recipientPhone: sendForm.recipientPhone,
          recipientEmail: sendForm.recipientEmail,
          swiftCode: sendForm.swiftCode,
        }),
      };

      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(err.error || 'Transfer failed');
      }

      toast.success('Transfer initiated successfully');

      // Show transaction advice
      const result = await res.json().catch(() => null);
      if (result) {
        const isWalletToBank = transferType === 'wallet_to_bank';
        const isBankToWallet = transferType === 'bank_to_wallet';
        const isBankToBank = transferType === 'bank_to_bank';
        const isInternational = transferType === 'international';
        const isW2W = transferType === 'wallet_to_wallet';

        setAdviceData({
          reference: result.reference ?? '',
          type: result.type ?? 'transfer',
          subType: result.subType ?? transferType,
          amount: result.amount ?? parseFloat(sendForm.amount),
          fee: result.fee ?? 0,
          currency: result.currency ?? sendForm.currency,
          description: result.description ?? sendForm.description ?? null,
          status: result.status ?? 'pending',
          createdAt: result.createdAt ?? new Date().toISOString(),
          completedAt: result.completedAt ?? null,
          paymentMethod: isBankToWallet || isBankToBank ? 'bank_account' : isW2W ? 'digital_wallet' : null,
          riskScore: result.riskScore ?? null,
          fraudFlag: result.fraudFlag ?? null,
          senderName: result.initiator?.name ?? 'You',
          senderEmail: result.initiator?.email ?? null,
          senderPhone: null,
          senderAddress: (result.senderAddress ?? sendForm.senderAddress) || null,
          senderBankName: isBankToWallet || isBankToBank ? sendForm.sourceBank : null,
          senderAccountNumber: isBankToWallet || isBankToBank ? sendForm.sourceAccount : null,
          senderWalletId: isW2W || isWalletToBank ? sendForm.sourceWallet : null,
          senderWalletCurrency: sendForm.currency,
          receiverName: isInternational ? sendForm.recipientName : (result.recipient?.name ?? (isWalletToBank || isBankToBank ? sendForm.accountName : null)),
          receiverEmail: isInternational ? sendForm.recipientEmail : (result.recipient?.email ?? null),
          receiverPhone: isInternational ? sendForm.recipientPhone : null,
          receiverAddress: (result.receiverAddress ?? sendForm.receiverAddress) || null,
          receiverBankName: isWalletToBank ? sendForm.destBank : isBankToBank ? sendForm.destBank : null,
          receiverAccountNumber: isWalletToBank || isBankToBank ? sendForm.destAccount : null,
          receiverWalletId: isW2W || isBankToWallet ? sendForm.destination : null,
          receiverWalletCurrency: sendForm.currency,
        });
      }

      setSendForm({
        amount: '', currency: 'ETB', description: '', sourceWallet: '', destination: '',
        sourceBank: '', sourceAccount: '', destBank: '', destAccount: '', accountName: '',
        sourceCurrency: 'ETB', destCurrency: 'USD', recipientName: '', recipientPhone: '',
        recipientEmail: '', swiftCode: '', senderAddress: '', receiverAddress: '',
      });
      fetchStats();
      fetchHistory();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Transfer failed');
    } finally {
      setSending(false);
    }
  };

  const handleGenerateRequest = async () => {
    if (!depositForm.walletId) {
      toast.error('Please enter your wallet ID');
      return;
    }
    if (!depositForm.amount || parseFloat(depositForm.amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    setGenerating(true);
    try {
      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'deposit_request',
          amount: parseFloat(depositForm.amount),
          currency: depositForm.currency,
          destinationWallet: depositForm.walletId,
          description: 'Wallet deposit request',
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(err.error || 'Failed to generate request');
      }

      toast.success('Deposit request generated successfully');
      setDepositForm({ walletId: '', amount: '', currency: 'ETB' });
      fetchStats();
      fetchHistory();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Failed to generate request');
    } finally {
      setGenerating(false);
    }
  };

  const handleSendRequest = async () => {
    if (!requestForm.amount || parseFloat(requestForm.amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (!requestForm.from) {
      toast.error('Please enter the requester\'s email or phone');
      return;
    }

    setRequesting(true);
    try {
      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'payment_request',
          amount: parseFloat(requestForm.amount),
          currency: requestForm.currency,
          recipientEmail: requestForm.from,
          description: requestForm.note,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(err.error || 'Failed to send request');
      }

      toast.success('Payment request sent successfully');
      setRequestForm({ amount: '', currency: 'ETB', from: '', note: '' });
      fetchStats();
      fetchHistory();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Failed to send request');
    } finally {
      setRequesting(false);
    }
  };

  // --- Render Helpers ---

  const formatCurrency = (amount: number, currency?: string) => {
    return `${currency || 'ETB'} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const renderCommonFields = () => (
    <>
      <div className="space-y-2">
        <Label>Amount *</Label>
        <Input
          type="number"
          placeholder="0.00"
          value={sendForm.amount}
          onChange={(e) => updateSendForm('amount', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Currency</Label>
        <Select value={sendForm.currency} onValueChange={(v) => updateSendForm('currency', v)}>
          <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ETB">ETB - Ethiopian Birr</SelectItem>
            <SelectItem value="USD">USD - US Dollar</SelectItem>
            <SelectItem value="EUR">EUR - Euro</SelectItem>
            <SelectItem value="GBP">GBP - British Pound</SelectItem>
            <SelectItem value="AED">AED - UAE Dirham</SelectItem>
            <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input
          placeholder="Transaction description"
          value={sendForm.description}
          onChange={(e) => updateSendForm('description', e.target.value)}
        />
      </div>
    </>
  );

  const renderWalletToWallet = () => (
    <>
      <div className="space-y-2">
        <Label>Source Wallet ID</Label>
        <Input
          placeholder="Enter source wallet ID"
          value={sendForm.sourceWallet}
          onChange={(e) => updateSendForm('sourceWallet', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Destination Wallet / Phone *</Label>
        <Input
          placeholder="Enter wallet ID or phone number"
          value={sendForm.destination}
          onChange={(e) => updateSendForm('destination', e.target.value)}
        />
      </div>
    </>
  );

  const renderWalletToBank = () => (
    <>
      <div className="space-y-2">
        <Label>Source Wallet</Label>
        <Input
          placeholder="Enter source wallet ID"
          value={sendForm.sourceWallet}
          onChange={(e) => updateSendForm('sourceWallet', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Destination Bank *</Label>
        <Select value={sendForm.destBank} onValueChange={(v) => updateSendForm('destBank', v)}>
          <SelectTrigger><SelectValue placeholder="Select bank" /></SelectTrigger>
          <SelectContent>
            {ETHIOPIAN_BANKS.map((bank) => (
              <SelectItem key={bank} value={bank}>{bank}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Account Number *</Label>
        <Input
          placeholder="Enter account number"
          value={sendForm.destAccount}
          onChange={(e) => updateSendForm('destAccount', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Account Name</Label>
        <Input
          placeholder="Beneficiary name"
          value={sendForm.accountName}
          onChange={(e) => updateSendForm('accountName', e.target.value)}
        />
      </div>
    </>
  );

  const renderBankToWallet = () => (
    <>
      <div className="space-y-2">
        <Label>Source Bank *</Label>
        <Select value={sendForm.sourceBank} onValueChange={(v) => updateSendForm('sourceBank', v)}>
          <SelectTrigger><SelectValue placeholder="Select bank" /></SelectTrigger>
          <SelectContent>
            {ETHIOPIAN_BANKS.map((bank) => (
              <SelectItem key={bank} value={bank}>{bank}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Source Account *</Label>
        <Input
          placeholder="Enter your account number"
          value={sendForm.sourceAccount}
          onChange={(e) => updateSendForm('sourceAccount', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Destination Phone / Wallet *</Label>
        <Input
          placeholder="Enter phone or wallet ID"
          value={sendForm.destination}
          onChange={(e) => updateSendForm('destination', e.target.value)}
        />
      </div>
    </>
  );

  const renderBankToBank = () => (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Source Bank *</Label>
          <Select value={sendForm.sourceBank} onValueChange={(v) => updateSendForm('sourceBank', v)}>
            <SelectTrigger><SelectValue placeholder="Select bank" /></SelectTrigger>
            <SelectContent>
              {ETHIOPIAN_BANKS.map((bank) => (
                <SelectItem key={bank} value={bank}>{bank}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Source Account *</Label>
          <Input
            placeholder="Account number"
            value={sendForm.sourceAccount}
            onChange={(e) => updateSendForm('sourceAccount', e.target.value)}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Destination Bank *</Label>
          <Select value={sendForm.destBank} onValueChange={(v) => updateSendForm('destBank', v)}>
            <SelectTrigger><SelectValue placeholder="Select bank" /></SelectTrigger>
            <SelectContent>
              {ETHIOPIAN_BANKS.map((bank) => (
                <SelectItem key={bank} value={bank}>{bank}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Destination Account *</Label>
          <Input
            placeholder="Destination account number"
            value={sendForm.destAccount}
            onChange={(e) => updateSendForm('destAccount', e.target.value)}
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Account Name</Label>
        <Input
          placeholder="Beneficiary name"
          value={sendForm.accountName}
          onChange={(e) => updateSendForm('accountName', e.target.value)}
        />
      </div>
    </>
  );

  const renderInternational = () => (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Source Currency</Label>
          <Select value={sendForm.sourceCurrency} onValueChange={(v) => updateSendForm('sourceCurrency', v)}>
            <SelectTrigger><SelectValue placeholder="Source currency" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ETB">ETB</SelectItem>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="AED">AED</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Destination Currency</Label>
          <Select value={sendForm.destCurrency} onValueChange={(v) => updateSendForm('destCurrency', v)}>
            <SelectTrigger><SelectValue placeholder="Dest currency" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="AED">AED</SelectItem>
              <SelectItem value="ETB">ETB</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label>Recipient Name *</Label>
        <Input
          placeholder="Full name of recipient"
          value={sendForm.recipientName}
          onChange={(e) => updateSendForm('recipientName', e.target.value)}
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Recipient Phone</Label>
          <Input
            placeholder="Phone number"
            value={sendForm.recipientPhone}
            onChange={(e) => updateSendForm('recipientPhone', e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Recipient Email</Label>
          <Input
            type="email"
            placeholder="Email address"
            value={sendForm.recipientEmail}
            onChange={(e) => updateSendForm('recipientEmail', e.target.value)}
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label>SWIFT Code *</Label>
        <Input
          placeholder="e.g. CBETETAA"
          value={sendForm.swiftCode}
          onChange={(e) => updateSendForm('swiftCode', e.target.value)}
        />
      </div>
    </>
  );

  // --- Main Render ---

  return (
    <div className="space-y-6">
      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 6px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: hsl(var(--muted)); border-radius: 3px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: hsl(var(--muted-foreground)); }
      `}</style>

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Send & Receive Money</h1>
        <p className="text-muted-foreground mt-1">Transfer funds between wallets, banks, and internationally</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {loadingStats ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <Skeleton className="h-4 w-24 mb-3" />
              <Skeleton className="h-8 w-32" />
            </div>
          ))
        ) : (
          <>
            <motion.div {...fadeIn} className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">Total Sent</span>
                <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center">
                  <ArrowUpRight className="h-5 w-5 text-primary" />
                </div>
              </div>
              <p className="text-2xl font-bold">{formatCurrency(stats.sent)}</p>
            </motion.div>

            <motion.div {...fadeIn} className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">Total Received</span>
                <div className="h-9 w-9 rounded-xl bg-green-500/10 flex items-center justify-center">
                  <Download className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <p className="text-2xl font-bold">{formatCurrency(stats.received)}</p>
            </motion.div>

            <motion.div {...fadeIn} className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">Pending Transfers</span>
                <div className="h-9 w-9 rounded-xl bg-yellow-500/10 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-yellow-600" />
                </div>
              </div>
              <p className="text-2xl font-bold">{stats.pending}</p>
            </motion.div>

            <motion.div {...fadeIn} className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">This Month</span>
                <div className="h-9 w-9 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <p className="text-2xl font-bold">{formatCurrency(stats.thisMonth)}</p>
            </motion.div>
          </>
        )}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="send" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="send" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Send className="h-4 w-4 mr-1.5" /> Send Money
          </TabsTrigger>
          <TabsTrigger value="receive" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <ArrowDownLeft className="h-4 w-4 mr-1.5" /> Receive Money
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <CreditCard className="h-4 w-4 mr-1.5" /> Transfer History
          </TabsTrigger>
        </TabsList>

        {/* ===== TAB 1: SEND MONEY ===== */}
        <TabsContent value="send">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader>
                <CardTitle className="text-lg">Send Money</CardTitle>
                <CardDescription>Select a transfer type and fill in the details below</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Transfer Type Grid */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {TRANSFER_TYPES.map((tt) => (
                    <button
                      key={tt.value}
                      type="button"
                      onClick={() => setTransferType(tt.value)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all cursor-pointer hover:shadow-md ${
                        transferType === tt.value
                          ? 'border-primary bg-primary/5 text-primary'
                          : 'border-border bg-card text-muted-foreground hover:border-primary/30'
                      }`}
                    >
                      {tt.icon}
                      <span className="text-xs font-medium text-center leading-tight">{tt.label}</span>
                    </button>
                  ))}
                </div>

                {/* Divider */}
                <div className="border-t border-border" />

                {/* Dynamic Form */}
                <div className="space-y-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    {TRANSFER_TYPES.find((t) => t.value === transferType)?.label} Details
                  </h3>

                  {/* QR Transfer is simple: just common fields */}
                  {transferType === 'qr_transfer' ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {renderCommonFields()}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Type-specific fields */}
                      {transferType === 'wallet_to_wallet' && renderWalletToWallet()}
                      {transferType === 'wallet_to_bank' && renderWalletToBank()}
                      {transferType === 'bank_to_wallet' && renderBankToWallet()}
                      {transferType === 'bank_to_bank' && renderBankToBank()}
                      {transferType === 'international' && renderInternational()}

                      {/* Common fields */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {renderCommonFields()}
                      </div>
                    </div>
                  )}
                </div>

                {/* Address Fields */}
                <div className="border-t border-border pt-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    Address Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-emerald-600" />
                        <Label>Sender Address</Label>
                      </div>
                      <Input
                        placeholder="e.g. Bole, Addis Ababa, Ethiopia"
                        value={sendForm.senderAddress}
                        onChange={(e) => updateSendForm('senderAddress', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-teal-600" />
                        <Label>Receiver Address</Label>
                      </div>
                      <Input
                        placeholder="e.g. Kazanchis, Addis Ababa, Ethiopia"
                        value={sendForm.receiverAddress}
                        onChange={(e) => updateSendForm('receiverAddress', e.target.value)}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Confirmation addresses will appear on the generated Transaction Advice.</p>
                </div>

                {/* Send Button */}
                <div className="flex justify-end pt-2">
                  <Button
                    onClick={handleSend}
                    disabled={sending}
                    className="btn-responsive bg-primary hover:bg-primary/90 text-white px-8"
                  >
                    {sending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send Now
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* ===== TAB 2: RECEIVE MONEY ===== */}
        <TabsContent value="receive">
          <motion.div {...fadeIn}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Wallet Deposit Card */}
              <Card className="bg-card rounded-2xl shadow-bs border border-border">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <div className="h-9 w-9 rounded-xl bg-green-500/10 flex items-center justify-center">
                      <Wallet className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Wallet Deposit</CardTitle>
                      <CardDescription>Generate a deposit request for your wallet</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Wallet ID *</Label>
                    <Input
                      placeholder="Enter your wallet ID"
                      value={depositForm.walletId}
                      onChange={(e) => setDepositForm((p) => ({ ...p, walletId: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Amount *</Label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={depositForm.amount}
                      onChange={(e) => setDepositForm((p) => ({ ...p, amount: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Currency</Label>
                    <Select
                      value={depositForm.currency}
                      onValueChange={(v) => setDepositForm((p) => ({ ...p, currency: v }))}
                    >
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ETB">ETB - Ethiopian Birr</SelectItem>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="EUR">EUR - Euro</SelectItem>
                        <SelectItem value="GBP">GBP - British Pound</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    onClick={handleGenerateRequest}
                    disabled={generating}
                    className="btn-responsive w-full bg-success hover:bg-success/90 text-white"
                  >
                    {generating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <ArrowDownLeft className="h-4 w-4 mr-2" />
                        Generate Request
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Payment Request Card */}
              <Card className="bg-card rounded-2xl shadow-bs border border-border">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <div className="h-9 w-9 rounded-xl bg-blue-500/10 flex items-center justify-center">
                      <DollarSign className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Payment Request</CardTitle>
                      <CardDescription>Request a payment from someone via email or phone</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Request Amount *</Label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={requestForm.amount}
                      onChange={(e) => setRequestForm((p) => ({ ...p, amount: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Currency</Label>
                    <Select
                      value={requestForm.currency}
                      onValueChange={(v) => setRequestForm((p) => ({ ...p, currency: v }))}
                    >
                      <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ETB">ETB - Ethiopian Birr</SelectItem>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="EUR">EUR - Euro</SelectItem>
                        <SelectItem value="GBP">GBP - British Pound</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>From (Email / Phone) *</Label>
                    <Input
                      placeholder="Enter email or phone"
                      value={requestForm.from}
                      onChange={(e) => setRequestForm((p) => ({ ...p, from: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Note</Label>
                    <Input
                      placeholder="Optional note"
                      value={requestForm.note}
                      onChange={(e) => setRequestForm((p) => ({ ...p, note: e.target.value }))}
                    />
                  </div>
                  <Button
                    onClick={handleSendRequest}
                    disabled={requesting}
                    className="btn-responsive w-full bg-primary hover:bg-primary/90 text-white"
                  >
                    {requesting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send Request
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        {/* ===== TAB 3: TRANSFER HISTORY ===== */}
        <TabsContent value="history">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Transfer History</CardTitle>
                    <CardDescription>View all your recent transfers</CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    onClick={fetchHistory}
                    disabled={loadingHistory}
                    className="rounded-2xl"
                  >
                    {loadingHistory ? <Loader2 className="h-4 w-4 sm:mr-2 animate-spin" /> : <CreditCard className="h-4 w-4 sm:mr-2" />}
                    <span className="hidden sm:inline">Refresh</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loadingHistory ? (
                  <div className="space-y-3">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-4 w-28" />
                      </div>
                    ))}
                  </div>
                ) : transactions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
                      <CreditCard className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <p className="text-lg font-medium text-muted-foreground">No transfers found</p>
                    <p className="text-sm text-muted-foreground mt-1">Your transfer history will appear here</p>
                  </div>
                ) : (
                  <div className="max-h-[500px] overflow-y-auto custom-scroll rounded-2xl border border-border">
                    <Table>
                      <TableHeader>
                        <TableRow className="hover:bg-transparent">
                          <TableHead className="text-xs font-semibold uppercase hidden lg:table-cell">Reference</TableHead>
                          <TableHead className="text-xs font-semibold uppercase">Type</TableHead>
                          <TableHead className="text-xs font-semibold uppercase">Amount</TableHead>
                          <TableHead className="text-xs font-semibold uppercase hidden md:table-cell">Currency</TableHead>
                          <TableHead className="text-xs font-semibold uppercase">Status</TableHead>
                          <TableHead className="text-xs font-semibold uppercase hidden md:table-cell">Recipient</TableHead>
                          <TableHead className="text-xs font-semibold uppercase hidden sm:table-cell">Date</TableHead>
                          <TableHead className="text-xs font-semibold uppercase w-16">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.map((tx) => (
                          <TableRow key={tx.id} className="hover:bg-muted/30">
                            <TableCell className="font-mono text-sm hidden lg:table-cell">
                              {tx.reference || tx.id.slice(0, 8)}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs font-normal">
                                {tx.subType
                                  ? tx.subType.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
                                  : tx.type || 'Transfer'}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-semibold">
                              {tx.amount != null ? tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '—'}
                            </TableCell>
                            <TableCell className="text-muted-foreground hidden md:table-cell">
                              {tx.currency || 'ETB'}
                            </TableCell>
                            <TableCell>{getStatusBadge(tx.status)}</TableCell>
                            <TableCell className="text-muted-foreground hidden md:table-cell">
                              {tx.recipient || tx.recipientEmail || tx.recipientPhone || '—'}
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm hidden sm:table-cell">
                              {tx.createdAt ? <span className="datetime-badge date-only">{formatDate(tx.createdAt)}</span> : '—'}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => { setSelectedTx(tx); setDetailOpen(true); }}
                                className="h-8 w-8 p-0 rounded-xl"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>

      {/* Transaction Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="bg-card rounded-2xl border border-border max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg">Transaction Details</DialogTitle>
            <DialogDescription>View complete transfer information</DialogDescription>
          </DialogHeader>
          {selectedTx && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Reference</p>
                  <p className="text-sm font-mono font-medium">{selectedTx.reference || selectedTx.id.slice(0, 8)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Type</p>
                  <p className="text-sm font-medium">
                    {selectedTx.subType
                      ? selectedTx.subType.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
                      : selectedTx.type || 'Transfer'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Amount</p>
                  <p className="text-sm font-semibold">
                    {selectedTx.amount != null
                      ? formatCurrency(selectedTx.amount, selectedTx.currency)
                      : '—'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Status</p>
                  {getStatusBadge(selectedTx.status)}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Recipient</p>
                  <p className="text-sm font-medium">
                    {selectedTx.recipient || selectedTx.recipientEmail || selectedTx.recipientPhone || '—'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Date</p>
                  <p className="text-sm font-medium">
                    {selectedTx.createdAt ? <span className="datetime-badge full">{formatDateTime(selectedTx.createdAt)}</span> : '—'}
                  </p>
                </div>
                {selectedTx.sourceBank && (
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Source Bank</p>
                    <p className="text-sm font-medium">{selectedTx.sourceBank}</p>
                  </div>
                )}
                {selectedTx.destBank && (
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Destination Bank</p>
                    <p className="text-sm font-medium">{selectedTx.destBank}</p>
                  </div>
                )}
                {selectedTx.description && (
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground mb-1">Description</p>
                    <p className="text-sm font-medium">{selectedTx.description}</p>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailOpen(false)} className="rounded-2xl">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction Advice Modal */}
      {adviceData && (
        <TransactionAdvice
          data={adviceData}
          onClose={() => setAdviceData(null)}
        />
      )}
    </div>
  );
}
