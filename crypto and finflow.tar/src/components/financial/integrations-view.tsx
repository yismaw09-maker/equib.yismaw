'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Plug,
  Search,
  RefreshCw,
  Inbox,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Key,
  Webhook,
  ScrollText,
  Building2,
  CreditCard,
  MessageSquare,
  Mail,
  ArrowLeftRight,
  UserCheck,
  Wifi,
  WifiOff,
  Loader2,
  Copy,
  Eye,
  EyeOff,
  Plus,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface Integration {
  id: string;
  name: string;
  type: 'bank' | 'payment' | 'sms' | 'email' | 'fx' | 'kyc' | 'other';
  status: 'active' | 'inactive' | 'error';
  lastSync: string | null;
  errorCount: number;
  description: string;
  version?: string;
  endpoint?: string;
}

interface IntegrationLog {
  id: string;
  integrationId: string;
  integrationName: string;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  statusCode?: number;
  duration?: number;
  createdAt: string;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  prefix: string;
  createdAt: string;
  lastUsed: string | null;
  status: 'active' | 'revoked';
}

interface WebhookConfig {
  id: string;
  url: string;
  events: string[];
  status: 'active' | 'inactive';
  lastTriggered: string | null;
  successRate: number;
  createdAt: string;
}

// --- Helpers ---

const statusColor: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  inactive: 'bg-gray-100 text-gray-500 border-gray-200',
  error: 'bg-rose-100 text-rose-700 border-rose-200',
};

const statusIcon: Record<string, typeof CheckCircle2> = {
  active: CheckCircle2,
  inactive: XCircle,
  error: AlertTriangle,
};

const typeColor: Record<string, string> = {
  bank: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  payment: 'bg-teal-100 text-teal-700 border-teal-200',
  sms: 'bg-amber-100 text-amber-700 border-amber-200',
  email: 'bg-violet-100 text-violet-700 border-violet-200',
  fx: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  kyc: 'bg-orange-100 text-orange-700 border-orange-200',
  other: 'bg-gray-100 text-gray-600 border-gray-200',
};

const typeIcon: Record<string, typeof Building2> = {
  bank: Building2,
  payment: CreditCard,
  sms: MessageSquare,
  email: Mail,
  fx: ArrowLeftRight,
  kyc: UserCheck,
  other: Plug,
};

const logLevelColor: Record<string, string> = {
  info: 'bg-gray-100 text-gray-600 border-gray-200',
  success: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  warning: 'bg-amber-100 text-amber-700 border-amber-200',
  error: 'bg-rose-100 text-rose-700 border-rose-200',
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const MOCK_INTEGRATIONS: Integration[] = [
  { id: 'int1', name: 'Commercial Bank of Ethiopia', type: 'bank', status: 'active', lastSync: new Date(Date.now() - 1000*60*5).toISOString(), errorCount: 0, description: 'Primary banking partner for settlements and withdrawals', version: 'v2.1', endpoint: 'https://api.cbe.com.et/v2' },
  { id: 'int2', name: 'Awash International Bank', type: 'bank', status: 'active', lastSync: new Date(Date.now() - 1000*60*12).toISOString(), errorCount: 0, description: 'Secondary banking partner', version: 'v1.4', endpoint: 'https://api.awashbank.com' },
  { id: 'int3', name: 'Telebirr Payment Gateway', type: 'payment', status: 'active', lastSync: new Date(Date.now() - 1000*60*2).toISOString(), errorCount: 1, description: 'Mobile money payment processing', version: 'v3.0', endpoint: 'https://api.telebirr.et' },
  { id: 'int4', name: 'HelloCash', type: 'payment', status: 'active', lastSync: new Date(Date.now() - 1000*60*8).toISOString(), errorCount: 0, description: 'Mobile money integration', version: 'v1.2', endpoint: 'https://api.hellocash.com' },
  { id: 'int5', name: 'Africastalking SMS', type: 'sms', status: 'active', lastSync: new Date(Date.now() - 1000*60*30).toISOString(), errorCount: 3, description: 'SMS notification delivery', version: 'v2.0', endpoint: 'https://api.africastalking.com' },
  { id: 'int6', name: 'SendGrid Email', type: 'email', status: 'active', lastSync: new Date(Date.now() - 1000*60*15).toISOString(), errorCount: 0, description: 'Transactional email delivery', version: 'v3.3', endpoint: 'https://api.sendgrid.com' },
  { id: 'int7', name: 'FX Rate Provider', type: 'fx', status: 'active', lastSync: new Date(Date.now() - 1000*60*1).toISOString(), errorCount: 0, description: 'Real-time foreign exchange rates', version: 'v1.0', endpoint: 'https://rates.fxprovider.com' },
  { id: 'int8', name: 'Jumio KYC', type: 'kyc', status: 'error', lastSync: new Date(Date.now() - 1000*60*120).toISOString(), errorCount: 5, description: 'Automated KYC document verification', version: 'v4.2', endpoint: 'https://netverify.jumio.com' },
];

const MOCK_LOGS: IntegrationLog[] = [
  { id: 'il1', integrationId: 'int1', integrationName: 'CBE Bank', level: 'success', message: 'Settlement batch processed — 23 transactions', statusCode: 200, duration: 1240, createdAt: new Date(Date.now() - 1000*60*5).toISOString() },
  { id: 'il2', integrationId: 'int3', integrationName: 'Telebirr', level: 'success', message: 'Payment callback received — TX-20250627055', statusCode: 200, duration: 320, createdAt: new Date(Date.now() - 1000*60*8).toISOString() },
  { id: 'il3', integrationId: 'int8', integrationName: 'Jumio KYC', level: 'error', message: 'Document verification failed — API timeout after 30s', statusCode: 504, duration: 30000, createdAt: new Date(Date.now() - 1000*60*15).toISOString() },
  { id: 'il4', integrationId: 'int5', integrationName: 'Africastalking', level: 'warning', message: 'SMS delivery delayed — 3 messages in queue', statusCode: 202, duration: 890, createdAt: new Date(Date.now() - 1000*60*20).toISOString() },
  { id: 'il5', integrationId: 'int7', integrationName: 'FX Provider', level: 'success', message: 'FX rates updated — 14 currency pairs', statusCode: 200, duration: 450, createdAt: new Date(Date.now() - 1000*60*25).toISOString() },
  { id: 'il6', integrationId: 'int6', integrationName: 'SendGrid', level: 'success', message: 'Welcome email sent — new user registration', statusCode: 200, duration: 560, createdAt: new Date(Date.now() - 1000*60*35).toISOString() },
  { id: 'il7', integrationId: 'int8', integrationName: 'Jumio KYC', level: 'error', message: 'Rate limit exceeded — 429 Too Many Requests', statusCode: 429, duration: 150, createdAt: new Date(Date.now() - 1000*60*40).toISOString() },
  { id: 'il8', integrationId: 'int2', integrationName: 'Awash Bank', level: 'success', message: 'Account balance verified — ETB 980,000', statusCode: 200, duration: 780, createdAt: new Date(Date.now() - 1000*60*50).toISOString() },
  { id: 'il9', integrationId: 'int4', integrationName: 'HelloCash', level: 'info', message: 'Webhook endpoint health check passed', statusCode: 200, duration: 120, createdAt: new Date(Date.now() - 1000*60*60).toISOString() },
  { id: 'il10', integrationId: 'int5', integrationName: 'Africastalking', level: 'error', message: 'SMS delivery failed — invalid phone number format', statusCode: 400, duration: 200, createdAt: new Date(Date.now() - 1000*60*75).toISOString() },
];

const MOCK_API_KEYS: ApiKey[] = [
  { id: 'ak1', name: 'Production API Key', key: 'ff_live_sk_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6', prefix: 'ff_live_sk_...p6', createdAt: new Date(Date.now() - 86400000 * 60).toISOString(), lastUsed: new Date(Date.now() - 1000*60*5).toISOString(), status: 'active' },
  { id: 'ak2', name: 'Staging API Key', key: 'ff_test_sk_q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2', prefix: 'ff_test_sk_...f2', createdAt: new Date(Date.now() - 86400000 * 30).toISOString(), lastUsed: new Date(Date.now() - 86400000).toISOString(), status: 'active' },
  { id: 'ak3', name: 'Old Production Key', key: 'ff_live_sk_g3h4i5j6k7l8m9n0o1p2q3r4s5t6u7v8', prefix: 'ff_live_sk_...v8', createdAt: new Date(Date.now() - 86400000 * 90).toISOString(), lastUsed: new Date(Date.now() - 86400000 * 15).toISOString(), status: 'revoked' },
];

const MOCK_WEBHOOKS: WebhookConfig[] = [
  { id: 'wh1', url: 'https://api.merkato.com/webhooks/finflow', events: ['transaction.completed', 'payment.received'], status: 'active', lastTriggered: new Date(Date.now() - 1000*60*10).toISOString(), successRate: 99.2, createdAt: new Date(Date.now() - 86400000 * 20).toISOString() },
  { id: 'wh2', url: 'https://hooks.slack.com/services/T00/B00/xxx', events: ['fraud.alert', 'compliance.case'], status: 'active', lastTriggered: new Date(Date.now() - 1000*60*60).toISOString(), successRate: 100, createdAt: new Date(Date.now() - 86400000 * 10).toISOString() },
  { id: 'wh3', url: 'https://internal.company.com/notifications', events: ['user.registered', 'kyc.completed'], status: 'inactive', lastTriggered: new Date(Date.now() - 86400000 * 3).toISOString(), successRate: 95.4, createdAt: new Date(Date.now() - 86400000 * 45).toISOString() },
];

// --- Component ---

export default function IntegrationsView() {
  const { formatDateTime, formatRelative } = useFormattedDate();

  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [logs, setLogs] = useState<IntegrationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [logLevelFilter, setLogLevelFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('services');
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [webhookDialog, setWebhookDialog] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/integrations');
      if (res.ok) {
        const data = await res.json();
        if (data.integrations) setIntegrations(data.integrations);
        if (data.logs) setLogs(data.logs);
      } else {
        setIntegrations(MOCK_INTEGRATIONS);
        setLogs(MOCK_LOGS);
      }
    } catch {
      setIntegrations(MOCK_INTEGRATIONS);
      setLogs(MOCK_LOGS);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredIntegrations = useMemo(() => {
    let result = integrations;
    if (statusFilter !== 'all') result = result.filter((i) => i.status === statusFilter);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter((i) => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q));
    }
    return result;
  }, [integrations, statusFilter, searchQuery]);

  const filteredLogs = useMemo(() => {
    let result = logs;
    if (logLevelFilter !== 'all') result = result.filter((l) => l.level === logLevelFilter);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter((l) => l.message.toLowerCase().includes(q) || l.integrationName.toLowerCase().includes(q));
    }
    return result;
  }, [logs, logLevelFilter, searchQuery]);

  const activeCount = integrations.filter((i) => i.status === 'active').length;
  const errorCount = integrations.filter((i) => i.status === 'error').length;
  const totalErrors = integrations.reduce((s, i) => s + i.errorCount, 0);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  const renderLoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}><CardContent className="p-4"><div className="space-y-2"><Skeleton className="h-5 w-2/3" /><Skeleton className="h-4 w-full" /><Skeleton className="h-3 w-1/3" /></div></CardContent></Card>
      ))}
    </div>
  );

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Inbox className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium">No results found</h3>
      <p className="text-sm text-muted-foreground mt-1">No items match your current filters.</p>
    </div>
  );

  const renderIntegrationCards = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {filteredIntegrations.map((integration) => {
        const TypeIcon = typeIcon[integration.type] || Plug;
        const StatusIcon = statusIcon[integration.status] || CheckCircle2;
        return (
          <motion.div
            key={integration.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
          >
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={cn('h-11 w-11 rounded-xl flex items-center justify-center shrink-0', typeColor[integration.type])}>
                    <TypeIcon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-sm font-semibold truncate">{integration.name}</h3>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {integration.errorCount > 0 && (
                          <Badge variant="outline" className="bg-rose-50 text-rose-600 border-rose-200 text-[10px]">
                            {integration.errorCount} errors
                          </Badge>
                        )}
                        <Badge variant="outline" className={cn('text-[10px]', statusColor[integration.status])}>
                          <StatusIcon className="h-3 w-3 mr-0.5" /> {integration.status}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{integration.description}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      {integration.lastSync && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Synced {formatRelative(integration.lastSync)}
                        </span>
                      )}
                      {integration.version && <span className="font-mono">{integration.version}</span>}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );

  const renderIntegrationLogs = () => (
    <ScrollArea className="max-h-[500px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Level</TableHead>
            <TableHead className="w-[140px]">Integration</TableHead>
            <TableHead className="min-w-[250px]">Message</TableHead>
            <TableHead className="w-[70px]">Code</TableHead>
            <TableHead className="w-[80px]">Duration</TableHead>
            <TableHead className="w-[120px]">Time</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredLogs.map((log) => (
            <TableRow key={log.id}>
              <TableCell>
                <Badge variant="outline" className={cn('text-[10px]', logLevelColor[log.level])}>{log.level}</Badge>
              </TableCell>
              <TableCell className="text-sm font-medium">{log.integrationName}</TableCell>
              <TableCell className="text-sm">{log.message}</TableCell>
              <TableCell className="text-xs font-mono">{log.statusCode || '—'}</TableCell>
              <TableCell className="text-xs font-mono">{log.duration ? `${(log.duration / 1000).toFixed(1)}s` : '—'}</TableCell>
              <TableCell className="text-xs text-muted-foreground" title={formatDateTime(log.createdAt)}>
                {formatRelative(log.createdAt)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  const renderApiKeys = () => (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button className="bg-emerald-600 hover:bg-emerald-700 gap-1.5" onClick={() => toast.info('API key creation would open a dialog')}> 
          <Plus className="h-4 w-4" /> Create New Key
        </Button>
      </div>
      <div className="space-y-3">
        {MOCK_API_KEYS.map((apiKey) => (
          <Card key={apiKey.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Key className="h-4 w-4 text-amber-500" />
                    <h3 className="text-sm font-medium">{apiKey.name}</h3>
                    <Badge variant="outline" className={apiKey.status === 'active' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-gray-100 text-gray-500 border-gray-200'}>
                      {apiKey.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                      {visibleKeys[apiKey.id] ? apiKey.key : apiKey.prefix}
                    </code>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setVisibleKeys((p) => ({ ...p, [apiKey.id]: !p[apiKey.id] }))}>
                      {visibleKeys[apiKey.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => copyToClipboard(apiKey.key)}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span>Created: {formatDateTime(apiKey.createdAt)}</span>
                    {apiKey.lastUsed && <span>Last used: {formatRelative(apiKey.lastUsed)}</span>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderWebhooks = () => (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button className="bg-emerald-600 hover:bg-emerald-700 gap-1.5" onClick={() => setWebhookDialog(true)}>
          <Plus className="h-4 w-4" /> Add Webhook
        </Button>
      </div>
      <div className="space-y-3">
        {MOCK_WEBHOOKS.map((webhook) => (
          <Card key={webhook.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Webhook className="h-4 w-4 text-cyan-500" />
                    <code className="text-xs bg-muted px-2 py-0.5 rounded font-mono truncate max-w-[300px] block">
                      {webhook.url}
                    </code>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap mt-2">
                    {webhook.events.map((event) => (
                      <Badge key={event} variant="outline" className="text-[10px] bg-cyan-50 text-cyan-700 border-cyan-200">
                        {event}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span>Success rate: <span className="font-medium text-emerald-600">{webhook.successRate}%</span></span>
                    {webhook.lastTriggered && <span>Last: {formatRelative(webhook.lastTriggered)}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant="outline" className={statusColor[webhook.status]}>{webhook.status}</Badge>
                  <div className="flex items-center gap-1">
                    <Switch checked={webhook.status === 'active'} onCheckedChange={() => {}} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <Plug className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">API & Integrations</h1>
            <p className="text-sm text-muted-foreground">Manage connected services, API keys, and webhook configurations</p>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-emerald-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Active Services</p>
                <p className="text-2xl font-bold text-emerald-600">{activeCount}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center">
                <Wifi className="h-4 w-4 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-rose-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">With Errors</p>
                <p className="text-2xl font-bold text-rose-600">{errorCount}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center">
                <WifiOff className="h-4 w-4 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Errors</p>
                <p className="text-2xl font-bold text-amber-600">{totalErrors}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">API Calls Today</p>
                <p className="text-2xl font-bold text-teal-600">1,247</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-teal-100 flex items-center justify-center">
                <Key className="h-4 w-4 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search & Filter */}
      <motion.div {...fadeUp} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search integrations, logs..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="error">Error</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchData} title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* Main Tabs */}
      <motion.div {...fadeUp}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Integration Management</CardTitle>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                {integrations.length} services
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="services" className="gap-1.5">
                  <Plug className="h-3.5 w-3.5" /> Connected Services
                </TabsTrigger>
                <TabsTrigger value="logs" className="gap-1.5">
                  <ScrollText className="h-3.5 w-3.5" /> Integration Logs
                </TabsTrigger>
                <TabsTrigger value="keys" className="gap-1.5">
                  <Key className="h-3.5 w-3.5" /> API Keys
                </TabsTrigger>
                <TabsTrigger value="webhooks" className="gap-1.5">
                  <Webhook className="h-3.5 w-3.5" /> Webhooks
                </TabsTrigger>
              </TabsList>

              <TabsContent value="services">
                {loading ? renderLoadingSkeleton() : filteredIntegrations.length === 0 ? renderEmptyState() : renderIntegrationCards()}
              </TabsContent>
              <TabsContent value="logs">
                <div className="flex justify-end mb-3">
                  <Select value={logLevelFilter} onValueChange={setLogLevelFilter}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Log Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="success">Success</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="error">Error</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {loading ? renderLoadingSkeleton() : filteredLogs.length === 0 ? renderEmptyState() : renderIntegrationLogs()}
              </TabsContent>
              <TabsContent value="keys">{renderApiKeys()}</TabsContent>
              <TabsContent value="webhooks">{renderWebhooks()}</TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>

      {/* Webhook Dialog (placeholder) */}
      <Dialog open={webhookDialog} onOpenChange={setWebhookDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Webhook</DialogTitle>
            <DialogDescription>Configure a new webhook endpoint to receive event notifications.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Endpoint URL</Label>
              <Input placeholder="https://your-domain.com/webhook" />
            </div>
            <div className="space-y-2">
              <Label>Events</Label>
              <div className="flex flex-wrap gap-2">
                {['transaction.completed', 'payment.received', 'fraud.alert', 'compliance.case', 'user.registered'].map((event) => (
                  <Badge key={event} variant="outline" className="cursor-pointer hover:bg-emerald-50 hover:border-emerald-200">{event}</Badge>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setWebhookDialog(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { setWebhookDialog(false); toast.success('Webhook created successfully'); }}>
              Create Webhook
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
