'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import {
  CreditCard,
  Smartphone,
  Landmark,
  Building2,
  QrCode,
  Bitcoin,
  CheckCircle2,
  Clock,
  DollarSign,
  Settings,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Eye,
  ArrowUpDown,
  Save,
  ExternalLink,
  Wallet,
  Zap,
  Shield,
  RefreshCw,
  MoreHorizontal,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

// --- Types ---

interface PaymentMethod {
  id: string;
  name: string;
  type: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  fee: string;
  status: string;
  users: string;
  volume: string;
  enabled?: boolean;
}

interface TransactionItem {
  id: string;
  reference: string;
  type: string;
  amount: number;
  currency: string;
  status: string;
  paymentMethod: string | null;
  createdAt: string;
  description?: string | null;
}

interface TransactionStats {
  total: number;
  completed: number;
  pending: number;
  failed: number;
  totalVolume: number;
  todayVolume: number;
}

interface GatewayConfig {
  id: string;
  name: string;
  apiEndpoint: string;
  webhookUrl: string;
  timeout: number;
  maxRetry: number;
  status: string;
}

interface ConfigFormData {
  name: string;
  type: string;
  feeType: string;
  feeValue: string;
  minAmount: string;
  maxAmount: string;
  status: string;
}

// --- Constants ---

const PAYMENT_METHODS: PaymentMethod[] = [
  { id: 'telebirr', name: 'telebirr', type: 'Mobile Money', icon: Smartphone, color: 'bg-green-600', fee: '1.5%', status: 'active', users: '12.5M', volume: 'ETB 2.3B', enabled: true },
  { id: 'cbe-birr', name: 'CBE Birr', type: 'Mobile Money', icon: Landmark, color: 'bg-blue-600', fee: '1.0%', status: 'active', users: '8.2M', volume: 'ETB 1.8B', enabled: true },
  { id: 'mpesa', name: 'M-PESA', type: 'Mobile Money', icon: Smartphone, color: 'bg-red-600', fee: '1.2%', status: 'active', users: '3.1M', volume: 'ETB 450M', enabled: true },
  { id: 'hellocash', name: 'HelloCash', type: 'Mobile Money', icon: Smartphone, color: 'bg-orange-500', fee: '1.8%', status: 'active', users: '2.4M', volume: 'ETB 320M', enabled: true },
  { id: 'chapa', name: 'Chapa', type: 'Payment Gateway', icon: CreditCard, color: 'bg-violet-600', fee: '2.5%', status: 'active', users: '1.8M', volume: 'ETB 780M', enabled: true },
  { id: 'visa', name: 'Visa', type: 'Card Payment', icon: CreditCard, color: 'bg-blue-700', fee: '2.0%', status: 'active', users: '5.6M', volume: 'ETB 4.1B', enabled: true },
  { id: 'mastercard', name: 'Mastercard', type: 'Card Payment', icon: CreditCard, color: 'bg-orange-700', fee: '2.0%', status: 'active', users: '4.2M', volume: 'ETB 3.5B', enabled: true },
  { id: 'qr', name: 'QR Payments', type: 'QR Code', icon: QrCode, color: 'bg-emerald-600', fee: '0.5%', status: 'active', users: '6.3M', volume: 'ETB 1.2B', enabled: true },
  { id: 'binance', name: 'Binance Pay', type: 'Crypto Payment', icon: Bitcoin, color: 'bg-yellow-500', fee: '0.1%', status: 'coming_soon', users: '890K', volume: 'ETB 120M', enabled: false },
  { id: 'bank-transfer', name: 'Bank Transfer', type: 'Bank-to-Bank', icon: Building2, color: 'bg-slate-600', fee: 'ETB 15', status: 'active', users: '3.5M', volume: 'ETB 5.7B', enabled: true },
  { id: 'card-payments', name: 'Card Payments', type: 'Debit/Credit', icon: CreditCard, color: 'bg-teal-600', fee: '1.5%', status: 'active', users: '7.1M', volume: 'ETB 3.8B', enabled: true },
];

const GATEWAY_CONFIGS: GatewayConfig[] = [
  { id: 'telebirr-gw', name: 'telebirr Gateway', apiEndpoint: 'https://api.telebirr.et/v2', webhookUrl: 'https://finflow.et/webhooks/telebirr', timeout: 30, maxRetry: 3, status: 'active' },
  { id: 'cbe-birr-gw', name: 'CBE Birr Gateway', apiEndpoint: 'https://api.cbe.com.et/v1/payments', webhookUrl: 'https://finflow.et/webhooks/cbe-birr', timeout: 30, maxRetry: 3, status: 'active' },
  { id: 'mpesa-gw', name: 'M-PESA Gateway', apiEndpoint: 'https://api.mpesa.safaricom.et/v1', webhookUrl: 'https://finflow.et/webhooks/mpesa', timeout: 25, maxRetry: 3, status: 'active' },
  { id: 'hellocash-gw', name: 'HelloCash Gateway', apiEndpoint: 'https://api.hellocash.et/v2', webhookUrl: 'https://finflow.et/webhooks/hellocash', timeout: 30, maxRetry: 2, status: 'active' },
  { id: 'chapa-gw', name: 'Chapa Gateway', apiEndpoint: 'https://api.chapa.co/v1', webhookUrl: 'https://finflow.et/webhooks/chapa', timeout: 20, maxRetry: 3, status: 'active' },
  { id: 'visa-gw', name: 'Visa Payment Gateway', apiEndpoint: 'https://api.visa.com/groundfloor/v2', webhookUrl: 'https://finflow.et/webhooks/visa', timeout: 15, maxRetry: 2, status: 'active' },
  { id: 'mastercard-gw', name: 'Mastercard Gateway', apiEndpoint: 'https://api.mastercard.com/integration', webhookUrl: 'https://finflow.et/webhooks/mastercard', timeout: 15, maxRetry: 2, status: 'active' },
  { id: 'qr-gw', name: 'QR Payment Processor', apiEndpoint: 'https://qr.finflow.et/api/v1', webhookUrl: 'https://finflow.et/webhooks/qr', timeout: 10, maxRetry: 1, status: 'active' },
  { id: 'binance-gw', name: 'Binance Pay Gateway', apiEndpoint: 'https://api.binance.com/pay/v1', webhookUrl: 'https://finflow.et/webhooks/binance', timeout: 30, maxRetry: 3, status: 'coming_soon' },
  { id: 'bank-transfer-gw', name: 'Bank Transfer Gateway', apiEndpoint: 'https://banking.finflow.et/api/v1', webhookUrl: 'https://finflow.et/webhooks/bank-transfer', timeout: 60, maxRetry: 5, status: 'active' },
  { id: 'card-payments-gw', name: 'Card Payments Gateway', apiEndpoint: 'https://cards.finflow.et/api/v1', webhookUrl: 'https://finflow.et/webhooks/cards', timeout: 20, maxRetry: 3, status: 'active' },
];

const ITEMS_PER_PAGE = 10;

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

// --- Status helpers ---

function getStatusBadge(status: string) {
  switch (status) {
    case 'active':
    case 'completed':
    case 'success':
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">Active</Badge>;
    case 'inactive':
    case 'failed':
      return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">Inactive</Badge>;
    case 'pending':
      return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">Pending</Badge>;
    case 'processing':
      return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">Processing</Badge>;
    case 'coming_soon':
      return <Badge className="bg-violet-100 text-violet-700 hover:bg-violet-100">Coming Soon</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function getTransactionStatusBadge(status: string) {
  switch (status) {
    case 'completed':
    case 'success':
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">Completed</Badge>;
    case 'pending':
      return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">Pending</Badge>;
    case 'failed':
      return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">Failed</Badge>;
    case 'processing':
      return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">Processing</Badge>;
    case 'cancelled':
      return <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100">Cancelled</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

// --- Component ---

export default function PaymentsView() {
  const { formatDateTime } = useFormattedDate();

  // Data state
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [stats, setStats] = useState<TransactionStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingTransactions, setLoadingTransactions] = useState(true);

  // Payment methods state (mutable copy for toggling)
  const [methods, setMethods] = useState<PaymentMethod[]>(PAYMENT_METHODS);

  // Gateway configs state (mutable copy for editing)
  const [gateways, setGateways] = useState<GatewayConfig[]>(GATEWAY_CONFIGS);

  // Tab state
  const [activeTab, setActiveTab] = useState('methods');

  // Filters for recent payments
  const [methodFilter, setMethodFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Dialog states
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<TransactionItem | null>(null);

  // Config form state
  const [configForm, setConfigForm] = useState<ConfigFormData>({
    name: '',
    type: '',
    feeType: 'percentage',
    feeValue: '',
    minAmount: '',
    maxAmount: '',
    status: 'active',
  });

  // Loading states
  const [savingConfig, setSavingConfig] = useState(false);
  const [togglingMethod, setTogglingMethod] = useState<string | null>(null);
  const [savingGateway, setSavingGateway] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // --- Fetch stats ---
  const fetchStats = useCallback(async () => {
    try {
      const res = await apiFetch('/api/transactions?limit=1');
      if (res.ok) {
        const data = await res.json();
        if (data.stats) {
          setStats(data.stats);
        }
      }
    } catch {
      // Use fallback stats
    } finally {
      setLoadingStats(false);
    }
  }, []);

  // --- Fetch transactions ---
  const fetchTransactions = useCallback(async () => {
    setLoadingTransactions(true);
    try {
      const res = await apiFetch('/api/transactions?limit=50');
      if (res.ok) {
        const data = await res.json();
        const items: TransactionItem[] = data.transactions || data || [];
        setTransactions(items);
      }
    } catch {
      toast.error('Failed to load transactions');
    } finally {
      setLoadingTransactions(false);
    }
  }, []);

  // --- Initial load ---
  useEffect(() => {
    fetchStats();
    fetchTransactions();
  }, [fetchStats, fetchTransactions]);

  // --- Filtered transactions ---
  const filteredTransactions = useMemo(() => {
    let result = [...transactions];
    if (methodFilter !== 'all') {
      result = result.filter(
        (t) =>
          t.paymentMethod?.toLowerCase().replace(/\s+/g, '-') === methodFilter ||
          t.paymentMethod?.toLowerCase() === methodFilter
      );
    }
    if (statusFilter !== 'all') {
      result = result.filter((t) => t.status === statusFilter);
    }
    return result;
  }, [transactions, methodFilter, statusFilter]);

  // --- Pagination ---
  const totalPages = Math.max(1, Math.ceil(filteredTransactions.length / ITEMS_PER_PAGE));
  const paginatedTransactions = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredTransactions.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredTransactions, currentPage]);

  // Reset page on filter change
  useEffect(() => {
    setCurrentPage(1);
  }, [methodFilter, statusFilter]);

  // --- Toggle payment method ---
  const handleToggleMethod = useCallback(async (methodId: string) => {
    setTogglingMethod(methodId);
    const method = methods.find((m) => m.id === methodId);
    const newEnabled = !method?.enabled;

    // Optimistic update
    setMethods((prev) =>
      prev.map((m) => (m.id === methodId ? { ...m, enabled: newEnabled, status: newEnabled ? 'active' : 'inactive' } : m))
    );

    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentMethod: methodId,
          status: newEnabled ? 'active' : 'inactive',
        }),
      });
      if (res.ok) {
        toast.success(`${method?.name || methodId} ${newEnabled ? 'enabled' : 'disabled'} successfully`);
      } else {
        // Revert on failure
        setMethods((prev) =>
          prev.map((m) => (m.id === methodId ? { ...m, enabled: !newEnabled, status: !newEnabled ? 'active' : 'inactive' } : m))
        );
        toast.error(`Failed to update ${method?.name || methodId}`);
      }
    } catch {
      setMethods((prev) =>
        prev.map((m) => (m.id === methodId ? { ...m, enabled: !newEnabled, status: !newEnabled ? 'active' : 'inactive' } : m))
      );
      toast.error('Network error while updating payment method');
    } finally {
      setTogglingMethod(null);
    }
  }, [methods]);

  // --- Open configure dialog ---
  const handleOpenConfig = useCallback((method: PaymentMethod) => {
    setSelectedMethod(method);
    const isPercentage = method.fee.endsWith('%');
    setConfigForm({
      name: method.name,
      type: method.type,
      feeType: isPercentage ? 'percentage' : 'flat',
      feeValue: isPercentage ? method.fee.replace('%', '') : method.fee.replace(/[^0-9.]/g, ''),
      minAmount: '0',
      maxAmount: '1000000',
      status: method.status,
    });
    setConfigDialogOpen(true);
  }, []);

  // --- Save configuration ---
  const handleSaveConfig = useCallback(async () => {
    if (!selectedMethod) return;
    if (!configForm.feeValue) {
      toast.error('Fee value is required');
      return;
    }

    setSavingConfig(true);
    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentMethod: selectedMethod.id,
          feeType: configForm.feeType,
          feeValue: parseFloat(configForm.feeValue),
          minAmount: parseFloat(configForm.minAmount) || 0,
          maxAmount: parseFloat(configForm.maxAmount) || 1000000,
          status: configForm.status,
        }),
      });
      if (res.ok) {
        toast.success(`${selectedMethod.name} configuration saved successfully`);
        setConfigDialogOpen(false);
        // Update local state
        const feeDisplay = configForm.feeType === 'percentage' ? `${configForm.feeValue}%` : `ETB ${configForm.feeValue}`;
        setMethods((prev) =>
          prev.map((m) =>
            m.id === selectedMethod.id
              ? { ...m, fee: feeDisplay, status: configForm.status, enabled: configForm.status === 'active' }
              : m
          )
        );
      } else {
        toast.error('Failed to save configuration');
      }
    } catch {
      toast.error('Network error while saving configuration');
    } finally {
      setSavingConfig(false);
    }
  }, [selectedMethod, configForm]);

  // --- Save gateway config ---
  const handleSaveGateway = useCallback(async (gatewayId: string) => {
    setSavingGateway(gatewayId);
    try {
      const gateway = gateways.find((g) => g.id === gatewayId);
      if (!gateway) return;

      const res = await apiFetch('/api/fee-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentMethod: gatewayId,
          gatewayConfig: {
            apiEndpoint: gateway.apiEndpoint,
            webhookUrl: gateway.webhookUrl,
            timeout: gateway.timeout,
            maxRetry: gateway.maxRetry,
          },
        }),
      });
      if (res.ok) {
        toast.success(`${gateway.name} configuration saved`);
      } else {
        toast.error(`Failed to save ${gateway.name} configuration`);
      }
    } catch {
      toast.error('Network error while saving gateway configuration');
    } finally {
      setSavingGateway(null);
    }
  }, [gateways]);

  // --- Update gateway field ---
  const updateGatewayField = useCallback((gatewayId: string, field: keyof GatewayConfig, value: string | number) => {
    setGateways((prev) =>
      prev.map((g) => (g.id === gatewayId ? { ...g, [field]: value } : g))
    );
  }, []);

  // --- View transaction detail ---
  const handleViewTransaction = useCallback((txn: TransactionItem) => {
    setSelectedTransaction(txn);
    setDetailDialogOpen(true);
  }, []);

  // --- Refresh ---
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([fetchStats(), fetchTransactions()]);
    setRefreshing(false);
    toast.success('Data refreshed');
  }, [fetchStats, fetchTransactions]);

  // --- Computed stats for header badges ---
  const activeMethodCount = useMemo(
    () => methods.filter((m) => m.status === 'active').length,
    [methods]
  );

  // --- Render ---

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <motion.div {...fadeIn} className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Payment Integration</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage payment methods, gateways, and transaction processing for the Ethiopian financial ecosystem.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="text-xs font-medium px-3 py-1.5">
            <CreditCard className="mr-1.5 h-3 w-3" />
            {PAYMENT_METHODS.length} Methods
          </Badge>
          <Badge variant="outline" className="text-xs font-medium px-3 py-1.5 bg-emerald-50 text-emerald-700 border-emerald-200">
            <CheckCircle2 className="mr-1.5 h-3 w-3" />
            {activeMethodCount} Active
          </Badge>
          <Badge variant="outline" className="text-xs font-medium px-3 py-1.5 bg-violet-50 text-violet-700 border-violet-200">
            <DollarSign className="mr-1.5 h-3 w-3" />
            {stats?.todayVolume
              ? `ETB ${(stats.todayVolume / 1000000).toFixed(1)}M Today`
              : 'ETB -- Today'}
          </Badge>
          <Button variant="outline" size="sm" className="btn-responsive" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`mr-2 h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {loadingStats ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="rounded-2xl border p-5">
              <Skeleton className="h-10 w-10 rounded-full mb-3" />
              <Skeleton className="h-7 w-24 mb-1" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))
        ) : (
          <>
            <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0 }} className="rounded-2xl border p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-emerald-600" />
                </div>
              </div>
              <div className="text-2xl font-bold">{PAYMENT_METHODS.length}</div>
              <div className="text-sm text-muted-foreground">Total Payment Methods</div>
            </motion.div>
            <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.05 }} className="rounded-2xl border p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <CheckCircle2 className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <div className="text-2xl font-bold">{activeMethodCount}</div>
              <div className="text-sm text-muted-foreground">Active Methods</div>
            </motion.div>
            <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.1 }} className="rounded-2xl border p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-full bg-violet-100 flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-violet-600" />
                </div>
              </div>
              <div className="text-2xl font-bold">
                {stats?.todayVolume
                  ? `ETB ${(stats.todayVolume / 1000000).toFixed(1)}M`
                  : 'ETB --'}
              </div>
              <div className="text-sm text-muted-foreground">Today&apos;s Volume</div>
            </motion.div>
            <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.15 }} className="rounded-2xl border p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <div className="text-2xl font-bold">{stats?.pending ?? '--'}</div>
              <div className="text-sm text-muted-foreground">Pending Transactions</div>
            </motion.div>
          </>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full max-w-md grid grid-cols-3">
          <TabsTrigger value="methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="payments">Recent Payments</TabsTrigger>
          <TabsTrigger value="gateway">Gateway Config</TabsTrigger>
        </TabsList>

        {/* Tab 1: Payment Methods */}
        <TabsContent value="methods" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {methods.map((method, idx) => {
              const IconComp = method.icon;
              return (
                <motion.div
                  key={method.id}
                  {...fadeIn}
                  transition={{ duration: 0.4, delay: idx * 0.03 }}
                  className="rounded-2xl border p-5 hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-full ${method.color} flex items-center justify-center`}>
                        <IconComp className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{method.name}</h3>
                        <p className="text-xs text-muted-foreground">{method.type}</p>
                      </div>
                    </div>
                    {getStatusBadge(method.status)}
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4 text-xs">
                    <div>
                      <span className="text-muted-foreground">Fee</span>
                      <p className="font-medium mt-0.5">{method.fee}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Users</span>
                      <p className="font-medium mt-0.5">{method.users}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-muted-foreground">Volume</span>
                      <p className="font-medium mt-0.5">{method.volume}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={method.enabled ?? method.status === 'active'}
                        disabled={togglingMethod === method.id || method.status === 'coming_soon'}
                        onCheckedChange={() => handleToggleMethod(method.id)}
                      />
                      <span className="text-xs text-muted-foreground">
                        {togglingMethod === method.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : method.enabled || method.status === 'active' ? (
                          'Enabled'
                        ) : (
                          'Disabled'
                        )}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs h-8"
                      onClick={() => handleOpenConfig(method)}
                    >
                      <Settings className="mr-1.5 h-3 w-3" />
                      Configure
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        {/* Tab 2: Recent Payments */}
        <TabsContent value="payments" className="mt-6">
          <Card className="rounded-2xl">
            <CardHeader className="pb-3">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <CardTitle className="text-lg">Recent Payments</CardTitle>
                  <CardDescription className="text-xs mt-1">Latest transactions across all payment methods</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={methodFilter} onValueChange={setMethodFilter}>
                    <SelectTrigger className="w-[160px] h-9 text-xs">
                      <SelectValue placeholder="Payment Method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Methods</SelectItem>
                      {PAYMENT_METHODS.map((m) => (
                        <SelectItem key={m.id} value={m.id}>
                          {m.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[130px] h-9 text-xs">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="space-y-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  ))}
                </div>
              ) : filteredTransactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <Wallet className="h-10 w-10 mb-3 opacity-40" />
                  <p className="text-sm">No transactions found</p>
                  <p className="text-xs mt-1">Try adjusting your filters</p>
                </div>
              ) : (
                <>
                  <div className="max-h-[500px] overflow-y-auto custom-scroll">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Reference</TableHead>
                          <TableHead className="text-xs">Type</TableHead>
                          <TableHead className="text-xs">Amount</TableHead>
                          <TableHead className="text-xs">Currency</TableHead>
                          <TableHead className="text-xs">Method</TableHead>
                          <TableHead className="text-xs">Status</TableHead>
                          <TableHead className="text-xs">Date</TableHead>
                          <TableHead className="text-xs text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paginatedTransactions.map((txn) => (
                          <TableRow key={txn.id}>
                            <TableCell className="text-xs font-mono">{txn.reference}</TableCell>
                            <TableCell className="text-xs">{txn.type}</TableCell>
                            <TableCell className="text-xs font-semibold">
                              {txn.currency} {txn.amount.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-xs">{txn.currency}</TableCell>
                            <TableCell className="text-xs">{txn.paymentMethod || '—'}</TableCell>
                            <TableCell>{getTransactionStatusBadge(txn.status)}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">
                              {txn.createdAt ? (
                                <span className="datetime-badge full">{formatDateTime(txn.createdAt)}</span>
                              ) : '—'}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={() => handleViewTransaction(txn)}
                              >
                                <Eye className="h-3.5 w-3.5" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  <div className="flex items-center justify-between pt-4 border-t mt-4">
                    <p className="text-xs text-muted-foreground">
                      Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1}–
                      {Math.min(currentPage * ITEMS_PER_PAGE, filteredTransactions.length)} of{' '}
                      {filteredTransactions.length} transactions
                    </p>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 p-0"
                        disabled={currentPage <= 1}
                        onClick={() => setCurrentPage((p) => p - 1)}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                        let pageNum: number;
                        if (totalPages <= 5) {
                          pageNum = i + 1;
                        } else if (currentPage <= 3) {
                          pageNum = i + 1;
                        } else if (currentPage >= totalPages - 2) {
                          pageNum = totalPages - 4 + i;
                        } else {
                          pageNum = currentPage - 2 + i;
                        }
                        return (
                          <Button
                            key={pageNum}
                            variant={currentPage === pageNum ? 'default' : 'outline'}
                            size="sm"
                            className="h-8 w-8 p-0 text-xs"
                            onClick={() => setCurrentPage(pageNum)}
                          >
                            {pageNum}
                          </Button>
                        );
                      })}
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 p-0"
                        disabled={currentPage >= totalPages}
                        onClick={() => setCurrentPage((p) => p + 1)}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Gateway Config */}
        <TabsContent value="gateway" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {gateways.map((gw, idx) => (
              <motion.div
                key={gw.id}
                {...fadeIn}
                transition={{ duration: 0.4, delay: idx * 0.03 }}
                className="rounded-2xl border p-5"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center">
                      <Zap className="h-5 w-5 text-slate-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm">{gw.name}</h3>
                      <div className="mt-0.5">{getStatusBadge(gw.status)}</div>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs btn-responsive"
                    onClick={() => handleSaveGateway(gw.id)}
                    disabled={savingGateway === gw.id}
                  >
                    {savingGateway === gw.id ? (
                      <Loader2 className="mr-1.5 h-3 w-3 animate-spin" />
                    ) : (
                      <Save className="mr-1.5 h-3 w-3" />
                    )}
                    Save
                  </Button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">API Endpoint</Label>
                    <div className="flex items-center gap-1.5">
                      <Input
                        value={gw.apiEndpoint}
                        onChange={(e) => updateGatewayField(gw.id, 'apiEndpoint', e.target.value)}
                        className="h-8 text-xs font-mono"
                        disabled={gw.status === 'coming_soon'}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 shrink-0"
                        onClick={() => {
                          navigator.clipboard.writeText(gw.apiEndpoint);
                          toast.success('Endpoint URL copied');
                        }}
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">Webhook URL</Label>
                    <div className="flex items-center gap-1.5">
                      <Input
                        value={gw.webhookUrl}
                        onChange={(e) => updateGatewayField(gw.id, 'webhookUrl', e.target.value)}
                        className="h-8 text-xs font-mono"
                        disabled={gw.status === 'coming_soon'}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 shrink-0"
                        onClick={() => {
                          navigator.clipboard.writeText(gw.webhookUrl);
                          toast.success('Webhook URL copied');
                        }}
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">Timeout (seconds)</Label>
                    <Input
                      type="number"
                      value={gw.timeout}
                      onChange={(e) => updateGatewayField(gw.id, 'timeout', parseInt(e.target.value) || 0)}
                      className="h-8 text-xs"
                      disabled={gw.status === 'coming_soon'}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">Max Retry</Label>
                    <Input
                      type="number"
                      value={gw.maxRetry}
                      onChange={(e) => updateGatewayField(gw.id, 'maxRetry', parseInt(e.target.value) || 0)}
                      className="h-8 text-xs"
                      disabled={gw.status === 'coming_soon'}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Configure Dialog */}
      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configure {selectedMethod?.name}
            </DialogTitle>
            <DialogDescription>
              Update payment method settings, fee structure, and transaction limits.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label className="text-xs">Payment Method</Label>
              <Input value={configForm.name} disabled className="h-9 text-sm bg-muted" />
            </div>
            <div className="grid gap-2">
              <Label className="text-xs">Type</Label>
              <Input value={configForm.type} disabled className="h-9 text-sm bg-muted" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label className="text-xs">Fee Type</Label>
                <Select
                  value={configForm.feeType}
                  onValueChange={(v) => setConfigForm((f) => ({ ...f, feeType: v }))}
                >
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="flat">Flat Amount (ETB)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">Fee Value</Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  value={configForm.feeValue}
                  onChange={(e) => setConfigForm((f) => ({ ...f, feeValue: e.target.value }))}
                  placeholder={configForm.feeType === 'percentage' ? 'e.g. 1.5' : 'e.g. 15'}
                  className="h-9 text-sm"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label className="text-xs">Min Amount (ETB)</Label>
                <Input
                  type="number"
                  min="0"
                  value={configForm.minAmount}
                  onChange={(e) => setConfigForm((f) => ({ ...f, minAmount: e.target.value }))}
                  className="h-9 text-sm"
                />
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">Max Amount (ETB)</Label>
                <Input
                  type="number"
                  min="0"
                  value={configForm.maxAmount}
                  onChange={(e) => setConfigForm((f) => ({ ...f, maxAmount: e.target.value }))}
                  className="h-9 text-sm"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label className="text-xs">Status</Label>
              <Select
                value={configForm.status}
                onValueChange={(v) => setConfigForm((f) => ({ ...f, status: v }))}
              >
                <SelectTrigger className="h-9 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="coming_soon">Coming Soon</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2 btn-responsive-group">
            <Button
              variant="outline"
              onClick={() => setConfigDialogOpen(false)}
              disabled={savingConfig}
            >
              Cancel
            </Button>
            <Button className="btn-responsive" onClick={handleSaveConfig} disabled={savingConfig}>
              {savingConfig && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Configuration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              Transaction Details
            </DialogTitle>
            <DialogDescription>
              Detailed view of the selected transaction.
            </DialogDescription>
          </DialogHeader>
          {selectedTransaction && (
            <div className="grid gap-3 py-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Reference</p>
                  <p className="text-sm font-mono font-medium">{selectedTransaction.reference}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Status</p>
                  <div>{getTransactionStatusBadge(selectedTransaction.status)}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Type</p>
                  <p className="text-sm font-medium">{selectedTransaction.type}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Payment Method</p>
                  <p className="text-sm font-medium">{selectedTransaction.paymentMethod || '—'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="text-sm font-semibold">
                    {selectedTransaction.currency} {selectedTransaction.amount.toLocaleString()}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Date</p>
                  <p className="text-sm">
                    {selectedTransaction.createdAt
                      ? (
                        <span className="datetime-badge full">{formatDateTime(selectedTransaction.createdAt)}</span>
                      )
                      : '—'}
                  </p>
                </div>
              </div>
              {selectedTransaction.description && (
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Description</p>
                  <p className="text-sm">{selectedTransaction.description}</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom scrollbar styles */}
    </div>
  );
}
