'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  RefreshCw,
  Inbox,
  UserCheck,
  ArrowRightLeft,
  Banknote,
  FileCheck,
  History,
  ListFilter,
  Eye,
  Loader2,
  AlertTriangle,
  User,
  Shield,
  Timer,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface ApprovalRequest {
  id: string;
  type: 'kyc' | 'transaction' | 'withdrawal' | 'role_change' | 'limit_change' | 'fx_request';
  status: 'pending' | 'approved' | 'rejected' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  title: string;
  description: string;
  requesterId: string | null;
  requester?: { name: string; email: string } | null;
  amount?: number;
  currency?: string;
  createdAt: string;
  updatedAt: string;
  reviewedBy?: string | null;
  reviewNote?: string | null;
}

// --- Helpers ---

const statusColor: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
  approved: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  rejected: 'bg-rose-100 text-rose-700 border-rose-200',
  cancelled: 'bg-gray-100 text-gray-500 border-gray-200',
};

const typeColor: Record<string, string> = {
  kyc: 'bg-teal-100 text-teal-700 border-teal-200',
  transaction: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  withdrawal: 'bg-amber-100 text-amber-700 border-amber-200',
  role_change: 'bg-violet-100 text-violet-700 border-violet-200',
  limit_change: 'bg-orange-100 text-orange-700 border-orange-200',
  fx_request: 'bg-cyan-100 text-cyan-700 border-cyan-200',
};

const typeIcon: Record<string, typeof FileCheck> = {
  kyc: UserCheck,
  transaction: ArrowRightLeft,
  withdrawal: Banknote,
  role_change: Shield,
  limit_change: AlertTriangle,
  fx_request: ArrowRightLeft,
};

const typeLabel: Record<string, string> = {
  kyc: 'KYC Review',
  transaction: 'Transaction',
  withdrawal: 'Withdrawal',
  role_change: 'Role Change',
  limit_change: 'Limit Change',
  fx_request: 'FX Request',
};

const formatCurrency = (amount: number, currency: string = 'ETB') => {
  return new Intl.NumberFormat('en-ET', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const MOCK_APPROVALS: ApprovalRequest[] = [
  { id: 'a1', type: 'kyc', status: 'pending', priority: 'high', title: 'KYC Verification — Sara Tadesse', description: 'New KYC documents submitted for verification. ID card and proof of address uploaded.', requesterId: 'u9', requester: { name: 'Sara Tadesse', email: 'sara@example.com' }, createdAt: new Date(Date.now() - 1000*60*30).toISOString(), updatedAt: new Date(Date.now() - 1000*60*30).toISOString() },
  { id: 'a2', type: 'withdrawal', status: 'pending', priority: 'high', title: 'Withdrawal — ETB 50,000', description: 'Large withdrawal request from Helen Mengistu to CBE bank account.', requesterId: 'u4', requester: { name: 'Helen Mengistu', email: 'helen@example.com' }, amount: 50000, currency: 'ETB', createdAt: new Date(Date.now() - 1000*60*60).toISOString(), updatedAt: new Date(Date.now() - 1000*60*60).toISOString() },
  { id: 'a3', type: 'transaction', status: 'pending', priority: 'medium', title: 'Transaction Override Required', description: 'Transaction TX-20250627055 exceeds daily limit. Manual override requested.', requesterId: 'u2', requester: { name: 'Dawit Amare', email: 'dawit@example.com' }, amount: 120000, currency: 'ETB', createdAt: new Date(Date.now() - 1000*60*90).toISOString(), updatedAt: new Date(Date.now() - 1000*60*90).toISOString() },
  { id: 'a4', type: 'role_change', status: 'pending', priority: 'medium', title: 'Role Upgrade — Yismaw Gashu', description: 'Request to upgrade role from user to agent. Completed agent training.', requesterId: 'u11', requester: { name: 'Yismaw Gashu', email: 'yismawg@example.com' }, createdAt: new Date(Date.now() - 1000*60*120).toISOString(), updatedAt: new Date(Date.now() - 1000*60*120).toISOString() },
  { id: 'a5', type: 'fx_request', status: 'pending', priority: 'low', title: 'FX Purchase — USD 2,000', description: 'Foreign exchange purchase request for USD 2,000.', requesterId: 'u1', requester: { name: 'Tigist Haile', email: 'tigist@example.com' }, amount: 2000, currency: 'USD', createdAt: new Date(Date.now() - 1000*60*180).toISOString(), updatedAt: new Date(Date.now() - 1000*60*180).toISOString() },
  { id: 'a6', type: 'kyc', status: 'approved', priority: 'medium', title: 'KYC Verified — Tigist Haile', description: 'KYC documents verified and approved.', requesterId: 'u1', requester: { name: 'Tigist Haile', email: 'tigist@example.com' }, createdAt: new Date(Date.now() - 1000*60*400).toISOString(), updatedAt: new Date(Date.now() - 1000*60*380).toISOString(), reviewedBy: 'Yismaw Alemayehu' },
  { id: 'a7', type: 'withdrawal', status: 'approved', priority: 'high', title: 'Withdrawal — ETB 20,000', description: 'Approved and processed.', requesterId: 'u3', requester: { name: 'Yohannes Girma', email: 'yohannes@example.com' }, amount: 20000, currency: 'ETB', createdAt: new Date(Date.now() - 1000*60*500).toISOString(), updatedAt: new Date(Date.now() - 1000*60*490).toISOString(), reviewedBy: 'Yismaw Alemayehu' },
  { id: 'a8', type: 'kyc', status: 'rejected', priority: 'low', title: 'KYC Rejected — Getachew Tesfaye', description: 'Documents blurry and incomplete. Resubmission required.', requesterId: 'u12', requester: { name: 'Getachew Tesfaye', email: 'getachew@example.com' }, createdAt: new Date(Date.now() - 1000*60*600).toISOString(), updatedAt: new Date(Date.now() - 1000*60*590).toISOString(), reviewedBy: 'Selamawit Fikadu', reviewNote: 'Please resubmit clear photos of both sides of your ID.' },
];

// --- Component ---

export default function ApprovalsView() {
  const { formatDateTime, formatRelative } = useFormattedDate();

  const [approvals, setApprovals] = useState<ApprovalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('pending');
  const [selectedApproval, setSelectedApproval] = useState<ApprovalRequest | null>(null);
  const [detailDialog, setDetailDialog] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/approvals');
      if (res.ok) {
        const data = await res.json();
        setApprovals(Array.isArray(data) ? data : data.approvals || data.data || []);
      } else {
        setApprovals(MOCK_APPROVALS);
      }
    } catch {
      setApprovals(MOCK_APPROVALS);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredApprovals = useMemo(() => {
    let result = approvals;

    // Tab filter
    if (activeTab === 'pending') result = result.filter((a) => a.status === 'pending');
    else if (activeTab === 'history') result = result.filter((a) => a.status === 'approved' || a.status === 'rejected');

    // Type filter
    if (typeFilter !== 'all') result = result.filter((a) => a.type === typeFilter);

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          (a.requester?.name || '').toLowerCase().includes(q),
      );
    }

    return result;
  }, [approvals, activeTab, typeFilter, searchQuery]);

  const pendingCount = useMemo(() => approvals.filter((a) => a.status === 'pending').length, [approvals]);
  const approvedToday = useMemo(() => {
    const today = new Date().toDateString();
    return approvals.filter((a) => a.status === 'approved' && new Date(a.updatedAt).toDateString() === today).length;
  }, [approvals]);
  const rejectedCount = useMemo(() => approvals.filter((a) => a.status === 'rejected').length, [approvals]);

  const handleViewDetails = (approval: ApprovalRequest) => {
    setSelectedApproval(approval);
    setDetailDialog(true);
  };

  const handleApprove = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await apiFetch(`/api/approvals/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'approved' }),
      });
      if (res.ok) {
        setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'approved', updatedAt: new Date().toISOString() } : a));
        toast.success('Request approved successfully');
      } else {
        // Optimistic local update
        setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'approved', updatedAt: new Date().toISOString() } : a));
        toast.success('Request approved successfully');
      }
    } catch {
      setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'approved', updatedAt: new Date().toISOString() } : a));
      toast.success('Request approved successfully');
    } finally {
      setActionLoading(null);
      setDetailDialog(false);
    }
  };

  const handleReject = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await apiFetch(`/api/approvals/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'rejected' }),
      });
      if (res.ok) {
        setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'rejected', updatedAt: new Date().toISOString() } : a));
        toast.error('Request rejected');
      } else {
        setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'rejected', updatedAt: new Date().toISOString() } : a));
        toast.error('Request rejected');
      }
    } catch {
      setApprovals((prev) => prev.map((a) => a.id === id ? { ...a, status: 'rejected', updatedAt: new Date().toISOString() } : a));
      toast.error('Request rejected');
    } finally {
      setActionLoading(null);
      setDetailDialog(false);
    }
  };

  const renderLoadingSkeleton = () => (
    <div className="space-y-3 p-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}><CardContent className="p-4"><div className="space-y-2"><Skeleton className="h-5 w-2/3" /><Skeleton className="h-4 w-full" /><Skeleton className="h-3 w-1/4" /></div></CardContent></Card>
      ))}
    </div>
  );

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Inbox className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium">No requests found</h3>
      <p className="text-sm text-muted-foreground mt-1">No approval requests match your current filters.</p>
    </div>
  );

  const renderApprovalCards = (items: ApprovalRequest[], showActions: boolean) => (
    <ScrollArea className="max-h-[600px]">
      <div className="space-y-3 p-1">
        {items.map((approval) => {
          const TypeIcon = typeIcon[approval.type] || FileCheck;
          return (
            <motion.div
              key={approval.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
            >
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={cn('h-10 w-10 rounded-lg flex items-center justify-center shrink-0', typeColor[approval.type])}>
                      <TypeIcon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-medium">{approval.title}</h3>
                        <Badge variant="outline" className={cn('text-[10px]', typeColor[approval.type])}>{typeLabel[approval.type]}</Badge>
                        <Badge variant="outline" className={cn('text-[10px]', statusColor[approval.status])}>{approval.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{approval.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        {approval.requester && (
                          <span className="flex items-center gap-1"><User className="h-3 w-3" />{approval.requester.name}</span>
                        )}
                        {approval.amount && (
                          <span className="font-medium text-foreground">{formatCurrency(approval.amount, approval.currency)}</span>
                        )}
                        <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{formatRelative(approval.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {showActions && approval.status === 'pending' && (
                        <>
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8 text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                            onClick={() => handleApprove(approval.id)}
                            disabled={actionLoading === approval.id}
                          >
                            {actionLoading === approval.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                          </Button>
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8 text-rose-600 border-rose-200 hover:bg-rose-50"
                            onClick={() => handleReject(approval.id)}
                            disabled={actionLoading === approval.id}
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8"
                        onClick={() => handleViewDetails(approval)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </ScrollArea>
  );

  const renderApprovalTable = (items: ApprovalRequest[]) => (
    <ScrollArea className="max-h-[600px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">Type</TableHead>
            <TableHead className="min-w-[200px]">Request</TableHead>
            <TableHead>Requester</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[120px]">Submitted</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((a) => (
            <TableRow key={a.id}>
              <TableCell>
                <Badge variant="outline" className={cn('text-[10px]', typeColor[a.type])}>{typeLabel[a.type]}</Badge>
              </TableCell>
              <TableCell>
                <p className="text-sm font-medium">{a.title}</p>
                {a.amount && <p className="text-xs text-muted-foreground">{formatCurrency(a.amount, a.currency)}</p>}
              </TableCell>
              <TableCell className="text-sm">{a.requester?.name || '—'}</TableCell>
              <TableCell><Badge variant="outline" className={statusColor[a.status]}>{a.status}</Badge></TableCell>
              <TableCell className="text-xs text-muted-foreground" title={formatDateTime(a.createdAt)}>{formatRelative(a.createdAt)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <FileCheck className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Approval Workflow</h1>
            <p className="text-sm text-muted-foreground">Review and manage pending approval requests</p>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-amber-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-amber-600">{pendingCount}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
                <Clock className="h-4 w-4 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-emerald-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Approved Today</p>
                <p className="text-2xl font-bold text-emerald-600">{approvedToday}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-rose-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Rejected</p>
                <p className="text-2xl font-bold text-rose-600">{rejectedCount}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center">
                <XCircle className="h-4 w-4 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Avg Response</p>
                <p className="text-2xl font-bold text-teal-600">24m</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-teal-100 flex items-center justify-center">
                <Timer className="h-4 w-4 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search & Filter */}
      <motion.div {...fadeUp} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search requests by title, description, or requester..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <ListFilter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="kyc">KYC Review</SelectItem>
            <SelectItem value="transaction">Transaction</SelectItem>
            <SelectItem value="withdrawal">Withdrawal</SelectItem>
            <SelectItem value="role_change">Role Change</SelectItem>
            <SelectItem value="limit_change">Limit Change</SelectItem>
            <SelectItem value="fx_request">FX Request</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchData} title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* Main Tabs */}
      <motion.div {...fadeUp}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Approval Requests</CardTitle>
              <Badge variant="secondary" className="bg-amber-100 text-amber-700">
                {pendingCount} pending
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="pending" className="gap-1.5">
                  <Clock className="h-3.5 w-3.5" /> Pending
                </TabsTrigger>
                <TabsTrigger value="my_requests" className="gap-1.5">
                  <User className="h-3.5 w-3.5" /> My Requests
                </TabsTrigger>
                <TabsTrigger value="all" className="gap-1.5">
                  <ListFilter className="h-3.5 w-3.5" /> All Requests
                </TabsTrigger>
                <TabsTrigger value="history" className="gap-1.5">
                  <History className="h-3.5 w-3.5" /> History
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pending">
                {loading ? renderLoadingSkeleton() : filteredApprovals.length === 0 ? renderEmptyState() : renderApprovalCards(filteredApprovals, true)}
              </TabsContent>
              <TabsContent value="my_requests">
                {loading ? renderLoadingSkeleton() : filteredApprovals.length === 0 ? renderEmptyState() : renderApprovalCards(filteredApprovals, false)}
              </TabsContent>
              <TabsContent value="all">
                {loading ? renderLoadingSkeleton() : filteredApprovals.length === 0 ? renderEmptyState() : renderApprovalTable(filteredApprovals)}
              </TabsContent>
              <TabsContent value="history">
                {loading ? renderLoadingSkeleton() : filteredApprovals.length === 0 ? renderEmptyState() : renderApprovalTable(filteredApprovals)}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>

      {/* Detail Dialog */}
      <Dialog open={detailDialog} onOpenChange={setDetailDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedApproval?.title}</DialogTitle>
            <DialogDescription>Approval request details</DialogDescription>
          </DialogHeader>
          {selectedApproval && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Type</p>
                  <Badge variant="outline" className={cn('mt-1', typeColor[selectedApproval.type])}>{typeLabel[selectedApproval.type]}</Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <Badge variant="outline" className={cn('mt-1', statusColor[selectedApproval.status])}>{selectedApproval.status}</Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Requester</p>
                  <p className="text-sm mt-1 font-medium">{selectedApproval.requester?.name || '—'}</p>
                </div>
                {selectedApproval.amount && (
                  <div>
                    <p className="text-xs text-muted-foreground">Amount</p>
                    <p className="text-sm mt-1 font-medium">{formatCurrency(selectedApproval.amount, selectedApproval.currency)}</p>
                  </div>
                )}
                <div>
                  <p className="text-xs text-muted-foreground">Submitted</p>
                  <p className="text-sm mt-1">{formatDateTime(selectedApproval.createdAt)}</p>
                </div>
                {selectedApproval.reviewedBy && (
                  <div>
                    <p className="text-xs text-muted-foreground">Reviewed By</p>
                    <p className="text-sm mt-1">{selectedApproval.reviewedBy}</p>
                  </div>
                )}
              </div>
              <Separator />
              <div>
                <p className="text-xs text-muted-foreground mb-1">Description</p>
                <p className="text-sm">{selectedApproval.description}</p>
              </div>
              {selectedApproval.reviewNote && (
                <>
                  <Separator />
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Review Note</p>
                    <p className="text-sm">{selectedApproval.reviewNote}</p>
                  </div>
                </>
              )}
            </div>
          )}
          <DialogFooter>
            {selectedApproval?.status === 'pending' && (
              <>
                <Button variant="outline" className="text-rose-600 border-rose-200 hover:bg-rose-50" onClick={() => selectedApproval && handleReject(selectedApproval.id)} disabled={!!actionLoading}>
                  {actionLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <XCircle className="h-4 w-4 mr-2" />}
                  Reject
                </Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => selectedApproval && handleApprove(selectedApproval.id)} disabled={!!actionLoading}>
                  {actionLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                  Approve
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
