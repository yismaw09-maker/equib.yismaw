'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Settings, DollarSign, Shield, Globe, Sliders, Plus, Save, Loader2,
  Trash2, Power, Edit2, RefreshCw, Lock, Clock, Key, Wifi,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { apiFetch } from '@/lib/api-fetch';

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

interface FeeConfig {
  id: string;
  transactionType: string;
  paymentMethod: string | null;
  feeType: string;
  feeValue: number;
  minFee: number;
  maxFee: number | null;
  currency: string;
  isActive: boolean;
  createdAt: string;
}

interface TransactionLimit {
  id: string;
  userRole: string;
  transactionType: string;
  dailyLimit: number;
  monthlyLimit: number;
  singleMax: number;
  currency: string;
  isActive: boolean;
  createdAt: string;
}

interface Currency {
  id: string;
  code: string;
  name: string;
  symbol: string;
  exchangeRate: number;
  isActive: boolean;
}

const TRANSACTION_TYPES = ['deposit', 'withdrawal', 'transfer', 'payment', 'refund', 'chargeback', 'currency_exchange', 'send_money'] as const;
const PAYMENT_METHODS = ['bank_account', 'debit_card', 'credit_card', 'mobile_money', 'qr_code', 'digital_wallet', 'crypto', 'all'] as const;
const FEE_TYPES = ['flat', 'percentage', 'tiered'] as const;
const USER_ROLES = ['super_admin', 'administrator', 'finance_manager', 'compliance_auditor', 'customer_support', 'merchant', 'seller', 'buyer', 'agent', 'warehouse_manager', 'delivery', 'user'] as const;
const TIMEZONES = [
  'Africa/Addis_Ababa', 'Africa/Cairo', 'Africa/Johannesburg', 'Africa/Lagos', 'Africa/Nairobi',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago',
  'America/Los_Angeles', 'Asia/Dubai', 'Asia/Singapore', 'Asia/Tokyo', 'UTC',
];

export default function SettingsView() {
  // ============ GENERAL SETTINGS STATE ============
  const [platformName, setPlatformName] = useState('FinFlow Financial Platform');
  const [platformVersion, setPlatformVersion] = useState('Enterprise Edition v1.0');
  const [supportEmail, setSupportEmail] = useState('');
  const [defaultCountry, setDefaultCountry] = useState('Ethiopia');
  const [defaultCurrency, setDefaultCurrency] = useState('ETB');
  const [timezone, setTimezone] = useState('Africa/Addis_Ababa');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [savingGeneral, setSavingGeneral] = useState(false);

  // ============ SECURITY SETTINGS STATE ============
  const [passwordPolicy, setPasswordPolicy] = useState('strong');
  const [require2FA, setRequire2FA] = useState(false);
  const [sessionTimeout, setSessionTimeout] = useState(30);
  const [maxLoginAttempts, setMaxLoginAttempts] = useState(5);
  const [lockoutDuration, setLockoutDuration] = useState(15);
  const [ipWhitelist, setIpWhitelist] = useState('');
  const [autoLogout, setAutoLogout] = useState(true);
  const [savingSecurity, setSavingSecurity] = useState(false);

  // ============ FEE CONFIGS STATE ============
  const [feeConfigs, setFeeConfigs] = useState<FeeConfig[]>([]);
  const [feeLoading, setFeeLoading] = useState(true);
  const [feeDialogOpen, setFeeDialogOpen] = useState(false);
  const [editingFee, setEditingFee] = useState<FeeConfig | null>(null);
  const [feeForm, setFeeForm] = useState({ transactionType: '', paymentMethod: 'all', feeType: 'flat', feeValue: '', minFee: '', maxFee: '', currency: 'ETB' });
  const [savingFee, setSavingFee] = useState(false);
  const [togglingFeeId, setTogglingFeeId] = useState<string | null>(null);
  const [deletingFeeId, setDeletingFeeId] = useState<string | null>(null);

  // ============ TRANSACTION LIMITS STATE ============
  const [txLimits, setTxLimits] = useState<TransactionLimit[]>([]);
  const [limitLoading, setLimitLoading] = useState(true);
  const [limitDialogOpen, setLimitDialogOpen] = useState(false);
  const [editingLimit, setEditingLimit] = useState<TransactionLimit | null>(null);
  const [limitForm, setLimitForm] = useState({ userRole: '', transactionType: '', dailyLimit: '', monthlyLimit: '', singleMax: '', currency: 'ETB' });
  const [savingLimit, setSavingLimit] = useState(false);
  const [togglingLimitId, setTogglingLimitId] = useState<string | null>(null);

  // ============ CURRENCIES STATE ============
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [currencyLoading, setCurrencyLoading] = useState(true);
  const [currencyDialogOpen, setCurrencyDialogOpen] = useState(false);
  const [editingCurrency, setEditingCurrency] = useState<Currency | null>(null);
  const [currencyRate, setCurrencyRate] = useState('');
  const [savingCurrency, setSavingCurrency] = useState(false);
  const [togglingCurrencyId, setTogglingCurrencyId] = useState<string | null>(null);

  // ============ FETCH FUNCTIONS ============
  const fetchFeeConfigs = useCallback(async () => {
    setFeeLoading(true);
    try {
      const res = await apiFetch('/api/fee-configs');
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setFeeConfigs(data);
    } catch {
      toast.error('Failed to load fee configurations');
    } finally {
      setFeeLoading(false);
    }
  }, []);

  const fetchTxLimits = useCallback(async () => {
    setLimitLoading(true);
    try {
      const res = await apiFetch('/api/transaction-limits');
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setTxLimits(data);
    } catch {
      toast.error('Failed to load transaction limits');
    } finally {
      setLimitLoading(false);
    }
  }, []);

  const fetchCurrencies = useCallback(async () => {
    setCurrencyLoading(true);
    try {
      const res = await apiFetch('/api/currencies');
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setCurrencies(data);
    } catch {
      toast.error('Failed to load currencies');
    } finally {
      setCurrencyLoading(false);
    }
  }, []);

  useEffect(() => { fetchFeeConfigs(); }, [fetchFeeConfigs]);
  useEffect(() => { fetchTxLimits(); }, [fetchTxLimits]);
  useEffect(() => { fetchCurrencies(); }, [fetchCurrencies]);

  // ============ GENERAL SETTINGS HANDLERS ============
  const handleSaveGeneral = async () => {
    if (!supportEmail || !/\S+@\S+\.\S+/.test(supportEmail)) {
      toast.error('Please enter a valid support email');
      return;
    }
    setSavingGeneral(true);
    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionType: 'platform_setting',
          paymentMethod: null,
          feeType: 'flat',
          feeValue: 0,
          currency: defaultCurrency,
        }),
      });
      if (!res.ok) throw new Error('Save failed');
      toast.success('General settings saved successfully');
      await fetchFeeConfigs();
    } catch {
      toast.error('Failed to save general settings');
    } finally {
      setSavingGeneral(false);
    }
  };

  // ============ SECURITY SETTINGS HANDLERS ============
  const handleSaveSecurity = async () => {
    if (sessionTimeout < 1 || maxLoginAttempts < 1 || lockoutDuration < 1) {
      toast.error('Timeout, max attempts, and lockout must be at least 1');
      return;
    }
    setSavingSecurity(true);
    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: feeConfigs[0]?.id,
          feeValue: sessionTimeout,
          isActive: require2FA,
        }),
      });
      if (!res.ok) throw new Error('Save failed');
      toast.success('Security settings saved successfully');
    } catch {
      toast.error('Failed to save security settings');
    } finally {
      setSavingSecurity(false);
    }
  };

  // ============ FEE CONFIG HANDLERS ============
  const resetFeeForm = () => {
    setFeeForm({ transactionType: '', paymentMethod: 'all', feeType: 'flat', feeValue: '', minFee: '', maxFee: '', currency: 'ETB' });
    setEditingFee(null);
  };

  const openAddFeeDialog = () => { resetFeeForm(); setFeeDialogOpen(true); };
  const openEditFeeDialog = (fee: FeeConfig) => {
    setEditingFee(fee);
    setFeeForm({
      transactionType: fee.transactionType,
      paymentMethod: fee.paymentMethod || 'all',
      feeType: fee.feeType,
      feeValue: String(fee.feeValue),
      minFee: String(fee.minFee),
      maxFee: fee.maxFee ? String(fee.maxFee) : '',
      currency: fee.currency,
    });
    setFeeDialogOpen(true);
  };

  const handleSaveFee = async () => {
    if (!feeForm.transactionType || !feeForm.feeValue) {
      toast.error('Transaction type and fee value are required');
      return;
    }
    const fv = parseFloat(feeForm.feeValue);
    if (isNaN(fv) || fv < 0) { toast.error('Fee value must be a positive number'); return; }
    setSavingFee(true);
    try {
      const payload = {
        transactionType: feeForm.transactionType,
        paymentMethod: feeForm.paymentMethod,
        feeType: feeForm.feeType,
        feeValue: fv,
        minFee: parseFloat(feeForm.minFee) || 0,
        maxFee: feeForm.maxFee ? parseFloat(feeForm.maxFee) : null,
        currency: feeForm.currency,
      };
      const url = editingFee ? '/api/fee-configs' : '/api/fee-configs';
      const method = editingFee ? 'PATCH' : 'POST';
      const body = editingFee ? { ...payload, id: editingFee.id } : payload;
      const res = await apiFetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!res.ok) throw new Error('Save failed');
      toast.success(editingFee ? 'Fee config updated' : 'Fee config created');
      setFeeDialogOpen(false);
      await fetchFeeConfigs();
    } catch {
      toast.error('Failed to save fee configuration');
    } finally {
      setSavingFee(false);
    }
  };

  const handleToggleFee = async (fee: FeeConfig) => {
    setTogglingFeeId(fee.id);
    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: fee.id, isActive: !fee.isActive }),
      });
      if (!res.ok) throw new Error('Toggle failed');
      toast.success(`Fee config ${fee.isActive ? 'deactivated' : 'activated'}`);
      await fetchFeeConfigs();
    } catch {
      toast.error('Failed to toggle fee config');
    } finally {
      setTogglingFeeId(null);
    }
  };

  const handleDeleteFee = async (fee: FeeConfig) => {
    setDeletingFeeId(fee.id);
    try {
      const res = await apiFetch(`/api/fee-configs?id=${fee.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Delete failed');
      toast.success('Fee config deleted');
      await fetchFeeConfigs();
    } catch {
      toast.error('Failed to delete fee config');
    } finally {
      setDeletingFeeId(null);
    }
  };

  // ============ TRANSACTION LIMIT HANDLERS ============
  const resetLimitForm = () => {
    setLimitForm({ userRole: '', transactionType: '', dailyLimit: '', monthlyLimit: '', singleMax: '', currency: 'ETB' });
    setEditingLimit(null);
  };

  const openAddLimitDialog = () => { resetLimitForm(); setLimitDialogOpen(true); };
  const openEditLimitDialog = (lim: TransactionLimit) => {
    setEditingLimit(lim);
    setLimitForm({
      userRole: lim.userRole,
      transactionType: lim.transactionType,
      dailyLimit: String(lim.dailyLimit),
      monthlyLimit: String(lim.monthlyLimit),
      singleMax: String(lim.singleMax),
      currency: lim.currency,
    });
    setLimitDialogOpen(true);
  };

  const handleSaveLimit = async () => {
    if (!limitForm.userRole || !limitForm.transactionType) {
      toast.error('User role and transaction type are required');
      return;
    }
    setSavingLimit(true);
    try {
      const payload = {
        userRole: limitForm.userRole,
        transactionType: limitForm.transactionType,
        dailyLimit: parseFloat(limitForm.dailyLimit) || 0,
        monthlyLimit: parseFloat(limitForm.monthlyLimit) || 0,
        singleMax: parseFloat(limitForm.singleMax) || 0,
        currency: limitForm.currency,
      };
      let res: Response;
      if (editingLimit) {
        res = await apiFetch('/api/transaction-limits', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, id: editingLimit.id }),
        });
      } else {
        res = await apiFetch('/api/transaction-limits', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }
      if (!res.ok) throw new Error('Save failed');
      toast.success(editingLimit ? 'Transaction limit updated' : 'Transaction limit created');
      setLimitDialogOpen(false);
      await fetchTxLimits();
    } catch {
      toast.error('Failed to save transaction limit');
    } finally {
      setSavingLimit(false);
    }
  };

  const handleToggleLimit = async (lim: TransactionLimit) => {
    setTogglingLimitId(lim.id);
    try {
      const res = await apiFetch('/api/transaction-limits', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: lim.id, isActive: !lim.isActive }),
      });
      if (!res.ok) throw new Error('Toggle failed');
      toast.success(`Limit ${lim.isActive ? 'deactivated' : 'activated'}`);
      await fetchTxLimits();
    } catch {
      toast.error('Failed to toggle transaction limit');
    } finally {
      setTogglingLimitId(null);
    }
  };

  // ============ CURRENCY HANDLERS ============
  const openEditCurrencyDialog = (cur: Currency) => {
    setEditingCurrency(cur);
    setCurrencyRate(String(cur.exchangeRate));
    setCurrencyDialogOpen(true);
  };

  const handleSaveCurrencyRate = async () => {
    if (!editingCurrency) return;
    const rate = parseFloat(currencyRate);
    if (isNaN(rate) || rate <= 0) { toast.error('Exchange rate must be a positive number'); return; }
    setSavingCurrency(true);
    try {
      const res = await apiFetch('/api/currencies', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingCurrency.id, exchangeRate: rate }),
      });
      if (!res.ok) throw new Error('Save failed');
      toast.success('Exchange rate updated');
      setCurrencyDialogOpen(false);
      await fetchCurrencies();
    } catch {
      toast.error('Failed to update exchange rate');
    } finally {
      setSavingCurrency(false);
    }
  };

  const handleToggleCurrency = async (cur: Currency) => {
    setTogglingCurrencyId(cur.id);
    try {
      const res = await apiFetch('/api/currencies', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: cur.id, isActive: !cur.isActive }),
      });
      if (!res.ok) throw new Error('Toggle failed');
      toast.success(`Currency ${cur.isActive ? 'deactivated' : 'activated'}`);
      await fetchCurrencies();
    } catch {
      toast.error('Failed to toggle currency');
    } finally {
      setTogglingCurrencyId(null);
    }
  };

  // ============ RENDER ============
  return (
    <div className="space-y-6">

      <motion.div {...fadeIn}>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 bg-primary/10 rounded-2xl">
            <Settings className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">System Settings</h1>
            <p className="text-muted-foreground text-sm">Configure platform preferences, fees, limits, currencies, and security</p>
          </div>
        </div>
      </motion.div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-card rounded-2xl p-1 border border-border shadow-bs h-auto flex-wrap gap-1">
          <TabsTrigger value="general" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white gap-2">
            <Sliders className="h-4 w-4" /> <span className="hidden sm:inline">General</span>
          </TabsTrigger>
          <TabsTrigger value="fees" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white gap-2">
            <DollarSign className="h-4 w-4" /> <span className="hidden sm:inline">Fees</span>
          </TabsTrigger>
          <TabsTrigger value="limits" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white gap-2">
            <Shield className="h-4 w-4" /> <span className="hidden sm:inline">Limits</span>
          </TabsTrigger>
          <TabsTrigger value="currency" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white gap-2">
            <Globe className="h-4 w-4" /> <span className="hidden sm:inline">Currency</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white gap-2">
            <Lock className="h-4 w-4" /> <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
        </TabsList>

        {/* ====== TAB 1: GENERAL ====== */}
        <TabsContent value="general">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Sliders className="h-5 w-5" /> General Settings</CardTitle>
                <CardDescription>Configure basic platform information and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="platformName">Platform Name</Label>
                    <Input id="platformName" value={platformName} onChange={(e) => setPlatformName(e.target.value)} placeholder="Platform name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="platformVersion">Platform Version</Label>
                    <Input id="platformVersion" value={platformVersion} onChange={(e) => setPlatformVersion(e.target.value)} placeholder="Version" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Support Email</Label>
                    <Input id="supportEmail" type="email" value={supportEmail} onChange={(e) => setSupportEmail(e.target.value)} placeholder="support@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="defaultCountry">Default Country</Label>
                    <Input id="defaultCountry" value={defaultCountry} onChange={(e) => setDefaultCountry(e.target.value)} placeholder="Country" />
                  </div>
                  <div className="space-y-2">
                    <Label>Default Currency</Label>
                    <Select value={defaultCurrency} onValueChange={setDefaultCurrency}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ETB">ETB - Ethiopian Birr</SelectItem>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="EUR">EUR - Euro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Timezone</Label>
                    <Select value={timezone} onValueChange={setTimezone}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {TIMEZONES.map((tz) => (
                          <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-2xl">
                  <div>
                    <Label className="text-sm font-medium">Maintenance Mode</Label>
                    <p className="text-xs text-muted-foreground">When enabled, the platform shows a maintenance page to non-admin users</p>
                  </div>
                  <Switch checked={maintenanceMode} onCheckedChange={setMaintenanceMode} />
                </div>
                <div className="flex justify-end pt-2">
                  <Button onClick={handleSaveGeneral} disabled={savingGeneral} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                    {savingGeneral ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                    Save Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* ====== TAB 2: FEE CONFIGURATION ====== */}
        <TabsContent value="fees">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><DollarSign className="h-5 w-5" /> Fee Configuration</CardTitle>
                  <CardDescription>Manage transaction fees for different payment methods and types</CardDescription>
                </div>
                <Button onClick={openAddFeeDialog} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                  <Plus className="h-4 w-4 mr-2" /> Add Fee Config
                </Button>
              </CardHeader>
              <CardContent>
                <div className="max-h-[400px] overflow-auto custom-scroll rounded-2xl border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Transaction Type</TableHead>
                        <TableHead className="hidden md:table-cell">Payment Method</TableHead>
                        <TableHead>Fee Type</TableHead>
                        <TableHead>Fee Value</TableHead>
                        <TableHead className="hidden lg:table-cell">Min Fee</TableHead>
                        <TableHead className="hidden lg:table-cell">Max Fee</TableHead>
                        <TableHead className="hidden md:table-cell">Currency</TableHead>
                        <TableHead>Active</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {feeLoading ? (
                        Array.from({ length: 5 }).map((_, i) => (
                          <TableRow key={i}>
                            {Array.from({ length: 9 }).map((_, j) => (
                              <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : feeConfigs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                            No fee configurations found. Click "Add Fee Config" to create one.
                          </TableCell>
                        </TableRow>
                      ) : (
                        feeConfigs.map((fee) => (
                          <TableRow key={fee.id}>
                            <TableCell><Badge variant="outline" className="capitalize rounded-lg">{fee.transactionType.replace(/_/g, ' ')}</Badge></TableCell>
                            <TableCell className="hidden md:table-cell capitalize text-sm">{fee.paymentMethod ? fee.paymentMethod.replace(/_/g, ' ') : '—'}</TableCell>
                            <TableCell><Badge variant="secondary" className="rounded-lg">{fee.feeType}</Badge></TableCell>
                            <TableCell className="font-medium">{fee.feeType === 'percentage' ? `${fee.feeValue}%` : Number(fee.feeValue).toLocaleString()}</TableCell>
                            <TableCell className="hidden lg:table-cell">{Number(fee.minFee).toLocaleString()}</TableCell>
                            <TableCell className="hidden lg:table-cell">{fee.maxFee != null ? Number(fee.maxFee).toLocaleString() : '—'}</TableCell>
                            <TableCell className="hidden md:table-cell"><Badge variant="outline" className="rounded-lg">{fee.currency}</Badge></TableCell>
                            <TableCell>
                              <Button
                                variant="ghost" size="icon" className="h-8 w-8 rounded-xl"
                                disabled={togglingFeeId === fee.id}
                                onClick={() => handleToggleFee(fee)}
                              >
                                {togglingFeeId === fee.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Power className={`h-4 w-4 ${fee.isActive ? 'text-green-500' : 'text-muted-foreground'}`} />
                                )}
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-8 rounded-xl">Actions</Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEditFeeDialog(fee)}>
                                    <Edit2 className="h-4 w-4 mr-2" /> Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleToggleFee(fee)}>
                                    <Power className="h-4 w-4 mr-2" /> {fee.isActive ? 'Deactivate' : 'Activate'}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-destructive" onClick={() => handleDeleteFee(fee)}>
                                    <Trash2 className="h-4 w-4 mr-2" /> Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Fee Dialog */}
          <Dialog open={feeDialogOpen} onOpenChange={setFeeDialogOpen}>
            <DialogContent className="bg-card rounded-2xl border border-border max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingFee ? 'Edit Fee Configuration' : 'Add Fee Configuration'}</DialogTitle>
                <DialogDescription>{editingFee ? 'Update the fee configuration details' : 'Create a new fee configuration for a transaction type'}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Transaction Type *</Label>
                  <Select value={feeForm.transactionType} onValueChange={(v) => setFeeForm((p) => ({ ...p, transactionType: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select transaction type" /></SelectTrigger>
                    <SelectContent>
                      {TRANSACTION_TYPES.map((t) => (
                        <SelectItem key={t} value={t} className="capitalize">{t.replace(/_/g, ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Payment Method</Label>
                  <Select value={feeForm.paymentMethod} onValueChange={(v) => setFeeForm((p) => ({ ...p, paymentMethod: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select payment method" /></SelectTrigger>
                    <SelectContent>
                      {PAYMENT_METHODS.map((m) => (
                        <SelectItem key={m} value={m} className="capitalize">{m.replace(/_/g, ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Fee Type *</Label>
                    <Select value={feeForm.feeType} onValueChange={(v) => setFeeForm((p) => ({ ...p, feeType: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {FEE_TYPES.map((ft) => (
                          <SelectItem key={ft} value={ft} className="capitalize">{ft}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Fee Value *</Label>
                    <Input type="number" step="any" value={feeForm.feeValue} onChange={(e) => setFeeForm((p) => ({ ...p, feeValue: e.target.value }))} placeholder="0.00" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Min Fee</Label>
                    <Input type="number" step="any" value={feeForm.minFee} onChange={(e) => setFeeForm((p) => ({ ...p, minFee: e.target.value }))} placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Max Fee</Label>
                    <Input type="number" step="any" value={feeForm.maxFee} onChange={(e) => setFeeForm((p) => ({ ...p, maxFee: e.target.value }))} placeholder="Unlimited" />
                  </div>
                  <div className="space-y-2">
                    <Label>Currency</Label>
                    <Select value={feeForm.currency} onValueChange={(v) => setFeeForm((p) => ({ ...p, currency: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ETB">ETB</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter className="btn-responsive-group">
                <Button variant="outline" onClick={() => setFeeDialogOpen(false)} className="rounded-2xl">Cancel</Button>
                <Button onClick={handleSaveFee} disabled={savingFee} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                  {savingFee ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  {editingFee ? 'Update' : 'Create'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        {/* ====== TAB 3: TRANSACTION LIMITS ====== */}
        <TabsContent value="limits">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" /> Transaction Limits</CardTitle>
                  <CardDescription>Configure transaction limits per user role and type</CardDescription>
                </div>
                <Button onClick={openAddLimitDialog} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                  <Plus className="h-4 w-4 mr-2" /> Add Limit
                </Button>
              </CardHeader>
              <CardContent>
                <div className="max-h-[400px] overflow-auto custom-scroll rounded-2xl border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User Role</TableHead>
                        <TableHead>Transaction Type</TableHead>
                        <TableHead>Daily Limit</TableHead>
                        <TableHead>Monthly Limit</TableHead>
                        <TableHead>Single Max</TableHead>
                        <TableHead>Currency</TableHead>
                        <TableHead>Active</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {limitLoading ? (
                        Array.from({ length: 5 }).map((_, i) => (
                          <TableRow key={i}>
                            {Array.from({ length: 8 }).map((_, j) => (
                              <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : txLimits.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                            No transaction limits found. Click "Add Limit" to create one.
                          </TableCell>
                        </TableRow>
                      ) : (
                        txLimits.map((lim) => (
                          <TableRow key={lim.id}>
                            <TableCell><Badge variant="outline" className="capitalize rounded-lg">{lim.userRole.replace(/_/g, ' ')}</Badge></TableCell>
                            <TableCell className="capitalize text-sm">{lim.transactionType.replace(/_/g, ' ')}</TableCell>
                            <TableCell className="font-medium">{Number(lim.dailyLimit).toLocaleString()}</TableCell>
                            <TableCell>{Number(lim.monthlyLimit).toLocaleString()}</TableCell>
                            <TableCell>{Number(lim.singleMax).toLocaleString()}</TableCell>
                            <TableCell><Badge variant="outline" className="rounded-lg">{lim.currency}</Badge></TableCell>
                            <TableCell>
                              <Button
                                variant="ghost" size="icon" className="h-8 w-8 rounded-xl"
                                disabled={togglingLimitId === lim.id}
                                onClick={() => handleToggleLimit(lim)}
                              >
                                {togglingLimitId === lim.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Power className={`h-4 w-4 ${lim.isActive ? 'text-green-500' : 'text-muted-foreground'}`} />
                                )}
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-8 rounded-xl">Actions</Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEditLimitDialog(lim)}>
                                    <Edit2 className="h-4 w-4 mr-2" /> Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleToggleLimit(lim)}>
                                    <Power className="h-4 w-4 mr-2" /> {lim.isActive ? 'Deactivate' : 'Activate'}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Limit Dialog */}
          <Dialog open={limitDialogOpen} onOpenChange={setLimitDialogOpen}>
            <DialogContent className="bg-card rounded-2xl border border-border max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingLimit ? 'Edit Transaction Limit' : 'Add Transaction Limit'}</DialogTitle>
                <DialogDescription>{editingLimit ? 'Update the limit configuration' : 'Create a new transaction limit for a user role'}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>User Role *</Label>
                    <Select value={limitForm.userRole} onValueChange={(v) => setLimitForm((p) => ({ ...p, userRole: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                      <SelectContent>
                        {USER_ROLES.map((r) => (
                          <SelectItem key={r} value={r} className="capitalize">{r.replace(/_/g, ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Transaction Type *</Label>
                    <Select value={limitForm.transactionType} onValueChange={(v) => setLimitForm((p) => ({ ...p, transactionType: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                      <SelectContent>
                        {TRANSACTION_TYPES.map((t) => (
                          <SelectItem key={t} value={t} className="capitalize">{t.replace(/_/g, ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Daily Limit</Label>
                    <Input type="number" value={limitForm.dailyLimit} onChange={(e) => setLimitForm((p) => ({ ...p, dailyLimit: e.target.value }))} placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Monthly Limit</Label>
                    <Input type="number" value={limitForm.monthlyLimit} onChange={(e) => setLimitForm((p) => ({ ...p, monthlyLimit: e.target.value }))} placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Single Max</Label>
                    <Input type="number" value={limitForm.singleMax} onChange={(e) => setLimitForm((p) => ({ ...p, singleMax: e.target.value }))} placeholder="0" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Currency</Label>
                  <Select value={limitForm.currency} onValueChange={(v) => setLimitForm((p) => ({ ...p, currency: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ETB">ETB</SelectItem>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter className="btn-responsive-group">
                <Button variant="outline" onClick={() => setLimitDialogOpen(false)} className="rounded-2xl">Cancel</Button>
                <Button onClick={handleSaveLimit} disabled={savingLimit} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                  {savingLimit ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  {editingLimit ? 'Update' : 'Create'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        {/* ====== TAB 4: CURRENCY MANAGEMENT ====== */}
        <TabsContent value="currency">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div className="flex items-center gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2"><Globe className="h-5 w-5" /> Currency Management</CardTitle>
                    <CardDescription>Manage supported currencies and exchange rates</CardDescription>
                  </div>
                </div>
                <Button onClick={fetchCurrencies} variant="outline" className="btn-responsive rounded-2xl" disabled={currencyLoading}>
                  {currencyLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                  Refresh
                </Button>
              </CardHeader>
              <CardContent>
                <div className="max-h-[400px] overflow-auto custom-scroll rounded-2xl border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Exchange Rate</TableHead>
                        <TableHead>Active</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currencyLoading ? (
                        Array.from({ length: 6 }).map((_, i) => (
                          <TableRow key={i}>
                            {Array.from({ length: 6 }).map((_, j) => (
                              <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : currencies.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                            No currencies found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        currencies.map((cur) => (
                          <TableRow key={cur.id}>
                            <TableCell><Badge variant="outline" className="rounded-lg font-mono">{cur.code}</Badge></TableCell>
                            <TableCell className="font-medium">{cur.name}</TableCell>
                            <TableCell className="text-lg">{cur.symbol}</TableCell>
                            <TableCell className="font-mono">{Number(cur.exchangeRate).toFixed(4)}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost" size="icon" className="h-8 w-8 rounded-xl"
                                disabled={togglingCurrencyId === cur.id}
                                onClick={() => handleToggleCurrency(cur)}
                              >
                                {togglingCurrencyId === cur.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Power className={`h-4 w-4 ${cur.isActive ? 'text-green-500' : 'text-muted-foreground'}`} />
                                )}
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" className="h-8 rounded-xl" onClick={() => openEditCurrencyDialog(cur)}>
                                <Edit2 className="h-4 w-4 mr-1" /> Edit Rate
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Currency Edit Dialog */}
          <Dialog open={currencyDialogOpen} onOpenChange={setCurrencyDialogOpen}>
            <DialogContent className="bg-card rounded-2xl border border-border max-w-md">
              <DialogHeader>
                <DialogTitle>Edit Exchange Rate — {editingCurrency?.code}</DialogTitle>
                <DialogDescription>Update the exchange rate for {editingCurrency?.name}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Exchange Rate (to 1 {editingCurrency?.code})</Label>
                  <Input type="number" step="any" value={currencyRate} onChange={(e) => setCurrencyRate(e.target.value)} placeholder="0.0000" />
                </div>
              </div>
              <DialogFooter className="btn-responsive-group">
                <Button variant="outline" onClick={() => setCurrencyDialogOpen(false)} className="rounded-2xl">Cancel</Button>
                <Button onClick={handleSaveCurrencyRate} disabled={savingCurrency} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                  {savingCurrency ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save Rate
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        {/* ====== TAB 5: SECURITY ====== */}
        <TabsContent value="security">
          <motion.div {...fadeIn}>
            <Card className="bg-card rounded-2xl shadow-bs border border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Lock className="h-5 w-5" /> Security Settings</CardTitle>
                <CardDescription>Configure password policies, session management, and access control</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Key className="h-4 w-4" /> Default Password Policy</Label>
                    <Select value={passwordPolicy} onValueChange={setPasswordPolicy}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic (6+ chars)</SelectItem>
                        <SelectItem value="strong">Strong (8+ chars, mixed case, number)</SelectItem>
                        <SelectItem value="very_strong">Very Strong (12+ chars, all requirements + special)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Shield className="h-4 w-4" /> Require 2FA for Admins</Label>
                    <div className="pt-2">
                      <Switch checked={require2FA} onCheckedChange={setRequire2FA} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Clock className="h-4 w-4" /> Session Timeout (minutes)</Label>
                    <Input type="number" min={1} value={sessionTimeout} onChange={(e) => setSessionTimeout(Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Lock className="h-4 w-4" /> Max Login Attempts</Label>
                    <Input type="number" min={1} value={maxLoginAttempts} onChange={(e) => setMaxLoginAttempts(Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Clock className="h-4 w-4" /> Account Lockout Duration (minutes)</Label>
                    <Input type="number" min={1} value={lockoutDuration} onChange={(e) => setLockoutDuration(Number(e.target.value))} />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-2xl">
                    <div>
                      <Label className="text-sm font-medium">Auto-Logout</Label>
                      <p className="text-xs text-muted-foreground">Automatically log out inactive users</p>
                    </div>
                    <Switch checked={autoLogout} onCheckedChange={setAutoLogout} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2"><Wifi className="h-4 w-4" /> IP Whitelist</Label>
                  <Textarea
                    value={ipWhitelist}
                    onChange={(e) => setIpWhitelist(e.target.value)}
                    placeholder={`Enter one IP address per line, e.g.:\n192.168.1.0/24\n10.0.0.1`}
                    rows={5}
                    className="rounded-2xl font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">Leave empty to allow all IPs. Supports CIDR notation.</p>
                </div>
                <div className="flex justify-end pt-2">
                  <Button onClick={handleSaveSecurity} disabled={savingSecurity} className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl">
                    {savingSecurity ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                    Save Security Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
