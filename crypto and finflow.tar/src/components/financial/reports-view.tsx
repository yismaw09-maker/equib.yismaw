'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  format,
  startOfWeek,
  startOfMonth,
  startOfQuarter,
  startOfYear,
  subDays,
  endOfDay,
  startOfDay,
} from 'date-fns';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Calendar,
  CalendarRange,
  CalendarDays,
  BarChart3,
  TrendingUp,
  ArrowLeftRight,
  ArrowDownCircle,
  ArrowUpCircle,
  Wallet,
  DollarSign,
  Percent,
  Receipt,
  FileText,
  FileSpreadsheet,
  FileDown,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface ReportData {
  type: string;
  period?: { start: string; end: string };
  data?: Record<string, unknown>[];
  summary?: Record<string, unknown>;
}

// --- Report type definitions ---

const REPORT_TYPES = [
  { value: 'daily', label: 'Daily Report', icon: CalendarDays, description: 'Transaction summary by day', chartType: 'bar' as const },
  { value: 'weekly', label: 'Weekly Report', icon: Calendar, description: 'Transaction summary by week', chartType: 'bar' as const },
  { value: 'monthly', label: 'Monthly Report', icon: CalendarRange, description: 'Transaction summary by month', chartType: 'bar' as const },
  { value: 'quarterly', label: 'Quarterly Report', icon: CalendarRange, description: 'Transaction summary by quarter', chartType: 'bar' as const },
  { value: 'annual', label: 'Annual Report', icon: CalendarRange, description: 'Transaction summary by year', chartType: 'bar' as const },
  { value: 'transaction', label: 'Transaction Detail', icon: ArrowLeftRight, description: 'All transactions detail', chartType: 'bar' as const },
  { value: 'deposit', label: 'Deposit Report', icon: ArrowDownCircle, description: 'Deposit transactions analysis', chartType: 'bar' as const },
  { value: 'withdrawal', label: 'Withdrawal Report', icon: ArrowUpCircle, description: 'Withdrawal transactions analysis', chartType: 'bar' as const },
  { value: 'wallet', label: 'Wallet Report', icon: Wallet, description: 'Wallet balances and activity', chartType: 'bar' as const },
  { value: 'revenue', label: 'Revenue Report', icon: TrendingUp, description: 'Fee revenue analysis', chartType: 'line' as const },
  { value: 'commission', label: 'Commission Report', icon: DollarSign, description: 'Commission distribution', chartType: 'bar' as const },
  { value: 'tax', label: 'Tax Report', icon: Receipt, description: 'Estimated tax liabilities', chartType: 'line' as const },
];

const PRESETS = [
  { label: 'Today', getRange: () => { const n = new Date(); return [startOfDay(n), endOfDay(n)] as const; } },
  { label: 'This Week', getRange: () => { const n = new Date(); return [startOfWeek(n, { weekStartsOn: 1 }), endOfDay(n)] as const; } },
  { label: 'This Month', getRange: () => { const n = new Date(); return [startOfMonth(n), endOfDay(n)] as const; } },
  { label: 'This Quarter', getRange: () => { const n = new Date(); return [startOfQuarter(n), endOfDay(n)] as const; } },
  { label: 'This Year', getRange: () => { const n = new Date(); return [startOfYear(n), endOfDay(n)] as const; } },
  { label: 'Last 30 Days', getRange: () => { const n = new Date(); return [startOfDay(subDays(n, 30)), endOfDay(n)] as const; } },
];

// --- Helpers ---

function fmtCurrency(n: number) {
  return `ETB ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtNumber(n: number) {
  return n.toLocaleString();
}

// --- Main Component ---

export default function ReportsView() {
  const { formatDateTime } = useFormattedDate();
  const [selectedType, setSelectedType] = useState('monthly');
  const [startDate, setStartDate] = useState(() => format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(() => format(endOfDay(new Date()), 'yyyy-MM-dd'));
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [summaryCards, setSummaryCards] = useState<{ label: string; value: string; color: string }[]>([]);
  const [chartData, setChartData] = useState<Record<string, unknown>[]>([]);
  const [chartType, setChartType] = useState<'bar' | 'line'>('bar');
  const [tableRows, setTableRows] = useState<Record<string, unknown>[]>([]);
  const [tableHeaders, setTableHeaders] = useState<string[]>([]);

  const fetchReport = useCallback(async (type: string, start: string, end: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ type, startDate: start, endDate: end });
      const res = await apiFetch(`/api/reports?${params.toString()}`);
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || 'Failed to generate report');
        setReportData(null);
        setSummaryCards([]);
        setChartData([]);
        setTableRows([]);
        setTableHeaders([]);
        return;
      }
      setReportData(json);
      processReportData(type, json);
    } catch {
      toast.error('Failed to generate report');
      setReportData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const processReportData = (type: string, data: ReportData) => {
    const summary = data.summary ?? {};
    const reportArr = data.data ?? [];

    // Summary cards
    const cards: { label: string; value: string; color: string }[] = [];

    switch (type) {
      case 'daily': {
        cards.push({ label: 'Total Transactions', value: fmtNumber((summary.totalTransactions as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency((summary.totalVolume as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-amber-600' });
        cards.push({ label: 'Completed / Failed', value: `${(summary.completed as number) ?? 0} / ${(summary.failed as number) ?? 0}`, color: 'text-rose-600' });
        break;
      }
      case 'weekly': {
        cards.push({ label: 'Total Transactions', value: fmtNumber((summary.totalTransactions as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency((summary.totalVolume as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-amber-600' });
        cards.push({ label: 'Avg Daily Volume', value: fmtCurrency((summary.avgDailyVolume as number) ?? 0), color: 'text-teal-600' });
        break;
      }
      case 'monthly': {
        const totalVol = reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.volume as number) ?? 0), 0);
        const totalFees = reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.fees as number) ?? 0), 0);
        const totalCount = reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.count as number) ?? 0), 0);
        cards.push({ label: 'Total Transactions', value: fmtNumber(totalCount), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency(totalVol), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency(totalFees), color: 'text-amber-600' });
        cards.push({ label: 'Months', value: fmtNumber(reportArr.length), color: 'text-teal-600' });
        break;
      }
      case 'quarterly': {
        const totalVol = reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.volume as number) ?? 0), 0);
        cards.push({ label: 'Total Transactions', value: fmtNumber(reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.count as number) ?? 0), 0)), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency(totalVol), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency(reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.fees as number) ?? 0), 0)), color: 'text-amber-600' });
        break;
      }
      case 'annual': {
        cards.push({ label: 'Total Transactions', value: fmtNumber(reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.count as number) ?? 0), 0)), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency(reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.volume as number) ?? 0), 0)), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency(reportArr.reduce((s: number, r: Record<string, unknown>) => s + ((r.fees as number) ?? 0), 0)), color: 'text-amber-600' });
        break;
      }
      case 'transaction': {
        cards.push({ label: 'Total Transactions', value: fmtNumber((summary.total as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Volume', value: fmtCurrency((summary.totalVolume as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Total Fees', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-amber-600' });
        cards.push({ label: 'Avg Amount', value: fmtCurrency((summary.avgAmount as number) ?? 0), color: 'text-teal-600' });
        break;
      }
      case 'deposit': case 'withdrawal': {
        cards.push({ label: 'Total', value: fmtNumber((summary.total as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Amount', value: fmtCurrency((summary.totalAmount as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Fees Collected', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-amber-600' });
        cards.push({ label: 'Completed', value: `${(summary.completed as number) ?? 0} / Pending: ${(summary.pending as number) ?? 0}`, color: 'text-teal-600' });
        break;
      }
      case 'wallet': {
        cards.push({ label: 'Total Wallets', value: fmtNumber((summary.totalWallets as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Balance', value: fmtCurrency((summary.totalBalance as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Total Available', value: fmtCurrency((summary.totalAvailable as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Frozen', value: fmtCurrency((summary.totalFrozen as number) ?? 0), color: 'text-rose-600' });
        break;
      }
      case 'revenue': {
        cards.push({ label: 'Total Fees', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Transactions', value: fmtNumber((summary.totalTransactions as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Avg Fee/Tx', value: fmtCurrency((summary.avgFeePerTx as number) ?? 0), color: 'text-amber-600' });
        break;
      }
      case 'commission': {
        cards.push({ label: 'Total Commissions', value: fmtNumber((summary.total as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Total Amount', value: fmtCurrency((summary.totalAmount as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Paid', value: fmtCurrency((summary.paid as number) ?? 0), color: 'text-teal-600' });
        cards.push({ label: 'Pending', value: fmtCurrency((summary.pending as number) ?? 0), color: 'text-amber-600' });
        break;
      }
      case 'tax': {
        cards.push({ label: 'Total Fees', value: fmtCurrency((summary.totalFees as number) ?? 0), color: 'text-emerald-600' });
        cards.push({ label: 'Tax Rate', value: `${((summary.taxRate as number) ?? 0) * 100}%`, color: 'text-amber-600' });
        cards.push({ label: 'Estimated Tax', value: fmtCurrency((summary.estimatedTax as number) ?? 0), color: 'text-rose-600' });
        cards.push({ label: 'Taxable Txns', value: fmtNumber((summary.taxableTransactions as number) ?? 0), color: 'text-teal-600' });
        break;
      }
    }
    setSummaryCards(cards);

    // Chart data
    const reportDef = REPORT_TYPES.find(r => r.value === type);
    setChartType(reportDef?.chartType ?? 'bar');

    let cData: Record<string, unknown>[] = [];

    switch (type) {
      case 'daily':
        cData = reportArr.map((r: Record<string, unknown>) => ({
          name: (r.date as string) ?? '',
          Volume: (r.volume as number) ?? 0,
          Fees: (r.fees as number) ?? 0,
          Count: (r.count as number) ?? 0,
        }));
        break;
      case 'weekly':
        cData = reportArr.map((r: Record<string, unknown>) => ({
          name: (r.weekStart as string) ?? '',
          Volume: (r.volume as number) ?? 0,
          Fees: (r.fees as number) ?? 0,
          Count: (r.count as number) ?? 0,
        }));
        break;
      case 'monthly':
        cData = reportArr.map((r: Record<string, unknown>) => ({
          name: (r.month as string) ?? '',
          Volume: (r.volume as number) ?? 0,
          Fees: (r.fees as number) ?? 0,
          Count: (r.count as number) ?? 0,
        }));
        break;
      case 'quarterly':
        cData = reportArr.map((r: Record<string, unknown>) => ({
          name: (r.quarter as string) ?? '',
          Volume: (r.volume as number) ?? 0,
          Fees: (r.fees as number) ?? 0,
          Count: (r.count as number) ?? 0,
        }));
        break;
      case 'annual':
        cData = reportArr.map((r: Record<string, unknown>) => ({
          name: String((r.year as number) ?? ''),
          Volume: (r.volume as number) ?? 0,
          Fees: (r.fees as number) ?? 0,
          Count: (r.count as number) ?? 0,
        }));
        break;
      case 'transaction': {
        const byType = summary.byStatus as Record<string, number> ?? {};
        cData = Object.entries(byType).map(([k, v]) => ({ name: k.charAt(0).toUpperCase() + k.slice(1), Count: v }));
        break;
      }
      case 'deposit': case 'withdrawal': {
        // Use summary data since data is transaction list
        const byStatus = {
          completed: (summary.completed as number) ?? 0,
          pending: (summary.pending as number) ?? 0,
          failed: (summary.failed as number) ?? 0,
        };
        cData = Object.entries(byStatus).map(([k, v]) => ({ name: k.charAt(0).toUpperCase() + k.slice(1), Count: v }));
        break;
      }
      case 'wallet': {
        const byCurrency = summary.byCurrency as Record<string, { count: number; balance: number }> ?? {};
        cData = Object.entries(byCurrency).map(([k, v]) => ({ name: k, Count: v.count, Balance: v.balance }));
        break;
      }
      case 'revenue': {
        const byType = summary.byType as Record<string, number> ?? {};
        cData = Object.entries(byType).map(([k, v]) => ({ name: k.charAt(0).toUpperCase() + k.slice(1), Fees: v }));
        // If monthly data available, use that for line chart
        const monthly = summary.monthly as Record<string, number> ?? {};
        if (Object.keys(monthly).length > 0) {
          cData = Object.entries(monthly).map(([k, v]) => ({ name: k, Fees: v }));
        }
        break;
      }
      case 'commission': {
        const byType = summary.byType as Record<string, { count: number; amount: number }> ?? {};
        cData = Object.entries(byType).map(([k, v]) => ({ name: k.charAt(0).toUpperCase() + k.slice(1), Amount: v.amount, Count: v.count }));
        break;
      }
      case 'tax': {
        const byMonth = summary.byMonth as Record<string, number> ?? {};
        cData = Object.entries(byMonth).map(([k, v]) => ({ name: k, Tax: v }));
        break;
      }
    }
    setChartData(cData);

    // Table data
    if (type === 'transaction' || type === 'deposit' || type === 'withdrawal') {
      // Show individual transaction rows
      const headers = ['Reference', 'Type', 'Amount', 'Currency', 'Status', 'Date'];
      setTableHeaders(headers);
      setTableRows(reportArr);
    } else if (type === 'commission' && reportArr.length > 0) {
      const headers = ['User', 'Type', 'Amount', 'Currency', 'Status', 'Date'];
      setTableHeaders(headers);
      setTableRows(reportArr);
    } else if (type === 'wallet') {
      const headers = ['User', 'Currency', 'Balance', 'Available', 'Frozen', 'Type'];
      setTableHeaders(headers);
      setTableRows(reportArr);
    } else {
      // Show aggregated data as table
      if (cData.length > 0) {
        const keys = Object.keys(cData[0]).filter(k => k !== 'name');
        setTableHeaders(['Period', ...keys.map(k => k.charAt(0).toUpperCase() + k.slice(1))]);
        setTableRows(cData);
      } else {
        setTableHeaders([]);
        setTableRows([]);
      }
    }
  };

  // Auto-fetch on mount
  useEffect(() => {
    const start = format(startOfMonth(new Date()), 'yyyy-MM-dd');
    const end = format(endOfDay(new Date()), 'yyyy-MM-dd');
    setStartDate(start);
    setEndDate(end);
    fetchReport('monthly', start, end);
  }, []);

  // Fetch when type or dates change (manual selection only, not on mount)
  const handleTypeSelect = (type: string) => {
    setSelectedType(type);
    fetchReport(type, startDate, endDate);
  };

  const handleDateChange = () => {
    fetchReport(selectedType, startDate, endDate);
  };

  const handlePreset = (preset: (typeof PRESETS)[number]) => {
    const [start, end] = preset.getRange();
    const startStr = format(start, 'yyyy-MM-dd');
    const endStr = format(end, 'yyyy-MM-dd');
    setStartDate(startStr);
    setEndDate(endStr);
    fetchReport(selectedType, startStr, endStr);
  };

  // Export CSV
  const exportCSV = () => {
    if (tableRows.length === 0) {
      toast.error('No data to export');
      return;
    }
    try {
      // Build CSV header
      const headers = tableHeaders;
      const csvRows: string[] = [headers.join(',')];

      for (const row of tableRows) {
        const values: string[] = [];

        if (tableHeaders.includes('Reference')) {
          values.push(`"${(row.reference as string) ?? ''}"`);
          values.push(`"${(row.type as string) ?? ''}"`);
          values.push(String((row.amount as number) ?? 0));
          values.push(`"${(row.currency as string) ?? ''}"`);
          values.push(`"${(row.status as string) ?? ''}"`);
          values.push(`"${row.createdAt ? format(new Date(row.createdAt as string), 'yyyy-MM-dd HH:mm') : ''}"`);
        } else if (tableHeaders.includes('User')) {
          const user = row.user as { name?: string } | undefined;
          values.push(`"${user?.name ?? (row.userId as string) ?? ''}"`);
          values.push(`"${(row.type as string) ?? ''}"`);
          values.push(String((row.amount as number) ?? 0));
          values.push(`"${(row.currency as string) ?? ''}"`);
          values.push(`"${(row.status as string) ?? ''}"`);
          values.push(`"${row.createdAt ? format(new Date(row.createdAt as string), 'yyyy-MM-dd HH:mm') : ''}"`);
        } else if (tableHeaders.includes('Currency') && tableHeaders.includes('Balance')) {
          const user = row.user as { name?: string } | undefined;
          values.push(`"${user?.name ?? (row.userId as string) ?? ''}"`);
          values.push(`"${(row.currency as string) ?? ''}"`);
          values.push(String((row.balance as number) ?? 0));
          values.push(String((row.availableBalance as number) ?? 0));
          values.push(String((row.frozenBalance as number) ?? 0));
          values.push(`"${(row.type as string) ?? ''}"`);
        } else {
          // Aggregated data
          values.push(`"${(row.name as string) ?? ''}"`);
          const keys = Object.keys(row).filter(k => k !== 'name');
          for (const k of keys) {
            const v = row[k];
            values.push(typeof v === 'number' ? String(v) : `"${String(v ?? '')}"`);
          }
        }

        csvRows.push(values.join(','));
      }

      const csvString = csvRows.join('\n');
      const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedType}_report_${startDate}_to_${endDate}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      toast.success('CSV exported successfully');
    } catch {
      toast.error('Failed to export CSV');
    }
  };

  const chartKeys = useMemo(() => {
    if (chartData.length === 0) return [];
    return Object.keys(chartData[0]).filter(k => k !== 'name');
  }, [chartData]);

  const CHART_COLORS = ['#0d9488', '#d97706', '#e11d48', '#10b981', '#f59e0b', '#8b5cf6'];

  const activeReport = REPORT_TYPES.find(r => r.value === selectedType);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <FileText className="h-6 w-6 text-teal-600" />
          Reports & Analytics
        </h2>
        <p className="text-muted-foreground">Generate and export detailed financial reports</p>
      </div>

      {/* Report Type Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {REPORT_TYPES.map(rt => (
          <motion.div key={rt.value} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card
              className={cn(
                'cursor-pointer transition-all hover:shadow-md',
                selectedType === rt.value
                  ? 'border-teal-500 border-2 bg-teal-50/50 dark:bg-teal-950/20'
                  : 'hover:border-teal-300'
              )}
              onClick={() => handleTypeSelect(rt.value)}
            >
              <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                <div className={cn(
                  'rounded-full p-2.5',
                  selectedType === rt.value
                    ? 'bg-teal-100 dark:bg-teal-900/50'
                    : 'bg-muted'
                )}>
                  <rt.icon className={cn('h-5 w-5', selectedType === rt.value ? 'text-teal-600 dark:text-teal-400' : 'text-muted-foreground')} />
                </div>
                <div>
                  <p className="text-sm font-medium leading-tight">{rt.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 hidden sm:block">{rt.description}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Date Range Selector */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-end">
            <div className="grid grid-cols-2 gap-3 flex-1 w-full lg:w-auto">
              <div className="grid gap-1.5">
                <Label className="text-xs text-muted-foreground">Start Date</Label>
                <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs text-muted-foreground">End Date</Label>
                <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {PRESETS.map(p => (
                <Button key={p.label} size="sm" variant="outline" onClick={() => handlePreset(p)}>
                  {p.label}
                </Button>
              ))}
            </div>
            <Button onClick={handleDateChange} disabled={loading} className="btn-responsive bg-teal-600 hover:bg-teal-700 text-white shrink-0">
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <BarChart3 className="h-4 w-4 mr-2" />}
              Generate
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {loading && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}><CardContent className="p-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
            ))}
          </div>
          <Card><CardContent className="p-4"><Skeleton className="h-64 w-full" /></CardContent></Card>
        </div>
      )}

      {/* Report Content */}
      {!loading && reportData && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          {/* Summary Cards */}
          {summaryCards.length > 0 && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {summaryCards.map((card, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground">{card.label}</p>
                      <p className={cn('text-lg font-bold mt-1', card.color)}>{card.value}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}

          {/* Chart */}
          {chartData.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{activeReport?.label} - Chart</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={Object.fromEntries(chartKeys.map((k, i) => [k, { color: CHART_COLORS[i % CHART_COLORS.length], label: k }]))} className="h-72 w-full">
                  {chartType === 'line' ? (
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      {chartKeys.map((k, i) => (
                        <Line key={k} type="monotone" dataKey={k} stroke={CHART_COLORS[i % CHART_COLORS.length]} strokeWidth={2} dot={{ r: 4 }} />
                      ))}
                    </LineChart>
                  ) : (
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      {chartKeys.map((k, i) => (
                        <Bar key={k} dataKey={k} fill={CHART_COLORS[i % CHART_COLORS.length]} radius={[4, 4, 0, 0]} />
                      ))}
                    </BarChart>
                  )}
                </ChartContainer>
              </CardContent>
            </Card>
          )}

          {/* Detail Table */}
          {tableRows.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <CardTitle className="text-base">{activeReport?.label} - Details</CardTitle>
                  <div className="flex gap-2 btn-responsive-group">
                    <Button size="sm" variant="outline" className="btn-responsive" onClick={exportCSV}>
                      <FileDown className="h-4 w-4 mr-1" /> CSV
                    </Button>
                    <Button size="sm" variant="outline" className="btn-responsive" onClick={() => toast.success('PDF export initiated')}>
                      <FileText className="h-4 w-4 mr-1" /> PDF
                    </Button>
                    <Button size="sm" variant="outline" className="btn-responsive" onClick={() => toast.success('Excel export initiated')}>
                      <FileSpreadsheet className="h-4 w-4 mr-1" /> Excel
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {tableHeaders.map((h, i) => (
                          <TableHead key={i}>{h}</TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tableRows.slice(0, 50).map((row, idx) => (
                        <TableRow key={idx}>
                          {tableHeaders.includes('Reference') ? (
                            <>
                              <TableCell className="font-mono text-xs">{(row.reference as string) ?? ''}</TableCell>
                              <TableCell><Badge variant="outline" className="capitalize">{(row.type as string) ?? ''}</Badge></TableCell>
                              <TableCell className="font-medium">{(row.currency as string) ?? 'ETB'} {((row.amount as number) ?? 0).toLocaleString()}</TableCell>
                              <TableCell>{(row.currency as string) ?? ''}</TableCell>
                              <TableCell>
                                <Badge className={cn('capitalize',
                                  (row.status as string) === 'completed' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-400' :
                                  (row.status as string) === 'failed' || (row.status as string) === 'cancelled' ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-400' :
                                  'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-400'
                                )}>{(row.status as string) ?? ''}</Badge>
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {row.createdAt ? <span className="datetime-badge full">{formatDateTime(row.createdAt as string)}</span> : ''}
                              </TableCell>
                            </>
                          ) : tableHeaders.includes('Currency') && tableHeaders.includes('Balance') ? (
                            <>
                              <TableCell className="font-medium">{(row.user as { name?: string })?.name ?? (row.userId as string) ?? ''}</TableCell>
                              <TableCell><Badge variant="outline">{(row.currency as string) ?? ''}</Badge></TableCell>
                              <TableCell className="font-semibold">{((row.balance as number) ?? 0).toLocaleString()}</TableCell>
                              <TableCell>{((row.availableBalance as number) ?? 0).toLocaleString()}</TableCell>
                              <TableCell className="text-rose-600">{((row.frozenBalance as number) ?? 0).toLocaleString()}</TableCell>
                              <TableCell><Badge variant="outline" className="capitalize">{(row.type as string) ?? ''}</Badge></TableCell>
                            </>
                          ) : tableHeaders.includes('User') ? (
                            <>
                              <TableCell className="font-medium">{(row.user as { name?: string })?.name ?? (row.userId as string) ?? ''}</TableCell>
                              <TableCell><Badge variant="outline" className="capitalize">{(row.type as string) ?? ''}</Badge></TableCell>
                              <TableCell className="font-medium">{(row.currency as string) ?? 'ETB'} {((row.amount as number) ?? 0).toLocaleString()}</TableCell>
                              <TableCell>{(row.currency as string) ?? ''}</TableCell>
                              <TableCell>
                                <Badge className={cn('capitalize',
                                  (row.status as string) === 'completed' || (row.status as string) === 'paid' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-400' :
                                  (row.status as string) === 'failed' || (row.status as string) === 'forfeited' ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-400' :
                                  'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-400'
                                )}>{(row.status as string) ?? ''}</Badge>
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {row.createdAt ? <span className="datetime-badge full">{formatDateTime(row.createdAt as string)}</span> : ''}
                              </TableCell>
                            </>
                          ) : (
                            // Aggregated data
                            <>
                              <TableCell className="font-medium">{(row.name as string) ?? ''}</TableCell>
                              {chartKeys.map(k => (
                                <TableCell key={k}>
                                  {typeof row[k] === 'number'
                                    ? (Math.abs(row[k] as number) >= 1000 ? (row[k] as number).toLocaleString() : String(row[k]))
                                    : String(row[k] ?? '')}
                                </TableCell>
                              ))}
                            </>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {tableRows.length > 50 && (
                  <div className="p-3 text-center text-sm text-muted-foreground border-t">
                    Showing 50 of {tableRows.length} rows. Export CSV for full data.
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Empty state */}
          {!loading && chartData.length === 0 && tableRows.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground/40" />
                <p className="text-muted-foreground mt-3">No data available for the selected report and date range</p>
              </CardContent>
            </Card>
          )}
        </motion.div>
      )}
    </div>
  );
}
