'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  BookOpen,
  ArrowRightLeft,
  ClipboardList,
  Shield,
  BarChart3,
  Server,
  Search,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Inbox,
  FileText,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Bar, BarChart, XAxis, YAxis, Line, LineChart, CartesianGrid } from 'recharts';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface LedgerEntry {
  id: string;
  date: string;
  account: string;
  accountCode: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
  currency: string;
  reference: string;
  category: string;
}

interface AuditLog {
  id: string;
  userId: string | null;
  action: string;
  resource: string;
  details: string | null;
  ipAddress: string | null;
  createdAt: string;
  user?: { id: string; name: string; email: string } | null;
}

interface BalanceHistoryPoint {
  date: string;
  balance: number;
  currency: string;
}

// --- Helpers ---

const accountColor: Record<string, string> = {
  ASSET: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  LIABILITY: 'bg-rose-100 text-rose-700 border-rose-200',
  EQUITY: 'bg-violet-100 text-violet-700 border-violet-200',
  REVENUE: 'bg-teal-100 text-teal-700 border-teal-200',
  EXPENSE: 'bg-amber-100 text-amber-700 border-amber-200',
};

const formatCurrency = (amount: number, currency: string = 'ETB') => {
  return new Intl.NumberFormat('en-ET', {
    style: 'currency',
    currency,
    maximumFractionDigits: 2,
  }).format(amount);
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const ACCOUNTS = [
  { code: '1000', name: 'Cash & Equivalents', category: 'ASSET' },
  { code: '1100', name: 'Bank — CBE', category: 'ASSET' },
  { code: '1200', name: 'Bank — Awash', category: 'ASSET' },
  { code: '2000', name: 'User Deposits (Liability)', category: 'LIABILITY' },
  { code: '2100', name: 'Pending Settlements', category: 'LIABILITY' },
  { code: '3000', name: 'Share Capital', category: 'EQUITY' },
  { code: '4000', name: 'Transfer Fees', category: 'REVENUE' },
  { code: '4100', name: 'FX Spread Income', category: 'REVENUE' },
  { code: '5000', name: 'Operations Cost', category: 'EXPENSE' },
  { code: '5100', name: 'SMS & Notification Costs', category: 'EXPENSE' },
];

const MOCK_LEDGER: LedgerEntry[] = [
  { id: 'le1', date: new Date(Date.now() - 1000*60*10).toISOString(), account: 'Cash & Equivalents', accountCode: '1000', description: 'Transfer fee received — TX-20250627001', debit: 15, credit: 0, balance: 2450015, currency: 'ETB', reference: 'TX-001', category: 'ASSET' },
  { id: 'le2', date: new Date(Date.now() - 1000*60*10).toISOString(), account: 'User Deposits (Liability)', accountCode: '2000', description: 'Transfer from Tigist to Dawit', debit: 0, credit: 5000, balance: 1205000, currency: 'ETB', reference: 'TX-001', category: 'LIABILITY' },
  { id: 'le3', date: new Date(Date.now() - 1000*60*30).toISOString(), account: 'Transfer Fees', accountCode: '4000', description: 'Fee income from transfer TX-20250627001', debit: 0, credit: 15, balance: 50015, currency: 'ETB', reference: 'TX-001', category: 'REVENUE' },
  { id: 'le4', date: new Date(Date.now() - 1000*60*60).toISOString(), account: 'Bank — CBE', accountCode: '1100', description: 'Settlement — withdrawal to Helen', debit: 0, credit: 20000, balance: 980000, currency: 'ETB', reference: 'WD-088', category: 'ASSET' },
  { id: 'le5', date: new Date(Date.now() - 1000*60*60).toISOString(), account: 'User Deposits (Liability)', accountCode: '2000', description: 'Withdrawal processed — Helen Mengistu', debit: 20000, credit: 0, balance: 1200000, currency: 'ETB', reference: 'WD-088', category: 'LIABILITY' },
  { id: 'le6', date: new Date(Date.now() - 1000*60*120).toISOString(), account: 'Bank — Awash', accountCode: '1200', description: 'FX purchase — USD 500', debit: 27500, credit: 0, balance: 527500, currency: 'ETB', reference: 'FX-033', category: 'ASSET' },
  { id: 'le7', date: new Date(Date.now() - 1000*60*120).toISOString(), account: 'FX Spread Income', accountCode: '4100', description: 'FX spread on USD 500 purchase', debit: 0, credit: 125, balance: 30125, currency: 'ETB', reference: 'FX-033', category: 'REVENUE' },
  { id: 'le8', date: new Date(Date.now() - 1000*60*180).toISOString(), account: 'Operations Cost', accountCode: '5000', description: 'Daily operations settlement', debit: 3500, credit: 0, balance: 83500, currency: 'ETB', reference: 'OP-101', category: 'EXPENSE' },
  { id: 'le9', date: new Date(Date.now() - 1000*60*240).toISOString(), account: 'Pending Settlements', accountCode: '2100', description: 'Payment to Merkato Electronics pending', debit: 0, credit: 3500, balance: 23500, currency: 'ETB', reference: 'PAY-210', category: 'LIABILITY' },
  { id: 'le10', date: new Date(Date.now() - 1000*60*300).toISOString(), account: 'SMS & Notification Costs', accountCode: '5100', description: 'Bulk SMS notification batch', debit: 450, credit: 0, balance: 12450, currency: 'ETB', reference: 'SMS-044', category: 'EXPENSE' },
];

const MOCK_BALANCE_HISTORY: BalanceHistoryPoint[] = Array.from({ length: 14 }).map((_, i) => ({
  date: new Date(Date.now() - (13 - i) * 86400000).toISOString().split('T')[0],
  balance: 2000000 + Math.floor(Math.random() * 500000) - 200000,
  currency: 'ETB',
}));

// --- Component ---

export default function LedgerView() {
  const { formatDateTime, formatRelative } = useFormattedDate();

  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [balanceHistory, setBalanceHistory] = useState<BalanceHistoryPoint[]>(MOCK_BALANCE_HISTORY);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [accountFilter, setAccountFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('general');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [ledgerRes, auditRes] = await Promise.all([
        apiFetch('/api/ledger?limit=100'),
        apiFetch('/api/audit-logs?limit=50'),
      ]);
      if (ledgerRes.ok) {
        const data = await ledgerRes.json();
        setLedger(Array.isArray(data) ? data : data.entries || data.data || []);
      } else {
        setLedger(MOCK_LEDGER);
      }
      if (auditRes.ok) {
        const data = await auditRes.json();
        setAuditLogs(Array.isArray(data) ? data : data.logs || data.data || []);
      }
    } catch {
      setLedger(MOCK_LEDGER);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredLedger = useMemo(() => {
    let result = ledger;
    if (accountFilter !== 'all') {
      result = result.filter((e) => e.accountCode === accountFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (e) =>
          e.description.toLowerCase().includes(q) ||
          e.account.toLowerCase().includes(q) ||
          e.reference.toLowerCase().includes(q),
      );
    }
    return result;
  }, [ledger, accountFilter, searchQuery]);

  const totalDebits = useMemo(() => filteredLedger.reduce((s, e) => s + e.debit, 0), [filteredLedger]);
  const totalCredits = useMemo(() => filteredLedger.reduce((s, e) => s + e.credit, 0), [filteredLedger]);

  const renderLoadingSkeleton = () => (
    <div className="space-y-3 p-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex gap-4">
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 flex-1" />
          <Skeleton className="h-4 w-24 text-right" />
          <Skeleton className="h-4 w-24 text-right" />
        </div>
      ))}
    </div>
  );

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Inbox className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium">No ledger entries found</h3>
      <p className="text-sm text-muted-foreground mt-1">No entries match your current filters.</p>
    </div>
  );

  const renderGeneralLedger = () => (
    <>
      <ScrollArea className="max-h-[500px]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[90px]">Date</TableHead>
              <TableHead className="w-[80px]">Account</TableHead>
              <TableHead className="min-w-[200px]">Description</TableHead>
              <TableHead className="w-[80px]">Ref</TableHead>
              <TableHead className="text-right w-[120px]">Debit</TableHead>
              <TableHead className="text-right w-[120px]">Credit</TableHead>
              <TableHead className="text-right w-[130px]">Balance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLedger.map((entry) => (
              <TableRow key={entry.id}>
                <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(entry.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={cn('text-[10px] whitespace-nowrap', accountColor[entry.category] || 'bg-gray-100 text-gray-600 border-gray-200')}>
                    {entry.accountCode}
                  </Badge>
                </TableCell>
                <TableCell>
                  <p className="text-sm">{entry.description}</p>
                  <p className="text-xs text-muted-foreground">{entry.account}</p>
                </TableCell>
                <TableCell className="text-xs font-mono text-muted-foreground">{entry.reference}</TableCell>
                <TableCell className="text-right font-mono text-sm">
                  {entry.debit > 0 ? (
                    <span className="text-emerald-600">{formatCurrency(entry.debit, entry.currency)}</span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell className="text-right font-mono text-sm">
                  {entry.credit > 0 ? (
                    <span className="text-rose-600">{formatCurrency(entry.credit, entry.currency)}</span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell className="text-right font-mono text-sm font-medium">{formatCurrency(entry.balance, entry.currency)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
      {/* Totals Row */}
      <div className="flex items-center justify-end gap-8 px-4 py-3 border-t bg-muted/30">
        <div className="text-sm">Total Debit: <span className="font-semibold text-emerald-600">{formatCurrency(totalDebits)}</span></div>
        <div className="text-sm">Total Credit: <span className="font-semibold text-rose-600">{formatCurrency(totalCredits)}</span></div>
      </div>
    </>
  );

  const renderTransactionLedger = () => (
    <ScrollArea className="max-h-[500px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Time</TableHead>
            <TableHead>Reference</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Description</TableHead>
            <TableHead className="text-right">Amount</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredLedger.filter((e) => e.reference.startsWith('TX')).map((entry) => (
            <TableRow key={entry.id}>
              <TableCell className="text-xs text-muted-foreground whitespace-nowrap" title={formatDateTime(entry.date)}>
                {formatRelative(entry.date)}
              </TableCell>
              <TableCell className="text-xs font-mono">{entry.reference}</TableCell>
              <TableCell><Badge variant="outline" className="bg-teal-100 text-teal-700 border-teal-200">Transfer</Badge></TableCell>
              <TableCell className="text-sm">{entry.description}</TableCell>
              <TableCell className="text-right font-mono text-sm font-medium">{formatCurrency(Math.max(entry.debit, entry.credit))}</TableCell>
              <TableCell><Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200">Completed</Badge></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  const renderAuditTimeline = () => (
    <ScrollArea className="max-h-[500px]">
      <div className="relative space-y-1">
        <div className="absolute left-[18px] top-0 bottom-0 w-px bg-border" />
        {(auditLogs.length > 0 ? auditLogs : MOCK_LEDGER.slice(0, 5).map((e) => ({
          id: e.id, userId: null, action: 'SYSTEM', resource: e.accountCode, details: e.description, ipAddress: null, createdAt: e.date, user: null,
        }))).map((log) => (
          <div key={log.id} className="relative flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <div className="relative z-10 mt-0.5 h-9 w-9 rounded-full bg-violet-500 flex items-center justify-center shrink-0">
              <FileText className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="bg-violet-100 text-violet-700 border-violet-200">{log.action}</Badge>
                <Badge variant="outline" className="bg-gray-100 text-gray-600 border-gray-200">{log.resource}</Badge>
              </div>
              <p className="text-sm mt-1">{log.details || '—'}</p>
              {log.user && <p className="text-xs text-muted-foreground mt-1">by {log.user.name}</p>}
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap shrink-0" title={formatDateTime(log.createdAt)}>
              {formatRelative(log.createdAt)}
            </span>
          </div>
        ))}
      </div>
    </ScrollArea>
  );

  const renderAdminActivity = () => (
    <ScrollArea className="max-h-[500px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Time</TableHead>
            <TableHead>Admin</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Target</TableHead>
            <TableHead>Details</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[
            { time: new Date(Date.now() - 1000*60*15).toISOString(), admin: 'Yismaw Alemayehu', action: 'UPDATE', target: 'User role changed', details: 'Dawit Amare promoted to agent' },
            { time: new Date(Date.now() - 1000*60*45).toISOString(), admin: 'Yismaw Alemayehu', action: 'APPROVE', target: 'KYC Review', details: 'Approved KYC for Tigist Haile' },
            { time: new Date(Date.now() - 1000*60*90).toISOString(), admin: 'Selamawit Fikadu', action: 'REJECT', target: 'KYC Review', details: 'Rejected KYC for Getachew Tesfaye' },
            { time: new Date(Date.now() - 1000*60*180).toISOString(), admin: 'Yismaw Alemayehu', action: 'CREATE', target: 'System Config', details: 'Updated transaction limits' },
            { time: new Date(Date.now() - 1000*60*300).toISOString(), admin: 'Yismaw Alemayehu', action: 'DELETE', target: 'Session', details: 'Terminated inactive sessions' },
          ].map((item, i) => (
            <TableRow key={i}>
              <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatRelative(item.time)}</TableCell>
              <TableCell className="text-sm font-medium">{item.admin}</TableCell>
              <TableCell><Badge variant="outline" className={
                item.action === 'APPROVE' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                item.action === 'REJECT' || item.action === 'DELETE' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                'bg-amber-100 text-amber-700 border-amber-200'
              }>{item.action}</Badge></TableCell>
              <TableCell className="text-sm">{item.target}</TableCell>
              <TableCell className="text-sm text-muted-foreground">{item.details}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  const renderBalanceHistory = () => (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-emerald-200/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Total Assets</p>
            <p className="text-xl font-bold text-emerald-600">{formatCurrency(3672025)}</p>
          </CardContent>
        </Card>
        <Card className="border-rose-200/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Total Liabilities</p>
            <p className="text-xl font-bold text-rose-600">{formatCurrency(2449000)}</p>
          </CardContent>
        </Card>
        <Card className="border-violet-200/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Equity</p>
            <p className="text-xl font-bold text-violet-600">{formatCurrency(1223025)}</p>
          </CardContent>
        </Card>
        <Card className="border-teal-200/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Revenue (MTD)</p>
            <p className="text-xl font-bold text-teal-600">{formatCurrency(80140)}</p>
          </CardContent>
        </Card>
      </div>
      {/* Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Platform Balance — 14 Day Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{}} className="h-[300px] w-full">
            <LineChart data={balanceHistory}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => new Date(v).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line type="monotone" dataKey="balance" stroke="#10b981" strokeWidth={2} dot={{ r: 3, fill: '#10b981' }} />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );

  const renderSystemEvents = () => (
    <ScrollArea className="max-h-[500px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Time</TableHead>
            <TableHead>Event</TableHead>
            <TableHead>Level</TableHead>
            <TableHead>Details</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[
            { time: new Date(Date.now() - 1000*60*5).toISOString(), event: 'AML Screening Complete', level: 'info', details: 'Batch screening of 47 transactions — 0 flagged' },
            { time: new Date(Date.now() - 1000*60*30).toISOString(), event: 'Daily Reconciliation', level: 'success', details: 'All accounts balanced. Variance: ETB 0.00' },
            { time: new Date(Date.now() - 1000*60*120).toISOString(), event: 'Scheduled Backup', level: 'success', details: 'Database backup completed — 2.4GB' },
            { time: new Date(Date.now() - 1000*60*240).toISOString(), event: 'Rate Limit Warning', level: 'warning', details: 'API rate limit reached for CBE bank integration' },
            { time: new Date(Date.now() - 1000*60*480).toISOString(), event: 'System Maintenance', level: 'info', details: 'Scheduled maintenance window started — no downtime' },
          ].map((item, i) => (
            <TableRow key={i}>
              <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatRelative(item.time)}</TableCell>
              <TableCell className="text-sm font-medium">{item.event}</TableCell>
              <TableCell>
                <Badge variant="outline" className={
                  item.level === 'success' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                  item.level === 'warning' ? 'bg-amber-100 text-amber-700 border-amber-200' :
                  'bg-gray-100 text-gray-600 border-gray-200'
                }>{item.level}</Badge>
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">{item.details}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <BookOpen className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Audit & Ledger</h1>
            <p className="text-sm text-muted-foreground">Double-entry accounting, audit trails, and balance history</p>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-emerald-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Ledger Entries</p>
                <p className="text-2xl font-bold text-emerald-600">{ledger.length || MOCK_LEDGER.length}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center">
                <BookOpen className="h-4 w-4 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Debits</p>
                <p className="text-lg font-bold text-teal-600">{formatCurrency(totalDebits)}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-teal-100 flex items-center justify-center">
                <ArrowDownRight className="h-4 w-4 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-rose-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Credits</p>
                <p className="text-lg font-bold text-rose-600">{formatCurrency(totalCredits)}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center">
                <ArrowUpRight className="h-4 w-4 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-violet-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Net Movement</p>
                <p className="text-lg font-bold text-violet-600">{formatCurrency(totalDebits - totalCredits)}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-violet-100 flex items-center justify-center">
                <BarChart3 className="h-4 w-4 text-violet-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search & Account Filter */}
      <motion.div {...fadeUp} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search ledger entries..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>
        <Select value={accountFilter} onValueChange={setAccountFilter}>
          <SelectTrigger className="w-full sm:w-[240px]">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="All Accounts" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Accounts</SelectItem>
            {ACCOUNTS.map((a) => (
              <SelectItem key={a.code} value={a.code}>{a.code} — {a.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchData} title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* Main Tabs */}
      <motion.div {...fadeUp}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Financial Records</CardTitle>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                {filteredLedger.length} entries
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4 flex-wrap h-auto gap-1">
                <TabsTrigger value="general" className="gap-1.5">
                  <BookOpen className="h-3.5 w-3.5" /> General Ledger
                </TabsTrigger>
                <TabsTrigger value="transaction" className="gap-1.5">
                  <ArrowRightLeft className="h-3.5 w-3.5" /> Transaction Ledger
                </TabsTrigger>
                <TabsTrigger value="audit" className="gap-1.5">
                  <ClipboardList className="h-3.5 w-3.5" /> Audit Logs
                </TabsTrigger>
                <TabsTrigger value="admin" className="gap-1.5">
                  <Shield className="h-3.5 w-3.5" /> Admin Activity
                </TabsTrigger>
                <TabsTrigger value="balance" className="gap-1.5">
                  <BarChart3 className="h-3.5 w-3.5" /> Balance History
                </TabsTrigger>
                <TabsTrigger value="system" className="gap-1.5">
                  <Server className="h-3.5 w-3.5" /> System Events
                </TabsTrigger>
              </TabsList>

              <TabsContent value="general">
                {loading ? renderLoadingSkeleton() : filteredLedger.length === 0 ? renderEmptyState() : renderGeneralLedger()}
              </TabsContent>
              <TabsContent value="transaction">
                {loading ? renderLoadingSkeleton() : filteredLedger.length === 0 ? renderEmptyState() : renderTransactionLedger()}
              </TabsContent>
              <TabsContent value="audit">
                {loading ? renderLoadingSkeleton() : renderAuditTimeline()}
              </TabsContent>
              <TabsContent value="admin">
                {renderAdminActivity()}
              </TabsContent>
              <TabsContent value="balance">
                {renderBalanceHistory()}
              </TabsContent>
              <TabsContent value="system">
                {renderSystemEvents()}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
