'use client';

import { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { isThisMonth } from 'date-fns';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Search,
  Users,
  ClipboardCheck,
  Landmark,
  AlertTriangle,
  Settings2,
  DollarSign,
  Pencil,
  Eye,
  CheckCircle2,
  XCircle,
  Lock,
  Unlock,
  ShieldCheck,
  Plus,
  Loader2,
  Power,
  PowerOff,
  UserCog,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import { useT } from '@/lib/i18n';
import { useAppStore } from '@/lib/store';
import { isAdminRole, isSuperAdmin, isAdministrator, canManageRole, getRoleLevel, getRoleInfo, getAllRoles, canViewAdmin, ROLES as ROLE_DEFINITIONS } from '@/lib/role-permissions';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface UserItem {
  id: string;
  name: string;
  email: string;
  username: string | null;
  phone: string | null;
  country: string | null;
  role: string;
  kycStatus: string;
  riskLevel: string;
  status: string;
  twoFactorEnabled: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  _count?: { wallets: number; transactions: number };
}

interface TransactionItem {
  id: string;
  reference: string;
  type: string;
  amount: number;
  currency: string;
  initiatorId: string | null;
  initiatorName?: string;
  recipientId: string | null;
  recipientName?: string;
  paymentMethod: string | null;
  status: string;
  createdAt: string;
}

interface SettlementItem {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  status: string;
  settledAt: string | null;
  createdAt: string;
  updatedAt: string;
  user?: { id: string; name: string; email: string; role: string };
}

interface DisputeItem {
  id: string;
  transactionId: string;
  userId: string;
  reason: string;
  status: string;
  resolution: string | null;
  createdAt: string;
  updatedAt: string;
  user?: { id: string; name: string; email: string };
}

interface FeeConfigItem {
  id: string;
  transactionType: string;
  paymentMethod: string | null;
  feeType: string;
  feeValue: number;
  minFee: number | null;
  maxFee: number | null;
  currency: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// --- Status badge helper ---

function statusColor(status: string) {
  switch (status) {
    case 'active': case 'completed': case 'verified': case 'resolved':
      return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-400';
    case 'pending': case 'processing': case 'open': case 'under_review':
      return 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-400';
    case 'approved':
      return 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-400';
    case 'suspended':
      return 'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-400';
    case 'frozen':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-400';
    case 'blocked': case 'failed': case 'rejected': case 'closed':
      return 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-400';
    case 'inactive':
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400';
  }
}

// ============================================================
// TAB 1: USER MANAGEMENT
// ============================================================

function UserManagementTab() {
  const { formatDate, formatDateTime } = useFormattedDate();
  const t = useT();
  const currentUser = useAppStore(s => s.user);
  const currentUserRole = currentUser?.role ?? 'user';
  const isSuperAdminRole = isSuperAdmin(currentUserRole);
  const canManage = currentUser ? isAdminRole(currentUserRole) : false;
  const myRoleLevel = getRoleLevel(currentUserRole);

  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [countryFilter, setCountryFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});

  // View detail dialog
  const [viewUser, setViewUser] = useState<UserItem | null>(null);

  // Edit dialog
  const [editUser, setEditUser] = useState<UserItem | null>(null);
  const [editName, setEditName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editCountry, setEditCountry] = useState('');
  const [editRole, setEditRole] = useState('');
  const [editKyc, setEditKyc] = useState('');
  const [editStatus, setEditStatus] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  // Confirmation dialog
  const [confirmAction, setConfirmAction] = useState<{user: UserItem; action: string; newStatus: string} | null>(null);
  const [confirmLoading, setConfirmLoading] = useState(false);

  // Change Role dialog (separate from full edit)
  const [changeRoleUser, setChangeRoleUser] = useState<UserItem | null>(null);
  const [changeRoleValue, setChangeRoleValue] = useState('');
  const [savingRoleChange, setSavingRoleChange] = useState(false);

  const ALL_ROLES = getAllRoles();
  // Roles available in the edit/change-role dropdowns, filtered by permission
  const availableRoles = isSuperAdminRole
    ? ALL_ROLES
    : ALL_ROLES.filter(r => canManageRole(currentUserRole, r));

  const STATUSES = ['pending', 'approved', 'active', 'blocked', 'inactive', 'suspended', 'frozen', 'closed'];
  const COUNTRIES = ['Ethiopia', 'USA', 'Kenya', 'Uganda', 'Tanzania', 'Nigeria', 'South Africa', 'United Kingdom', 'Germany', 'Canada', 'Australia', 'India', 'China', 'Japan', 'Brazil'];

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('page', String(page));
      params.set('limit', '20');
      if (search) params.set('search', search);
      if (roleFilter !== 'all') params.set('role', roleFilter);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (countryFilter !== 'all') params.set('country', countryFilter);
      const res = await apiFetch(`/api/users?${params.toString()}`);
      const json = await res.json();
      if (res.ok) {
        setUsers(json.users ?? []);
        setTotal(json.pagination?.total ?? 0);
        setTotalPages(json.pagination?.totalPages ?? 1);
      } else {
        toast.error(json.error || t('admin.failedToLoad'));
      }
    } catch {
      toast.error(t('admin.failedToLoad'));
    } finally {
      setLoading(false);
    }
  }, [search, roleFilter, statusFilter, countryFilter, page]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  // Reset to page 1 when filters change
  useEffect(() => { setPage(1); }, [search, roleFilter, statusFilter, countryFilter]);

  const openEdit = (u: UserItem) => {
    setEditUser(u);
    setEditName(u.name);
    setEditUsername(u.username ?? '');
    setEditEmail(u.email);
    setEditPhone(u.phone ?? '');
    setEditCountry(u.country ?? '');
    setEditRole(u.role);
    setEditKyc(u.kycStatus);
    setEditStatus(u.status);
  };

  const saveEdit = async () => {
    if (!editUser) return;
    setSavingEdit(true);
    try {
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editUser.id, name: editName, username: editUsername || null,
          email: editEmail, phone: editPhone || null, country: editCountry || null,
          role: editRole, kycStatus: editKyc, status: editStatus,
        }),
      });
      if (res.ok) {
        toast.success(t('admin.userUpdated').replace('{name}', editUser.name));
        setEditUser(null);
        fetchUsers();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failedToUpdate'));
      }
    } catch { toast.error(t('admin.failedToUpdate')); }
    finally { setSavingEdit(false); }
  };

  const handleConfirmAction = async () => {
    if (!confirmAction) return;
    setConfirmLoading(true);
    const { user: u, newStatus } = confirmAction;
    try {
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: u.id, status: newStatus }),
      });
      if (res.ok) {
        toast.success(t(`admin.user${confirmAction.action.charAt(0).toUpperCase() + confirmAction.action.slice(1)}`).replace('{name}', u.name));
        setConfirmAction(null);
        fetchUsers();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.actionFailed'));
      }
    } catch { toast.error(t('admin.actionFailed')); }
    finally { setConfirmLoading(false); }
  };

  const requestAction = (user: UserItem, action: string, newStatus: string) => {
    setConfirmAction({ user, action, newStatus });
  };

  const openChangeRole = (u: UserItem) => {
    setChangeRoleUser(u);
    setChangeRoleValue(u.role);
  };

  const saveRoleChange = async () => {
    if (!changeRoleUser || !changeRoleValue) return;
    // Prevent changing to same role
    if (changeRoleValue === changeRoleUser.role) {
      setChangeRoleUser(null);
      return;
    }
    setSavingRoleChange(true);
    try {
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: changeRoleUser.id, role: changeRoleValue }),
      });
      if (res.ok) {
        const oldInfo = getRoleInfo(changeRoleUser.role);
        const newInfo = getRoleInfo(changeRoleValue);
        toast.success(`${changeRoleUser.name}'s role changed from ${oldInfo.label} to ${newInfo.label}`);
        setChangeRoleUser(null);
        fetchUsers();
      } else {
        const j = await res.json();
        toast.error(j.error || 'Failed to change role');
      }
    } catch { toast.error('Failed to change role'); }
    finally { setSavingRoleChange(false); }
  };

  const confirmTitle = confirmAction
    ? confirmAction.action === 'approved'
      ? t('admin.approveUser')
      : confirmAction.action === 'rejected'
        ? t('admin.rejectUser')
        : confirmAction.action === 'blocked'
          ? t('admin.blockUser')
          : confirmAction.action === 'activated'
            ? t('admin.activateUser')
            : t('admin.deactivateUser')
    : '';

  const confirmDesc = confirmAction
    ? t('admin.confirmActionDesc').replace('{action}', confirmAction.action).replace('{name}', confirmAction.user.name).replace('{email}', confirmAction.user.email).replace('{status}', confirmAction.newStatus)
    : '';

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('admin.searchPlaceholder')}
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder={t('admin.allRoles')} /></SelectTrigger>
          <SelectContent className="max-h-72 overflow-y-auto">
            <SelectItem value="all">{t('admin.allRoles')}</SelectItem>
            {ALL_ROLES.map(r => (
              <SelectItem key={r} value={r} className="capitalize">{ROLE_DEFINITIONS[r].label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder={t('admin.allStatuses')} /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('admin.allStatuses')}</SelectItem>
            {STATUSES.map(s => (
              <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={countryFilter} onValueChange={setCountryFilter}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder={t('admin.allCountries')} /></SelectTrigger>
          <SelectContent className="max-h-72 overflow-y-auto">
            <SelectItem value="all">{t('admin.allCountries')}</SelectItem>
            {COUNTRIES.map(c => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('admin.fullName')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('admin.country')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('admin.email')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('admin.phone')}</TableHead>
                  <TableHead>{t('admin.role')}</TableHead>
                  <TableHead className="hidden md:table-cell">Role Level</TableHead>
                  <TableHead>{t('admin.status')}</TableHead>
                  <TableHead className="hidden xl:table-cell">{t('admin.registeredLabel')}</TableHead>
                  <TableHead className="text-right">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 9 }).map((_, j) => (
                        <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : users.length === 0 ? (
                  <TableRow><TableCell colSpan={9} className="text-center py-12 text-muted-foreground">{t('admin.noUsers')}</TableCell></TableRow>
                ) : (
                  <AnimatePresence mode="popLayout">
                    {users.map(u => (
                      <motion.tr
                        key={u.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                        className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                      >
                        <td className="px-4 py-3 font-medium">{u.name}</td>
                        <td className="hidden md:table-cell px-4 py-3 text-sm text-muted-foreground">{u.country ?? '—'}</td>
                        <td className="hidden lg:table-cell px-4 py-3 text-sm text-muted-foreground">{u.email}</td>
                        <td className="hidden lg:table-cell px-4 py-3 text-sm text-muted-foreground">{u.phone ?? '—'}</td>
                        <td className="px-4 py-3"><Badge variant="outline" className="capitalize text-xs">{getRoleInfo(u.role).label}</Badge></td>
                        <td className="hidden md:table-cell px-4 py-3 text-sm font-mono text-muted-foreground">{getRoleLevel(u.role)}</td>
                        <td className="px-4 py-3"><Badge className={cn('capitalize text-xs', statusColor(u.status))}>{u.status}</Badge></td>
                        <td className="hidden xl:table-cell px-4 py-3 text-sm text-muted-foreground"><span className="datetime-badge date-only">{formatDate(u.createdAt)}</span></td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {/* View */}
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setViewUser(u)} title={t('admin.view')}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            {/* Edit */}
                            {canManage && (
                              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(u)} title={t('admin.editUser')}>
                                <Pencil className="h-4 w-4" />
                              </Button>
                            )}
                            {/* Change Role */}
                            {canManage && (
                              <Button
                                size="icon" variant="ghost" className="h-8 w-8 text-teal-600 hover:text-teal-700"
                                onClick={() => openChangeRole(u)}
                                title="Change Role"
                              >
                                <UserCog className="h-4 w-4" />
                              </Button>
                            )}
                            {/* Pending: Approve + Reject */}
                            {u.status === 'pending' && canManage && (
                              <>
                                <Button
                                  size="icon" variant="ghost" className="h-8 w-8 text-emerald-600 hover:text-emerald-700"
                                  onClick={() => requestAction(u, 'approved', 'approved')}
                                  disabled={actionLoading[u.id]}
                                  title={t('admin.approve')}
                                >
                                  {actionLoading[u.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                                </Button>
                                <Button
                                  size="icon" variant="ghost" className="h-8 w-8 text-rose-600 hover:text-rose-700"
                                  onClick={() => requestAction(u, 'rejected', 'blocked')}
                                  disabled={actionLoading[u.id]}
                                  title={t('admin.reject')}
                                >
                                  {actionLoading[u.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
                                </Button>
                              </>
                            )}
                            {/* Active: Block + Deactivate */}
                            {u.status === 'active' && canManage && (
                              <>
                                <Button
                                  size="icon" variant="ghost" className="h-8 w-8 text-rose-600 hover:text-rose-700"
                                  onClick={() => requestAction(u, 'blocked', 'blocked')}
                                  disabled={actionLoading[u.id]}
                                  title={t('admin.block')}
                                >
                                  {actionLoading[u.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                                </Button>
                                <Button
                                  size="icon" variant="ghost" className="h-8 w-8 text-amber-600 hover:text-amber-700"
                                  onClick={() => requestAction(u, 'deactivated', 'inactive')}
                                  disabled={actionLoading[u.id]}
                                  title={t('admin.deactivate')}
                                >
                                  {actionLoading[u.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : <PowerOff className="h-4 w-4" />}
                                </Button>
                              </>
                            )}
                            {/* Blocked/Inactive: Activate */}
                            {(u.status === 'blocked' || u.status === 'inactive') && canManage && (
                              <Button
                                size="icon" variant="ghost" className="h-8 w-8 text-emerald-600 hover:text-emerald-700"
                                onClick={() => requestAction(u, 'activated', 'active')}
                                disabled={actionLoading[u.id]}
                                title={t('admin.activate')}
                              >
                                {actionLoading[u.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unlock className="h-4 w-4" />}
                              </Button>
                            )}
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>{t('admin.usersTotal').replace('{count}', String(total))}</span>
          <div className="flex items-center gap-2">
            <Button
              size="sm" variant="outline" disabled={page <= 1}
              onClick={() => setPage(p => p - 1)}
            >{t('admin.previous')}</Button>
            <span className="px-2">{t('admin.pageOf').replace('{page}', String(page)).replace('{totalPages}', String(totalPages))}</span>
            <Button
              size="sm" variant="outline" disabled={page >= totalPages}
              onClick={() => setPage(p => p + 1)}
            >{t('admin.next')}</Button>
          </div>
        </div>
      )}

      {/* View User Detail Dialog */}
      <Dialog open={!!viewUser} onOpenChange={open => !open && setViewUser(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('admin.userDetails')}</DialogTitle>
          </DialogHeader>
          {viewUser && (
            <div className="grid gap-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.fullName')}</p>
                  <p className="text-sm font-medium">{viewUser.name}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.username')}</p>
                  <p className="text-sm font-medium">{viewUser.username ?? '—'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.email')}</p>
                  <p className="text-sm font-medium">{viewUser.email}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.phone')}</p>
                  <p className="text-sm font-medium">{viewUser.phone ?? '—'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.country')}</p>
                  <p className="text-sm font-medium">{viewUser.country ?? '—'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.role')}</p>
                  <Badge variant="outline" className="capitalize text-xs">{getRoleInfo(viewUser.role).label}</Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.status')}</p>
                  <Badge className={cn('capitalize text-xs', statusColor(viewUser.status))}>{viewUser.status}</Badge>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.kycStatusLabel')}</p>
                  <Badge className={cn('capitalize text-xs', statusColor(viewUser.kycStatus))}>{viewUser.kycStatus}</Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.riskLevelLabel')}</p>
                  <p className="text-sm font-medium capitalize">{viewUser.riskLevel ?? '—'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.twoFactorLabel')}</p>
                  <Badge className={viewUser.twoFactorEnabled ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-400' : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400'}>
                    {viewUser.twoFactorEnabled ? t('common.yes') : t('common.no')}
                  </Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.walletsCount')}</p>
                  <p className="text-sm font-medium">{viewUser._count?.wallets ?? 0}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.transactionsCount')}</p>
                  <p className="text-sm font-medium">{viewUser._count?.transactions ?? 0}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.lastLoginLabel')}</p>
                  <p className="text-sm font-medium">{viewUser.lastLoginAt ? <span className="datetime-badge full">{formatDateTime(viewUser.lastLoginAt)}</span> : t('common.never')}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{t('admin.registeredLabel')}</p>
                  <p className="text-sm font-medium"><span className="datetime-badge full">{formatDateTime(viewUser.createdAt)}</span></p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={!!editUser} onOpenChange={open => !open && setEditUser(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('admin.editUserTitle').replace('{name}', editUser?.name ?? '')}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.name')}</Label>
              <Input className="col-span-3" value={editName} onChange={e => setEditName(e.target.value)} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.username')}</Label>
              <Input className="col-span-3" value={editUsername} onChange={e => setEditUsername(e.target.value)} placeholder={t('admin.optional')} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.email')}</Label>
              <Input className="col-span-3" type="email" value={editEmail} onChange={e => setEditEmail(e.target.value)} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.phone')}</Label>
              <Input className="col-span-3" value={editPhone} onChange={e => setEditPhone(e.target.value)} placeholder={t('admin.optional')} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.country')}</Label>
              <Select value={editCountry} onValueChange={setEditCountry}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder={t('admin.selectCountry')} /></SelectTrigger>
                <SelectContent className="max-h-72 overflow-y-auto">
                  <SelectItem value="">{t('admin.none')}</SelectItem>
                  {COUNTRIES.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.role')}</Label>
              <Select value={editRole} onValueChange={setEditRole}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72 overflow-y-auto">
                  {(isSuperAdminRole ? ALL_ROLES : availableRoles).map(r => {
                    const info = ROLE_DEFINITIONS[r];
                    return (
                      <SelectItem key={r} value={r}>
                        {info.label} (Level {info.level} - {info.accessLevel})
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            {!isSuperAdminRole && editUser && getRoleLevel(editUser.role) >= myRoleLevel && (
              <div className="rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-800 p-3 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                <p className="text-sm text-amber-800 dark:text-amber-400">
                  You cannot modify users at or above your role level (Level {myRoleLevel}). This user is Level {getRoleLevel(editUser.role)}.
                </p>
              </div>
            )}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.status')}</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map(s => (
                    <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right text-sm">{t('admin.kycStatusLabel')}</Label>
              <Select value={editKyc} onValueChange={setEditKyc}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">{t('common.pending')}</SelectItem>
                  <SelectItem value="verified">{t('common.verified')}</SelectItem>
                  <SelectItem value="rejected">{t('common.rejected')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setEditUser(null)}>{t('common.cancel')}</Button>
            <Button onClick={saveEdit} disabled={savingEdit} className="btn-responsive">
              {savingEdit && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('admin.saveChanges')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <AlertDialog open={!!confirmAction} onOpenChange={open => !open && setConfirmAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirmTitle}</AlertDialogTitle>
            <AlertDialogDescription>{confirmDesc}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={confirmLoading}>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmAction}
              disabled={confirmLoading}
              className={cn(
                confirmAction?.newStatus === 'approved' || confirmAction?.newStatus === 'active'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-rose-600 hover:bg-rose-700'
              )}
            >
              {confirmLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('common.confirm')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Change Role Dialog */}
      <Dialog open={!!changeRoleUser} onOpenChange={open => !open && setChangeRoleUser(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCog className="h-5 w-5 text-teal-600" />
              Change Role
            </DialogTitle>
          </DialogHeader>
          {changeRoleUser && (
            <div className="grid gap-4 py-2">
              <div className="rounded-lg bg-muted p-3 space-y-1">
                <p className="text-sm font-medium">{changeRoleUser.name}</p>
                <p className="text-xs text-muted-foreground">{changeRoleUser.email}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-muted-foreground">Current:</span>
                  <Badge variant="outline" className="text-xs">{getRoleInfo(changeRoleUser.role).label} (Level {getRoleLevel(changeRoleUser.role)})</Badge>
                </div>
              </div>
              {!isSuperAdminRole && getRoleLevel(changeRoleUser.role) >= myRoleLevel && (
                <div className="rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-800 p-3 flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-amber-800 dark:text-amber-400">
                    You cannot modify users at or above your role level (Level {myRoleLevel}). This user is Level {getRoleLevel(changeRoleUser.role)}.
                  </p>
                </div>
              )}
              <div className="grid gap-2">
                <Label>New Role</Label>
                <Select value={changeRoleValue} onValueChange={setChangeRoleValue}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent className="max-h-72 overflow-y-auto">
                    {availableRoles.map(r => {
                      const info = ROLE_DEFINITIONS[r];
                      return (
                        <SelectItem key={r} value={r}>
                          {info.label} (Level {info.level} - {info.accessLevel})
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              {changeRoleValue !== changeRoleUser.role && (
                <div className="rounded-lg bg-muted p-3">
                  <p className="text-xs text-muted-foreground mb-1">Role Hierarchy:</p>
                  <p className="text-sm">
                    <span className="font-medium">{getRoleInfo(changeRoleUser.role).label}</span>
                    <span className="mx-2 text-muted-foreground">→</span>
                    <span className="font-medium text-teal-600 dark:text-teal-400">{getRoleInfo(changeRoleValue).label}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Level {getRoleLevel(changeRoleUser.role)} → Level {getRoleLevel(changeRoleValue)}
                    {getRoleLevel(changeRoleValue) > getRoleLevel(changeRoleUser.role) && ' (↑ Elevated)'}
                    {getRoleLevel(changeRoleValue) < getRoleLevel(changeRoleUser.role) && ' (↓ Demoted)'}
                  </p>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setChangeRoleUser(null)}>{t('common.cancel')}</Button>
            <Button
              onClick={saveRoleChange}
              disabled={savingRoleChange || changeRoleValue === changeRoleUser?.role || (!isSuperAdminRole && changeRoleUser ? getRoleLevel(changeRoleUser.role) >= myRoleLevel : false)}
              className="btn-responsive bg-teal-600 hover:bg-teal-700 text-white"
            >
              {savingRoleChange && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Update Role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// TAB 2: PAYMENT APPROVALS
// ============================================================

function PaymentApprovalsTab() {
  const t = useT();
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [rowLoading, setRowLoading] = useState<Record<string, boolean>>({});

  const fetchPending = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/transactions?status=pending&limit=100');
      const json = await res.json();
      if (res.ok) setTransactions(json.transactions ?? []);
      else toast.error(json.error || t('admin.failedToLoadPending'));
    } catch { toast.error(t('admin.failedToLoadPending')); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchPending(); }, [fetchPending]);

  const updateStatus = async (id: string, status: string, label: string) => {
    setRowLoading(p => ({ ...p, [id]: true }));
    try {
      const res = await apiFetch(`/api/transactions/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        toast.success(label === 'approved' ? t('admin.transactionApproved') : t('admin.transactionRejected'));
        fetchPending();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failed'));
      }
    } catch { toast.error(t('admin.failed')); }
    finally { setRowLoading(p => ({ ...p, [id]: false })); }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ClipboardCheck className="h-5 w-5 text-amber-500" />
          {t('admin.pendingApprovals')}
        </CardTitle>
        <CardDescription>{t('admin.pendingApprovalsDesc')}</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[500px] overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('common.reference')}</TableHead>
                <TableHead>{t('common.type')}</TableHead>
                <TableHead>{t('common.amount')}</TableHead>
                <TableHead className="hidden md:table-cell">{t('transactions.initiator')}</TableHead>
                <TableHead className="hidden lg:table-cell">{t('common.date')}</TableHead>
                <TableHead className="text-right">{t('common.actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : transactions.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">{t('admin.noPending')}</TableCell></TableRow>
              ) : (
                transactions.map(tx => (
                  <TableRow key={tx.id}>
                    <TableCell className="font-mono text-xs">{tx.reference}</TableCell>
                    <TableCell><Badge variant="outline" className="capitalize">{tx.type}</Badge></TableCell>
                    <TableCell className="font-semibold">{tx.currency} {tx.amount.toLocaleString()}</TableCell>
                    <TableCell className="hidden md:table-cell text-sm">{tx.initiatorName ?? t('admin.na')}</TableCell>
                    <TableCell className="hidden lg:table-cell text-sm text-muted-foreground"><span className="datetime-badge full">{formatDateTime(tx.createdAt)}</span></TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1 btn-responsive-group">
                        <Button
                          size="sm"
                          className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white"
                          onClick={() => updateStatus(tx.id, 'completed', 'approved')}
                          disabled={rowLoading[tx.id]}
                        >
                          {rowLoading[tx.id] ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <CheckCircle2 className="h-4 w-4 mr-1" />}
                          {t('admin.approve')}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="btn-responsive"
                          onClick={() => updateStatus(tx.id, 'failed', 'rejected')}
                          disabled={rowLoading[tx.id]}
                        >
                          {rowLoading[tx.id] ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <XCircle className="h-4 w-4 mr-1" />}
                          {t('admin.reject')}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// TAB 3: SETTLEMENT MANAGEMENT
// ============================================================

function SettlementManagementTab() {
  const t = useT();
  const [settlements, setSettlements] = useState<SettlementItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [rowLoading, setRowLoading] = useState<Record<string, boolean>>({});
  const [viewSettlement, setViewSettlement] = useState<SettlementItem | null>(null);

  const fetchSettlements = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/settlements?limit=100');
      const json = await res.json();
      if (res.ok) setSettlements(json.settlements ?? []);
      else toast.error(json.error || t('admin.failedToLoad'));
    } catch { toast.error(t('admin.failedToLoad')); }
    finally { setLoading(false); }
  }, [t]);

  useEffect(() => { fetchSettlements(); }, [fetchSettlements]);

  const processSettlement = async (s: SettlementItem) => {
    setRowLoading(p => ({ ...p, [s.id]: true }));
    try {
      const res = await apiFetch('/api/settlements', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: s.id, status: 'completed' }),
      });
      if (res.ok) {
        toast.success(t('admin.processed'));
        fetchSettlements();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failedToProcess'));
      }
    } catch { toast.error(t('admin.failedToProcess')); }
    finally { setRowLoading(p => ({ ...p, [s.id]: false })); }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Landmark className="h-5 w-5 text-teal-500" />
            {t('admin.settlements')}
          </CardTitle>
          <CardDescription>{t('admin.settlementsDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.name')}</TableHead>
                  <TableHead>{t('common.amount')}</TableHead>
                  <TableHead>{t('common.status')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('common.date')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('admin.settledAt')}</TableHead>
                  <TableHead className="text-right">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 6 }).map((_, j) => (
                        <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : settlements.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">{t('admin.noSettlements')}</TableCell></TableRow>
                ) : (
                  settlements.map(s => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">{s.user?.name ?? s.userId}</TableCell>
                      <TableCell className="font-semibold">{s.currency} {s.amount.toLocaleString()}</TableCell>
                      <TableCell><Badge className={cn('capitalize', statusColor(s.status))}>{s.status}</Badge></TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground"><span className="datetime-badge full">{formatDateTime(s.createdAt)}</span></TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{s.settledAt ? <span className="datetime-badge full">{formatDateTime(s.settledAt)}</span> : '-'}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setViewSettlement(s)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          {(s.status === 'pending' || s.status === 'processing') && (
                            <Button
                              size="sm"
                              className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white"
                              onClick={() => processSettlement(s)}
                              disabled={rowLoading[s.id]}
                            >
                              {rowLoading[s.id] ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <CheckCircle2 className="h-4 w-4 mr-1" />}
                              {t('admin.process')}
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Settlement Dialog */}
      <Dialog open={!!viewSettlement} onOpenChange={open => !open && setViewSettlement(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('admin.settlementDetails')}</DialogTitle>
          </DialogHeader>
          {viewSettlement && (
            <div className="grid gap-3 py-2">
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementId')}</span><span className="font-mono text-xs">{viewSettlement.id}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementUser')}</span><span>{viewSettlement.user?.name ?? viewSettlement.userId}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementEmail')}</span><span>{viewSettlement.user?.email ?? t('admin.na')}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementAmount')}</span><span className="font-semibold">{viewSettlement.currency} {viewSettlement.amount.toLocaleString()}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementStatus')}</span><Badge className={cn('capitalize', statusColor(viewSettlement.status))}>{viewSettlement.status}</Badge></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settlementCreated')}</span><span className="datetime-badge full">{formatDateTime(viewSettlement.createdAt)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('admin.settledAt')}</span><span>{viewSettlement.settledAt ? <span className="datetime-badge full">{formatDateTime(viewSettlement.settledAt)}</span> : t('admin.notSettled')}</span></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// TAB 4: DISPUTE MANAGEMENT
// ============================================================

function DisputeManagementTab() {
  const t = useT();
  const [disputes, setDisputes] = useState<DisputeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});

  // Create dispute dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [createTxnId, setCreateTxnId] = useState('');
  const [createUserId, setCreateUserId] = useState('');
  const [createReason, setCreateReason] = useState('');
  const [creating, setCreating] = useState(false);

  // Resolve dispute dialog
  const [resolveDispute, setResolveDispute] = useState<DisputeItem | null>(null);
  const [resolveStatus, setResolveStatus] = useState('');
  const [resolveResolution, setResolveResolution] = useState('');
  const [resolving, setResolving] = useState(false);

  // For create dialog: fetch transactions and users
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [users, setUsers] = useState<UserItem[]>([]);

  const fetchDisputes = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/disputes?limit=100');
      const json = await res.json();
      if (res.ok) setDisputes(json.disputes ?? []);
      else toast.error(json.error || t('admin.failedToLoad'));
    } catch { toast.error(t('admin.failedToLoad')); }
    finally { setLoading(false); }
  }, [t]);

  useEffect(() => { fetchDisputes(); }, [fetchDisputes]);

  const openCreate = async () => {
    setCreateOpen(true);
    setCreateTxnId('');
    setCreateUserId('');
    setCreateReason('');
    try {
      const [txRes, uRes] = await Promise.all([
        apiFetch('/api/transactions?limit=50'),
        apiFetch('/api/users?limit=100'),
      ]);
      const txJson = await txRes.json();
      const uJson = await uRes.json();
      if (txRes.ok) setTransactions(txJson.transactions ?? []);
      if (uRes.ok) setUsers(uJson.users ?? []);
    } catch { /* silent */ }
  };

  const createDispute = async () => {
    if (!createTxnId || !createUserId || !createReason.trim()) {
      toast.error(t('admin.allFieldsRequired'));
      return;
    }
    setCreating(true);
    try {
      const res = await apiFetch('/api/disputes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactionId: createTxnId, userId: createUserId, reason: createReason.trim() }),
      });
      if (res.ok) {
        toast.success(t('admin.disputeCreated'));
        setCreateOpen(false);
        fetchDisputes();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failedToCreateDispute'));
      }
    } catch { toast.error(t('admin.failedToCreateDispute')); }
    finally { setCreating(false); }
  };

  const openResolve = (d: DisputeItem) => {
    setResolveDispute(d);
    setResolveStatus('resolved');
    setResolveResolution('');
  };

  const resolveDisputeAction = async () => {
    if (!resolveDispute) return;
    if (!resolveResolution.trim()) {
      toast.error(t('admin.resolutionRequired'));
      return;
    }
    setResolving(true);
    setActionLoading(p => ({ ...p, [resolveDispute.id]: true }));
    try {
      const res = await apiFetch('/api/disputes', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: resolveDispute.id, status: resolveStatus, resolution: resolveResolution.trim() }),
      });
      if (res.ok) {
        toast.success(t('admin.disputeResolved'));
        setResolveDispute(null);
        fetchDisputes();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failedToResolveDispute'));
      }
    } catch { toast.error(t('admin.failedToResolveDispute')); }
    finally { setResolving(false); setActionLoading(p => ({ ...p, [resolveDispute.id]: false })); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          {t('admin.disputes')}
        </h3>
        <Button onClick={openCreate} className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="h-4 w-4 mr-2" /> {t('admin.newDispute')}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.name')}</TableHead>
                  <TableHead>{t('admin.reason')}</TableHead>
                  <TableHead>{t('common.status')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('admin.resolution')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('common.date')}</TableHead>
                  <TableHead className="text-right">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 6 }).map((_, j) => (
                        <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : disputes.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">{t('admin.noDisputes')}</TableCell></TableRow>
                ) : (
                  disputes.map(d => (
                    <TableRow key={d.id}>
                      <TableCell className="font-medium">{d.user?.name ?? d.userId}</TableCell>
                      <TableCell className="max-w-[200px] truncate text-sm">{d.reason}</TableCell>
                      <TableCell><Badge className={cn('capitalize', statusColor(d.status))}>{d.status.replace('_', ' ')}</Badge></TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground max-w-[150px] truncate">{d.resolution ?? '-'}</TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground"><span className="datetime-badge full">{formatDateTime(d.createdAt)}</span></TableCell>
                      <TableCell className="text-right">
                        {(d.status === 'open' || d.status === 'under_review') && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="btn-responsive"
                            onClick={() => openResolve(d)}
                            disabled={actionLoading[d.id]}
                          >
                            {actionLoading[d.id] ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <ShieldCheck className="h-4 w-4 mr-1" />}
                            {t('admin.resolve')}
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create Dispute Dialog */}
      <Dialog open={createOpen} onOpenChange={open => !open && setCreateOpen(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('admin.createDispute')}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>{t('admin.transactionId')}</Label>
              <Select value={createTxnId} onValueChange={setCreateTxnId}>
                <SelectTrigger><SelectValue placeholder={t('admin.selectTransaction')} /></SelectTrigger>
                <SelectContent>
                  {transactions.map(tx => (
                    <SelectItem key={tx.id} value={tx.id}>
                      {tx.reference} - {tx.type} - {tx.currency} {tx.amount.toLocaleString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.userId')}</Label>
              <Select value={createUserId} onValueChange={setCreateUserId}>
                <SelectTrigger><SelectValue placeholder={t('admin.selectUser')} /></SelectTrigger>
                <SelectContent>
                  {users.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.name} ({u.email})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.reasonLabel')}</Label>
              <Textarea
                value={createReason}
                onChange={e => setCreateReason(e.target.value)}
                placeholder={t('admin.enterReason')}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>{t('common.cancel')}</Button>
            <Button onClick={createDispute} disabled={creating} className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white">
              {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('admin.createDispute')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Resolve Dispute Dialog */}
      <Dialog open={!!resolveDispute} onOpenChange={open => !open && setResolveDispute(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('admin.resolveDispute')}</DialogTitle>
          </DialogHeader>
          {resolveDispute && (
            <div className="grid gap-4 py-4">
              <div className="rounded-lg bg-muted p-3 space-y-1">
                <p className="text-sm"><span className="text-muted-foreground">{t('admin.resolveUserLabel')}:</span> {resolveDispute.user?.name}</p>
                <p className="text-sm"><span className="text-muted-foreground">{t('admin.resolveReasonLabel')}:</span> {resolveDispute.reason}</p>
                <p className="text-sm"><span className="text-muted-foreground">{t('admin.resolveCreatedLabel')}:</span> <span className="datetime-badge full">{formatDateTime(resolveDispute.createdAt)}</span></p>
              </div>
              <div className="grid gap-2">
                <Label>{t('admin.resolveStatusLabel')}</Label>
                <Select value={resolveStatus} onValueChange={setResolveStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="resolved">{t('admin.resolveResolved')}</SelectItem>
                    <SelectItem value="closed">{t('admin.resolveClosed')}</SelectItem>
                    <SelectItem value="under_review">{t('admin.resolveUnderReview')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>{t('admin.resolveDescriptionLabel')}</Label>
                <Textarea
                  value={resolveResolution}
                  onChange={e => setResolveResolution(e.target.value)}
                  placeholder={t('admin.enterResolution')}
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setResolveDispute(null)}>{t('common.cancel')}</Button>
            <Button onClick={resolveDisputeAction} disabled={resolving} className="btn-responsive">
              {resolving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('admin.resolving')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// TAB 5: FEE & COMMISSION MANAGEMENT
// ============================================================

function FeeManagementTab() {
  const t = useT();
  const [fees, setFees] = useState<FeeConfigItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [rowLoading, setRowLoading] = useState<Record<string, boolean>>({});

  // Edit dialog
  const [editFee, setEditFee] = useState<FeeConfigItem | null>(null);
  const [editFeeType, setEditFeeType] = useState('');
  const [editFeeValue, setEditFeeValue] = useState('');
  const [editMinFee, setEditMinFee] = useState('');
  const [editMaxFee, setEditMaxFee] = useState('');
  const [editPaymentMethod, setEditPaymentMethod] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [newTxnType, setNewTxnType] = useState('');
  const [newFeeType, setNewFeeType] = useState('');
  const [newFeeValue, setNewFeeValue] = useState('');
  const [newMinFee, setNewMinFee] = useState('');
  const [newMaxFee, setNewMaxFee] = useState('');
  const [newPaymentMethod, setNewPaymentMethod] = useState('');
  const [creating, setCreating] = useState(false);

  const fetchFees = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/fee-configs');
      const json = await res.json();
      if (res.ok) setFees(Array.isArray(json) ? json : []);
      else toast.error(json.error || t('admin.failedToLoadFeeConfigs'));
    } catch { toast.error(t('admin.failedToLoadFeeConfigs')); }
    finally { setLoading(false); }
  }, [t]);

  useEffect(() => { fetchFees(); }, [fetchFees]);

  const toggleActive = async (f: FeeConfigItem) => {
    setRowLoading(p => ({ ...p, [f.id]: true }));
    try {
      const res = await apiFetch('/api/fee-configs', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: f.id, isActive: !f.isActive }),
      });
      if (res.ok) {
        toast.success(f.isActive ? t('admin.feeConfigDeactivated') : t('admin.feeConfigActivated'));
        fetchFees();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failed'));
      }
    } catch { toast.error(t('admin.failed')); }
    finally { setRowLoading(p => ({ ...p, [f.id]: false })); }
  };

  const openEdit = (f: FeeConfigItem) => {
    setEditFee(f);
    setEditFeeType(f.feeType);
    setEditFeeValue(String(f.feeValue));
    setEditMinFee(String(f.minFee ?? 0));
    setEditMaxFee(f.maxFee !== null ? String(f.maxFee) : '');
    setEditPaymentMethod(f.paymentMethod ?? '');
  };

  const saveEdit = async () => {
    if (!editFee) return;
    setSavingEdit(true);
    try {
      const body: Record<string, unknown> = {
        id: editFee.id,
        feeType: editFeeType,
        feeValue: parseFloat(editFeeValue),
        minFee: parseFloat(editMinFee) || 0,
        paymentMethod: editPaymentMethod || null,
      };
      if (editMaxFee) body.maxFee = parseFloat(editMaxFee);
      else body.maxFee = null;

      const res = await apiFetch('/api/fee-configs', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        toast.success(t('admin.feeConfigUpdated'));
        setEditFee(null);
        fetchFees();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failed'));
      }
    } catch { toast.error(t('admin.failed')); }
    finally { setSavingEdit(false); }
  };

  const createFee = async () => {
    if (!newTxnType || !newFeeType || !newFeeValue) {
      toast.error(t('admin.feeFieldsRequired'));
      return;
    }
    setCreating(true);
    try {
      const body: Record<string, unknown> = {
        transactionType: newTxnType,
        feeType: newFeeType,
        feeValue: parseFloat(newFeeValue),
        minFee: parseFloat(newMinFee) || 0,
        paymentMethod: newPaymentMethod || null,
      };
      if (newMaxFee) body.maxFee = parseFloat(newMaxFee);

      const res = await apiFetch('/api/fee-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        toast.success(t('admin.feeConfigCreated'));
        setCreateOpen(false);
        fetchFees();
      } else {
        const j = await res.json();
        toast.error(j.error || t('admin.failed'));
      }
    } catch { toast.error(t('admin.failed')); }
    finally { setCreating(false); }
  };

  const TXN_TYPES = ['transfer', 'deposit', 'withdrawal', 'payment', 'escrow', 'split_payment', 'commission', 'refund', 'chargeback', 'reversal'];
  const FEE_TYPES = ['flat', 'percentage', 'tiered'];
  const PAYMENT_METHODS = ['bank_account', 'debit_card', 'credit_card', 'mobile_money', 'digital_wallet', 'qr_code'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Settings2 className="h-5 w-5 text-teal-500" />
          {t('admin.feeConfigTitle')}
        </h3>
        <Button onClick={() => { setNewTxnType(''); setNewFeeType(''); setNewFeeValue(''); setNewMinFee(''); setNewMaxFee(''); setNewPaymentMethod(''); setCreateOpen(true); }} className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="h-4 w-4 mr-2" /> {t('admin.newFeeConfig')}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.type')}</TableHead>
                  <TableHead>{t('admin.feeType')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('admin.paymentMethod')}</TableHead>
                  <TableHead>{t('common.active')}</TableHead>
                  <TableHead className="text-right">{t('common.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 5 }).map((_, j) => (
                        <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : fees.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">{t('admin.noFeeConfigs')}</TableCell></TableRow>
                ) : (
                  fees.map(f => (
                    <TableRow key={f.id} className={cn(!f.isActive && 'opacity-60')}>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">{f.transactionType}</Badge>
                      </TableCell>
                      <TableCell className="font-medium">
                        {f.feeType === 'percentage' ? `${f.feeValue}%` : `${f.feeValue} ${f.currency}`}
                        {f.minFee ? <span className="text-xs text-muted-foreground ml-1">{t('admin.minLabel')} {f.minFee}</span> : null}
                        {f.maxFee ? <span className="text-xs text-muted-foreground ml-1">{t('admin.maxLabel')} {f.maxFee}</span> : null}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">{f.paymentMethod ?? t('common.all')}</TableCell>
                      <TableCell>
                        <Button
                          size="icon" variant="ghost" className={cn('h-8 w-8', f.isActive ? 'text-emerald-600 hover:text-emerald-700' : 'text-rose-600 hover:text-rose-700')}
                          onClick={() => toggleActive(f)}
                          disabled={rowLoading[f.id]}
                        >
                          {rowLoading[f.id] ? <Loader2 className="h-4 w-4 animate-spin" /> : f.isActive ? <Power className="h-4 w-4" /> : <PowerOff className="h-4 w-4" />}
                        </Button>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(f)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Fee Dialog */}
      <Dialog open={!!editFee} onOpenChange={open => !open && setEditFee(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('admin.editFeeConfig')}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>{t('admin.feeType')}</Label>
              <Select value={editFeeType} onValueChange={setEditFeeType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{FEE_TYPES.map(ft => <SelectItem key={ft} value={ft} className="capitalize">{ft}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.feeValue')}</Label>
              <Input type="number" step="any" value={editFeeValue} onChange={e => setEditFeeValue(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>{t('admin.minFee')}</Label>
                <Input type="number" step="any" value={editMinFee} onChange={e => setEditMinFee(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>{t('admin.maxFee')}</Label>
                <Input type="number" step="any" value={editMaxFee} onChange={e => setEditMaxFee(e.target.value)} placeholder={t('admin.noLimit')} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.paymentMethod')}</Label>
              <Select value={editPaymentMethod} onValueChange={setEditPaymentMethod}>
                <SelectTrigger><SelectValue placeholder={t('admin.allMethods')} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t('admin.allMethods')}</SelectItem>
                  {PAYMENT_METHODS.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setEditFee(null)}>{t('common.cancel')}</Button>
            <Button onClick={saveEdit} disabled={savingEdit} className="btn-responsive">
              {savingEdit && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Fee Dialog */}
      <Dialog open={createOpen} onOpenChange={open => !open && setCreateOpen(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('admin.createFeeConfig')}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>{t('common.type')}</Label>
              <Select value={newTxnType} onValueChange={setNewTxnType}>
                <SelectTrigger><SelectValue placeholder={t('admin.selectType')} /></SelectTrigger>
                <SelectContent>{TXN_TYPES.map(tt => <SelectItem key={tt} value={tt}>{tt.replace('_', ' ')}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.feeType')}</Label>
              <Select value={newFeeType} onValueChange={setNewFeeType}>
                <SelectTrigger><SelectValue placeholder={t('admin.selectFeeType')} /></SelectTrigger>
                <SelectContent>{FEE_TYPES.map(ft => <SelectItem key={ft} value={ft} className="capitalize">{ft}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.feeValue')}</Label>
              <Input type="number" step="any" value={newFeeValue} onChange={e => setNewFeeValue(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>{t('admin.minFee')}</Label>
                <Input type="number" step="any" value={newMinFee} onChange={e => setNewMinFee(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>{t('admin.maxFee')}</Label>
                <Input type="number" step="any" value={newMaxFee} onChange={e => setNewMaxFee(e.target.value)} placeholder={t('admin.noLimit')} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>{t('admin.paymentMethodOptional')}</Label>
              <Select value={newPaymentMethod} onValueChange={setNewPaymentMethod}>
                <SelectTrigger><SelectValue placeholder={t('admin.allMethods')} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t('admin.allMethods')}</SelectItem>
                  {PAYMENT_METHODS.map(m => <SelectItem key={m} value={m}>{m.replace('_', ' ')}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="btn-responsive-group">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>{t('common.cancel')}</Button>
            <Button onClick={createFee} disabled={creating} className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white">
              {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('admin.create')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// TAB 6: COMMISSION DISTRIBUTION
// ============================================================

function CommissionDistributionTab() {
  const t = useT();
  const [commissions, setCommissions] = useState<TransactionItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCommissions = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/transactions?type=commission&limit=200');
      const json = await res.json();
      if (res.ok) setCommissions(json.transactions ?? []);
      else toast.error(json.error || t('admin.failedToLoadCommissions'));
    } catch { toast.error(t('admin.failedToLoadCommissions')); }
    finally { setLoading(false); }
  }, [t]);

  useEffect(() => { fetchCommissions(); }, [fetchCommissions]);

  const totalPaid = commissions.filter(c => c.status === 'completed').reduce((s, c) => s + c.amount, 0);
  const totalPending = commissions.filter(c => c.status === 'pending' || c.status === 'processing').reduce((s, c) => s + c.amount, 0);
  const thisMonthCommissions = commissions.filter(c => isThisMonth(new Date(c.createdAt)));
  const thisMonthTotal = thisMonthCommissions.reduce((s, c) => s + c.amount, 0);

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-emerald-100 dark:bg-emerald-900/40 p-2.5">
                  <DollarSign className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('admin.totalPaid')}</p>
                  <p className="text-xl font-bold">ETB {totalPaid.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-amber-100 dark:bg-amber-900/40 p-2.5">
                  <DollarSign className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('admin.totalPending')}</p>
                  <p className="text-xl font-bold">ETB {totalPending.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-teal-100 dark:bg-teal-900/40 p-2.5">
                  <DollarSign className="h-5 w-5 text-teal-600 dark:text-teal-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('admin.thisMonth')}</p>
                  <p className="text-xl font-bold">ETB {thisMonthTotal.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-emerald-500" />
            {t('admin.commissionTransactions')}
          </CardTitle>
          <CardDescription>{t('admin.allCommissionTransactions')}</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.reference')}</TableHead>
                  <TableHead>{t('common.amount')}</TableHead>
                  <TableHead className="hidden md:table-cell">{t('admin.initiator')}</TableHead>
                  <TableHead>{t('common.status')}</TableHead>
                  <TableHead className="hidden lg:table-cell">{t('common.date')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 5 }).map((_, j) => (
                        <TableCell key={j}><Skeleton className="h-5 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : commissions.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">{t('admin.noCommissionTransactions')}</TableCell></TableRow>
                ) : (
                  commissions.map(c => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono text-xs">{c.reference}</TableCell>
                      <TableCell className="font-semibold">{c.currency} {c.amount.toLocaleString()}</TableCell>
                      <TableCell className="hidden md:table-cell text-sm">{c.initiatorName ?? t('admin.na')}</TableCell>
                      <TableCell><Badge className={cn('capitalize', statusColor(c.status))}>{c.status}</Badge></TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground"><span className="datetime-badge full">{formatDateTime(c.createdAt)}</span></TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================
// ROLE HIERARCHY CARD
// ============================================================

function RoleHierarchyCard({ currentRole }: { currentRole: string }) {
  const isSAorAdmin = isSuperAdmin(currentRole) || isAdministrator(currentRole);

  if (!isSAorAdmin) return null;

  const treeNode = (roleKey: string, indent: number, isCurrent: boolean) => {
    const info = ROLE_DEFINITIONS[roleKey as keyof typeof ROLE_DEFINITIONS];
    if (!info) return null;
    const isCur = roleKey === currentRole;
    return (
      <div
        key={roleKey}
        className={cn(
          'flex items-center gap-2 py-1 px-2 rounded-md text-sm transition-colors',
          isCur && 'bg-emerald-100 dark:bg-emerald-900/30 font-semibold text-emerald-800 dark:text-emerald-300',
          !isCur && 'text-muted-foreground',
        )}
        style={{ paddingLeft: `${indent * 20 + 8}px` }}
      >
        {indent > 0 && (
          <span className="text-muted-foreground/60 text-xs">{'└─'}</span>
        )}
        <span className={isCur ? 'text-emerald-700 dark:text-emerald-300' : ''}>{info.label}</span>
        <Badge variant="outline" className="text-[10px] px-1.5 py-0 font-mono">L{info.level}</Badge>
        {isCur && (
          <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0 rounded-full ml-auto">You</span>
        )}
      </div>
    );
  };

  return (
    <Card className="border-dashed">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-emerald-600" />
          Role Hierarchy
        </CardTitle>
        <CardDescription className="text-xs">Permission levels across the organization. Your role is highlighted.</CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-0.5 font-mono text-xs">
          {treeNode('super_admin', 0, false)}
          {treeNode('administrator', 1, false)}
          {treeNode('finance_manager', 2, false)}
          {treeNode('compliance_auditor', 2, false)}
          {treeNode('customer_support', 2, false)}
          <div className="text-muted-foreground/50 text-xs py-0.5" style={{ paddingLeft: '28px' }}>└─ Business Roles</div>
          {treeNode('merchant', 2, false)}
          {treeNode('seller', 2, false)}
          {treeNode('buyer', 2, false)}
          {treeNode('agent', 2, false)}
          <div className="text-muted-foreground/50 text-xs py-0.5" style={{ paddingLeft: '28px' }}>└─ Operational</div>
          {treeNode('warehouse_manager', 2, false)}
          {treeNode('delivery', 2, false)}
          {treeNode('user', 2, false)}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// MAIN ADMIN VIEW
// ============================================================

export default function AdminView() {
  const { formatDate, formatDateTime } = useFormattedDate();
  const t = useT();
  const currentUser = useAppStore(s => s.user);
  const userRole = currentUser?.role ?? 'user';
  const roleLevel = getRoleLevel(userRole);
  const [activeTab, setActiveTab] = useState('users');

  const allTabs = [
    { value: 'users', label: t('admin.tabUsers'), icon: Users, minLevel: 45 },
    { value: 'approvals', label: t('admin.tabApprovals'), icon: ClipboardCheck, minLevel: 60 },
    { value: 'settlements', label: t('admin.tabSettlements'), icon: Landmark, minLevel: 60 },
    { value: 'disputes', label: t('admin.tabDisputes'), icon: AlertTriangle, minLevel: 45 },
    { value: 'fees', label: t('admin.tabFees'), icon: Settings2, minLevel: 80 },
    { value: 'commissions', label: t('admin.tabCommissions'), icon: DollarSign, minLevel: 60 },
  ];

  const tabs = allTabs.filter(tab => roleLevel >= tab.minLevel);

  // Derive effective tab: if current active tab is no longer visible, fall back to first visible
  const effectiveTab = tabs.some(tab => tab.value === activeTab) ? activeTab : tabs[0]?.value ?? 'users';

  // Access control
  if (!currentUser || !canViewAdmin(userRole)) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 rounded-full bg-rose-100 dark:bg-rose-900/30 p-3 w-fit">
              <Lock className="h-6 w-6 text-rose-600 dark:text-rose-400" />
            </div>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>
              You do not have the required privileges to access the admin panel.
              Your current role is <span className="font-semibold capitalize">{getRoleInfo(userRole).label}</span> (Level {getRoleLevel(userRole)}).
              Admin access requires Level 45 or above.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <ShieldCheck className="h-6 w-6 text-emerald-600" />
          {t('common.adminPanel')}
        </h2>
        <p className="text-muted-foreground">{t('admin.panelDescription')}</p>
      </div>

      {/* Role Hierarchy Card */}
      <RoleHierarchyCard currentRole={userRole} />

      <Tabs value={effectiveTab} onValueChange={setActiveTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted p-1">
          {tabs.map(tab => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm"
            >
              <tab.icon className="h-4 w-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        <AnimatePresence mode="wait">
          <motion.div
            key={effectiveTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="mt-4"
          >
            <TabsContent value="users" forceMount={effectiveTab === 'users'}>
              {effectiveTab === 'users' && <UserManagementTab />}
            </TabsContent>
            <TabsContent value="approvals" forceMount={effectiveTab === 'approvals'}>
              {effectiveTab === 'approvals' && <PaymentApprovalsTab />}
            </TabsContent>
            <TabsContent value="settlements" forceMount={effectiveTab === 'settlements'}>
              {effectiveTab === 'settlements' && <SettlementManagementTab />}
            </TabsContent>
            <TabsContent value="disputes" forceMount={effectiveTab === 'disputes'}>
              {effectiveTab === 'disputes' && <DisputeManagementTab />}
            </TabsContent>
            <TabsContent value="fees" forceMount={effectiveTab === 'fees'}>
              {effectiveTab === 'fees' && <FeeManagementTab />}
            </TabsContent>
            <TabsContent value="commissions" forceMount={effectiveTab === 'commissions'}>
              {effectiveTab === 'commissions' && <CommissionDistributionTab />}
            </TabsContent>
          </motion.div>
        </AnimatePresence>
      </Tabs>
    </div>
  );
}
