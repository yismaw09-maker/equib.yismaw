'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Activity,
  ArrowRightLeft,
  Shield,
  Settings,
  Search,
  Filter,
  Clock,
  User,
  CreditCard,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Loader2,
  RotateCcw,
  Inbox,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface AuditLog {
  id: string;
  userId: string | null;
  action: string;
  resource: string;
  resourceId: string | null;
  details: string | null;
  ipAddress: string | null;
  createdAt: string;
  user?: { id: string; name: string; email: string } | null;
}

// --- Helpers ---

const categoryColor: Record<string, string> = {
  transaction: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  security: 'bg-rose-100 text-rose-700 border-rose-200',
  system: 'bg-violet-100 text-violet-700 border-violet-200',
  user: 'bg-amber-100 text-amber-700 border-amber-200',
};

const categoryIconBg: Record<string, string> = {
  transaction: 'bg-emerald-500',
  security: 'bg-rose-500',
  system: 'bg-violet-500',
  user: 'bg-amber-500',
};

const getCategory = (log: AuditLog): string => {
  const r = (log.resource || '').toLowerCase();
  if (['transaction', 'transfer', 'payment', 'withdrawal', 'deposit'].some((t) => r.includes(t))) return 'transaction';
  if (['session', 'login', 'password', '2fa', 'mfa', 'security', 'device'].some((t) => r.includes(t))) return 'security';
  if (['user', 'kyc', 'profile', 'role'].some((t) => r.includes(t))) return 'user';
  return 'system';
};

const getActionBadgeColor = (action: string): string => {
  const upper = action.toUpperCase();
  if (upper.includes('CREATE') || upper.includes('APPROVE') || upper.startsWith('COMPLETE'))
    return 'bg-emerald-100 text-emerald-700 border-emerald-200';
  if (upper.includes('DELETE') || upper.includes('REJECT') || upper.includes('FAIL') || upper.includes('BLOCK'))
    return 'bg-rose-100 text-rose-700 border-rose-200';
  if (upper.includes('UPDATE') || upper.includes('LOGIN') || upper.includes('VERIF'))
    return 'bg-amber-100 text-amber-700 border-amber-200';
  return 'bg-gray-100 text-gray-600 border-gray-200';
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.04 } },
};

const MOCK_LOGS: AuditLog[] = [
  { id: '1', userId: 'u1', action: 'CREATE', resource: 'Transaction', resourceId: 'tx-001', details: 'Transfer of ETB 5,000 to merchant account', ipAddress: '192.168.1.10', createdAt: new Date(Date.now() - 1000 * 60 * 2).toISOString(), user: { id: 'u1', name: 'Tigist Haile', email: 'tigist@example.com' } },
  { id: '2', userId: 'u2', action: 'LOGIN', resource: 'Session', resourceId: 'sess-042', details: 'Successful login from mobile device', ipAddress: '10.0.0.55', createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(), user: { id: 'u2', name: 'Dawit Amare', email: 'dawit@example.com' } },
  { id: '3', userId: 'u3', action: 'UPDATE', resource: 'User', resourceId: 'u3', details: 'KYC status updated to verified', ipAddress: '172.16.0.1', createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), user: { id: 'u3', name: 'Yohannes Girma', email: 'yohannes@example.com' } },
  { id: '4', userId: 'u4', action: 'CREATE', resource: 'Withdrawal', resourceId: 'wd-088', details: 'Withdrawal request of ETB 20,000 to bank account', ipAddress: '192.168.1.22', createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(), user: { id: 'u4', name: 'Helen Mengistu', email: 'helen@example.com' } },
  { id: '5', userId: null, action: 'SYSTEM', resource: 'System', resourceId: null, details: 'Automated AML screening completed — 3 transactions flagged', ipAddress: null, createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(), user: null },
  { id: '6', userId: 'u5', action: 'DELETE', resource: 'Device', resourceId: 'dev-012', details: 'Revoked trusted device session', ipAddress: '192.168.1.45', createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(), user: { id: 'u5', name: 'Sara Tadesse', email: 'sara@example.com' } },
  { id: '7', userId: 'u1', action: 'UPDATE', resource: 'Password', resourceId: null, details: 'Password changed successfully', ipAddress: '192.168.1.10', createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(), user: { id: 'u1', name: 'Tigist Haile', email: 'tigist@example.com' } },
  { id: '8', userId: null, action: 'SYSTEM', resource: 'System', resourceId: null, details: 'Scheduled backup completed successfully', ipAddress: null, createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(), user: null },
  { id: '9', userId: 'u2', action: 'CREATE', resource: 'Payment', resourceId: 'pay-210', details: 'Payment of ETB 3,500 to Merkato Electronics', ipAddress: '10.0.0.55', createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(), user: { id: 'u2', name: 'Dawit Amare', email: 'dawit@example.com' } },
  { id: '10', userId: 'u6', action: 'REJECT', resource: 'KYC', resourceId: 'kyc-044', details: 'KYC document rejected — blurry ID photo', ipAddress: '172.16.0.5', createdAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(), user: { id: 'u6', name: 'Selamawit Fikadu', email: 'selamawit@example.com' } },
];

// --- Component ---

export default function ActivityCenterView() {
  const { formatDateTime, formatRelative } = useFormattedDate();

  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('all');

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/audit-logs?limit=100');
      if (res.ok) {
        const data = await res.json();
        setLogs(Array.isArray(data) ? data : data.logs || data.data || []);
      } else {
        setLogs(MOCK_LOGS);
      }
    } catch {
      setLogs(MOCK_LOGS);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const filteredLogs = useMemo(() => {
    let result = logs;

    // Tab filter
    if (activeTab !== 'all') {
      result = result.filter((log) => {
        const cat = getCategory(log);
        if (activeTab === 'transactions') return cat === 'transaction';
        if (activeTab === 'security') return cat === 'security';
        if (activeTab === 'system') return cat === 'system';
        return true;
      });
    }

    // Type filter
    if (typeFilter !== 'all') {
      const upper = typeFilter.toUpperCase();
      result = result.filter((log) => log.action.toUpperCase().includes(upper));
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (log) =>
          (log.details || '').toLowerCase().includes(q) ||
          (log.action || '').toLowerCase().includes(q) ||
          (log.resource || '').toLowerCase().includes(q) ||
          (log.user?.name || '').toLowerCase().includes(q) ||
          (log.user?.email || '').toLowerCase().includes(q),
      );
    }

    return result;
  }, [logs, activeTab, typeFilter, searchQuery]);

  const stats = useMemo(() => {
    const txCount = logs.filter((l) => getCategory(l) === 'transaction').length;
    const secCount = logs.filter((l) => getCategory(l) === 'security').length;
    const sysCount = logs.filter((l) => getCategory(l) === 'system').length;
    return { total: logs.length, transactions: txCount, security: secCount, system: sysCount };
  }, [logs]);

  const renderTimelineIcon = (log: AuditLog) => {
    const cat = getCategory(log);
    const bg = categoryIconBg[cat] || 'bg-gray-500';
    const IconComponent =
      cat === 'transaction' ? CreditCard : cat === 'security' ? Shield : cat === 'user' ? User : Settings;
    return (
      <div className={cn('h-9 w-9 rounded-full flex items-center justify-center shrink-0', bg)}>
        <IconComponent className="h-4 w-4 text-white" />
      </div>
    );
  };

  const renderLoadingSkeleton = () => (
    <div className="space-y-3 p-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="flex items-start gap-4">
          <Skeleton className="h-9 w-9 rounded-full shrink-0" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
          <Skeleton className="h-3 w-20 shrink-0" />
        </div>
      ))}
    </div>
  );

  const renderEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Inbox className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium">No activity found</h3>
      <p className="text-sm text-muted-foreground mt-1">No activity matches your current filters. Try adjusting your search or filters.</p>
      <Button variant="outline" className="mt-4" onClick={() => { setSearchQuery(''); setTypeFilter('all'); }}>
        <RotateCcw className="h-4 w-4 mr-2" /> Reset Filters
      </Button>
    </div>
  );

  const renderTimelineList = (items: AuditLog[]) => (
    <ScrollArea className="max-h-[600px]">
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-[18px] top-0 bottom-0 w-px bg-border" />
        <motion.div className="space-y-1" variants={stagger} initial="initial" animate="animate">
          {items.map((log, idx) => (
            <motion.div
              key={log.id}
              variants={fadeUp}
              className="relative flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="relative z-10 mt-0.5">{renderTimelineIcon(log)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className={getActionBadgeColor(log.action)}>
                    {log.action}
                  </Badge>
                  <Badge variant="outline" className={categoryColor[getCategory(log)] || 'bg-gray-100 text-gray-600 border-gray-200'}>
                    {log.resource}
                  </Badge>
                </div>
                <p className="text-sm mt-1.5 text-foreground/90 leading-relaxed">{log.details || 'No details'}</p>
                {log.user && (
                  <div className="flex items-center gap-1.5 mt-1.5 text-xs text-muted-foreground">
                    <User className="h-3 w-3" />
                    <span>{log.user.name}</span>
                    {log.user.email && <span className="text-muted-foreground/60">· {log.user.email}</span>}
                  </div>
                )}
                {log.ipAddress && (
                  <span className="text-xs text-muted-foreground/60 mt-0.5 block font-mono">IP: {log.ipAddress}</span>
                )}
              </div>
              <div className="shrink-0 text-right">
                <span className="text-xs text-muted-foreground whitespace-nowrap block" title={formatDateTime(log.createdAt)}>
                  {formatRelative(log.createdAt)}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </ScrollArea>
  );

  const renderTableView = (items: AuditLog[]) => (
    <ScrollArea className="max-h-[600px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Action</TableHead>
            <TableHead>Resource</TableHead>
            <TableHead className="min-w-[250px]">Details</TableHead>
            <TableHead>User</TableHead>
            <TableHead className="w-[140px]">Time</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((log) => (
            <TableRow key={log.id}>
              <TableCell>
                <Badge variant="outline" className={getActionBadgeColor(log.action)}>
                  {log.action}
                </Badge>
              </TableCell>
              <TableCell>
                <Badge variant="outline" className={categoryColor[getCategory(log)]}>
                  {log.resource}
                </Badge>
              </TableCell>
              <TableCell className="text-sm">{log.details || '—'}</TableCell>
              <TableCell className="text-sm">{log.user?.name || '—'}</TableCell>
              <TableCell className="text-xs text-muted-foreground" title={formatDateTime(log.createdAt)}>
                {formatRelative(log.createdAt)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </ScrollArea>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <Activity className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Activity Center</h1>
            <p className="text-sm text-muted-foreground">Track all recent activity across the platform</p>
          </div>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-emerald-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Events</p>
                <p className="text-2xl font-bold text-emerald-600">{stats.total}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center">
                <Activity className="h-4 w-4 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Transactions</p>
                <p className="text-2xl font-bold text-teal-600">{stats.transactions}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-teal-100 flex items-center justify-center">
                <ArrowRightLeft className="h-4 w-4 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-rose-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Security</p>
                <p className="text-2xl font-bold text-rose-600">{stats.security}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center">
                <Shield className="h-4 w-4 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-violet-200/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">System</p>
                <p className="text-2xl font-bold text-violet-600">{stats.system}</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-violet-100 flex items-center justify-center">
                <Settings className="h-4 w-4 text-violet-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Search & Filter Bar */}
      <motion.div {...fadeUp} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search activity by description, user, action..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Action type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Actions</SelectItem>
            <SelectItem value="CREATE">Create</SelectItem>
            <SelectItem value="UPDATE">Update</SelectItem>
            <SelectItem value="DELETE">Delete</SelectItem>
            <SelectItem value="LOGIN">Login</SelectItem>
            <SelectItem value="SYSTEM">System</SelectItem>
            <SelectItem value="REJECT">Reject</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchLogs} title="Refresh">
          <RotateCcw className="h-4 w-4" />
        </Button>
      </motion.div>

      {/* Main Card with Tabs */}
      <motion.div {...fadeUp}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Recent Activity</CardTitle>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                {filteredLogs.length} events
              </Badge>
            </div>
            <CardDescription>View and filter platform activity in real-time</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all" className="gap-1.5">
                  <Activity className="h-3.5 w-3.5" /> All Activity
                </TabsTrigger>
                <TabsTrigger value="transactions" className="gap-1.5">
                  <CreditCard className="h-3.5 w-3.5" /> Transactions
                </TabsTrigger>
                <TabsTrigger value="security" className="gap-1.5">
                  <Shield className="h-3.5 w-3.5" /> Security
                </TabsTrigger>
                <TabsTrigger value="system" className="gap-1.5">
                  <Settings className="h-3.5 w-3.5" /> System
                </TabsTrigger>
              </TabsList>

              {['all', 'transactions', 'security', 'system'].map((tab) => (
                <TabsContent key={tab} value={tab}>
                  {loading ? (
                    renderLoadingSkeleton()
                  ) : filteredLogs.length === 0 ? (
                    renderEmptyState()
                  ) : tab === 'all' ? (
                    renderTimelineList(filteredLogs)
                  ) : (
                    renderTableView(filteredLogs)
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
