'use client';

import { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import {
  Bell,
  ArrowDownCircle,
  ArrowUpCircle,
  Shield,
  CreditCard,
  ArrowLeftRight,
  Wallet,
  Settings,
  CheckCheck,
  Inbox,
  Mail,
  Smartphone,
  Megaphone,
  Circle,
  Loader2,
  Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';

// --- Types ---

interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  channel: string;
  isRead: boolean;
  createdAt: string;
  user?: { id: string; name: string; email: string } | null;
}

// --- Helpers ---

const typeIcon: Record<string, React.ComponentType<{ className?: string }>> = {
  deposit: ArrowDownCircle,
  withdrawal: ArrowUpCircle,
  payment: CreditCard,
  transfer: ArrowLeftRight,
  security: Shield,
  balance: Wallet,
  system: Megaphone,
};

const typeColor: Record<string, string> = {
  deposit: 'text-emerald-600 bg-emerald-50',
  withdrawal: 'text-rose-600 bg-rose-50',
  payment: 'text-teal-600 bg-teal-50',
  transfer: 'text-amber-600 bg-amber-50',
  security: 'text-red-600 bg-red-50',
  balance: 'text-orange-600 bg-orange-50',
  system: 'text-gray-600 bg-gray-50',
};

const typeBadgeColor: Record<string, string> = {
  deposit: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  withdrawal: 'bg-rose-100 text-rose-700 border-rose-200',
  payment: 'bg-teal-100 text-teal-700 border-teal-200',
  transfer: 'bg-amber-100 text-amber-700 border-amber-200',
  security: 'bg-red-100 text-red-700 border-red-200',
  balance: 'bg-orange-100 text-orange-700 border-orange-200',
  system: 'bg-gray-100 text-gray-600 border-gray-200',
};

const channelBadgeColor: Record<string, string> = {
  in_app: 'bg-teal-50 text-teal-700 border-teal-200',
  sms: 'bg-amber-50 text-amber-700 border-amber-200',
  email: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  push: 'bg-rose-50 text-rose-700 border-rose-200',
};

const channelIcon: Record<string, React.ComponentType<{ className?: string }>> = {
  in_app: Bell,
  sms: Smartphone,
  email: Mail,
  push: Megaphone,
};

const FILTER_TABS = [
  { key: 'all', label: 'All' },
  { key: 'deposit', label: 'Deposits' },
  { key: 'withdrawal', label: 'Withdrawals' },
  { key: 'payment', label: 'Payments' },
  { key: 'transfer', label: 'Transfers' },
  { key: 'security', label: 'Security' },
  { key: 'balance', label: 'Balance' },
  { key: 'system', label: 'System' },
] as const;

type FilterTab = (typeof FILTER_TABS)[number]['key'];

// --- Component ---

export default function NotificationsView() {
  const { formatRelative } = useFormattedDate();
  // --- State ---
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<FilterTab>('all');
  const [unreadCount, setUnreadCount] = useState(0);
  const [markingAllRead, setMarkingAllRead] = useState(false);
  const [markingRead, setMarkingRead] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Notification settings (mock state)
  const [channelSettings, setChannelSettings] = useState({
    in_app: true,
    sms: true,
    email: true,
    push: false,
  });

  const [typeSettings, setTypeSettings] = useState({
    deposit: true,
    withdrawal: true,
    payment: true,
    security: true,
    balance: true,
    system: false,
  });

  // --- Fetch ---
  const fetchNotifications = useCallback(async (filter: FilterTab = activeFilter) => {
    setLoading(true);
    setSelectedIds(new Set());
    try {
      const params = filter !== 'all' ? `?type=${filter}` : '';
      const res = await apiFetch(`/api/notifications${params}`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      const notifs: Notification[] = data.notifications || data || [];
      setNotifications(notifs);
      // Use the unreadCount from the API (it's based on the current filter's where clause)
      // For the header, we want total unread, so fetch it separately for 'all'
      if (filter === 'all') {
        setUnreadCount(data.unreadCount ?? notifs.filter((n: Notification) => !n.isRead).length);
      }
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
      toast.error('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  }, [activeFilter]);

  // Fetch total unread count on mount (independent of filter)
  const fetchUnreadCount = useCallback(async () => {
    try {
      const res = await apiFetch('/api/notifications?isRead=false');
      if (!res.ok) return;
      const data = await res.json();
      setUnreadCount(data.unreadCount ?? 0);
    } catch {
      // silent
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    fetchUnreadCount();
  }, [fetchNotifications, fetchUnreadCount]);

  // --- Actions ---
  const markAsRead = async (notification: Notification) => {
    if (notification.isRead) return;
    const id = notification.id;
    setMarkingRead(id);
    // Optimistic update
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
    try {
      const res = await apiFetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: [id] }),
      });
      if (!res.ok) {
        // Revert optimistic update
        setNotifications((prev) =>
          prev.map((n) => (n.id === id ? { ...n, isRead: false } : n))
        );
        setUnreadCount((prev) => prev + 1);
        toast.error('Failed to mark notification as read');
      }
    } catch {
      // Revert optimistic update
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: false } : n))
      );
      setUnreadCount((prev) => prev + 1);
      toast.error('Network error');
    } finally {
      setMarkingRead(null);
    }
  };

  const markAllAsRead = async () => {
    if (unreadCount === 0) return;
    setMarkingAllRead(true);
    // Optimistic update
    const prevNotifications = notifications.map((n) => ({ ...n, isRead: true }));
    const prevCount = unreadCount;
    setNotifications(prevNotifications);
    setUnreadCount(0);
    try {
      const res = await apiFetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          markAll: true,
          userId: notifications[0]?.userId,
        }),
      });
      if (res.ok) {
        toast.success('All notifications marked as read');
      } else {
        // Revert
        setNotifications(notifications);
        setUnreadCount(prevCount);
        toast.error('Failed to mark all as read');
      }
    } catch {
      setNotifications(notifications);
      setUnreadCount(prevCount);
      toast.error('Network error');
    } finally {
      setMarkingAllRead(false);
    }
  };

  const handleChannelToggle = (key: string, checked: boolean) => {
    setChannelSettings((prev) => ({ ...prev, [key]: checked }));
    const labels: Record<string, string> = {
      in_app: 'In-App',
      sms: 'SMS',
      email: 'Email',
      push: 'Push',
    };
    toast.success(`${labels[key] || key} notifications ${checked ? 'enabled' : 'disabled'}`);
  };

  const handleTypeToggle = (key: string, checked: boolean) => {
    setTypeSettings((prev) => ({ ...prev, [key]: checked }));
    const labels: Record<string, string> = {
      deposit: 'Deposit',
      withdrawal: 'Withdrawal',
      payment: 'Payment',
      security: 'Security',
      balance: 'Low Balance',
      system: 'System',
    };
    toast.success(`${labels[key] || key} notifications ${checked ? 'enabled' : 'disabled'}`);
  };

  // Delete selected notifications
  const handleDeleteSelected = async () => {
    if (selectedIds.size === 0) return;
    setDeleteLoading(true);
    try {
      const res = await apiFetch('/api/notifications', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedIds) }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      toast.success(`Deleted ${data.deleted} notification${data.deleted !== 1 ? 's' : ''}`);
      setSelectedIds(new Set());
      fetchNotifications();
    } catch {
      toast.error('Failed to delete notifications');
    } finally {
      setDeleteLoading(false);
    }
  };

  // Delete all notifications
  const handleDeleteAll = async () => {
    setDeleteLoading(true);
    try {
      const res = await apiFetch('/api/notifications?deleteAll=true', { method: 'DELETE' });
      if (!res.ok) throw new Error();
      const data = await res.json();
      toast.success(`Deleted all ${data.deleted} notifications`);
      setSelectedIds(new Set());
      fetchNotifications();
    } catch {
      toast.error('Failed to delete all notifications');
    } finally {
      setDeleteLoading(false);
    }
  };

  // Select All logic
  const allSelected = notifications.length > 0 && notifications.every((n) => selectedIds.has(n.id));
  const toggleAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(notifications.map((n) => n.id)));
    }
  };
  const toggleNotification = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  // --- Computed ---
  // Count per type for tab badges (use the current notifications from API)
  const typeCounts = notifications.reduce<Record<string, number>>((acc, n) => {
    acc[n.type] = (acc[n.type] || 0) + 1;
    return acc;
  }, {});

  // --- Render ---
  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
      >
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-teal-100 flex items-center justify-center">
            <Bell className="h-5 w-5 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold">Notifications</h1>
              {unreadCount > 0 && (
                <Badge className="bg-rose-600 text-white hover:bg-rose-700">
                  {unreadCount} unread
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              Stay up to date with your transaction activity
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          onClick={markAllAsRead}
          disabled={unreadCount === 0 || markingAllRead}
          className="btn-responsive text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
        >
          {markingAllRead ? (
            <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
          ) : (
            <CheckCheck className="h-4 w-4 mr-1.5" />
          )}
          Mark All as Read
        </Button>
      </motion.div>

      {/* Filter Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.05 }}
      >
        <div className="flex flex-wrap gap-2">
          {FILTER_TABS.map((tab) => {
            const count = tab.key === 'all' ? notifications.length : (typeCounts[tab.key] || 0);
            return (
              <Button
                key={tab.key}
                variant={activeFilter === tab.key ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveFilter(tab.key)}
                className={
                  activeFilter === tab.key
                    ? 'bg-teal-600 text-white hover:bg-teal-700'
                    : ''
                }
              >
                {tab.label}
                <span className="ml-1.5 text-xs opacity-70">({count})</span>
              </Button>
            );
          })}
        </div>
      </motion.div>

      {/* Notification List */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.1 }}
      >
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="divide-y">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="p-4 flex items-start gap-3">
                    <Skeleton className="h-10 w-10 rounded-full shrink-0" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-3 w-full" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                ))}
              </div>
            ) : notifications.length === 0 ? (
              <div className="py-16 text-center">
                <Inbox className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground font-medium">No notifications found</p>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  {activeFilter !== 'all'
                    ? `No ${activeFilter} notifications to show`
                    : "You're all caught up!"}
                </p>
              </div>
            ) : (
              <>
                {/* Select All Bar */}
                <div className="flex items-center gap-3 px-4 py-2 border-b bg-muted/30 flex-wrap">
                  <Checkbox checked={allSelected} onCheckedChange={toggleAll} />
                  <span className="text-xs text-muted-foreground cursor-pointer" onClick={toggleAll}>
                    {allSelected ? 'Deselect All' : 'Select All'} ({notifications.length})
                  </span>
                  <div className="flex items-center gap-2 ml-auto">
                    {selectedIds.size > 0 && (
                      <>
                        <span className="text-xs text-muted-foreground">{selectedIds.size} selected</span>
                        <Button variant="destructive" size="sm" className="h-7 text-xs" onClick={handleDeleteSelected} disabled={deleteLoading}>
                          {deleteLoading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Trash2 className="h-3.5 w-3.5 mr-1" />}
                          Delete Selected
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelectedIds(new Set())}>
                          Clear
                        </Button>
                      </>
                    )}
                    {selectedIds.size === 0 && notifications.length > 0 && (
                      <Button variant="outline" size="sm" className="h-7 text-xs text-destructive border-destructive/30 hover:bg-destructive/5" onClick={handleDeleteAll} disabled={deleteLoading}>
                        {deleteLoading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Trash2 className="h-3.5 w-3.5 mr-1" />}
                        Delete All
                      </Button>
                    )}
                  </div>
                </div>
                <div className="max-h-[600px] overflow-y-auto divide-y">
                  <AnimatePresence mode="popLayout">
                    {notifications.map((notification, idx) => {
                    const IconComponent = typeIcon[notification.type] || Bell;
                    const iconColorClass = typeColor[notification.type] || 'text-gray-600 bg-gray-50';
                    const ChannelIcon = channelIcon[notification.channel] || Bell;
                    const isMarkingThis = markingRead === notification.id;

                    return (
                      <motion.div
                        key={notification.id}
                        layout
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 8 }}
                        transition={{ duration: 0.2, delay: idx * 0.03 }}
                        className={
                          `flex items-start gap-3 p-4 cursor-pointer transition-colors hover:bg-muted/50 ${selectedIds.has(notification.id) ? 'bg-muted/30' : ''}`
                        }
                        onClick={() => markAsRead(notification)}
                      >
                        {/* Checkbox */}
                        <div className="mt-1.5 shrink-0" onClick={e => { e.stopPropagation(); toggleNotification(notification.id); }}>
                          <Checkbox
                            checked={selectedIds.has(notification.id)}
                            onCheckedChange={() => toggleNotification(notification.id)}
                          />
                        </div>

                        {/* Unread dot */}
                        {!notification.isRead && (
                          <div className="mt-1.5 shrink-0">
                            <Circle className="h-2.5 w-2.5 fill-teal-500 text-teal-500" />
                          </div>
                        )}

                        {/* Type icon */}
                        <div
                          className={`
                            h-10 w-10 rounded-full flex items-center justify-center shrink-0
                            ${iconColorClass}
                          `}
                        >
                          {isMarkingThis ? (
                            <Loader2 className="h-5 w-5 animate-spin" />
                          ) : (
                            <IconComponent className="h-5 w-5" />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p
                              className={`text-sm ${
                                notification.isRead
                                  ? 'text-muted-foreground'
                                  : 'font-semibold text-foreground'
                              }`}
                            >
                              {notification.title}
                            </p>
                            <Badge
                              variant="outline"
                              className={`text-xs ${typeBadgeColor[notification.type] || ''}`}
                            >
                              {notification.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="datetime-badge text-xs text-muted-foreground">
                              {formatRelative(notification.createdAt)}
                            </span>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <ChannelIcon className="h-3 w-3" />
                              <Badge
                                variant="outline"
                                className={`text-xs px-1.5 py-0 ${channelBadgeColor[notification.channel] || ''}`}
                              >
                                {notification.channel === 'in_app'
                                  ? 'In-App'
                                  : notification.channel === 'push'
                                    ? 'Push'
                                    : notification.channel.charAt(0).toUpperCase() + notification.channel.slice(1)}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
              </>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Notification Settings */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.15 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Settings className="h-5 w-5 text-muted-foreground" />
              Notification Settings
            </CardTitle>
            <CardDescription>
              Configure how and when you receive notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Channel Settings */}
            <div>
              <h4 className="text-sm font-medium mb-3">Notification Channels</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(
                  [
                    { key: 'in_app' as const, label: 'In-App Notifications', desc: 'Show notifications in the app', icon: Bell },
                    { key: 'sms' as const, label: 'SMS Notifications', desc: 'Receive text messages', icon: Smartphone },
                    { key: 'email' as const, label: 'Email Notifications', desc: 'Receive email alerts', icon: Mail },
                    { key: 'push' as const, label: 'Push Notifications', desc: 'Browser push notifications', icon: Megaphone },
                  ] as const
                ).map((channel) => (
                  <div
                    key={channel.key}
                    className="flex items-center justify-between p-3 rounded-lg border bg-muted/20"
                  >
                    <div className="flex items-center gap-3">
                      <channel.icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">{channel.label}</p>
                        <p className="text-xs text-muted-foreground">{channel.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={channelSettings[channel.key]}
                      onCheckedChange={(checked) => handleChannelToggle(channel.key, checked)}
                    />
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Type Settings */}
            <div>
              <h4 className="text-sm font-medium mb-3">Notification Types</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(
                  [
                    { key: 'deposit' as const, label: 'Deposits', desc: 'Money received into wallet', icon: ArrowDownCircle },
                    { key: 'withdrawal' as const, label: 'Withdrawals', desc: 'Money withdrawn from wallet', icon: ArrowUpCircle },
                    { key: 'payment' as const, label: 'Payments', desc: 'Payment sent or received', icon: CreditCard },
                    { key: 'security' as const, label: 'Security Alerts', desc: 'Login attempts and suspicious activity', icon: Shield },
                    { key: 'balance' as const, label: 'Low Balance', desc: 'Alert when balance falls below threshold', icon: Wallet },
                    { key: 'system' as const, label: 'System Updates', desc: 'Maintenance and platform updates', icon: Megaphone },
                  ] as const
                ).map((ntype) => (
                  <div
                    key={ntype.key}
                    className="flex items-center justify-between p-3 rounded-lg border bg-muted/20"
                  >
                    <div className="flex items-center gap-3">
                      <ntype.icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">{ntype.label}</p>
                        <p className="text-xs text-muted-foreground">{ntype.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={typeSettings[ntype.key]}
                      onCheckedChange={(checked) => handleTypeToggle(ntype.key, checked)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
