'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { toast } from 'sonner';
import {
  Plus,
  FileText,
  FileSpreadsheet,
  Download,
  Wallet as WalletIcon,
  DollarSign,
  Lock,
  Loader2,
  User,
  CreditCard,
  TrendingUp,
  Snowflake,
  ShieldCheck,
  CircleDot,
  ArrowRight,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { useT } from '@/lib/i18n';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { getCurrencyFlag } from '@/lib/currency-flags';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface WalletUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface UserOption {
  id: string;
  name: string;
  email: string;
}

interface Wallet {
  id: string;
  userId: string;
  currency: string;
  balance: number;
  availableBalance: number;
  frozenBalance: number;
  type: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  user: WalletUser;
}

interface StatementTransaction {
  id: string;
  reference: string;
  type: string;
  amount: number;
  fee: number;
  currency: string;
  status: string;
  createdAt: string;
  sourceWalletId?: string | null;
  destinationWalletId?: string | null;
}

// --- Constants ---

const CURRENCY_NAMES: Record<string, string> = {
  ETB: 'Ethiopian Birr',
  USD: 'US Dollar',
  EUR: 'Euro',
  GBP: 'British Pound',
  AED: 'UAE Dirham',
  SAR: 'Saudi Riyal',
  CAD: 'Canadian Dollar',
  AUD: 'Australian Dollar',
  JPY: 'Japanese Yen',
  CNY: 'Chinese Yuan',
  INR: 'Indian Rupee',
};

const CURRENCY_OPTIONS = [
  { value: 'ETB', label: 'ETB - Ethiopian Birr' },
  { value: 'USD', label: 'USD - US Dollar' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound' },
  { value: 'AED', label: 'AED - UAE Dirham' },
  { value: 'SAR', label: 'SAR - Saudi Riyal' },
  { value: 'CAD', label: 'CAD - Canadian Dollar' },
  { value: 'AUD', label: 'AUD - Australian Dollar' },
  { value: 'JPY', label: 'JPY - Japanese Yen' },
  { value: 'CNY', label: 'CNY - Chinese Yuan' },
  { value: 'INR', label: 'INR - Indian Rupee' },
];

// --- Helpers ---

function formatCurrency(amount: number, currency: string): string {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  }
}

function formatCurrencyNoSymbol(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function getCurrencySymbol(currency: string): string {
  if (currency === 'ETB') return 'Br';
  if (currency === 'USD') return '$';
  if (currency === 'EUR') return '€';
  if (currency === 'GBP') return '£';
  if (currency === 'AED') return 'AED';
  if (currency === 'SAR') return 'SAR';
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, currencyDisplay: 'narrowSymbol' }).format(0).replace(/[×0]/, '').trim();
  } catch {
    return currency;
  }
}

function getStatementStatusBadge(status: string, t: (key: string) => string) {
  const statusLabel = status === 'active' ? t('status.active')
    : status === 'completed' ? t('status.completed')
    : status === 'pending' ? t('status.pending')
    : status === 'processing' ? t('status.processing')
    : status === 'failed' ? t('status.failed')
    : status === 'cancelled' ? t('status.cancelled')
    : status === 'reversed' ? t('status.reversed')
    : status === 'frozen' ? t('status.frozen')
    : status === 'closed' ? t('status.closed')
    : status;
  if (status === 'completed') {
    return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">{statusLabel}</Badge>;
  }
  if (status === 'pending' || status === 'processing') {
    return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">{statusLabel}</Badge>;
  }
  if (status === 'failed' || status === 'cancelled' || status === 'reversed') {
    return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">{statusLabel}</Badge>;
  }
  return <Badge variant="outline">{statusLabel}</Badge>;
}

// --- Wallet Summary Section ---

function WalletSummarySection({ wallets }: { wallets: Wallet[] }) {
  const t = useT();
  const totalWallets = wallets.length;
  const totalBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
  const totalFrozen = wallets.reduce((sum, w) => sum + w.frozenBalance, 0);
  const uniqueCurrencies = [...new Set(wallets.map(w => w.currency))];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className="bg-gradient-to-r from-emerald-50 via-teal-50/60 to-emerald-50 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-emerald-950/40 border-emerald-200/60 dark:border-emerald-800/40">
        <CardContent className="p-4 sm:p-5">
          <div className="grid grid-cols-2 gap-3 sm:gap-6 lg:grid-cols-4">
            {/* Total Wallets */}
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-sm">
                <WalletIcon className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{t('wallets.totalWallets') || 'Total Wallets'}</p>
                <p className="text-lg font-bold">{totalWallets}</p>
              </div>
            </div>
            {/* Total Balance */}
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 shadow-sm">
                <DollarSign className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{t('wallets.totalBalance') || 'Total Balance'}</p>
                <p className="text-lg font-bold truncate">{formatCurrencyNoSymbol(totalBalance)}</p>
              </div>
            </div>
            {/* Total Frozen */}
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-sm">
                <Snowflake className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{t('wallets.totalFrozen') || 'Total Frozen'}</p>
                <p className="text-lg font-bold truncate">{formatCurrencyNoSymbol(totalFrozen)}</p>
              </div>
            </div>
            {/* Wallets Currencies */}
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 shadow-sm">
                <CreditCard className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{t('wallets.currencies') || 'Wallets Currencies'}</p>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  {uniqueCurrencies.map(c => (
                    <span key={c} className="inline-flex items-center gap-1 text-sm font-semibold">
                      <span>{getCurrencyFlag(c)}</span>
                      <span>{c}</span>
                      <span className="text-xs text-muted-foreground font-normal">{CURRENCY_NAMES[c] ?? ''}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// --- Wallet Detail Card ---

function WalletDetailCard({ wallet, onSelect, isSelected }: { wallet: Wallet; onSelect: (w: Wallet) => void; isSelected: boolean }) {
  const t = useT();
  const flag = getCurrencyFlag(wallet.currency);
  const currencyName = CURRENCY_NAMES[wallet.currency] ?? wallet.currency;
  const symbol = getCurrencySymbol(wallet.currency);
  const frozenPercent = wallet.balance > 0
    ? Math.round((wallet.frozenBalance / wallet.balance) * 100)
    : 0;
  const availablePercent = wallet.balance > 0
    ? Math.round((wallet.availableBalance / wallet.balance) * 100)
    : 0;

  const walletTypeLabel = wallet.type === 'merchant'
    ? (t('wallets.merchantWallet') || 'Merchant Wallet')
    : wallet.type === 'escrow'
      ? (t('wallets.escrowWallet') || 'Escrow Wallet')
      : (t('wallets.digitalWallet') || 'Digital Wallet');

  const statusLabel = wallet.status === 'active'
    ? (t('status.active') || 'Active')
    : wallet.status === 'frozen'
      ? (t('status.frozen') || 'Frozen')
      : wallet.status === 'closed'
        ? (t('status.closed') || 'Closed')
        : wallet.status;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card
        className={"cursor-pointer overflow-hidden border-emerald-100 dark:border-emerald-900/50 " +
          (isSelected
            ? 'ring-2 ring-emerald-500 shadow-lg shadow-emerald-500/10'
            : 'hover:shadow-lg hover:shadow-emerald-500/5 hover:ring-1 hover:ring-emerald-200')}
        onClick={() => onSelect(wallet)}
      >
        <CardContent className="p-0">
          {/* --- Header: Flag + Currency + Type + Status + Wallet ID --- */}
          <div className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 px-4 sm:px-5 py-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl" role="img" aria-label={wallet.currency}>
                  {flag}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-bold text-white">{wallet.currency}</h3>
                    <span className="text-sm text-emerald-100 font-medium">{currencyName}</span>
                  </div>
                  <p className="text-xs text-emerald-200 mt-0.5 font-mono">ID: {wallet.id}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/20 text-xs font-medium">
                  {walletTypeLabel}
                </Badge>
                <Badge className="bg-emerald-400/30 text-white border-emerald-300/40 hover:bg-emerald-400/30 text-xs font-medium">
                  {statusLabel}
                </Badge>
              </div>
            </div>
          </div>

          {/* --- Total Balance --- */}
          <div className="px-4 sm:px-5 pt-5 pb-4">
            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5">
              {t('wallets.totalBalance') || 'Total Balance'}
            </p>
            <p className="text-2xl sm:text-3xl font-bold tracking-tight">
              <span className="text-base sm:text-lg font-medium text-muted-foreground mr-1">{symbol}</span>
              {formatCurrencyNoSymbol(wallet.balance)}
            </p>
          </div>

          {/* --- Details --- */}
          <div className="px-4 sm:px-5 pb-4 space-y-2.5">
            {/* Available Balance */}
            <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-emerald-50/60 dark:bg-emerald-950/20">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900/40">
                  <TrendingUp className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <span className="text-sm font-medium text-muted-foreground">{t('wallets.availableBalance') || 'Available Balance'}</span>
              </div>
              <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                {symbol} {formatCurrencyNoSymbol(wallet.availableBalance)}
              </span>
            </div>

            {/* Frozen Balance */}
            <div className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-amber-50/60 dark:bg-amber-950/20">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-900/40">
                  <Snowflake className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                </div>
                <span className="text-sm font-medium text-muted-foreground">{t('wallets.frozenBalance') || 'Frozen Balance'}</span>
              </div>
              <span className={"text-sm font-bold " + (wallet.frozenBalance > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground')}>
                {symbol} {formatCurrencyNoSymbol(wallet.frozenBalance)}
              </span>
            </div>

            {/* Frozen Progress Bar */}
            {wallet.frozenBalance > 0 && (
              <div className="px-3 pt-1">
                <div className="flex justify-between text-[11px] text-muted-foreground mb-1">
                  <span>{t('wallets.availableBalance') || 'Available'}</span>
                  <span>{availablePercent}%</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden flex">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full"
                    style={{ width: `${availablePercent}%` }}
                  />
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 to-orange-400 rounded-full"
                    style={{ width: `${frozenPercent}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* --- Footer: Owner --- */}
          <div className="bg-muted/30 px-4 sm:px-5 py-3.5 border-t">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/50">
                  <User className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground leading-none">{t('wallets.owner') || 'Owner'}</p>
                  <p className="text-sm font-semibold leading-tight mt-0.5">{wallet.user.name}</p>
                </div>
              </div>
              <ArrowRight className={"h-4 w-4 text-muted-foreground " + (isSelected ? 'rotate-90' : '')} />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// --- Wallet Card Skeleton ---

function WalletCardSkeleton() {
  return (
    <Card className="border-emerald-100">
      <CardContent className="p-0">
        {/* Header skeleton */}
        <div className="bg-muted/50 px-4 sm:px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Skeleton className="h-8 w-8 rounded" />
              <div className="space-y-1.5">
                <Skeleton className="h-4 w-14" />
                <Skeleton className="h-3 w-24" />
              </div>
            </div>
            <div className="flex gap-2">
              <Skeleton className="h-5 w-24 rounded-full" />
              <Skeleton className="h-5 w-14 rounded-full" />
            </div>
          </div>
        </div>
        {/* Balance skeleton */}
        <div className="px-4 sm:px-5 pt-5 pb-4">
          <Skeleton className="h-3 w-20 mb-2" />
          <Skeleton className="h-7 w-40" />
        </div>
        {/* Details skeleton */}
        <div className="px-4 sm:px-5 pb-4 space-y-2.5">
          <div className="flex items-center justify-between py-2.5 px-3 rounded-lg">
            <div className="flex items-center gap-2.5">
              <Skeleton className="h-8 w-8 rounded-lg" />
              <Skeleton className="h-4 w-28" />
            </div>
            <Skeleton className="h-4 w-24" />
          </div>
          <div className="flex items-center justify-between py-2.5 px-3 rounded-lg">
            <div className="flex items-center gap-2.5">
              <Skeleton className="h-8 w-8 rounded-lg" />
              <Skeleton className="h-4 w-24" />
            </div>
            <Skeleton className="h-4 w-20" />
          </div>
        </div>
        {/* Footer skeleton */}
        <div className="bg-muted/30 px-4 sm:px-5 py-3.5 border-t">
          <div className="flex items-center gap-2.5">
            <Skeleton className="h-8 w-8 rounded-full" />
            <div className="space-y-1">
              <Skeleton className="h-2.5 w-10" />
              <Skeleton className="h-3.5 w-28" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// --- Create Wallet Dialog ---

function CreateWalletDialog({ onCreated }: { onCreated: () => void }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [users, setUsers] = useState<UserOption[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userId, setUserId] = useState('');
  const [currency, setCurrency] = useState('');
  const [type, setType] = useState('');
  const [initialBalance, setInitialBalance] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchUsers = useCallback(async () => {
    setLoadingUsers(true);
    try {
      const res = await apiFetch('/api/users?limit=100');
      if (!res.ok) throw new Error('Failed to load users');
      const json = await res.json();
      const list = Array.isArray(json.users) ? json.users : Array.isArray(json) ? json : [];
      setUsers(list.map((u: { id: string; name: string; email: string }) => ({ id: u.id, name: u.name, email: u.email })));
    } catch {
      toast.error(t('wallets.failedLoadUsers') || 'Failed to load users');
    } finally {
      setLoadingUsers(false);
    }
  }, [t]);

  useEffect(() => {
    if (open) {
      fetchUsers();
    }
  }, [open, fetchUsers]);

  const resetForm = () => {
    setUserId('');
    setCurrency('');
    setType('');
    setInitialBalance('');
  };

  const handleSubmit = async () => {
    if (!userId) {
      toast.error(t('wallets.pleaseSelectUser') || 'Please select a user');
      return;
    }
    if (!currency) {
      toast.error(t('wallets.pleaseSelectCurrency') || 'Please select a currency');
      return;
    }

    const balance = parseFloat(initialBalance) || 0;

    setSubmitting(true);
    try {
      const res = await apiFetch('/api/wallets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          currency,
          type: type || 'digital',
          initialBalance: balance,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || t('wallets.failedCreateWallet') || 'Failed to create wallet');
      }

      toast.success(t('wallets.walletCreated') || 'Wallet created successfully');
      setOpen(false);
      resetForm();
      onCreated();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t('wallets.failedCreateWallet') || 'Failed to create wallet');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
      <DialogTrigger asChild>
        <Button className="btn-responsive">
          <Plus className="mr-2 h-4 w-4" />
          <span className="btn-label">Create Wallet</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t('wallets.createWalletTitle') || 'Create New Wallet'}</DialogTitle>
          <DialogDescription>
            {t('wallets.createWalletDesc') || 'Create a new digital wallet for a user.'}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="user">{t('common.user') || 'User'}</Label>
            <Select value={userId} onValueChange={setUserId}>
              <SelectTrigger>
                <SelectValue placeholder={loadingUsers ? (t('wallets.loadingUsers') || 'Loading users...') : (t('wallets.selectUser') || 'Select a user')} />
              </SelectTrigger>
              <SelectContent>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.name} ({u.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="currency">{t('common.currency') || 'Currency'}</Label>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger>
                <SelectValue placeholder={t('wallets.selectCurrency') || 'Select currency'} />
              </SelectTrigger>
              <SelectContent>
                {CURRENCY_OPTIONS.map((c) => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">{t('wallets.walletType') || 'Wallet Type'}</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue placeholder={t('wallets.selectType') || 'Select type'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="digital">{t('wallets.digitalWallet') || 'Digital Wallet'}</SelectItem>
                <SelectItem value="merchant">{t('wallets.merchantWallet') || 'Merchant Wallet'}</SelectItem>
                <SelectItem value="escrow">{t('wallets.escrowWallet') || 'Escrow Wallet'}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="initialBalance">{t('wallets.initialBalance') || 'Initial Balance'}</Label>
            <Input
              id="initialBalance"
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={initialBalance}
              onChange={(e) => setInitialBalance(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter className="btn-responsive-group">
          <Button variant="outline" className="btn-responsive" onClick={() => setOpen(false)}>{t('common.cancel') || 'Cancel'}</Button>
          <Button className="btn-responsive" onClick={handleSubmit} disabled={submitting}>
            {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {t('wallets.createWallet') || 'Create Wallet'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Export Helpers ---

function exportToCSV(statements: StatementTransaction[], wallet: Wallet, t: (key: string) => string) {
  if (statements.length === 0) {
    toast.error(t('wallets.noTransactionsToExport') || 'No transactions to export');
    return;
  }

  const headers = [t('common.date') || 'Date', t('common.reference') || 'Reference', t('common.type') || 'Type', t('common.amount') || 'Amount', t('common.currency') || 'Currency', t('common.status') || 'Status'];
  const rows = statements.map((s) => [
    format(new Date(s.createdAt), 'yyyy-MM-dd'),
    s.reference,
    s.type,
    s.amount.toString(),
    s.currency,
    s.status,
  ]);

  const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${wallet.user.name}-${wallet.currency}-statement-${format(new Date(), 'yyyy-MM-dd')}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  toast.success(t('wallets.csvExported') || 'CSV exported successfully');
}

// --- Main Component ---

export default function WalletsView() {
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedWallet, setSelectedWallet] = useState<Wallet | null>(null);
  const [allTransactions, setAllTransactions] = useState<StatementTransaction[]>([]);
  const [loadingStatements, setLoadingStatements] = useState(false);
  const t = useT();
  const { formatDate } = useFormattedDate();

  const fetchWallets = useCallback(async () => {
    try {
      const res = await apiFetch('/api/wallets');
      if (!res.ok) throw new Error(t('wallets.failedLoadWallets') || 'Failed to load wallets');
      const json = await res.json();
      setWallets(Array.isArray(json) ? json : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : t('wallets.unknownError') || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    fetchWallets();
  }, [fetchWallets]);

  const fetchAllTransactions = useCallback(async () => {
    setLoadingStatements(true);
    try {
      const res = await apiFetch('/api/transactions?limit=200');
      if (!res.ok) throw new Error(t('wallets.failedLoadTransactions') || 'Failed to load transactions');
      const json = await res.json();
      const list = Array.isArray(json.transactions) ? json.transactions : Array.isArray(json) ? json : [];
      setAllTransactions(list);
    } catch {
      setAllTransactions([]);
    } finally {
      setLoadingStatements(false);
    }
  }, [t]);

  const statements = useMemo(() => {
    if (!selectedWallet || allTransactions.length === 0) return [];
    return allTransactions.filter(
      (tx) =>
        tx.sourceWalletId === selectedWallet.id ||
        tx.destinationWalletId === selectedWallet.id
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [selectedWallet, allTransactions]);

  const handleSelectWallet = (wallet: Wallet) => {
    setSelectedWallet(wallet);
    if (allTransactions.length === 0) {
      fetchAllTransactions();
    }
  };

  const handleExportCSV = () => {
    if (selectedWallet) exportToCSV(statements, selectedWallet, t);
  };

  const handleExportPDF = () => {
    toast.success(t('wallets.pdfExportInitiated') || 'PDF export initiated');
  };

  const handleExportExcel = () => {
    toast.success(t('wallets.excelExportInitiated') || 'Excel export initiated');
  };

  const handleWalletCreated = () => {
    fetchWallets();
  };

  if (error) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-muted-foreground">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('wallets.management') || 'Wallets Management'}</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            {t('wallets.managementDesc') || 'Manage and monitor all digital wallets'}
          </p>
        </div>
        <CreateWalletDialog onCreated={handleWalletCreated} />
      </motion.div>

      {/* Wallet Summary Section */}
      {!loading && wallets.length > 0 && (
        <WalletSummarySection wallets={wallets} />
      )}

      {/* Wallet Detail Cards Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <WalletCardSkeleton key={i} />)
          : wallets.map((w) => (
              <WalletDetailCard
                key={w.id}
                wallet={w}
                onSelect={handleSelectWallet}
                isSelected={selectedWallet?.id === w.id}
              />
            ))}
      </div>

      {/* Wallet Statements Section */}
      {selectedWallet && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card>
            <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <CardTitle className="text-base">
                  {getCurrencyFlag(selectedWallet.currency)} {selectedWallet.user.name} - {selectedWallet.currency} {t('wallets.walletStatement') || 'Wallet Statement'}
                  <span className="ml-2 text-xs font-mono text-muted-foreground font-normal">ID: {selectedWallet.id}</span>
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {loadingStatements
                    ? (t('wallets.loadingTransactions') || 'Loading transactions...')
                    : `${statements.length} ${t('wallets.transactionsFound') || 'transactions found'}`}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={handleExportPDF}>
                  <FileText className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">PDF</span>
                </Button>
                <Button variant="outline" size="sm" onClick={handleExportExcel}>
                  <FileSpreadsheet className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">Excel</span>
                </Button>
                <Button variant="outline" size="sm" onClick={handleExportCSV}>
                  <Download className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">CSV</span>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              {loadingStatements ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : statements.length === 0 ? (
                <div className="flex items-center justify-center py-12">
                  <p className="text-muted-foreground">{t('wallets.noTransactions') || 'No transactions found'}</p>
                </div>
              ) : (
                <div className="max-h-[400px] overflow-y-auto rounded-md border [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead className="hidden sm:table-cell">{t('common.date') || 'Date'}</TableHead>
                        <TableHead className="hidden sm:table-cell">{t('common.reference') || 'Reference'}</TableHead>
                        <TableHead>{t('common.type') || 'Type'}</TableHead>
                        <TableHead>{t('common.status') || 'Status'}</TableHead>
                        <TableHead className="text-right">{t('common.amount') || 'Amount'}</TableHead>
                        <TableHead className="text-right hidden md:table-cell">{t('common.fee') || 'Fee'}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {statements.map((stmt) => {
                        const isCredit = stmt.destinationWalletId === selectedWallet.id && stmt.sourceWalletId !== selectedWallet.id;

                        return (
                          <TableRow key={stmt.id}>
                            <TableCell className="text-sm hidden sm:table-cell">
                              <span className="datetime-badge date-only">{formatDate(stmt.createdAt)}</span>
                            </TableCell>
                            <TableCell className="font-mono text-sm hidden sm:table-cell">
                              {stmt.reference}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {stmt.type.replace('_', ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {getStatementStatusBadge(stmt.status, t)}
                            </TableCell>
                            <TableCell className={`text-right font-mono text-sm ${
                              isCredit ? 'text-emerald-600' : 'text-rose-600'
                            }`}>
                              {isCredit ? '+' : '-'}
                              {formatCurrencyNoSymbol(stmt.amount)} {stmt.currency}
                            </TableCell>
                            <TableCell className="text-right font-mono text-sm text-muted-foreground hidden md:table-cell">
                              {formatCurrencyNoSymbol(stmt.fee)} {stmt.currency}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
