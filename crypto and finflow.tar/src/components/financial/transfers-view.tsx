'use client';

import { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
  CreditCard,
  RotateCcw,
  Clock,
  Split,
  ShieldCheck,
  Wallet,
  Landmark,
  Smartphone,
  QrCode,
  ChevronLeft,
  ChevronRight,
  Check,
  Loader2,
  Info,
  MapPin,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from '@/components/ui/input-otp';
import { toast } from 'sonner';
import { useT } from '@/lib/i18n';
import { apiFetch } from '@/lib/api-fetch';
import TransactionAdvice, { type AdviceData } from '@/components/financial/transaction-advice';

// --- Types ---

interface WalletItem {
  id: string;
  userId: string;
  currency: string;
  balance: number;
  availableBalance: number;
  frozenBalance: number;
  type: string;
  status: string;
  user?: { id: string; name: string; email: string } | null;
}

interface BankAccountItem {
  id: string;
  userId: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  accountType: string;
  currency: string;
  isVerified: boolean;
  status: string;
  user?: { id: string; name: string; email: string } | null;
}

interface UserItem {
  id: string;
  name: string;
  email: string;
  phone: string | null;
}

interface FeeConfigItem {
  id: string;
  transactionType: string;
  paymentMethod: string | null;
  feeType: string;
  feeValue: number;
  minFee: number;
  maxFee: number | null;
  currency: string;
  isActive: boolean;
}

// --- Constants ---

const CURRENCIES = [
  { code: 'ETB', name: 'Ethiopian Birr' },
  { code: 'USD', name: 'US Dollar' },
  { code: 'EUR', name: 'Euro' },
  { code: 'GBP', name: 'British Pound' },
  { code: 'AED', name: 'UAE Dirham' },
  { code: 'SAR', name: 'Saudi Riyal' },
  { code: 'CAD', name: 'Canadian Dollar' },
  { code: 'AUD', name: 'Australian Dollar' },
  { code: 'JPY', name: 'Japanese Yen' },
  { code: 'CNY', name: 'Chinese Yuan' },
  { code: 'INR', name: 'Indian Rupee' },
];

const TXN_TYPES = [
  { value: 'deposit', label: 'Deposit', icon: ArrowDownToLine, color: 'text-emerald-600' },
  { value: 'withdrawal', label: 'Withdrawal', icon: ArrowUpFromLine, color: 'text-rose-600' },
  { value: 'transfer', label: 'Transfer', icon: ArrowLeftRight, color: 'text-teal-600' },
  { value: 'payment', label: 'Payment', icon: CreditCard, color: 'text-amber-600' },
  { value: 'refund', label: 'Refund', icon: RotateCcw, color: 'text-orange-600' },
  { value: 'scheduled', label: 'Scheduled Payment', icon: Clock, color: 'text-cyan-600' },
  { value: 'split_payment', label: 'Split Payment', icon: Split, color: 'text-fuchsia-600' },
  { value: 'escrow', label: 'Escrow Payment', icon: ShieldCheck, color: 'text-purple-600' },
];

const PAYMENT_METHODS = [
  { value: 'bank_account', label: 'Bank Account', icon: Landmark },
  { value: 'debit_card', label: 'Debit Card', icon: CreditCard },
  { value: 'credit_card', label: 'Credit Card', icon: CreditCard },
  { value: 'mobile_money', label: 'Mobile Money', icon: Smartphone },
  { value: 'qr_code', label: 'QR Code', icon: QrCode },
  { value: 'digital_wallet', label: 'Digital Wallet', icon: Wallet },
];

function formatCurrency(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency === 'ETB' ? 'ETB' : currency,
      minimumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  }
}

// --- Step builder: compute which steps to show based on txn type ---

function buildVisibleSteps(txnType: string | null): string[] {
  const steps: string[] = ['type'];
  if (!txnType) return steps;

  steps.push('basicInfo');

  const showSource = ['withdrawal', 'transfer', 'payment', 'refund', 'scheduled', 'split_payment', 'escrow'].includes(txnType);
  const showDestination = ['deposit', 'transfer', 'payment', 'refund', 'scheduled', 'split_payment', 'escrow'].includes(txnType);
  const showPayment = !['deposit'].includes(txnType);
  const showSchedule = ['scheduled', 'split_payment'].includes(txnType);

  if (showSource) steps.push('source');
  if (showDestination) steps.push('destination');
  if (showPayment) steps.push('payment');
  if (showSchedule) steps.push('schedule');
  steps.push('review');

  return steps;
}

// STEP_LABELS are translated at render time using t()
const STEP_KEYS = ['type', 'basicInfo', 'source', 'destination', 'payment', 'schedule', 'review'] as const;

function getTxnLabel(value: string, t: (key: string) => string): string {
  return value === 'deposit' ? t('transfers.deposit')
    : value === 'withdrawal' ? t('transfers.withdrawal')
    : value === 'transfer' ? t('transfers.transfer')
    : value === 'payment' ? t('transfers.payment')
    : value === 'refund' ? t('transfers.refund')
    : value === 'scheduled' ? t('transfers.scheduledPayment')
    : value === 'split_payment' ? t('transfers.splitPayment')
    : value === 'escrow' ? t('transfers.escrowPayment')
    : value;
}

// --- Component ---

export default function TransfersView() {
  // Step state
  const [currentStepKey, setCurrentStepKey] = useState('type');
  const [txnType, setTxnType] = useState<string | null>(null);

  // Basic Info
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('ETB');
  const [description, setDescription] = useState('');

  // Source
  const [sourceType, setSourceType] = useState<'wallet' | 'bank'>('wallet');
  const [sourceWalletId, setSourceWalletId] = useState('');
  const [sourceBankId, setSourceBankId] = useState('');

  // Destination
  const [destType, setDestType] = useState<'wallet' | 'bank' | 'p2p'>('wallet');
  const [destWalletId, setDestWalletId] = useState('');
  const [destBankId, setDestBankId] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientUserId, setRecipientUserId] = useState('');

  // Payment Method
  const [paymentMethod, setPaymentMethod] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [mobileMoneyPhone, setMobileMoneyPhone] = useState('');

  // Addresses
  const [senderAddress, setSenderAddress] = useState('');
  const [receiverAddress, setReceiverAddress] = useState('');

  // Schedule
  const [scheduleType, setScheduleType] = useState('one_time');
  const [scheduleStartDate, setScheduleStartDate] = useState('');
  const [scheduleEndDate, setScheduleEndDate] = useState('');

  // OTP
  const [otpValue, setOtpValue] = useState('');
  const [showOtp, setShowOtp] = useState(false);

  const [adviceData, setAdviceData] = useState<AdviceData | null>(null);

  // Data from API
  const [wallets, setWallets] = useState<WalletItem[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccountItem[]>([]);
  const [users, setUsers] = useState<UserItem[]>([]);
  const [feeConfigs, setFeeConfigs] = useState<FeeConfigItem[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const t = useT();

  // Computed visible steps
  const visibleSteps = buildVisibleSteps(txnType);
  const currentStepIdx = visibleSteps.indexOf(currentStepKey);
  const isReviewStep = currentStepKey === 'review';
  const isFirstStep = currentStepIdx === 0;
  const isLastStep = currentStepIdx === visibleSteps.length - 1;

  // Computed: numeric amount
  const numericAmount = parseFloat(amount) || 0;

  // Computed: find applicable fee config
  const applicableFeeConfig = (() => {
    if (!txnType || !paymentMethod) return null;
    // First try exact match on type + payment method
    let match = feeConfigs.find(
      (fc) => fc.transactionType === txnType && fc.paymentMethod === paymentMethod && fc.isActive
    );
    // Fallback to type-only match
    if (!match) {
      match = feeConfigs.find(
        (fc) => fc.transactionType === txnType && fc.isActive
      );
    }
    return match ?? null;
  })();

  // Computed: calculate fee
  const calculatedFee = (() => {
    if (!applicableFeeConfig || numericAmount <= 0) return 0;
    if (applicableFeeConfig.feeType === 'flat') {
      return applicableFeeConfig.feeValue;
    }
    if (applicableFeeConfig.feeType === 'percentage') {
      const pctFee = (numericAmount * applicableFeeConfig.feeValue) / 100;
      const minFee = applicableFeeConfig.minFee ?? 0;
      const maxFee = applicableFeeConfig.maxFee;
      let fee = pctFee;
      if (fee < minFee) fee = minFee;
      if (maxFee !== null && fee > maxFee) fee = maxFee;
      return fee;
    }
    return 0;
  })();

  const feeLabel = applicableFeeConfig
    ? applicableFeeConfig.feeType === 'flat'
      ? `${t('transfers.flatFee')} ${formatCurrency(applicableFeeConfig.feeValue, applicableFeeConfig.currency)}`
      : `${applicableFeeConfig.feeValue}%`
    : '0%';

  // Computed selections
  const selectedSourceWallet = wallets.find((w) => w.id === sourceWalletId);
  const selectedDestWallet = wallets.find((w) => w.id === destWalletId);
  const selectedSourceBank = bankAccounts.find((b) => b.id === sourceBankId);
  const selectedDestBank = bankAccounts.find((b) => b.id === destBankId);
  const selectedRecipientUser = users.find((u) => u.id === recipientUserId);

  // Fetch reference data
  const fetchData = useCallback(async () => {
    setLoadingData(true);
    try {
      const [wRes, bRes, uRes, fRes] = await Promise.all([
        apiFetch('/api/wallets?status=active'),
        apiFetch('/api/bank-accounts?isVerified=true'),
        apiFetch('/api/users?limit=100'),
        apiFetch('/api/fee-configs?isActive=true'),
      ]);
      if (wRes.ok) setWallets(await wRes.json());
      if (bRes.ok) setBankAccounts(await bRes.json());
      if (uRes.ok) {
        const uData = await uRes.json();
        setUsers(uData.users ?? uData);
      }
      if (fRes.ok) setFeeConfigs(await fRes.json());
    } catch {
      toast.error(t('transfers.failedLoadRefData'));
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Validation per step
  const canAdvance = (): boolean => {
    switch (currentStepKey) {
      case 'type':
        return txnType !== null;
      case 'basicInfo':
        return numericAmount > 0;
      case 'source': {
        if (sourceType === 'wallet') return sourceWalletId !== '';
        return sourceBankId !== '';
      }
      case 'destination': {
        if (destType === 'p2p') return recipientName !== '' || recipientUserId !== '';
        if (destType === 'wallet') return destWalletId !== '';
        return destBankId !== '';
      }
      case 'payment':
        return paymentMethod !== '';
      case 'schedule':
        return true;
      case 'review':
        return true;
      default:
        return false;
    }
  };

  // Navigation
  const nextStep = () => {
    if (!canAdvance()) {
      toast.error(t('transfers.fillRequiredFields'));
      return;
    }
    if (currentStepIdx < visibleSteps.length - 1) {
      setCurrentStepKey(visibleSteps[currentStepIdx + 1]);
    }
  };

  const prevStep = () => {
    if (currentStepIdx > 0) {
      setCurrentStepKey(visibleSteps[currentStepIdx - 1]);
    }
  };

  const goToStep = (idx: number) => {
    // Allow navigating back to any completed step or current + 1
    if (idx <= currentStepIdx + 1 && idx >= 0) {
      setCurrentStepKey(visibleSteps[idx]);
    }
  };

  // Submit
  const handleSubmit = async () => {
    if (showOtp) {
      if (otpValue.length < 6) {
        toast.error(t('transfers.enterFullOtp'));
        return;
      }
    } else {
      setShowOtp(true);
      return;
    }

    setSubmitting(true);
    try {
      const initiatorId = selectedSourceWallet?.userId ?? selectedSourceBank?.userId ?? wallets[0]?.userId ?? '';
      if (!initiatorId) {
        toast.error(t('transfers.noInitiator'));
        setSubmitting(false);
        return;
      }

      const body: Record<string, unknown> = {
        type: txnType,
        amount: numericAmount,
        currency,
        description: description || undefined,
        initiatorId,
        sourceWalletId: sourceType === 'wallet' ? (sourceWalletId || undefined) : undefined,
        sourceBankId: sourceType === 'bank' ? (sourceBankId || undefined) : undefined,
        paymentMethod: paymentMethod || undefined,
        senderAddress: senderAddress || undefined,
        receiverAddress: receiverAddress || undefined,
      };

      // Set destination info
      if (destType === 'wallet' && destWalletId) body.destinationWalletId = destWalletId;
      if (destType === 'bank' && destBankId) body.destinationBankId = destBankId;
      if (recipientUserId) body.recipientId = recipientUserId;
      if (recipientName) body.recipientName = recipientName;
      if (recipientPhone) body.recipientPhone = recipientPhone;

      // Schedule info
      if (['scheduled', 'split_payment'].includes(txnType ?? '') && scheduleType !== 'one_time') {
        body.subType = scheduleType;
      }

      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || t('transfers.failedCreateTxn'));
      }

      const result = await res.json();
      toast.success(t("transfers.txnCreated") + ` Ref: ${result.reference ?? 'N/A'}`);

      // Build & show transaction advice
      const sWallet = wallets.find(w => w.id === sourceWalletId);
      const sBank = bankAccounts.find(b => b.id === sourceBankId);
      const dWallet = wallets.find(w => w.id === destWalletId);
      const dBank = bankAccounts.find(b => b.id === destBankId);
      const rUser = users.find(u => u.id === recipientUserId);

      setAdviceData({
        reference: result.reference ?? '',
        type: result.type ?? txnType ?? 'transfer',
        subType: result.subType ?? null,
        amount: result.amount ?? numericAmount,
        fee: result.fee ?? 0,
        currency: result.currency ?? currency,
        description: result.description ?? description ?? null,
        status: result.status ?? 'pending',
        createdAt: result.createdAt ?? new Date().toISOString(),
        completedAt: result.completedAt ?? null,
        paymentMethod: result.paymentMethod ?? paymentMethod ?? null,
        riskScore: result.riskScore ?? null,
        fraudFlag: result.fraudFlag ?? null,
        senderName: result.initiator?.name ?? sWallet?.user?.name ?? 'Unknown',
        senderEmail: result.initiator?.email ?? null,
        senderPhone: null,
        senderAddress: (result.senderAddress ?? senderAddress) || null,
        senderBankName: sBank?.bankName ?? null,
        senderAccountNumber: sBank?.accountNumber ?? null,
        senderWalletId: sourceWalletId || null,
        senderWalletCurrency: sWallet?.currency ?? null,
        receiverName: result.recipient?.name ?? rUser?.name ?? recipientName ?? null,
        receiverEmail: result.recipient?.email ?? null,
        receiverPhone: recipientPhone || rUser?.phone || null,
        receiverAddress: (result.receiverAddress ?? receiverAddress) || null,
        receiverBankName: dBank?.bankName ?? null,
        receiverAccountNumber: dBank?.accountNumber ?? null,
        receiverWalletId: destWalletId || null,
        receiverWalletCurrency: dWallet?.currency ?? null,
      });

      resetForm();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t('transfers.failedCreateTxn'));
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setTxnType(null);
    setCurrentStepKey('type');
    setAmount('');
    setCurrency('ETB');
    setDescription('');
    setSourceType('wallet');
    setSourceWalletId('');
    setSourceBankId('');
    setDestType('wallet');
    setDestWalletId('');
    setDestBankId('');
    setRecipientName('');
    setRecipientPhone('');
    setRecipientUserId('');
    setSenderAddress('');
    setReceiverAddress('');
    setPaymentMethod('');
    setCardNumber('');
    setMobileMoneyPhone('');
    setScheduleType('one_time');
    setScheduleStartDate('');
    setScheduleEndDate('');
    setShowOtp(false);
    setOtpValue('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">{t('transfers.title')}</h2>
        <p className="text-muted-foreground">{t('transfers.subtitle')}</p>
      </div>

      {/* Progress Indicator */}
      {txnType && (
        <Card className="p-4">
          <div className="flex items-center justify-between gap-2 overflow-x-auto">
            {visibleSteps.map((stepKey, idx) => {
              const isActive = currentStepKey === stepKey;
              const isCompleted = currentStepIdx > idx;
              const label = stepKey === 'type' ? t('transfers.stepType') : stepKey === 'basicInfo' ? t('transfers.stepBasicInfo') : stepKey === 'source' ? t('transfers.source') : stepKey === 'destination' ? t('transfers.destination') : stepKey === 'payment' ? t('transfers.stepPayment') : stepKey === 'schedule' ? t('transfers.stepSchedule') : stepKey === 'review' ? t('transfers.review') : stepKey;
              return (
                <div key={stepKey} className="flex items-center gap-2 flex-shrink-0">
                  {idx > 0 && (
                    <div className={`w-6 sm:w-10 h-px ${isCompleted ? 'bg-emerald-500' : 'bg-border'}`} />
                  )}
                  <button
                    onClick={() => goToStep(idx)}
                    className={`flex items-center gap-2 px-4 py-2 min-h-9 rounded-full text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                        : isCompleted
                          ? 'bg-emerald-50 text-emerald-600'
                          : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="h-3.5 w-3.5" />
                    ) : (
                      <span className={`h-3.5 w-3.5 rounded-full flex items-center justify-center text-[10px] ${isActive ? 'bg-emerald-500 text-white' : 'bg-muted-foreground/20'}`}>
                        {idx + 1}
                      </span>
                    )}
                    <span className="hidden sm:inline">{label}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Step Content */}
      <AnimatePresence mode="wait">
        {/* Step: Type Selector */}
        {currentStepKey === 'type' && (
          <motion.div
            key="step-type"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {TXN_TYPES.map((txn) => {
                const Icon = txn.icon;
                const isSelected = txnType === txn.value;
                return (
                  <motion.button
                    key={txn.value}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      setTxnType(txn.value);
                      setCurrentStepKey('basicInfo');
                    }}
                    className={`flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all text-center ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50 shadow-sm'
                        : 'border-border bg-card hover:border-emerald-300 hover:bg-muted/50'
                    }`}
                  >
                    <div className={`p-3 rounded-full ${isSelected ? 'bg-emerald-100' : 'bg-muted'}`}>
                      <Icon className={`h-6 w-6 ${isSelected ? 'text-emerald-600' : txn.color}`} />
                    </div>
                    <span className={`text-sm font-medium ${isSelected ? 'text-emerald-700' : 'text-foreground'}`}>
                      {txn.value === 'deposit' ? t('transfers.deposit') : txn.value === 'withdrawal' ? t('transfers.withdrawal') : txn.value === 'transfer' ? t('transfers.transfer') : txn.value === 'payment' ? t('transfers.payment') : txn.value === 'refund' ? t('transfers.refund') : txn.value === 'scheduled' ? t('transfers.scheduledPayment') : txn.value === 'split_payment' ? t('transfers.splitPayment') : txn.value === 'escrow' ? t('transfers.escrowPayment') : txn.label}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Step: Basic Info */}
        {currentStepKey === 'basicInfo' && txnType && (
          <motion.div
            key="step-basicInfo"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 rounded-lg bg-emerald-100">
                  {(() => {
                    const Icon = TXN_TYPES.find((t) => t.value === txnType)?.icon ?? CreditCard;
                    return <Icon className="h-5 w-5 text-emerald-600" />;
                  })()}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{TXN_TYPES.find((t) => t.value === txnType)?.label} - Basic Information</h3>
                  <p className="text-sm text-muted-foreground">{t('transfers.enterTxnDetails')}</p>
                </div>
              </div>

              <div className="space-y-6">
                {/* Amount */}
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-sm font-medium">
                    {t('common.amount')} <span className="text-rose-500">*</span>
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-3xl font-bold h-16 text-center tabular-nums"
                    min="0"
                    step="0.01"
                  />
                  {numericAmount > 0 && (
                    <p className="text-sm text-muted-foreground text-center">
                      ≈ {formatCurrency(numericAmount, currency)}
                    </p>
                  )}
                </div>

                {/* Currency */}
                <div className="space-y-2">
                  <Label htmlFor="currency" className="text-sm font-medium">
                    {t('common.currency')} <span className="text-rose-500">*</span>
                  </Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CURRENCIES.map((c) => (
                        <SelectItem key={c.code} value={c.code}>
                          {c.code} - {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description" className="text-sm font-medium">
                    {t('transfers.descriptionNote')}
                  </Label>
                  <Textarea
                    id="description"
                    placeholder={t('transfers.descriptionPlaceholder')}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Step: Source */}
        {currentStepKey === 'source' && txnType && (
          <motion.div
            key="step-source"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-1">{t('transfers.source')}</h3>
              <p className="text-sm text-muted-foreground mb-6">{t('transfers.selectFundsSource')}</p>

              {/* Source type toggle */}
              <div className="flex gap-2 mb-6">
                {(['wallet', 'bank'] as const).map((srcType) => (
                  <Button
                    key={srcType}
                    variant={sourceType === srcType ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSourceType(srcType)}
                    className={sourceType === srcType ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                  >
                    {srcType === 'wallet' ? <Wallet className="h-4 w-4 mr-1" /> : <Landmark className="h-4 w-4 mr-1" />}
                    {srcType === 'wallet' ? t('transfers.wallet') : t('transfers.bankAccount')}
                  </Button>
                ))}
              </div>

              {loadingData ? (
                <div className="space-y-3">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : sourceType === 'wallet' ? (
                <div className="space-y-4">
                  <Select value={sourceWalletId} onValueChange={setSourceWalletId}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={t('transfers.selectSourceWallet')} />
                    </SelectTrigger>
                    <SelectContent>
                      {wallets.map((w) => (
                        <SelectItem key={w.id} value={w.id}>
                          <div className="flex items-center justify-between gap-4 w-full">
                            <span>{w.user?.name ?? t('transfers.unknown')} - {w.currency}</span>
                            <span className="font-mono text-xs text-muted-foreground">
                              {formatCurrency(w.availableBalance, w.currency)}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedSourceWallet && (
                    <div className="rounded-lg bg-muted/50 p-4">
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{t('transfers.availableBalance')}</div>
                      <div className="text-xl font-bold text-emerald-600">
                        {formatCurrency(selectedSourceWallet.availableBalance, selectedSourceWallet.currency)}
                      </div>
                      {selectedSourceWallet.frozenBalance > 0 && (
                        <div className="text-sm text-amber-600 mt-1">
                          {t('transfers.frozenLabel')}: {formatCurrency(selectedSourceWallet.frozenBalance, selectedSourceWallet.currency)}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <Select value={sourceBankId} onValueChange={setSourceBankId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={t('transfers.selectSourceBank')} />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccounts.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.bankName} - {b.accountNumber} ({b.currency})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              {/* Sender Address */}
              <div className="mt-6 space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-emerald-600" />
                  <Label htmlFor="senderAddress" className="text-sm font-medium">{t('transfers.senderAddress') || 'Sender Address'}</Label>
                </div>
                <Input
                  id="senderAddress"
                  placeholder="e.g. Bole, Addis Ababa, Ethiopia"
                  value={senderAddress}
                  onChange={(e) => setSenderAddress(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">{t('transfers.senderAddressHint') || 'Confirmation address of the sender for the transaction advice'}</p>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Step: Destination */}
        {currentStepKey === 'destination' && txnType && (
          <motion.div
            key="step-destination"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-1">{t('transfers.destination')}</h3>
              <p className="text-sm text-muted-foreground mb-6">{t('transfers.selectFundsDest')}</p>

              <div className="flex flex-wrap gap-2 mb-6">
                {(['wallet', 'bank', 'p2p'] as const).map((dstType) => (
                  <Button
                    key={dstType}
                    variant={destType === dstType ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setDestType(dstType)}
                    className={destType === dstType ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                  >
                    {dstType === 'wallet' ? <Wallet className="h-4 w-4 mr-1" /> : dstType === 'bank' ? <Landmark className="h-4 w-4 mr-1" /> : <Smartphone className="h-4 w-4 mr-1" />}
                    {dstType === 'wallet' ? t('transfers.wallet') : dstType === 'bank' ? t('transfers.bankAccount') : t('transfers.p2pUser')}
                  </Button>
                ))}
              </div>

              {loadingData ? (
                <div className="space-y-3">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : destType === 'wallet' ? (
                <Select value={destWalletId} onValueChange={setDestWalletId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={t('transfers.selectDestWallet')} />
                  </SelectTrigger>
                  <SelectContent>
                    {wallets
                      .filter((w) => w.id !== sourceWalletId)
                      .map((w) => (
                        <SelectItem key={w.id} value={w.id}>
                          {w.user?.name ?? t('transfers.unknown')} - {w.currency}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              ) : destType === 'bank' ? (
                <Select value={destBankId} onValueChange={setDestBankId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={t('transfers.selectDestBank')} />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccounts.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.bankName} - {b.accountNumber} ({b.currency})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="space-y-4">
                  {/* P2P: Select from known users */}
                  <div className="space-y-2">
                    <Label>{t('transfers.selectUser')}</Label>
                    <Select
                      value={recipientUserId}
                      onValueChange={(val) => {
                        setRecipientUserId(val);
                        const user = users.find((u) => u.id === val);
                        if (user) {
                          setRecipientName(user.name);
                          setRecipientPhone(user.phone ?? '');
                        }
                      }}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder={t('transfers.chooseUser')} />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((u) => (
                          <SelectItem key={u.id} value={u.id}>
                            {u.name} {u.phone ? `(${u.phone})` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{t('transfers.recipientName')} <span className="text-rose-500">*</span></Label>
                      <Input
                        placeholder={t('transfers.fullNamePlaceholder')}
                        value={recipientName}
                        onChange={(e) => setRecipientName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{t('transfers.phoneNumber')}</Label>
                      <Input
                        placeholder="+251..."
                        value={recipientPhone}
                        onChange={(e) => setRecipientPhone(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Receiver Address */}
              <div className="mt-6 space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-teal-600" />
                  <Label htmlFor="receiverAddress" className="text-sm font-medium">{t('transfers.receiverAddress') || 'Receiver Address'}</Label>
                </div>
                <Input
                  id="receiverAddress"
                  placeholder="e.g. Kazanchis, Addis Ababa, Ethiopia"
                  value={receiverAddress}
                  onChange={(e) => setReceiverAddress(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">{t('transfers.receiverAddressHint') || 'Confirmation address of the receiver for the transaction advice'}</p>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Step: Payment Method */}
        {currentStepKey === 'payment' && txnType && (
          <PaymentMethodStep
            paymentMethod={paymentMethod}
            setPaymentMethod={setPaymentMethod}
            cardNumber={cardNumber}
            setCardNumber={setCardNumber}
            mobileMoneyPhone={mobileMoneyPhone}
            setMobileMoneyPhone={setMobileMoneyPhone}
          />
        )}

        {/* Step: Schedule */}
        {currentStepKey === 'schedule' && txnType && (
          <motion.div
            key="step-schedule"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-1">{t('transfers.stepSchedule')}</h3>
              <p className="text-sm text-muted-foreground mb-6">{t('transfers.configureSchedule')}</p>

              <RadioGroup value={scheduleType} onValueChange={setScheduleType} className="space-y-3">
                {[
                  { value: 'one_time', label: t('transfers.scheduleOneTime') },
                  { value: 'daily', label: t('transfers.scheduleDaily') },
                  { value: 'weekly', label: t('transfers.scheduleWeekly') },
                  { value: 'monthly', label: t('transfers.scheduleMonthly') },
                ].map((s) => (
                  <label
                    key={s.value}
                    className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      scheduleType === s.value
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-border hover:border-emerald-300'
                    }`}
                  >
                    <RadioGroupItem value={s.value} />
                    <span className={`text-sm font-medium ${scheduleType === s.value ? 'text-emerald-700' : 'text-foreground'}`}>
                      {s.label}
                    </span>
                  </label>
                ))}
              </RadioGroup>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                <div className="space-y-2">
                  <Label>{t('transfers.startDate')}</Label>
                  <Input
                    type="date"
                    value={scheduleStartDate}
                    onChange={(e) => setScheduleStartDate(e.target.value)}
                  />
                </div>
                {scheduleType !== 'one_time' && (
                  <div className="space-y-2">
                    <Label>{t('transfers.endDate')}</Label>
                    <Input
                      type="date"
                      value={scheduleEndDate}
                      onChange={(e) => setScheduleEndDate(e.target.value)}
                    />
                  </div>
                )}
              </div>
            </Card>
          </motion.div>
        )}

        {/* Step: Review & Confirm */}
        {currentStepKey === 'review' && txnType && (
          <motion.div
            key="step-review"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-1">{t('transfers.reviewConfirm')}</h3>
              <p className="text-sm text-muted-foreground mb-6">{t('transfers.reviewDesc')}</p>

              <div className="space-y-4">
                {/* Summary grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <ReviewField label={t('common.type')} value={getTxnLabel(txnType, t)} />
                  <ReviewField label={t('common.currency')} value={currency} />
                  <ReviewField label={t('common.amount')} value={formatCurrency(numericAmount, currency)} className="text-emerald-600 font-bold" />
                  <ReviewField label="{t('common.fee')} ({feeLabel})" value={formatCurrency(calculatedFee, currency)} />
                  <ReviewField label={t('common.total')} value={formatCurrency(numericAmount + calculatedFee, currency)} className="text-lg font-bold" />
                  {description && <ReviewField label={t('common.description')} value={description} className="sm:col-span-2" />}
                </div>

                <Separator />

                {/* Source info */}
                {visibleSteps.includes('source') && (
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">{t('transfers.source')}</h4>
                    {sourceType === 'wallet' && selectedSourceWallet && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                        <Wallet className="h-5 w-5 text-emerald-600" />
                        <div>
                          <div className="text-sm font-medium">{selectedSourceWallet.user?.name ?? 'Unknown'}</div>
                          <div className="text-xs text-muted-foreground">{selectedSourceWallet.currency} {t('transfers.wallet')} &bull; {formatCurrency(selectedSourceWallet.availableBalance, selectedSourceWallet.currency)} {t('transfers.availableLabel')}</div>
                        </div>
                      </div>
                    )}
                    {sourceType === 'bank' && selectedSourceBank && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                        <Landmark className="h-5 w-5 text-rose-600" />
                        <div>
                          <div className="text-sm font-medium">{selectedSourceBank.bankName}</div>
                          <div className="text-xs text-muted-foreground">{selectedSourceBank.accountNumber} &bull; {selectedSourceBank.accountName}</div>
                        </div>
                      </div>
                    )}
                    {!selectedSourceWallet && sourceType === 'wallet' && (
                      <div className="rounded-lg bg-muted/50 p-3 text-sm text-muted-foreground">t('transfers.noSourceWallet')</div>
                    )}
                    {!selectedSourceBank && sourceType === 'bank' && (
                      <div className="rounded-lg bg-muted/50 p-3 text-sm text-muted-foreground">t('transfers.noSourceBank')</div>
                    )}
                    {senderAddress && (
                      <div className="flex items-center gap-3 rounded-lg bg-emerald-50/50 border border-emerald-100 p-3 mt-2">
                        <MapPin className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                        <div>
                          <div className="text-xs text-muted-foreground">{t('transfers.senderAddress') || 'Sender Address'}</div>
                          <div className="text-sm font-medium">{senderAddress}</div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Destination info */}
                {visibleSteps.includes('destination') && (
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">{t('transfers.destination')}</h4>
                    {destType === 'wallet' && selectedDestWallet && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                        <Wallet className="h-5 w-5 text-teal-600" />
                        <div>
                          <div className="text-sm font-medium">{selectedDestWallet.user?.name ?? 'Unknown'}</div>
                          <div className="text-xs text-muted-foreground">{selectedDestWallet.currency} Wallet</div>
                        </div>
                      </div>
                    )}
                    {destType === 'bank' && selectedDestBank && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                        <Landmark className="h-5 w-5 text-teal-600" />
                        <div>
                          <div className="text-sm font-medium">{selectedDestBank.bankName}</div>
                          <div className="text-xs text-muted-foreground">{selectedDestBank.accountNumber} &bull; {selectedDestBank.accountName}</div>
                        </div>
                      </div>
                    )}
                    {destType === 'p2p' && (recipientName || selectedRecipientUser) && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                        <Smartphone className="h-5 w-5 text-amber-600" />
                        <div>
                          <div className="text-sm font-medium">{selectedRecipientUser?.name ?? recipientName}</div>
                          <div className="text-xs text-muted-foreground">
                            {(selectedRecipientUser?.phone ?? recipientPhone) || t('transfers.noPhone')} &bull; {(selectedRecipientUser?.email) ?? t('transfers.noEmail')}
                          </div>
                        </div>
                      </div>
                    )}
                    {receiverAddress && (
                      <div className="flex items-center gap-3 rounded-lg bg-teal-50/50 border border-teal-100 p-3 mt-2">
                        <MapPin className="h-4 w-4 text-teal-600 flex-shrink-0" />
                        <div>
                          <div className="text-xs text-muted-foreground">{t('transfers.receiverAddress') || 'Receiver Address'}</div>
                          <div className="text-sm font-medium">{receiverAddress}</div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Payment method */}
                {paymentMethod && (
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">{t('transfers.paymentMethod')}</h4>
                    <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                      <CreditCard className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm font-medium capitalize">{paymentMethod.replace(/_/g, ' ')}</span>
                      {paymentMethod.includes('card') && cardNumber && (
                        <span className="text-xs text-muted-foreground font-mono ml-auto">**** {cardNumber.slice(-4)}</span>
                      )}
                      {paymentMethod === 'mobile_money' && mobileMoneyPhone && (
                        <span className="text-xs text-muted-foreground ml-auto">{mobileMoneyPhone}</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Schedule */}
                {visibleSteps.includes('schedule') && scheduleType !== 'one_time' && (
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">{t('transfers.stepSchedule')}</h4>
                    <div className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                      <Clock className="h-5 w-5 text-cyan-600" />
                      <div>
                        <div className="text-sm font-medium capitalize">{scheduleType.replace(/_/g, ' ')}</div>
                        {scheduleStartDate && <div className="text-xs text-muted-foreground">{t('transfers.fromLabel')}: {scheduleStartDate}</div>}
                        {scheduleEndDate && <div className="text-xs text-muted-foreground">{t('transfers.untilLabel')}: {scheduleEndDate}</div>}
                      </div>
                    </div>
                  </div>
                )}

                <Separator />

                {/* Fee display */}
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="h-4 w-4 text-emerald-600" />
                    <span className="text-sm font-medium text-emerald-700">{t('transfers.feeSummary')}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-xs text-emerald-600/70">{t('common.amount')}</div>
                      <div className="text-sm font-bold text-emerald-700">{formatCurrency(numericAmount, currency)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-emerald-600/70">{t('common.fee')} ({feeLabel})</div>
                      <div className="text-sm font-bold text-emerald-700">{formatCurrency(calculatedFee, currency)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-emerald-600/70">{t('common.total')}</div>
                      <div className="text-lg font-bold text-emerald-700">{formatCurrency(numericAmount + calculatedFee, currency)}</div>
                    </div>
                  </div>
                </div>

                {/* OTP Verification */}
                {showOtp && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <Label className="text-sm font-medium">{t('transfers.otpVerification')}</Label>
                    <p className="text-xs text-muted-foreground">{t('transfers.otpDescription')}</p>
                    <div className="flex justify-center">
                      <InputOTP maxLength={6} value={otpValue} onChange={setOtpValue}>
                        <InputOTPGroup>
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                        </InputOTPGroup>
                        <InputOTPSeparator />
                        <InputOTPGroup>
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                          <InputOTPSlot index={5} />
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                    <div className="flex justify-center">
                      {otpValue.length < 6 && (
                        <p className="text-xs text-muted-foreground">
                          {t('transfers.otpEnterDigits').replace('{n}', String(6 - otpValue.length))}
                        </p>
                      )}
                      {otpValue.length === 6 && (
                        <p className="text-xs text-emerald-600 font-medium">t('transfers.codeReady')</p>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* Confirm Button */}
                <Button
                  onClick={handleSubmit}
                  disabled={submitting || numericAmount <= 0 || (showOtp && otpValue.length < 6)}
                  className="btn-responsive w-full h-12 text-base font-semibold bg-emerald-600 hover:bg-emerald-700"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      {t('transfers.processing')}
                    </>
                  ) : showOtp ? (
                    t('transfers.confirm')
                  ) : (
                    t('transfers.continueToVerify')
                  )}
                </Button>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation Buttons */}
      {!isFirstStep && !isReviewStep && (
        <div className="flex items-center justify-between btn-responsive-group">
          <Button variant="outline" onClick={prevStep}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            {t('common.back')}
          </Button>
          <Button className="btn-responsive bg-emerald-600 hover:bg-emerald-700" onClick={nextStep}>
            {t('common.next')}
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
      {isReviewStep && !showOtp && (
        <div className="flex justify-start">
          <Button variant="outline" onClick={prevStep}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            {t('common.back')}
          </Button>
        </div>
      )}
      {isReviewStep && showOtp && (
        <div className="flex justify-start">
          <Button variant="outline" onClick={prevStep}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            {t('common.back')}
          </Button>
        </div>
      )}

      {/* Transaction Advice Modal */}
      {adviceData && (
        <TransactionAdvice
          data={adviceData}
          onClose={() => setAdviceData(null)}
        />
      )}
    </motion.div>
  );
}

// --- Sub-components ---

function ReviewField({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</span>
      <span className={`text-sm ${className ?? 'text-foreground'}`}>{value || '-'}</span>
    </div>
  );
}

function getPaymentMethodLabel(value: string, t: (key: string) => string): string {
  return value === 'bank_account' ? t('transfers.bankAccount')
    : value === 'debit_card' ? t('transfers.debitCard')
    : value === 'credit_card' ? t('transfers.creditCard')
    : value === 'mobile_money' ? t('transfers.mobileMoney')
    : value === 'qr_code' ? t('transfers.qrCode')
    : value === 'digital_wallet' ? t('transfers.digitalWalletLabel')
    : value;
}

function PaymentMethodStep({
  paymentMethod,
  setPaymentMethod,
  cardNumber,
  setCardNumber,
  mobileMoneyPhone,
  setMobileMoneyPhone,
}: {
  paymentMethod: string;
  setPaymentMethod: (v: string) => void;
  cardNumber: string;
  setCardNumber: (v: string) => void;
  mobileMoneyPhone: string;
  setMobileMoneyPhone: (v: string) => void;
}) {
  const t = useT();
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-1">{t('transfers.paymentMethod')}</h3>
        <p className="text-sm text-muted-foreground mb-6">{t('transfers.choosePayment')}</p>

        <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
          {PAYMENT_METHODS.map((m) => {
            const Icon = m.icon;
            return (
              <label
                key={m.value}
                className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  paymentMethod === m.value
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-border hover:border-emerald-300'
                }`}
              >
                <RadioGroupItem value={m.value} />
                <Icon className={`h-5 w-5 ${paymentMethod === m.value ? 'text-emerald-600' : 'text-muted-foreground'}`} />
                <span className={`text-sm font-medium ${paymentMethod === m.value ? 'text-emerald-700' : 'text-foreground'}`}>
                  {getPaymentMethodLabel(m.value, t)}
                </span>
              </label>
            );
          })}
        </RadioGroup>

        {paymentMethod && (paymentMethod === 'debit_card' || paymentMethod === 'credit_card') && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-6 space-y-2"
          >
            <Label>{t('transfers.cardNumber')}</Label>
            <Input
              placeholder="1234 5678 9012 3456"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="font-mono"
              maxLength={19}
            />
          </motion.div>
        )}

        {paymentMethod === 'mobile_money' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-6 space-y-2"
          >
            <Label>{t('transfers.mobileMoneyPhone')}</Label>
            <Input
              placeholder="+251 9XX XXX XXXX"
              value={mobileMoneyPhone}
              onChange={(e) => setMobileMoneyPhone(e.target.value)}
            />
          </motion.div>
        )}
      </Card>
    </motion.div>
  );
}
