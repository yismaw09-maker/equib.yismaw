'use client';

import { useAppStore } from '@/lib/store';
import { apiFetch } from '@/lib/api-fetch';
import { getRoleInfo } from '@/lib/role-permissions';
import { useT, useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Menu,
  Search,
  Bell,
  Moon,
  Sun,
  User,
  Shield,
  Settings,
  LogOut,
  ChevronDown,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';
import type { ViewId } from '@/lib/store';
import { cn } from '@/lib/utils';

const viewLabelKeys: Record<string, string> = {
  dashboard: 'header.view.dashboard',
  wallets: 'header.view.wallets',
  transactions: 'header.view.transactions',
  transfers: 'header.view.transfers',
  banking: 'header.view.banking',
  payments: 'header.view.payments',
  currencies: 'header.view.currencies',
  'send-receive': 'header.view.send-receive',
  merchants: 'header.view.merchants',
  customers: 'header.view.customers',
  security: 'header.view.security',
  notifications: 'header.view.notifications',
  admin: 'header.view.admin',
  reports: 'header.view.reports',
  settings: 'header.view.settings',
};

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

const LANGUAGES = [
  { code: 'en', label: 'English', shortCode: 'US', flag: '\u{1F1FA}\u{1F1F8}' },
  { code: 'am', label: '\u12A0\u121B\u122D\u129B', shortCode: 'ET', flag: '\u{1F1EA}\u{1F1F9}' },
];

function LanguageToggle() {
  const { locale, setLocale } = useI18n();
  const current = LANGUAGES.find((l) => l.code === locale) ?? LANGUAGES[0];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-9 gap-2 px-2 text-sm">
          <span className="text-base leading-none">{current.flag}</span>
          <span className="hidden sm:inline text-xs font-medium text-muted-foreground">{current.shortCode}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        {LANGUAGES.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLocale(lang.code)}
            className={cn(
              'flex items-center gap-3 cursor-pointer',
              locale === lang.code && 'bg-accent'
            )}
          >
            <span className="text-xl leading-none">{lang.flag}</span>
            <div className="flex flex-col">
              <span className="text-sm font-medium">{lang.label}</span>
              <span className="text-[11px] text-muted-foreground">{lang.flag} {lang.shortCode}</span>
            </div>
            {locale === lang.code && (
              <span className="ml-auto text-xs text-emerald-600 font-medium">✓</span>
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function AppHeader() {
  const { activeView, toggleSidebar, setActiveView, user, logout } = useAppStore();
  const { theme, setTheme } = useTheme();
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [notifCount, setNotifCount] = useState(0);
  const t = useT();

  const role = user?.role || 'user';
  const roleInfo = getRoleInfo(role);
  const displayName = user?.name || 'User';
  const initials = getInitials(displayName);
  const shortName = displayName.split(' ').map(w => w[0] + '.').join(' ').slice(0, 12);

  const canSeeSecurity = roleInfo.level >= 55;
  const canSeeAdmin = roleInfo.level >= 45;

  const pageTitle = t(viewLabelKeys[activeView] || 'header.view.dashboard');

  useEffect(() => {
    apiFetch('/api/notifications?isRead=false')
      .then((r) => r.json())
      .then((d) => setNotifCount(d.unreadCount || 0))
      .catch(() => {});
  }, [activeView]);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 md:px-6">
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden h-10 w-10"
        onClick={toggleSidebar}
      >
        <Menu className="h-5 w-5" />
      </Button>

      {/* Page title */}
      <div className="flex flex-col">
        <h1 className="text-base font-semibold leading-none">
          {pageTitle}
        </h1>
        <p className="text-[11px] text-muted-foreground mt-0.5 hidden sm:block">
          {t('header.platformSubtitle')}
        </p>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Mobile search button */}
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden h-10 w-10"
        onClick={() => setMobileSearchOpen(true)}
      >
        <Search className="h-5 w-5" />
      </Button>

      {/* Mobile search overlay */}
      {mobileSearchOpen && (
        <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm md:hidden">
          <div className="flex items-center gap-3 p-4">
            <Input
              placeholder={t('header.searchPlaceholder')}
              className="flex-1 h-10 text-base"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Escape') setMobileSearchOpen(false);
              }}
            />
            <Button
              variant="ghost"
              className="h-10 px-3 text-sm"
              onClick={() => setMobileSearchOpen(false)}
            >
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Desktop search */}
      <div className="relative hidden md:flex items-center">
        {searchOpen ? (
          <div className="flex items-center gap-2">
            <Input
              placeholder={t('header.searchPlaceholder')}
              className="w-[240px] h-9"
              autoFocus
              onBlur={() => setSearchOpen(false)}
            />
          </div>
        ) : (
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={() => setSearchOpen(true)}
          >
            <Search className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Language Toggle */}
      <LanguageToggle />

      {/* Theme toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="h-10 w-10"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'dark' ? (
          <Sun className="h-4 w-4" />
        ) : (
          <Moon className="h-4 w-4" />
        )}
      </Button>

      {/* Notifications */}
      <Button
        variant="ghost"
        size="icon"
        className="h-10 w-10 relative"
        onClick={() => setActiveView('notifications')}
      >
        <Bell className="h-4 w-4" />
        {notifCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
            {notifCount > 9 ? '9+' : notifCount}
          </span>
        )}
      </Button>

      {/* User menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="min-h-10 gap-2 pl-2 pr-1">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
              {initials}
            </div>
            <span className="hidden lg:block text-sm">{shortName}</span>
            <ChevronDown className="h-3 w-3 text-muted-foreground" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel>{displayName}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <User className="mr-2 h-4 w-4" /> {t('header.profile')}
          </DropdownMenuItem>
          {canSeeSecurity && (
            <DropdownMenuItem onClick={() => setActiveView('security')}>
              <Shield className="mr-2 h-4 w-4" /> {t('common.security')}
            </DropdownMenuItem>
          )}
          <DropdownMenuItem onClick={() => setActiveView('notifications')}>
            <Bell className="mr-2 h-4 w-4" /> {t('header.notifications')}
            {notifCount > 0 && (
              <Badge variant="secondary" className="ml-auto text-[10px]">
                {notifCount}
              </Badge>
            )}
          </DropdownMenuItem>
          {canSeeAdmin && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setActiveView('admin')}>
                <Settings className="mr-2 h-4 w-4" /> {t('header.adminPanel')}
              </DropdownMenuItem>
            </>
          )}
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-destructive" onClick={logout}>
            <LogOut className="mr-2 h-4 w-4" /> {t('header.signOut')}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
