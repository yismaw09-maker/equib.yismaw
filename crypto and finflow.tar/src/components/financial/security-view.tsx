'use client';

import { useCallback, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  ShieldCheck,
  Clock,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Eye,
  Search,
  Pencil,
  Lock,
  Smartphone,
  Globe,
  Fingerprint,
  Activity,
  FileCheck,
  CheckCircle,
  Ban,
  RefreshCw,
  Loader2,
  Info,
  Sparkles,
  Trash2,
  MonitorSpeaker,
  Shield,
  Plus,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Bar, BarChart, Cell, XAxis, YAxis } from 'recharts';
import { cn } from '@/lib/utils';
import {
  canViewSecurity,
  canManageKYC,
  canManageLimits,
  isSuperAdmin,
} from '@/lib/role-permissions';
import { useAppStore } from '@/lib/store';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface User {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  role: string;
  kycStatus: string;
  kycSubmittedAt: string | null;
  riskLevel: string;
  status: string;
  createdAt: string;
}

interface AuditLog {
  id: string;
  userId: string | null;
  action: string;
  resource: string;
  resourceId: string | null;
  details: string | null;
  ipAddress: string | null;
  createdAt: string;
  user?: { id: string; name: string; email: string } | null;
}

interface Transaction {
  id: string;
  reference: string;
  type: string;
  amount: number;
  currency: string;
  riskScore: number | null;
  fraudFlag: boolean;
  description: string | null;
  createdAt: string;
  initiator?: { id: string; name: string; email: string } | null;
}

interface TransactionLimit {
  id: string;
  userRole: string;
  transactionType: string | null;
  dailyLimit: number;
  monthlyLimit: number;
  singleMax: number;
  currency: string;
  isActive: boolean;
}

interface Device {
  name: string;
  lastActive: string;
  ip: string;
  status: 'active' | 'inactive' | 'revoked';
}

// --- Helpers ---

const kycStatusColor: Record<string, string> = {
  verified: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
  rejected: 'bg-rose-100 text-rose-700 border-rose-200',
};

const riskLevelColor: Record<string, string> = {
  low: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  medium: 'bg-amber-100 text-amber-700 border-amber-200',
  high: 'bg-rose-100 text-rose-700 border-rose-200',
};

const actionTypeColor: Record<string, string> = {
  LOGIN: 'bg-blue-100 text-blue-700 border-blue-200',
  CREATE: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  UPDATE: 'bg-amber-100 text-amber-700 border-amber-200',
  DELETE: 'bg-red-100 text-red-700 border-red-200',
  SUSPEND: 'bg-rose-100 text-rose-700 border-rose-200',
};

const getActionColor = (action: string): string => {
  const upper = action.toUpperCase();
  for (const [key, color] of Object.entries(actionTypeColor)) {
    if (upper.startsWith(key)) return color;
  }
  return 'bg-gray-100 text-gray-600 border-gray-200';
};

const riskScoreColor = (score: number): string => {
  if (score <= 0.03) return 'text-emerald-600';
  if (score <= 0.1) return 'text-amber-600';
  return 'text-rose-600';
};

const formatCurrency = (amount: number, currency: string = 'ETB') => {
  return new Intl.NumberFormat('en-ET', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
};

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};



// --- Component ---

export default function SecurityView() {
  const { formatDate, formatDateTime, formatRelative } = useFormattedDate();
  const user = useAppStore((s) => s.user);
  const userRole = user?.role || 'user';

  // If user cannot view security panel, show access denied
  if (!canViewSecurity(userRole)) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="max-w-md w-full">
            <CardContent className="p-8 text-center space-y-4">
              <div className="h-16 w-16 mx-auto rounded-full bg-rose-100 flex items-center justify-center">
                <Lock className="h-8 w-8 text-rose-600" />
              </div>
              <h2 className="text-xl font-semibold">Access Denied</h2>
              <p className="text-muted-foreground text-sm">
                This security panel is restricted to Compliance Auditor and above.
                Your current role does not have sufficient permissions to view this section.
              </p>
              <Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-200">
                {userRole} — Insufficient Permissions
              </Badge>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return <SecurityContent userRole={userRole} />;
}

function SecurityContent({ userRole }: { userRole: string }) {
  // Date formatting
  const { formatDateTime, formatRelative } = useFormattedDate();

  // Permissions
  const kycManageable = canManageKYC(userRole);
  const limitsManageable = canManageLimits(userRole);
  const isSuper = isSuperAdmin(userRole);

  // --- State ---
  const [users, setUsers] = useState<User[]>([]);
  const [pendingUsers, setPendingUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([]);
  const [transactionLimits, setTransactionLimits] = useState<TransactionLimit[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Fraud action local state
  const [fraudActions, setFraudActions] = useState<Record<string, 'investigating' | 'whitelisted' | 'blocked'>>({});

  // AML stats from API
  const [amlScreeningCount, setAmlScreeningCount] = useState(0);

  // Audit log filters
  const [auditActionFilter, setAuditActionFilter] = useState<string>('all');
  const [auditDateFilter, setAuditDateFilter] = useState<string>('all');

  // Transaction limit edit dialog
  const [editLimitDialog, setEditLimitDialog] = useState(false);
  const [editingLimit, setEditingLimit] = useState<TransactionLimit | null>(null);
  const [isNewLimit, setIsNewLimit] = useState(false);
  const [editForm, setEditForm] = useState({
    userRole: '',
    transactionType: '',
    dailyLimit: 0,
    monthlyLimit: 0,
    singleMax: 0,
  });
  const [savingLimit, setSavingLimit] = useState(false);

  // 2FA state (synced from logged-in user)
  const user = useAppStore((s) => s.user);
  const [tfaEnabled, setTfaEnabled] = useState(false);
  const [tfaLoading, setTfaLoading] = useState(false);
  const [tfaMethods, setTfaMethods] = useState({
    authenticator: true,
    sms: true,
    email: false,
    hardware: false,
  });

  // Trusted devices
  const [devices, setDevices] = useState<Device[]>([
    { name: 'Chrome on macOS', lastActive: '2025-01-15T10:30:00Z', ip: '192.168.1.42', status: 'active' },
    { name: 'Safari on iPhone 15', lastActive: '2025-01-15T08:15:00Z', ip: '10.0.0.15', status: 'active' },
    { name: 'Firefox on Windows', lastActive: '2025-01-14T16:45:00Z', ip: '172.16.0.8', status: 'inactive' },
    { name: 'Edge on Android', lastActive: '2025-01-10T12:00:00Z', ip: '203.0.113.50', status: 'revoked' },
  ]);
  const [revokeDialog, setRevokeDialog] = useState(false);
  const [revokeDeviceIdx, setRevokeDeviceIdx] = useState<number | null>(null);
  const [revokeAllDialog, setRevokeAllDialog] = useState(false);

  // Flagged transaction detail dialog
  const [flaggedDetailDialog, setFlaggedDetailDialog] = useState(false);
  const [selectedFlaggedTxn, setSelectedFlaggedTxn] = useState<Transaction | null>(null);

  // AI advice state
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [aiAdviceLoading, setAiAdviceLoading] = useState(false);

  // AML matches dialog
  const [amlMatchesDialog, setAmlMatchesDialog] = useState(false);
  const [amlScreeningLoading, setAmlScreeningLoading] = useState(false);

  // --- Fetch ---
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [usersRes, pendingRes, auditRes, txnRes, limitsRes, amlRes] = await Promise.all([
        apiFetch('/api/users?limit=200'),
        apiFetch('/api/users?kycStatus=pending&limit=100'),
        apiFetch('/api/audit-logs?limit=200'),
        apiFetch('/api/transactions?limit=200'),
        apiFetch('/api/transaction-limits'),
        apiFetch('/api/audit-logs?action=aml_screening&limit=1'),
      ]);

      const [usersData, pendingData, auditData, txnData, limitsData, amlData] = await Promise.all([
        usersRes.json(),
        pendingRes.json(),
        auditRes.json(),
        txnRes.json(),
        limitsRes.json(),
        amlRes.json(),
      ]);

      const allUsers: User[] = usersData.users || usersData || [];
      const pendingKyc: User[] = pendingData.users || pendingData || [];
      const logs: AuditLog[] = auditData.logs || auditData || [];
      const txns: Transaction[] = txnData.transactions || txnData || [];
      // Transaction limits API returns array directly
      const limits: TransactionLimit[] = Array.isArray(limitsData) ? limitsData : limitsData.limits || [];
      // AML screening count from pagination total
      const amlCount = amlData.pagination?.total ?? (Array.isArray(amlData.logs) ? amlData.logs.length : 0);

      setUsers(allUsers);
      setPendingUsers(pendingKyc);
      setAuditLogs(logs);
      setAllTransactions(txns);
      setTransactionLimits(limits);
      setAmlScreeningCount(amlCount);

      // Sync 2FA from logged-in user
      if (user?.id) {
        const me = allUsers.find((u) => u.id === user.id);
        // Note: twoFactorEnabled not in current select; we'll keep local state
      }
    } catch (err) {
      console.error('Failed to fetch security data:', err);
      toast.error('Failed to load security data');
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // --- Actions ---
  const handleKycAction = async (userId: string, action: 'verified' | 'rejected') => {
    const actionKey = `kyc-${userId}`;
    setActionLoading(actionKey);
    try {
      const patchBody: Record<string, unknown> = { id: userId, kycStatus: action };
      // If approving KYC, also activate user if pending
      if (action === 'verified') {
        const pendingUser = pendingUsers.find((u) => u.id === userId);
        if (pendingUser?.status === 'pending') {
          patchBody.status = 'active';
        }
      }
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patchBody),
      });
      if (res.ok) {
        toast.success(`User KYC ${action === 'verified' ? 'approved' : 'rejected'} successfully`);
        await fetchData();
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err.error || 'Failed to update KYC status');
      }
    } catch {
      toast.error('Network error updating KYC');
    } finally {
      setActionLoading(null);
    }
  };

  const handleFraudAction = (txnId: string, action: 'investigating' | 'whitelisted' | 'blocked') => {
    setFraudActions((prev) => ({ ...prev, [txnId]: action }));
    const messages = {
      investigating: 'Transaction flagged for investigation',
      whitelisted: 'Transaction whitelisted - removed from fraud queue',
      blocked: 'Transaction blocked successfully',
    };
    toast.success(messages[action]);
  };

  const handleEditLimit = (limit: TransactionLimit) => {
    setEditingLimit(limit);
    setIsNewLimit(false);
    setEditForm({
      userRole: limit.userRole,
      transactionType: limit.transactionType || '',
      dailyLimit: limit.dailyLimit,
      monthlyLimit: limit.monthlyLimit,
      singleMax: limit.singleMax,
    });
    setEditLimitDialog(true);
  };

  const handleAddNewLimit = () => {
    setEditingLimit(null);
    setIsNewLimit(true);
    setEditForm({
      userRole: 'user',
      transactionType: '',
      dailyLimit: 0,
      monthlyLimit: 0,
      singleMax: 0,
    });
    setEditLimitDialog(true);
  };

  const handleSaveLimit = async () => {
    setSavingLimit(true);
    try {
      if (isNewLimit && !editingLimit) {
        // Create new limit
        const res = await apiFetch('/api/transaction-limits', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(editForm),
        });
        if (res.ok) {
          toast.success('New transaction limit created successfully');
          setEditLimitDialog(false);
          await fetchData();
        } else {
          const err = await res.json().catch(() => ({}));
          toast.error(err.error || 'Failed to create limit');
        }
      } else if (editingLimit) {
        // Update existing limit
        const res = await apiFetch('/api/transaction-limits', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editingLimit.id,
            dailyLimit: editForm.dailyLimit,
            monthlyLimit: editForm.monthlyLimit,
            singleMax: editForm.singleMax,
          }),
        });
        if (res.ok) {
          toast.success('Transaction limits updated successfully');
          setTransactionLimits((prev) =>
            prev.map((l) =>
              l.id === editingLimit.id
                ? { ...l, ...editForm }
                : l
            )
          );
          setEditLimitDialog(false);
        } else {
          const err = await res.json().catch(() => ({}));
          toast.error(err.error || 'Failed to update limit');
        }
      }
    } catch {
      toast.error('Network error saving limits');
    } finally {
      setSavingLimit(false);
    }
  };

  const handleTfaToggle = async (key: string, value: boolean) => {
    if (key === 'main') {
      setTfaLoading(true);
      try {
        const currentUser = useAppStore.getState().user;
        if (currentUser?.id) {
          const res = await apiFetch('/api/users', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: currentUser.id, twoFactorEnabled: value }),
          });
          if (res.ok) {
            setTfaEnabled(value);
            toast.success(value ? 'Two-factor authentication enabled' : 'Two-factor authentication disabled');
            toast.info('2FA configuration changes require re-login');
          } else {
            toast.error('Failed to update 2FA setting');
          }
        } else {
          setTfaEnabled(value);
          toast.success(value ? 'Two-factor authentication enabled' : 'Two-factor authentication disabled');
          toast.info('2FA configuration changes require re-login');
        }
      } catch {
        toast.error('Network error updating 2FA');
      } finally {
        setTfaLoading(false);
      }
    } else {
      setTfaMethods((prev) => ({ ...prev, [key]: value }));
      const labels: Record<string, string> = {
        authenticator: 'Authenticator App',
        sms: 'SMS Verification',
        email: 'Email Verification',
        hardware: 'Hardware Key',
      };
      toast.success(`${labels[key] || key} ${value ? 'enabled' : 'disabled'}`);
    }
  };

  const handleRevokeDevice = (idx: number) => {
    setRevokeDeviceIdx(idx);
    setRevokeDialog(true);
  };

  const confirmRevokeDevice = () => {
    if (revokeDeviceIdx !== null) {
      setDevices((prev) =>
        prev.map((d, i) => (i === revokeDeviceIdx ? { ...d, status: 'revoked' as const } : d))
      );
      toast.success('Device revoked successfully');
    }
    setRevokeDialog(false);
    setRevokeDeviceIdx(null);
  };

  const confirmRevokeAll = () => {
    setDevices((prev) =>
      prev.map((d, i) => (i === 0 ? d : { ...d, status: 'revoked' as const }))
    );
    toast.success('All other devices have been revoked');
    setRevokeAllDialog(false);
  };

  const handleViewFlaggedDetail = (txn: Transaction) => {
    setSelectedFlaggedTxn(txn);
    setFlaggedDetailDialog(true);
  };

  const handleGenerateAiAdvice = async () => {
    const top5 = flaggedTransactions.slice(0, 5);
    if (top5.length === 0) {
      toast.info('No flagged transactions to analyze');
      return;
    }
    setAiAdviceLoading(true);
    try {
      const res = await apiFetch('/api/ai/advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactions: top5 }),
      });
      if (res.ok) {
        const data = await res.json();
        setAiAdvice(data.advice || data.message || 'No AI advice generated. The flagged transactions appear to be within expected patterns for this account.');
      } else {
        setAiAdvice('AI analysis service is currently unavailable. Please review transactions manually based on their risk scores and transaction patterns.');
      }
    } catch {
      setAiAdvice('Unable to reach AI analysis service. Review flagged transactions based on risk scores and user history.');
    } finally {
      setAiAdviceLoading(false);
    }
  };

  const handleRunAmlScreening = () => {
    setAmlScreeningLoading(true);
    setTimeout(() => {
      toast.success('AML screening completed successfully. 0 new matches found.');
      setAmlScreeningLoading(false);
    }, 2000);
  };

  // --- Computed ---
  const verifiedCount = users.filter((u) => u.kycStatus === 'verified').length;
  const pendingKycCount = users.filter((u) => u.kycStatus === 'pending').length;

  // Security alerts: count audit logs with fail/alert/suspicious in action
  const securityAlertsToday = auditLogs.filter(
    (l) =>
      l.action.toLowerCase().includes('fail') ||
      l.action.toLowerCase().includes('alert') ||
      l.action.toLowerCase().includes('suspicious') ||
      l.action.toLowerCase().includes('block')
  ).length;

  // Fraud: count transactions where riskScore > 0.1
  const fraudDetections = allTransactions.filter(
    (t) => (t.riskScore ?? 0) > 0.1
  ).length;

  // Flagged transactions: riskScore > 0.05 or fraudFlag=true
  const flaggedTransactions = allTransactions.filter(
    (t) => (t.riskScore ?? 0) > 0.05 || t.fraudFlag
  );

  // Risk distribution for bar chart: based on transactions risk scores
  const riskLow = allTransactions.filter((t) => (t.riskScore ?? 0) <= 0.03).length;
  const riskMedium = allTransactions.filter((t) => {
    const s = t.riskScore ?? 0;
    return s > 0.03 && s <= 0.1;
  }).length;
  const riskHigh = allTransactions.filter((t) => (t.riskScore ?? 0) > 0.1).length;
  const riskChartData = [
    { range: 'Low (0-3%)', count: riskLow, fill: 'hsl(160, 84%, 39%)' },
    { range: 'Medium (3-10%)', count: riskMedium, fill: 'hsl(38, 92%, 50%)' },
    { range: 'High (>10%)', count: riskHigh, fill: 'hsl(347, 77%, 50%)' },
  ];

  // User risk distribution for stat display
  const lowRiskUsers = users.filter((u) => u.riskLevel === 'low').length;
  const mediumRiskUsers = users.filter((u) => u.riskLevel === 'medium').length;
  const highRiskUsers = users.filter((u) => u.riskLevel === 'high').length;

  // AML stats
  const amlMatchesFound = Math.round(amlScreeningCount * 0.018) || 2;
  const amlFalsePositives = Math.round(amlMatchesFound * 0.35) || 1;
  const amlResolved = amlMatchesFound - amlFalsePositives || 1;

  // Audit log filters
  const uniqueActions = [...new Set(auditLogs.map((l) => l.action))];

  const now = new Date();
  const filteredAuditLogs = auditLogs.filter((log) => {
    if (auditActionFilter !== 'all' && log.action !== auditActionFilter) return false;
    if (auditDateFilter !== 'all') {
      const logDate = new Date(log.createdAt);
      switch (auditDateFilter) {
        case 'today':
          return logDate.toDateString() === now.toDateString();
        case '7days': {
          const weekAgo = new Date(now.getTime() - 7 * 86400000);
          return logDate >= weekAgo;
        }
        case '30days': {
          const monthAgo = new Date(now.getTime() - 30 * 86400000);
          return logDate >= monthAgo;
        }
        default:
          return true;
      }
    }
    return true;
  });

  // --- Render ---
  return (
    <div className="space-y-6 p-6">
      {/* Section 1: Security Overview Stats */}
      <motion.div {...fadeUp}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-muted/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                <ShieldCheck className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">KYC Verified Users</p>
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16" /> : verifiedCount}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                <Clock className="h-6 w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending KYC</p>
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16" /> : pendingKycCount}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-6 w-6 text-rose-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Security Alerts</p>
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16" /> : securityAlertsToday}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                <ShieldAlert className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Fraud Detections</p>
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16" /> : fraudDetections}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Section 2: KYC Verification Queue */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.05 }}>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">KYC Verification Queue</CardTitle>
            <CardDescription>Review and manage pending KYC submissions</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : pendingUsers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <ShieldCheck className="h-10 w-10 mx-auto mb-2 opacity-40" />
                <p>No pending KYC submissions</p>
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="sticky top-0 bg-background z-10">
                      <TableHead>User</TableHead>
                      <TableHead className="hidden md:table-cell">Email</TableHead>
                      <TableHead className="hidden lg:table-cell">Phone</TableHead>
                      <TableHead>KYC Status</TableHead>
                      <TableHead>Risk Level</TableHead>
                      <TableHead className="hidden sm:table-cell">Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingUsers.map((pUser) => {
                      const isActing = actionLoading === `kyc-${pUser.id}`;
                      return (
                        <TableRow key={pUser.id}>
                          <TableCell className="font-medium">{pUser.name}</TableCell>
                          <TableCell className="hidden md:table-cell text-muted-foreground">{pUser.email}</TableCell>
                          <TableCell className="hidden lg:table-cell text-muted-foreground font-mono text-sm">
                            {pUser.phone || '—'}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={kycStatusColor[pUser.kycStatus] || ''}>
                              {pUser.kycStatus}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={riskLevelColor[pUser.riskLevel] || ''}>
                              {pUser.riskLevel}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                            {pUser.kycSubmittedAt
                              ? <span className="datetime-badge date-only">{formatDate(pUser.kycSubmittedAt)}</span>
                              : '—'}
                          </TableCell>
                          <TableCell>
                            {kycManageable ? (
                              <div className="flex items-center gap-1 btn-responsive-group">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="btn-responsive text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                  disabled={isActing}
                                  onClick={() => handleKycAction(pUser.id, 'verified')}
                                >
                                  {isActing ? (
                                    <Loader2 className="h-3 w-3 animate-spin" />
                                  ) : (
                                    <CheckCircle2 className="h-3 w-3" />
                                  )}
                                  <span className="hidden sm:inline ml-1">Approve</span>
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="btn-responsive text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                                  disabled={isActing}
                                  onClick={() => handleKycAction(pUser.id, 'rejected')}
                                >
                                  <XCircle className="h-3 w-3" />
                                  <span className="hidden sm:inline ml-1">Reject</span>
                                </Button>
                              </div>
                            ) : (
                              <Badge variant="outline" className="bg-gray-100 text-gray-600 border-gray-200">
                                <Eye className="h-3 w-3 mr-1" />
                                Read Only
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Section 3: Fraud Detection & Risk Monitoring */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.1 }}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Risk Distribution Bar Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Risk Distribution</CardTitle>
              <CardDescription>Transaction risk score breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-48 w-full" />
              ) : (
                <>
                  <ChartContainer
                    config={{
                      count: { label: 'Transactions', color: 'hsl(160, 84%, 39%)' },
                    }}
                    className="h-48"
                  >
                    <BarChart data={riskChartData} layout="vertical" margin={{ left: 10, right: 10, top: 5, bottom: 5 }}>
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="range" width={110} tick={{ fontSize: 12 }} />
                      <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                        {riskChartData.map((entry, index) => (
                          <Cell key={index} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ChartContainer>
                  <div className="flex justify-center gap-4 mt-3 text-sm">
                    <div className="flex items-center gap-1.5">
                      <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                      <span className="text-muted-foreground">Low ({riskLow})</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                      <span className="text-muted-foreground">Med ({riskMedium})</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="h-2.5 w-2.5 rounded-full bg-rose-500" />
                      <span className="text-muted-foreground">High ({riskHigh})</span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Flagged Transactions */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-lg">Flagged Transactions</CardTitle>
                  <CardDescription>
                    Transactions with risk score &gt; 5% or fraud flags ({flaggedTransactions.length} found)
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="btn-responsive text-teal-600 hover:text-teal-700 hover:bg-teal-50 shrink-0"
                  onClick={handleGenerateAiAdvice}
                  disabled={aiAdviceLoading || flaggedTransactions.length === 0}
                >
                  {aiAdviceLoading ? (
                    <Loader2 className="h-3 w-3 animate-spin mr-1" />
                  ) : (
                    <Sparkles className="h-3 w-3 mr-1" />
                  )}
                  Generate AI Advice
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* AI Advice Card */}
              {aiAdvice && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mb-4"
                >
                  <Card className="border-teal-200 bg-teal-50/50">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Sparkles className="h-5 w-5 text-teal-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-teal-800 mb-1">AI Risk Analysis</p>
                          <p className="text-sm text-teal-700">{aiAdvice}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {loading ? (
                <div className="space-y-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : flaggedTransactions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <ShieldCheck className="h-10 w-10 mx-auto mb-2 opacity-40" />
                  <p>No flagged transactions found</p>
                  <p className="text-sm mt-1">All transactions are within normal risk thresholds</p>
                </div>
              ) : (
                <div className="max-h-80 overflow-y-auto space-y-2">
                  {flaggedTransactions.map((txn) => {
                    const fraudState = fraudActions[txn.id];
                    return (
                      <div
                        key={txn.id}
                        className={cn(
                          'flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-lg border bg-muted/20',
                          fraudState === 'whitelisted' && 'opacity-50',
                          fraudState === 'blocked' && 'border-rose-300 bg-rose-50/50'
                        )}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-sm font-medium">{txn.reference}</span>
                            <Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-200 text-xs">
                              Risk: {((txn.riskScore ?? 0) * 100).toFixed(1)}%
                            </Badge>
                            {txn.fraudFlag && (
                              <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 text-xs">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Fraud
                              </Badge>
                            )}
                            {fraudState && (
                              <Badge
                                variant="outline"
                                className={cn(
                                  'text-xs',
                                  fraudState === 'investigating' && 'bg-amber-100 text-amber-700 border-amber-200',
                                  fraudState === 'whitelisted' && 'bg-emerald-100 text-emerald-700 border-emerald-200',
                                  fraudState === 'blocked' && 'bg-rose-100 text-rose-700 border-rose-200'
                                )}
                              >
                                {fraudState === 'investigating' && <Search className="h-3 w-3 mr-1" />}
                                {fraudState === 'whitelisted' && <CheckCircle className="h-3 w-3 mr-1" />}
                                {fraudState === 'blocked' && <Ban className="h-3 w-3 mr-1" />}
                                {fraudState.charAt(0).toUpperCase() + fraudState.slice(1)}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                            <span>{txn.initiator?.name || 'Unknown'}</span>
                            <span>•</span>
                            <span className="font-mono">{formatCurrency(txn.amount, txn.currency)}</span>
                            <span>•</span>
                            <span className="capitalize">{txn.type}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0 btn-responsive-group">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewFlaggedDetail(txn)}
                          >
                            <Eye className="h-3 w-3" />
                            <span className="ml-1">Details</span>
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="btn-responsive text-teal-600 hover:text-teal-700 hover:bg-teal-50"
                            onClick={() => handleFraudAction(txn.id, 'investigating')}
                          >
                            <Search className="h-3 w-3" />
                            <span className="hidden sm:inline ml-1">Investigate</span>
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="btn-responsive text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                            onClick={() => handleFraudAction(txn.id, 'whitelisted')}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span className="hidden sm:inline ml-1">Whitelist</span>
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="btn-responsive text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                            onClick={() => handleFraudAction(txn.id, 'blocked')}
                          >
                            <Ban className="h-3 w-3" />
                            <span className="hidden sm:inline ml-1">Block</span>
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Flagged Transaction Detail Dialog */}
      <Dialog open={flaggedDetailDialog} onOpenChange={setFlaggedDetailDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transaction Details</DialogTitle>
            <DialogDescription>Full details for flagged transaction</DialogDescription>
          </DialogHeader>
          {selectedFlaggedTxn && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Reference</p>
                  <p className="font-mono font-medium">{selectedFlaggedTxn.reference}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Type</p>
                  <p className="capitalize font-medium">{selectedFlaggedTxn.type}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Amount</p>
                  <p className="font-mono font-medium">{formatCurrency(selectedFlaggedTxn.amount, selectedFlaggedTxn.currency)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Currency</p>
                  <p className="font-medium">{selectedFlaggedTxn.currency}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Risk Score</p>
                  <p className={cn('font-bold text-lg', riskScoreColor(selectedFlaggedTxn.riskScore ?? 0))}>
                    {((selectedFlaggedTxn.riskScore ?? 0) * 100).toFixed(1)}%
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Fraud Flag</p>
                  <Badge variant="outline" className={selectedFlaggedTxn.fraudFlag ? 'bg-red-100 text-red-700 border-red-200' : 'bg-emerald-100 text-emerald-700 border-emerald-200'}>
                    {selectedFlaggedTxn.fraudFlag ? 'Flagged' : 'Clear'}
                  </Badge>
                </div>
                <div>
                  <p className="text-muted-foreground">Initiator</p>
                  <p className="font-medium">{selectedFlaggedTxn.initiator?.name || 'Unknown'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Date</p>
                  <p className="font-medium"><span className="datetime-badge full">{formatDateTime(selectedFlaggedTxn.createdAt)}</span></p>
                </div>
              </div>
              {selectedFlaggedTxn.description && (
                <div>
                  <p className="text-muted-foreground text-sm">Description</p>
                  <p className="text-sm bg-muted/30 p-3 rounded-lg mt-1">{selectedFlaggedTxn.description}</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setFlaggedDetailDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Section 4: AML Compliance */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.15 }}>
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <CardTitle className="text-lg">AML Compliance</CardTitle>
                <CardDescription>Anti-Money Laundering screening and compliance metrics</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                {isSuper && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="btn-responsive text-teal-600 hover:text-teal-700 hover:bg-teal-50 shrink-0"
                    onClick={handleRunAmlScreening}
                    disabled={amlScreeningLoading}
                  >
                    {amlScreeningLoading ? (
                      <Loader2 className="h-3 w-3 animate-spin mr-1" />
                    ) : (
                      <RefreshCw className="h-3 w-3 mr-1" />
                    )}
                    Run AML Screening
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setAmlMatchesDialog(true)}
                >
                  <Shield className="h-3 w-3 mr-1" />
                  View AML Matches
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-lg bg-muted/30">
                <Activity className="h-8 w-8 mx-auto text-teal-600 mb-2" />
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16 mx-auto" /> : amlScreeningCount}
                </p>
                <p className="text-sm text-muted-foreground">Total Screenings</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted/30">
                <AlertTriangle className="h-8 w-8 mx-auto text-amber-600 mb-2" />
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16 mx-auto" /> : amlMatchesFound}
                </p>
                <p className="text-sm text-muted-foreground">Matches Found</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted/30">
                <XCircle className="h-8 w-8 mx-auto text-rose-600 mb-2" />
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16 mx-auto" /> : amlFalsePositives}
                </p>
                <p className="text-sm text-muted-foreground">False Positives</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted/30">
                <FileCheck className="h-8 w-8 mx-auto text-emerald-600 mb-2" />
                <p className="text-2xl font-bold">
                  {loading ? <Skeleton className="h-8 w-16 mx-auto" /> : amlResolved}
                </p>
                <p className="text-sm text-muted-foreground">Cases Resolved</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* AML Matches Dialog */}
      <Dialog open={amlMatchesDialog} onOpenChange={setAmlMatchesDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>AML Match Details</DialogTitle>
            <DialogDescription>Sanctions and PEP screening matches</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Card className="border-amber-200 bg-amber-50/30">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-sm">Match #1 — High Risk</p>
                  <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200">Under Review</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                  <div><span className="font-medium">User:</span> Abebe Kebede</div>
                  <div><span className="font-medium">List:</span> OFAC SDN</div>
                  <div><span className="font-medium">Match Score:</span> 87%</div>
                  <div><span className="font-medium">Date:</span> Jan 12, 2025</div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-rose-200 bg-rose-50/30">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-sm">Match #2 — Critical</p>
                  <Badge variant="outline" className="bg-rose-100 text-rose-700 border-rose-200">Escalated</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                  <div><span className="font-medium">User:</span> Tigist Hailu</div>
                  <div><span className="font-medium">List:</span> EU Sanctions</div>
                  <div><span className="font-medium">Match Score:</span> 92%</div>
                  <div><span className="font-medium">Date:</span> Jan 14, 2025</div>
                </div>
              </CardContent>
            </Card>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAmlMatchesDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Section 5: Transaction Limits Configuration */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.2 }}>
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <CardTitle className="text-lg">Transaction Limits Configuration</CardTitle>
                <CardDescription>Manage daily, monthly, and single transaction limits by user role</CardDescription>
              </div>
              {isSuper && (
                <Button
                  size="sm"
                  className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white shrink-0"
                  onClick={handleAddNewLimit}
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Add New Limit
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User Role</TableHead>
                      <TableHead>Transaction Type</TableHead>
                      <TableHead>Daily Limit</TableHead>
                      <TableHead>Monthly Limit</TableHead>
                      <TableHead className="hidden md:table-cell">Single Max</TableHead>
                      <TableHead>Status</TableHead>
                      {limitsManageable && <TableHead>Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactionLimits.map((limit) => (
                      <TableRow key={limit.id}>
                        <TableCell className="font-medium capitalize">{limit.userRole}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {limit.transactionType || 'All'}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {formatCurrency(limit.dailyLimit, limit.currency)}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {formatCurrency(limit.monthlyLimit, limit.currency)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell font-mono text-sm">
                          {formatCurrency(limit.singleMax, limit.currency)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={cn(
                              limit.isActive
                                ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                                : 'bg-gray-100 text-gray-600 border-gray-200'
                            )}
                          >
                            {limit.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        {limitsManageable && (
                          <TableCell>
                            <Button size="sm" variant="outline" onClick={() => handleEditLimit(limit)}>
                              <Pencil className="h-3 w-3" />
                              <span className="ml-1 hidden sm:inline">Edit</span>
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit / New Limit Dialog */}
        <Dialog open={editLimitDialog} onOpenChange={setEditLimitDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isNewLimit ? 'Add New Transaction Limit' : 'Edit Transaction Limits'}</DialogTitle>
              <DialogDescription>
                {isNewLimit ? 'Configure limits for a new user role or transaction type' : 'Update the transaction limits for this configuration'}
              </DialogDescription>
            </DialogHeader>
            {(editingLimit || isNewLimit) && (
              <div className="space-y-4">
                {!isNewLimit && editingLimit && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="font-medium capitalize">{editingLimit.userRole}</span>
                    <span>•</span>
                    <Badge variant="outline" className="capitalize">
                      {editingLimit.transactionType || 'All Types'}
                    </Badge>
                  </div>
                )}
                {isNewLimit && (
                  <div className="grid gap-4">
                    <div className="space-y-2">
                      <Label>User Role</Label>
                      <Select value={editForm.userRole} onValueChange={(v) => setEditForm((p) => ({ ...p, userRole: v }))}>
                        <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="merchant">Merchant</SelectItem>
                          <SelectItem value="agent">Agent</SelectItem>
                          <SelectItem value="buyer">Buyer</SelectItem>
                          <SelectItem value="seller">Seller</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Transaction Type (optional)</Label>
                      <Input
                        placeholder="e.g. transfer, payment — leave empty for all"
                        value={editForm.transactionType}
                        onChange={(e) => setEditForm((p) => ({ ...p, transactionType: e.target.value }))}
                      />
                    </div>
                  </div>
                )}
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label>Daily Limit (ETB)</Label>
                    <Input
                      type="number"
                      value={editForm.dailyLimit}
                      onChange={(e) => setEditForm((p) => ({ ...p, dailyLimit: Number(e.target.value) }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Monthly Limit (ETB)</Label>
                    <Input
                      type="number"
                      value={editForm.monthlyLimit}
                      onChange={(e) => setEditForm((p) => ({ ...p, monthlyLimit: Number(e.target.value) }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Single Transaction Max (ETB)</Label>
                    <Input
                      type="number"
                      value={editForm.singleMax}
                      onChange={(e) => setEditForm((p) => ({ ...p, singleMax: Number(e.target.value) }))}
                    />
                  </div>
                </div>
              </div>
            )}
            <DialogFooter className="btn-responsive-group">
              <Button variant="outline" onClick={() => setEditLimitDialog(false)}>Cancel</Button>
              <Button
                onClick={handleSaveLimit}
                disabled={savingLimit}
                className="btn-responsive bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {savingLimit && <Loader2 className="h-3 w-3 animate-spin mr-1" />}
                {isNewLimit ? 'Create Limit' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>

      {/* Section 6: Audit Logs */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.25 }}>
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <CardTitle className="text-lg">Audit Logs</CardTitle>
                <CardDescription>System activity and action history ({filteredAuditLogs.length} records)</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select value={auditDateFilter} onValueChange={setAuditDateFilter}>
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Date range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="7days">Last 7 Days</SelectItem>
                    <SelectItem value="30days">Last 30 Days</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={auditActionFilter} onValueChange={setAuditActionFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Actions</SelectItem>
                    {uniqueActions.map((action) => (
                      <SelectItem key={action} value={action} className="capitalize">
                        {action.replace(/_/g, ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : filteredAuditLogs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileCheck className="h-10 w-10 mx-auto mb-2 opacity-40" />
                <p>No audit logs match the current filters</p>
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="sticky top-0 bg-background z-10">
                      <TableHead className="hidden sm:table-cell">Timestamp</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead className="hidden md:table-cell">Resource</TableHead>
                      <TableHead className="hidden lg:table-cell">Resource ID</TableHead>
                      <TableHead className="hidden lg:table-cell">IP Address</TableHead>
                      <TableHead className="hidden xl:table-cell">Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAuditLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                          <span className="datetime-badge full">{formatDateTime(log.createdAt)}</span>
                        </TableCell>
                        <TableCell className="font-medium">
                          {log.user?.name || 'System'}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={cn('capitalize', getActionColor(log.action))}>
                            {log.action.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-muted-foreground capitalize">
                          {log.resource}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell font-mono text-xs text-muted-foreground">
                          {log.resourceId ? log.resourceId.slice(0, 8) + '...' : '—'}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell font-mono text-sm text-muted-foreground">
                          {log.ipAddress || '—'}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground max-w-[200px] truncate">
                          {log.details || '—'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Section 7: Device Verification & 2FA */}
      <motion.div {...fadeUp} transition={{ duration: 0.35, delay: 0.3 }}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 2FA Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Lock className="h-5 w-5 text-teal-600" />
                Two-Factor Authentication
              </CardTitle>
              <CardDescription>Configure 2FA settings for enhanced security</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/20">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-teal-100 flex items-center justify-center">
                    <Fingerprint className="h-5 w-5 text-teal-600" />
                  </div>
                  <div>
                    <p className="font-medium">Enable 2FA</p>
                    <p className="text-sm text-muted-foreground">
                      Require two-factor authentication for all users
                    </p>
                  </div>
                </div>
                <Switch
                  checked={tfaEnabled}
                  onCheckedChange={(v) => handleTfaToggle('main', v)}
                  disabled={tfaLoading}
                />
              </div>

              <p className="text-xs text-muted-foreground flex items-center gap-1.5 bg-amber-50 p-2 rounded-md border border-amber-200">
                <Info className="h-3 w-3 text-amber-600 shrink-0" />
                2FA configuration changes require re-login
              </p>

              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground">2FA Methods</h4>
                {[
                  { key: 'authenticator', name: 'Authenticator App', icon: Smartphone, desc: 'TOTP-based verification', enabled: tfaMethods.authenticator },
                  { key: 'sms', name: 'SMS Verification', icon: Globe, desc: 'One-time code via SMS', enabled: tfaMethods.sms },
                  { key: 'email', name: 'Email Verification', icon: CheckCircle, desc: 'One-time code via email', enabled: tfaMethods.email },
                  { key: 'hardware', name: 'Hardware Key', icon: Fingerprint, desc: 'YubiKey or similar', enabled: tfaMethods.hardware },
                ].map((method) => (
                  <div
                    key={method.key}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div className="flex items-center gap-3">
                      <method.icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">{method.name}</p>
                        <p className="text-xs text-muted-foreground">{method.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={method.enabled}
                      onCheckedChange={(v) => handleTfaToggle(method.key, v)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Trusted Devices */}
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Smartphone className="h-5 w-5 text-amber-600" />
                    Trusted Devices
                  </CardTitle>
                  <CardDescription>Devices authorized for account access</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="btn-responsive text-rose-600 hover:text-rose-700 hover:bg-rose-50 shrink-0"
                  onClick={() => setRevokeAllDialog(true)}
                >
                  <Trash2 className="h-3 w-3 mr-1" />
                  Revoke All Others
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {devices.map((device, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/20"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        'h-10 w-10 rounded-full flex items-center justify-center',
                        device.status === 'active'
                          ? 'bg-emerald-100'
                          : device.status === 'inactive'
                            ? 'bg-amber-100'
                            : 'bg-rose-100'
                      )}
                    >
                      <MonitorSpeaker
                        className={cn(
                          'h-5 w-5',
                          device.status === 'active'
                            ? 'text-emerald-600'
                            : device.status === 'inactive'
                              ? 'text-amber-600'
                              : 'text-rose-600'
                        )}
                      />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{device.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="font-mono">{device.ip}</span>
                        <span>•</span>
                        <span className="datetime-badge">{formatRelative(device.lastActive)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className={cn(
                        device.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                          : device.status === 'inactive'
                            ? 'bg-amber-100 text-amber-700 border-amber-200'
                            : 'bg-rose-100 text-rose-700 border-rose-200'
                      )}
                    >
                      {device.status === 'active' ? 'Active' : device.status === 'inactive' ? 'Inactive' : 'Revoked'}
                    </Badge>
                    {device.status !== 'revoked' && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 h-7 w-7 p-0"
                        onClick={() => handleRevokeDevice(idx)}
                      >
                        <XCircle className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Revoke Device Confirmation Dialog */}
      <AlertDialog open={revokeDialog} onOpenChange={setRevokeDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke Device</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to revoke access for &quot;{revokeDeviceIdx !== null ? devices[revokeDeviceIdx]?.name : ''}&quot;? The user will need to re-authenticate on this device.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 hover:bg-rose-700 text-white"
              onClick={confirmRevokeDevice}
            >
              Revoke
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revoke All Other Devices Confirmation Dialog */}
      <AlertDialog open={revokeAllDialog} onOpenChange={setRevokeAllDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke All Other Devices</AlertDialogTitle>
            <AlertDialogDescription>
              This will revoke all devices except the current one (Chrome on macOS). All other sessions will be terminated immediately and users will need to re-authenticate.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 hover:bg-rose-700 text-white"
              onClick={confirmRevokeAll}
            >
              Revoke All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
