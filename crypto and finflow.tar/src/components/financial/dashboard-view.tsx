'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { useT } from '@/lib/i18n';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { getCurrencyFlag } from '@/lib/currency-flags';
import { apiFetch } from '@/lib/api-fetch';
import {
  TrendingUp,
  ArrowLeftRight,
  Wallet,
  Users,
  ArrowRight,
  DollarSign,
  Activity,
  BarChart3,
  FileBarChart,
  Send,
  CreditCard,
  Landmark,
  Globe,
  Store,
  UserCheck,
  Shield,
  Bell,
  Settings,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  XAxis,
  YAxis,
} from 'recharts';

// --- Types ---

interface RecentTransaction {
  id: string;
  reference: string;
  type: string;
  amount: number;
  fee: number;
  currency: string;
  status: string;
  createdAt: string;
  initiator?: { id: string; name: string; email: string } | null;
  recipient?: { id: string; name: string; email: string } | null;
}

interface DailyVolumeItem {
  date: string;
  volume: number;
}

interface TypeBreakdownItem {
  type: string;
  count: number;
}

interface MonthlyRevenueItem {
  month: string;
  volume: number;
  fees: number;
}

interface DashboardData {
  totalUsers: number;
  totalTransactions: number;
  totalVolume: number;
  activeWallets: number;
  recentTransactions: RecentTransaction[];
  dailyVolume: DailyVolumeItem[];
  transactionTypeBreakdown: TypeBreakdownItem[];
  monthlyRevenue: MonthlyRevenueItem[];
}

// --- Chart Configs ---

const volumeChartConfig = {
  volume: { label: 'Volume', color: 'hsl(160, 84%, 39%)' },
};

const typeChartConfig = {
  deposit: { label: 'Deposit', color: 'hsl(160, 84%, 39%)' },
  withdrawal: { label: 'Withdrawal', color: 'hsl(190, 90%, 50%)' },
  transfer: { label: 'Transfer', color: 'hsl(250, 95%, 64%)' },
  payment: { label: 'Payment', color: 'hsl(280, 80%, 60%)' },
  refund: { label: 'Refund', color: 'hsl(45, 93%, 47%)' },
  escrow: { label: 'Escrow', color: 'hsl(340, 75%, 55%)' },
  commission: { label: 'Commission', color: 'hsl(160, 60%, 45%)' },
  chargeback: { label: 'Chargeback', color: 'hsl(0, 72%, 51%)' },
  reversal: { label: 'Reversal', color: 'hsl(30, 80%, 55%)' },
  split_payment: { label: 'Split Payment', color: 'hsl(210, 90%, 56%)' },
};

const revenueChartConfig = {
  volume: { label: 'Volume', color: 'hsl(160, 84%, 39%)' },
  fees: { label: 'Fees', color: 'hsl(190, 90%, 50%)' },
};

// --- Helpers ---

function formatETB(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'decimal',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function formatCompact(num: number): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(num);
}

function formatDateLabel(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatMonthLabel(monthStr: string): string {
  const [year, month] = monthStr.split('-');
  const d = new Date(parseInt(year), parseInt(month) - 1);
  return d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
}

function getTypeBadgeVariant(type: string) {
  const map: Record<string, 'default' | 'secondary' | 'outline' | 'destructive'> = {
    deposit: 'default',
    withdrawal: 'secondary',
    transfer: 'outline',
    payment: 'default',
    refund: 'secondary',
    chargeback: 'destructive',
    reversal: 'destructive',
    escrow: 'outline',
    commission: 'secondary',
    split_payment: 'outline',
  };
  return map[type] ?? 'outline';
}

function getStatusBadge(status: string) {
  if (status === 'completed') {
    return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">{status}</Badge>;
  }
  if (status === 'pending' || status === 'processing') {
    return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">{status}</Badge>;
  }
  if (status === 'failed' || status === 'cancelled' || status === 'reversed') {
    return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">{status}</Badge>;
  }
  return <Badge variant="outline">{status}</Badge>;
}

// --- Quick Action Button ---

interface QuickAction {
  id: string;
  labelKey: string;
  icon: React.ElementType;
  gradient: string;
}

const quickActions: QuickAction[] = [
  { id: 'transfers', labelKey: 'nav.newTransaction', icon: Send, gradient: 'from-emerald-500 to-teal-500' },
  { id: 'wallets', labelKey: 'nav.wallets', icon: Wallet, gradient: 'from-teal-500 to-cyan-500' },
  { id: 'transactions', labelKey: 'nav.transactions', icon: ArrowLeftRight, gradient: 'from-cyan-500 to-sky-500' },
  { id: 'banking', labelKey: 'nav.banking', icon: Landmark, gradient: 'from-violet-500 to-purple-500' },
  { id: 'payments', labelKey: 'nav.payments', icon: CreditCard, gradient: 'from-purple-500 to-fuchsia-500' },
  { id: 'currencies', labelKey: 'nav.currencies', icon: Globe, gradient: 'from-fuchsia-500 to-pink-500' },
  { id: 'customers', labelKey: 'nav.customers', icon: UserCheck, gradient: 'from-orange-500 to-red-500' },
  { id: 'merchants', labelKey: 'nav.merchants', icon: Store, gradient: 'from-amber-500 to-orange-500' },
  { id: 'security', labelKey: 'nav.security', icon: Shield, gradient: 'from-red-500 to-rose-600' },
  { id: 'notifications', labelKey: 'nav.notifications', icon: Bell, gradient: 'from-rose-500 to-pink-500' },
  { id: 'reports', labelKey: 'nav.reports', icon: FileBarChart, gradient: 'from-violet-500 to-purple-600' },
  { id: 'settings', labelKey: 'nav.settings', icon: Settings, gradient: 'from-slate-500 to-gray-600' },
];

function QuickActionsGrid() {
  const { setActiveView } = useAppStore();
  const t = useT();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.05 }}
    >
      <div className="grid grid-cols-3 gap-2 sm:gap-3 md:grid-cols-4 lg:grid-cols-6">
        {quickActions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => setActiveView(action.id as any)}
              className="group flex flex-col items-center gap-2 rounded-xl p-3 sm:p-4 transition-all duration-200 hover:bg-accent hover:shadow-md hover:-translate-y-0.5 cursor-pointer border-0 bg-transparent"
            >
              <div className={`flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-xl bg-gradient-to-br ${action.gradient} shadow-md group-hover:shadow-lg transition-shadow duration-200`}>
                <Icon className="h-5 w-5 text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-medium text-center leading-tight text-muted-foreground group-hover:text-foreground transition-colors">
                {t(action.labelKey)}
              </span>
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}

// --- Stat Card ---

function StatCard({
  icon: Icon,
  label,
  value,
  gradient,
  prefix,
  suffix,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  gradient: string;
  prefix?: string;
  suffix?: string;
}) {
  return (
    <Card className="relative overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-center gap-3 sm:gap-4">
          <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} shadow-md`}>
            <Icon className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0">
            <p className="text-[11px] sm:text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
            <p className="text-xl sm:text-2xl font-bold tracking-tight truncate">
              {prefix}{value}{suffix}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// --- Skeletons ---

function StatCardsSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="border-0 shadow-sm">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center gap-3 sm:gap-4">
              <Skeleton className="h-11 w-11 rounded-xl" />
              <div className="space-y-2">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="h-7 w-28" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function TableSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-4 w-32" />
        </div>
      ))}
    </div>
  );
}

function WelcomeSkeleton() {
  return (
    <Card className="overflow-hidden border-0 shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-14 w-14 rounded-full shrink-0" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-8 w-72" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// --- Empty Chart State ---

function EmptyChartState({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-[200px] text-muted-foreground">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-3">
        <BarChart3 className="h-6 w-6 text-muted-foreground/50" />
      </div>
      <p className="text-sm font-medium">{title}</p>
      <p className="text-xs text-muted-foreground/70 mt-1">Data will appear as transactions are processed</p>
    </div>
  );
}

// --- Main Component ---

export default function DashboardView() {
  const { user, setActiveView } = useAppStore();
  const t = useT();
  const { formatRelative } = useFormattedDate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchDashboard() {
      try {
        const res = await apiFetch('/api/dashboard');
        if (!res.ok) throw new Error('Failed to load dashboard data');
        const json = await res.json();
        setData(json);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    }
    fetchDashboard();
  }, []);

  if (error) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-muted-foreground">{error}</p>
      </div>
    );
  }

  const hasChartData = (data?.dailyVolume?.some(d => d.volume > 0)) ?? false;
  const hasTypeData = (data?.transactionTypeBreakdown?.length ?? 0) > 0;
  const hasRevenueData = (data?.monthlyRevenue?.some(m => m.volume > 0 || m.fees > 0)) ?? false;
  const hasTransactions = (data?.recentTransactions?.length ?? 0) > 0;

  // Build chart data for type breakdown using the config keys
  const typeChartData = data?.transactionTypeBreakdown?.map((item) => ({
    ...item,
    fill: typeChartConfig[item.type as keyof typeof typeChartConfig]?.color ?? 'hsl(160, 84%, 39%)',
  })) ?? [];

  return (
    <div className="space-y-5">
      {/* Personalized Welcome Greeting */}
      {loading ? (
        <WelcomeSkeleton />
      ) : user ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="overflow-hidden border-0 shadow-sm">
            <div className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500">
              <CardContent className="p-5 sm:p-6">
                <div className="flex items-center gap-4">
                  <div className="flex h-13 w-13 sm:h-14 sm:w-14 shrink-0 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm text-white text-xl font-bold ring-2 ring-white/30">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                      {t('dashboard.welcomeBack')}, {user.name}!
                    </h2>
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-2">
                      <Badge className="text-[10px] sm:text-xs font-medium bg-white/20 text-white border-white/30 hover:bg-white/20">
                        {t(`role.${user.role}`) || user.role}
                      </Badge>
                      <span className="text-sm text-emerald-100">
                        {t('dashboard.productiveDay')}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>
      ) : null}

      {/* Quick Actions Grid */}
      <QuickActionsGrid />

      {/* Top Stats Row */}
      {loading ? (
        <StatCardsSkeleton />
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4"
        >
          <StatCard
            icon={DollarSign}
            label={t('dashboard.totalVolume')}
            value={formatETB(data!.totalVolume)}
            gradient="from-emerald-500 to-teal-500"
            prefix="ETB "
          />
          <StatCard
            icon={Activity}
            label={t('dashboard.totalTransactions')}
            value={data!.totalTransactions.toLocaleString()}
            gradient="from-amber-500 to-orange-500"
          />
          <StatCard
            icon={Wallet}
            label={t('dashboard.activeWallets')}
            value={data!.activeWallets.toLocaleString()}
            gradient="from-teal-500 to-cyan-500"
          />
          <StatCard
            icon={Users}
            label={t('dashboard.totalUsers')}
            value={data!.totalUsers.toLocaleString()}
            gradient="from-violet-500 to-purple-500"
          />
        </motion.div>
      )}

      {/* Charts Row */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {/* Transaction Volume Area Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-sm sm:text-base font-semibold">{t('dashboard.transactionVolume')}</CardTitle>
              <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">
                7 Days
              </Badge>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[260px] w-full" />
              ) : !hasChartData ? (
                <EmptyChartState title={t('dashboard.transactionVolume')} />
              ) : (
                <ChartContainer config={volumeChartConfig} className="h-[260px] w-full">
                  <AreaChart data={data?.dailyVolume ?? []}>
                    <CartesianGrid strokeDasharray="3 3" strokeDashoffset={1} />
                    <XAxis
                      dataKey="date"
                      tickFormatter={formatDateLabel}
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      tickFormatter={formatCompact}
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="volume"
                      stroke="var(--color-volume)"
                      fill="var(--color-volume)"
                      fillOpacity={0.15}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Transaction Types Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
        >
          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="text-sm sm:text-base font-semibold">{t('dashboard.transactionTypes')}</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[260px] w-full" />
              ) : !hasTypeData ? (
                <EmptyChartState title={t('dashboard.transactionTypes')} />
              ) : (
                <ChartContainer config={typeChartConfig} className="h-[260px] w-full">
                  <BarChart data={typeChartData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis
                      type="category"
                      dataKey="type"
                      width={90}
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                      {typeChartData.map((entry, index) => (
                        <rect key={index} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Transactions Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-sm sm:text-base font-semibold">{t('dashboard.recentTransactions')}</CardTitle>
            <Button
              variant="outline"
              size="sm"
              className="btn-responsive gap-1.5"
              onClick={() => setActiveView('transactions')}
            >
              {t('dashboard.viewAll')}
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="px-4 sm:px-6 pb-6">
            {loading ? (
              <TableSkeleton />
            ) : (
              <div className="max-h-[400px] overflow-y-auto rounded-md border [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent">
                <Table>
                  <TableHeader className="sticky top-0 bg-background z-10">
                    <TableRow>
                      <TableHead className="hidden sm:table-cell">{t('common.reference')}</TableHead>
                      <TableHead>{t('common.type')}</TableHead>
                      <TableHead className="text-right">{t('common.amount')}</TableHead>
                      <TableHead>{t('common.status')}</TableHead>
                      <TableHead className="hidden md:table-cell">{t('common.date')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data?.recentTransactions?.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="font-mono text-sm hidden sm:table-cell">
                          {tx.reference}
                        </TableCell>
                        <TableCell>
                          <Badge variant={getTypeBadgeVariant(tx.type)}>
                            {tx.type.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          {formatETB(tx.amount)} {getCurrencyFlag(tx.currency)} {tx.currency}
                        </TableCell>
                        <TableCell>{getStatusBadge(tx.status)}</TableCell>
                        <TableCell className="text-muted-foreground text-sm hidden md:table-cell">
                          <span className="datetime-badge">{formatRelative(tx.createdAt)}</span>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(!data?.recentTransactions || data.recentTransactions.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={5} className="h-32 text-center">
                          <div className="flex flex-col items-center gap-2 text-muted-foreground">
                            <ArrowLeftRight className="h-8 w-8 text-muted-foreground/30" />
                            <p className="text-sm">{t('dashboard.noTransactions')}</p>
                            <Button
                              variant="outline"
                              size="sm"
                              className="gap-1.5 mt-1"
                              onClick={() => setActiveView('transfers')}
                            >
                              <Send className="h-3.5 w-3.5" />
                              <span className="btn-label">{t('nav.newTransaction')}</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Monthly Revenue Trend */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.25 }}
      >
        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-sm sm:text-base font-semibold">{t('dashboard.monthlyRevenue')}</CardTitle>
            <Badge variant="outline" className="text-[10px] bg-teal-50 text-teal-700 border-teal-200">
              6 Months
            </Badge>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[260px] w-full" />
            ) : !hasRevenueData ? (
              <EmptyChartState title={t('dashboard.monthlyRevenue')} />
            ) : (
              <ChartContainer config={revenueChartConfig} className="h-[260px] w-full">
                <LineChart data={data?.monthlyRevenue ?? []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="month"
                    tickFormatter={formatMonthLabel}
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tickFormatter={formatCompact}
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="volume"
                    stroke="var(--color-volume)"
                    strokeWidth={2}
                    dot={{ r: 4, fill: 'var(--color-volume)' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="fees"
                    stroke="var(--color-fees)"
                    strokeWidth={2}
                    dot={{ r: 4, fill: 'var(--color-fees)' }}
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
