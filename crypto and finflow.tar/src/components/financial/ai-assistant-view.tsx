'use client';

import { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import {
  Brain,
  Send,
  Sparkles,
  BarChart3,
  ShieldAlert,
  FileText,
  ArrowRightLeft,
  Lightbulb,
  Bot,
  User,
  Loader2,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Target,
  Zap,
  Wallet,
  RefreshCw,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Bar, BarChart, XAxis, YAxis, Cell, PieChart, Pie } from 'recharts';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

// --- Types ---

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

interface Insight {
  id: string;
  title: string;
  description: string;
  type: 'opportunity' | 'warning' | 'info' | 'action';
  value?: string;
}

// --- Helpers ---

const fadeUp = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35 },
};

const insightColor: Record<string, string> = {
  opportunity: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  warning: 'bg-amber-100 text-amber-700 border-amber-200',
  info: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  action: 'bg-violet-100 text-violet-700 border-violet-200',
};

const insightIcon: Record<string, typeof Sparkles> = {
  opportunity: TrendingUp,
  warning: AlertTriangle,
  info: Lightbulb,
  action: Target,
};

const MOCK_RESPONSES: Record<string, string> = {
  default: "Based on current platform data, here's what I found:\n\n📊 **Transaction Volume**: 847 transactions processed today, 12% above the weekly average.\n💰 **Total Value**: ETB 4.2M in transfers, ETB 1.8M in withdrawals.\n⚠️ **Alerts**: 2 transactions flagged for review (risk score > 0.8).\n📈 **Trend**: Mobile payments up 23% this week.\n\nWould you like me to drill into any specific area?",
  fraud: "🔍 **Fraud Intelligence Report**\n\n• 3 suspicious patterns detected in the last 24 hours\n• 1 potential structuring pattern: 15 transactions of ETB 49,999 (just under the reporting threshold)\n• Account takeover attempt blocked for user #u3 — new device from unusual location\n• False positive rate remains low at 2.3%\n\nRecommended actions:\n1. Review the structuring pattern immediately\n2. Enable enhanced monitoring for the flagged accounts\n3. No action needed on the blocked takeover (automated defense worked)",
  reconcile: "🔄 **Reconciliation Status**\n\n✅ Bank — CBE: Balanced (variance: ETB 0.00)\n✅ Bank — Awash: Balanced (variance: ETB 0.00)\n⚠️ Mobile Money: 3 pending settlements (ETB 15,400)\n✅ FX Position: Balanced\n\nAll major accounts are reconciled. The 3 pending mobile money settlements are expected to clear within 2 hours.",
  report: "📋 **Quick Financial Summary**\n\n| Metric | Value |\n|---|---|\n| Active Users | 1,247 |\n| Daily Volume | ETB 6.1M |\n| Revenue (MTD) | ETB 284,500 |\n| Compliance Score | 94% |\n| System Uptime | 99.97% |\n\nThe platform is performing well within all KPI targets.",
};

const getMockResponse = (query: string): string => {
  const q = query.toLowerCase();
  if (q.includes('fraud') || q.includes('suspicious') || q.includes('risk')) return MOCK_RESPONSES.fraud;
  if (q.includes('reconcil') || q.includes('balance') || q.includes('settle')) return MOCK_RESPONSES.reconcile;
  if (q.includes('report') || q.includes('summary') || q.includes('kpi')) return MOCK_RESPONSES.report;
  return MOCK_RESPONSES.default;
};

const QUICK_ACTIONS = [
  { label: 'Transaction Summary', query: 'Give me a summary of today\'s transactions', icon: BarChart3 },
  { label: 'Fraud Report', query: 'Show fraud intelligence report', icon: ShieldAlert },
  { label: 'Reconciliation', query: 'Run reconciliation check', icon: ArrowRightLeft },
  { label: 'Financial Report', query: 'Generate a financial report', icon: FileText },
];

const MOCK_INSIGHTS: Insight[] = [
  { id: 'i1', title: 'Revenue Growth Opportunity', description: 'Cross-border transfer volume is up 34%. Consider reducing FX spread to capture more volume.', type: 'opportunity', value: '+34%' },
  { id: 'i2', title: 'High-Value User Churn Risk', description: '3 users with >ETB 500K balance have reduced activity by 60% in the past week.', type: 'warning' },
  { id: 'i3', title: 'Peak Usage Hours', description: 'Platform traffic peaks between 9-11 AM. Consider scaling resources for this window.', type: 'info' },
  { id: 'i4', title: 'Pending Compliance Actions', description: '5 KYC reviews are pending beyond SLA. Immediate action recommended.', type: 'action', value: '5 items' },
  { id: 'i5', title: 'Cost Optimization', description: 'SMS notification costs reduced by 18% after batch optimization. Annual savings: ETB 42,000.', type: 'opportunity', value: '-18%' },
];

const MOCK_ANALYSIS_DATA = [
  { name: 'Mon', volume: 4200, avgAmount: 5500 },
  { name: 'Tue', volume: 3800, avgAmount: 6100 },
  { name: 'Wed', volume: 5100, avgAmount: 5800 },
  { name: 'Thu', volume: 4600, avgAmount: 6300 },
  { name: 'Fri', volume: 6200, avgAmount: 7200 },
  { name: 'Sat', volume: 3400, avgAmount: 4500 },
  { name: 'Sun', volume: 2100, avgAmount: 3800 },
];

const MOCK_FRAUD_DATA = [
  { name: 'Low (< 0.1)', value: 892, color: '#10b981' },
  { name: 'Medium (0.1–0.5)', value: 45, color: '#f59e0b' },
  { name: 'High (0.5–0.8)', value: 8, color: '#f97316' },
  { name: 'Critical (> 0.8)', value: 2, color: '#f43f5e' },
];

// --- Component ---

export default function AIAssistantView() {
  const { formatDateTime } = useFormattedDate();

  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: '👋 Welcome to FinFlow AI Assistant! I can help you with:\n\n• **Transaction Analysis** — Query transaction patterns and trends\n• **Fraud Detection** — Review flagged transactions and risk scores\n• **Reconciliation** — Check account balances and settlement status\n• **Financial Reports** — Generate summaries and KPI reports\n\nTry one of the quick actions below, or type your question!',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState('assistant');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = (text?: string) => {
    const query = text || input.trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: getMockResponse(query),
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1200 + Math.random() * 800);
  };

  const renderChatBubble = (msg: ChatMessage) => {
    const isUser = msg.role === 'user';
    return (
      <motion.div
        key={msg.id}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className={cn('flex gap-3 max-w-[85%]', isUser ? 'ml-auto flex-row-reverse' : 'mr-auto')}
      >
        <div className={cn(
          'h-8 w-8 rounded-full flex items-center justify-center shrink-0 mt-1',
          isUser ? 'bg-emerald-500' : 'bg-violet-500',
        )}>
          {isUser ? <User className="h-4 w-4 text-white" /> : <Bot className="h-4 w-4 text-white" />}
        </div>
        <div className={cn(
          'rounded-2xl px-4 py-3 text-sm leading-relaxed',
          isUser
            ? 'bg-emerald-600 text-white rounded-tr-sm'
            : 'bg-muted text-foreground rounded-tl-sm',
        )}>
          <div className="whitespace-pre-wrap">{msg.content}</div>
          <div className={cn('text-[10px] mt-1.5', isUser ? 'text-emerald-200' : 'text-muted-foreground')}>
            {formatDateTime(msg.timestamp)}
          </div>
        </div>
      </motion.div>
    );
  };

  const renderAssistantTab = () => (
    <div className="flex flex-col h-[600px]">
      {/* Messages Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(renderChatBubble)}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-3 max-w-[85%] mr-auto"
          >
            <div className="h-8 w-8 rounded-full bg-violet-500 flex items-center justify-center shrink-0 mt-1">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex items-center gap-1.5">
                <Loader2 className="h-4 w-4 text-violet-500 animate-spin" />
                <span className="text-sm text-muted-foreground">Analyzing...</span>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Quick Actions */}
      {messages.length <= 2 && (
        <div className="px-4 pb-2">
          <p className="text-xs text-muted-foreground mb-2">Quick Actions:</p>
          <div className="flex flex-wrap gap-2">
            {QUICK_ACTIONS.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.label}
                  variant="outline"
                  size="sm"
                  className="gap-1.5 text-xs h-8"
                  onClick={() => handleSend(action.query)}
                >
                  <Icon className="h-3.5 w-3.5" /> {action.label}
                </Button>
              );
            })}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="border-t p-4">
        <div className="flex gap-2">
          <Input
            placeholder="Ask about transactions, fraud, reconciliation..."
            className="flex-1"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            disabled={isTyping}
          />
          <Button
            onClick={() => handleSend()}
            disabled={isTyping || !input.trim()}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  const renderTransactionAnalysis = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Today\'s Volume', value: 'ETB 6.1M', icon: BarChart3, color: 'text-emerald-600 bg-emerald-100' },
          { label: 'Transactions', value: '847', icon: ArrowRightLeft, color: 'text-teal-600 bg-teal-100' },
          { label: 'Avg Amount', value: 'ETB 7,200', icon: Wallet, color: 'text-violet-600 bg-violet-100' },
          { label: 'Success Rate', value: '99.4%', icon: CheckCircle2, color: 'text-cyan-600 bg-cyan-100' },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <p className="text-xl font-bold mt-1">{stat.value}</p>
                  </div>
                  <div className={cn('h-9 w-9 rounded-lg flex items-center justify-center', stat.color)}>
                    <Icon className="h-4 w-4" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Weekly Transaction Volume</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{}} className="h-[250px] w-full">
            <BarChart data={MOCK_ANALYSIS_DATA}>
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="volume" radius={[4, 4, 0, 0]}>
                {MOCK_ANALYSIS_DATA.map((_, i) => (
                  <Cell key={i} fill={i === 4 ? '#10b981' : '#99f6e4'} />
                ))}
              </Bar>
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );

  const renderFraudIntelligence = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Risk Score Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="w-36 h-36">
                <ChartContainer config={{}} className="h-full w-full">
                  <PieChart>
                    <Pie data={MOCK_FRAUD_DATA} cx="50%" cy="50%" innerRadius={35} outerRadius={60} dataKey="value" strokeWidth={2}>
                      {MOCK_FRAUD_DATA.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <ChartTooltip content={<ChartTooltipContent />} />
                  </PieChart>
                </ChartContainer>
              </div>
              <div className="flex-1 space-y-2">
                {MOCK_FRAUD_DATA.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm">{item.name}</span>
                    </div>
                    <span className="text-sm font-semibold">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Fraud Detection Metrics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { label: 'Detection Rate', value: 97, color: 'bg-emerald-500' },
              { label: 'False Positive Rate', value: 2.3, color: 'bg-amber-500' },
              { label: 'Auto-Block Rate', value: 84, color: 'bg-teal-500' },
              { label: 'Investigation Closure', value: 72, color: 'bg-violet-500' },
            ].map((metric) => (
              <div key={metric.label}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>{metric.label}</span>
                  <span className="font-medium">{metric.value}%</span>
                </div>
                <Progress value={metric.value} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderSmartReports = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {[
        { title: 'Daily Operations Report', desc: 'Auto-generated at 11:59 PM daily. Covers transactions, reconciliation, and system health.', status: 'ready', icon: FileText, color: 'text-emerald-600 bg-emerald-100' },
        { title: 'Weekly Compliance Report', desc: 'KYC/AML statistics, case resolutions, risk trends. Generated every Monday.', status: 'ready', icon: ShieldAlert, color: 'text-violet-600 bg-violet-100' },
        { title: 'Monthly Financial Summary', desc: 'Revenue, expenses, user growth, and KPI tracking. Available on the 1st of each month.', status: 'pending', icon: BarChart3, color: 'text-amber-600 bg-amber-100' },
        { title: 'Fraud Intelligence Brief', desc: 'Real-time fraud detection summary with actionable recommendations.', status: 'ready', icon: Zap, color: 'text-rose-600 bg-rose-100' },
      ].map((report) => {
        const Icon = report.icon;
        return (
          <Card key={report.title} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className={cn('h-10 w-10 rounded-lg flex items-center justify-center shrink-0', report.color)}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-sm">{report.title}</h3>
                    <Badge variant="outline" className={report.status === 'ready' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-amber-100 text-amber-700 border-amber-200'}>
                      {report.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{report.desc}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );

  const renderAutoReconciliation = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { name: 'CBE Bank', status: 'balanced', variance: 'ETB 0.00' },
          { name: 'Awash Bank', status: 'balanced', variance: 'ETB 0.00' },
          { name: 'Telebirr', status: 'pending', variance: 'ETB 15,400' },
          { name: 'HelloCash', status: 'balanced', variance: 'ETB 0.00' },
          { name: 'FX Position', status: 'balanced', variance: 'USD 0.00' },
          { name: 'Fee Account', status: 'balanced', variance: 'ETB 0.00' },
        ].map((account) => (
          <Card key={account.name}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">{account.name}</span>
                <Badge variant="outline" className={account.status === 'balanced' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-amber-100 text-amber-700 border-amber-200'}>
                  {account.status === 'balanced' ? '✓' : '⏳'} {account.status}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">Variance: <span className={cn('font-mono font-medium', account.status === 'balanced' ? 'text-emerald-600' : 'text-amber-600')}>{account.variance}</span></p>
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardContent className="p-4 text-center">
          <p className="text-sm text-muted-foreground">Last reconciliation: 30 minutes ago</p>
          <p className="text-sm text-muted-foreground mt-1">Next scheduled: in 30 minutes</p>
          <Button variant="outline" className="mt-3" onClick={() => {}}>
            <RefreshCw className="h-4 w-4 mr-2" /> Run Manual Reconciliation
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderFinancialInsights = () => (
    <div className="space-y-3">
      {MOCK_INSIGHTS.map((insight) => {
        const Icon = insightIcon[insight.type];
        return (
          <motion.div
            key={insight.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={cn('h-9 w-9 rounded-lg flex items-center justify-center shrink-0', insightColor[insight.type])}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-medium">{insight.title}</h3>
                      <Badge variant="outline" className={cn('text-[10px]', insightColor[insight.type])}>{insight.type}</Badge>
                      {insight.value && (
                        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 text-[10px]">{insight.value}</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-1">
          <div className="h-10 w-10 rounded-xl bg-violet-100 flex items-center justify-center">
            <Brain className="h-5 w-5 text-violet-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">AI & Automation</h1>
            <p className="text-sm text-muted-foreground">Intelligent financial analysis, fraud detection, and automated workflows</p>
          </div>
        </div>
      </motion.div>

      {/* AI Capability Stats */}
      <motion.div {...fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'AI Queries Today', value: '24', icon: Brain, color: 'text-violet-600 bg-violet-100' },
          { label: 'Reports Generated', value: '8', icon: FileText, color: 'text-emerald-600 bg-emerald-100' },
          { label: 'Auto-Reconciled', value: '99.2%', icon: CheckCircle2, color: 'text-teal-600 bg-teal-100' },
          { label: 'Fraud Alerts', value: '3', icon: ShieldAlert, color: 'text-amber-600 bg-amber-100' },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="border-transparent">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold mt-1">{stat.value}</p>
                  </div>
                  <div className={cn('h-9 w-9 rounded-lg flex items-center justify-center', stat.color)}>
                    <Icon className="h-4 w-4" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </motion.div>

      {/* Main Tabs */}
      <motion.div {...fadeUp}>
        <Card>
 <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-violet-500" />
              <CardTitle className="text-lg">AI-Powered Tools</CardTitle>
            </div>
            <CardDescription>Leverage artificial intelligence for smarter financial operations</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4 flex-wrap h-auto gap-1">
                <TabsTrigger value="assistant" className="gap-1.5">
                  <Bot className="h-3.5 w-3.5" /> AI Assistant
                </TabsTrigger>
                <TabsTrigger value="analysis" className="gap-1.5">
                  <BarChart3 className="h-3.5 w-3.5" /> Transaction Analysis
                </TabsTrigger>
                <TabsTrigger value="fraud" className="gap-1.5">
                  <ShieldAlert className="h-3.5 w-3.5" /> Fraud Intelligence
                </TabsTrigger>
                <TabsTrigger value="reports" className="gap-1.5">
                  <FileText className="h-3.5 w-3.5" /> Smart Reports
                </TabsTrigger>
                <TabsTrigger value="reconciliation" className="gap-1.5">
                  <ArrowRightLeft className="h-3.5 w-3.5" /> Auto Reconciliation
                </TabsTrigger>
                <TabsTrigger value="insights" className="gap-1.5">
                  <Lightbulb className="h-3.5 w-3.5" /> Financial Insights
                </TabsTrigger>
              </TabsList>

              <TabsContent value="assistant">{renderAssistantTab()}</TabsContent>
              <TabsContent value="analysis">{renderTransactionAnalysis()}</TabsContent>
              <TabsContent value="fraud">{renderFraudIntelligence()}</TabsContent>
              <TabsContent value="reports">{renderSmartReports()}</TabsContent>
              <TabsContent value="reconciliation">{renderAutoReconciliation()}</TabsContent>
              <TabsContent value="insights">{renderFinancialInsights()}</TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
