'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import {
  Users, UserPlus, Download, Search, CheckCircle, Clock, AlertTriangle,
  Eye, Shield, Ban, Unlock, Loader2, MoreHorizontal, Globe, Phone, Mail,
  Filter, CheckCircle2, XCircle,
} from 'lucide-react';
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// --- Types ---

interface CustomerUser {
  id: string;
  email: string;
  username: string | null;
  name: string;
  phone: string | null;
  country: string;
  role: string;
  kycStatus: string;
  twoFactorEnabled: boolean;
  isVerified: boolean;
  riskLevel: string;
  status: string;
  lastLoginAt: string | null;
  createdAt: string;
  _count: { wallets: number; transactions: number };
}

// --- Helpers ---

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function getAvatarColor(name: string): string {
  const colors = [
    'bg-primary text-white',
    'bg-success text-white',
    'bg-info text-black',
    'bg-warning text-black',
    'bg-destructive text-white',
    'bg-purple-600 text-white',
    'bg-pink-600 text-white',
    'bg-orange-600 text-white',
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

function getKycBadgeVariant(kycStatus: string) {
  switch (kycStatus) {
    case 'verified':
      return 'bg-success text-white';
    case 'pending':
      return 'bg-warning text-black';
    case 'rejected':
      return 'bg-destructive text-white';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

function getStatusBadgeVariant(status: string) {
  switch (status) {
    case 'active':
      return 'bg-success text-white';
    case 'pending':
    case 'approved':
      return 'bg-warning text-black';
    case 'suspended':
      return 'bg-info text-black';
    case 'blocked':
    case 'frozen':
    case 'closed':
      return 'bg-destructive text-white';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

function getRiskBadgeVariant(riskLevel: string) {
  switch (riskLevel) {
    case 'low':
      return 'bg-success text-white';
    case 'medium':
      return 'bg-warning text-black';
    case 'high':
      return 'bg-destructive text-white';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

// --- Component ---

export default function CustomersView() {
  const { formatDate, formatDateTime } = useFormattedDate();

  // State
  const [customers, setCustomers] = useState<CustomerUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [kycFilter, setKycFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');

  // Dialogs
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerUser | null>(null);

  // Add customer form
  const [addForm, setAddForm] = useState({
    name: '',
    email: '',
    phone: '',
    country: 'Ethiopia',
  });
  const [addLoading, setAddLoading] = useState(false);

  // Action loading
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [exportLoading, setExportLoading] = useState(false);

  // --- Fetch customers ---
  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/users');
      if (!res.ok) throw new Error('Failed to fetch users');
      const data = await res.json();
      const allUsers: CustomerUser[] = data.users || [];
      // Filter to only show individual users (non-admin, non-merchant)
      const filtered = allUsers.filter(
        (u) => u.role !== 'admin' && u.role !== 'super_admin' && u.role !== 'merchant'
          && u.role !== 'agent' && u.role !== 'seller' && u.role !== 'buyer'
          && u.role !== 'delivery' && u.role !== 'warehouse_manager'
          && u.role !== 'finance_manager' && u.role !== 'compliance_auditor'
          && u.role !== 'customer_support'
      );
      setCustomers(filtered);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  // --- Computed stats ---
  const stats = useMemo(() => {
    const total = customers.length;
    const active = customers.filter((c) => c.status === 'active').length;
    const pendingKyc = customers.filter((c) => c.kycStatus === 'pending').length;
    const highRisk = customers.filter((c) => c.riskLevel === 'high').length;
    return { total, active, pendingKyc, highRisk };
  }, [customers]);

  // --- Filtered customers ---
  const filteredCustomers = useMemo(() => {
    let result = [...customers];

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (c) =>
          c.name?.toLowerCase().includes(q) ||
          c.email?.toLowerCase().includes(q) ||
          c.phone?.includes(q) ||
          c.country?.toLowerCase().includes(q) ||
          c.username?.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'all') {
      result = result.filter((c) => c.status === statusFilter);
    }

    if (kycFilter !== 'all') {
      result = result.filter((c) => c.kycStatus === kycFilter);
    }

    if (riskFilter !== 'all') {
      result = result.filter((c) => c.riskLevel === riskFilter);
    }

    // Default sort: newest first
    result.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    return result;
  }, [customers, search, statusFilter, kycFilter, riskFilter]);

  // --- Customer actions ---
  const handlePatchCustomer = async (
    id: string,
    data: Record<string, string>,
    label: string
  ) => {
    setActionLoading(id + ':' + label);
    try {
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...data }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }
      toast.success(label);
      fetchCustomers();
      if (selectedCustomer?.id === id) {
        const updated = await res.json();
        setSelectedCustomer({ ...selectedCustomer, ...data, ...updated });
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Action failed';
      toast.error(message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleVerifyKyc = (customer: CustomerUser) => {
    handlePatchCustomer(
      customer.id,
      { kycStatus: 'verified' },
      'KYC verified for ' + customer.name
    );
  };

  const handleApprove = (customer: CustomerUser) => {
    handlePatchCustomer(
      customer.id,
      { status: 'active', isVerified: 'true' },
      customer.name + ' has been approved'
    );
  };

  const handleSuspend = (customer: CustomerUser) => {
    handlePatchCustomer(
      customer.id,
      { status: 'suspended' },
      customer.name + ' has been suspended'
    );
  };

  const handleBlock = (customer: CustomerUser) => {
    handlePatchCustomer(
      customer.id,
      { status: 'blocked' },
      customer.name + ' has been blocked'
    );
  };

  // --- Add customer ---
  const handleAddCustomer = async () => {
    if (!addForm.name.trim() || !addForm.email.trim() || !addForm.phone.trim() || !addForm.country.trim()) {
      toast.error('All fields are required');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(addForm.email)) {
      toast.error('Invalid email format');
      return;
    }
    setAddLoading(true);
    try {
      const res = await apiFetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: addForm.name.trim(),
          email: addForm.email.trim(),
          phone: addForm.phone.trim(),
          country: addForm.country.trim(),
          role: 'user',
          password: 'Customer@2024!',
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Registration failed');
      }
      toast.success('Customer account created successfully');
      setAddDialogOpen(false);
      setAddForm({ name: '', email: '', phone: '', country: 'Ethiopia' });
      fetchCustomers();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create customer';
      toast.error(message);
    } finally {
      setAddLoading(false);
    }
  };

  // --- Export ---
  const handleExport = async () => {
    setExportLoading(true);
    try {
      const csvRows = [
        ['Name', 'Email', 'Phone', 'Country', 'KYC Status', 'Risk Level', 'Status', 'Wallets', 'Transactions', 'Joined'],
        ...filteredCustomers.map((c) => [
          c.name, c.email, c.phone || '', c.country, c.kycStatus, c.riskLevel || 'low',
          c.status, String(c._count.wallets), String(c._count.transactions),
          format(new Date(c.createdAt), 'yyyy-MM-dd'),
        ]),
      ];
      const csvContent = csvRows.map((r) => r.join(',')).join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'customers-export.csv';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Customers exported successfully');
    } catch {
      toast.error('Export failed');
    } finally {
      setExportLoading(false);
    }
  };

  // --- View details ---
  const handleViewDetails = (customer: CustomerUser) => {
    setSelectedCustomer(customer);
    setDetailDialogOpen(true);
  };

  const isActionLoading = (customerId: string, action: string) =>
    actionLoading === customerId + ':' + action;

  // --- Render ---
  return (
    <>

      <div className="space-y-6">
        {/* Header */}
        <motion.div
          {...fadeIn}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Customer Management</h1>
            <p className="text-muted-foreground">
              Manage customer accounts, verify identities, and monitor activity.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className="gap-2 rounded-2xl btn-responsive"
              onClick={handleExport}
              disabled={exportLoading}
            >
              {exportLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Download className="h-4 w-4" />
              )}
              Export CSV
            </Button>
            <Button
              className="bg-primary hover:bg-primary/90 text-white gap-2 rounded-2xl btn-responsive"
              onClick={() => setAddDialogOpen(true)}
            >
              <UserPlus className="h-4 w-4" />
              Add Customer
            </Button>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Customers</p>
                  <p className="text-2xl font-bold">
                    {loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.total}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.1 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-success/10">
                  <CheckCircle className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Customers</p>
                  <p className="text-2xl font-bold">
                    {loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.active}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.2 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-warning/10">
                  <Clock className="h-6 w-6 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Pending Verification</p>
                  <p className="text-2xl font-bold">
                    {loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.pendingKyc}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.3 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High Risk</p>
                  <p className="text-2xl font-bold">
                    {loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.highRisk}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Filters Row */}
        <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.4 }}>
          <Card className="bg-card rounded-2xl shadow-bs border border-border">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search customers by name, email, phone..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 rounded-2xl"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full sm:w-[160px] rounded-2xl">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={kycFilter} onValueChange={setKycFilter}>
                  <SelectTrigger className="w-full sm:w-[160px] rounded-2xl">
                    <Shield className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="KYC" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All KYC</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={riskFilter} onValueChange={setRiskFilter}>
                  <SelectTrigger className="w-full sm:w-[160px] rounded-2xl">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Risk" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Risk</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Customers Table */}
        <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.5 }}>
          <Card className="bg-card rounded-2xl shadow-bs border border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold">Customers</CardTitle>
              <CardDescription>
                {filteredCustomers.length} of {customers.length} customers
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[500px] overflow-y-auto custom-scroll">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead>Customer</TableHead>
                      <TableHead className="hidden md:table-cell">Email</TableHead>
                      <TableHead className="hidden lg:table-cell">Phone</TableHead>
                      <TableHead className="hidden xl:table-cell">Country</TableHead>
                      <TableHead>KYC</TableHead>
                      <TableHead>Risk</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="hidden md:table-cell">Wallets</TableHead>
                      <TableHead className="hidden lg:table-cell">Transactions</TableHead>
                      <TableHead className="hidden xl:table-cell">Joined</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 6 }).map((_, i) => (
                        <TableRow key={i} className="hover:bg-transparent">
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Skeleton className="h-9 w-9 rounded-full" />
                              <div className="space-y-1">
                                <Skeleton className="h-4 w-28" />
                                <Skeleton className="h-3 w-36" />
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Skeleton className="h-4 w-32" />
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            <Skeleton className="h-4 w-24" />
                          </TableCell>
                          <TableCell className="hidden xl:table-cell">
                            <Skeleton className="h-4 w-20" />
                          </TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-12" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Skeleton className="h-4 w-8" />
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            <Skeleton className="h-4 w-12" />
                          </TableCell>
                          <TableCell className="hidden xl:table-cell">
                            <Skeleton className="h-4 w-24" />
                          </TableCell>
                          <TableCell className="text-right">
                            <Skeleton className="h-8 w-8 ml-auto" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filteredCustomers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={11} className="text-center py-16">
                          <div className="flex flex-col items-center gap-2 text-muted-foreground">
                            <Users className="h-10 w-10 opacity-40" />
                            <p className="text-sm font-medium">No customers found</p>
                            <p className="text-xs">Try adjusting your search or filter criteria.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredCustomers.map((customer) => (
                        <TableRow key={customer.id} className="hover:bg-muted/30">
                          {/* Customer column */}
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div
                                className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold ${getAvatarColor(customer.name)}`}
                              >
                                {getInitials(customer.name)}
                              </div>
                              <div className="min-w-0">
                                <p className="font-medium truncate max-w-[180px]">{customer.name}</p>
                                <p className="text-xs text-muted-foreground truncate max-w-[180px]">
                                  {customer.username || customer.email}
                                </p>
                              </div>
                            </div>
                          </TableCell>

                          {/* Email (md+) */}
                          <TableCell className="hidden md:table-cell">
                            <span className="text-sm text-muted-foreground">{customer.email}</span>
                          </TableCell>

                          {/* Phone (lg+) */}
                          <TableCell className="hidden lg:table-cell">
                            <span className="text-sm text-muted-foreground">{customer.phone || '—'}</span>
                          </TableCell>

                          {/* Country (xl+) */}
                          <TableCell className="hidden xl:table-cell">
                            <div className="flex items-center gap-1.5">
                              <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">{customer.country}</span>
                            </div>
                          </TableCell>

                          {/* KYC Status */}
                          <TableCell>
                            <Badge className={`text-xs font-medium ${getKycBadgeVariant(customer.kycStatus)}`}>
                              {customer.kycStatus}
                            </Badge>
                          </TableCell>

                          {/* Risk Level */}
                          <TableCell>
                            <Badge className={`text-xs font-medium ${getRiskBadgeVariant(customer.riskLevel)}`}>
                              {customer.riskLevel || 'low'}
                            </Badge>
                          </TableCell>

                          {/* Status */}
                          <TableCell>
                            <Badge className={`text-xs font-medium ${getStatusBadgeVariant(customer.status)}`}>
                              {customer.status}
                            </Badge>
                          </TableCell>

                          {/* Wallets (md+) */}
                          <TableCell className="hidden md:table-cell">
                            <span className="text-sm font-medium">{customer._count.wallets}</span>
                          </TableCell>

                          {/* Transactions (lg+) */}
                          <TableCell className="hidden lg:table-cell">
                            <span className="text-sm font-medium">{customer._count.transactions}</span>
                          </TableCell>

                          {/* Joined (xl+) */}
                          <TableCell className="hidden xl:table-cell">
                            <span className="datetime-badge date-only">{formatDate(customer.createdAt)}</span>
                          </TableCell>

                          {/* Actions */}
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  {isActionLoading(customer.id, 'any') ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <MoreHorizontal className="h-4 w-4" />
                                  )}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDetails(customer)}>
                                  <Eye className="h-4 w-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                {customer.kycStatus !== 'verified' && (
                                  <DropdownMenuItem
                                    onClick={() => handleVerifyKyc(customer)}
                                    disabled={isActionLoading(customer.id, 'verify-kyc')}
                                  >
                                    {isActionLoading(customer.id, 'verify-kyc') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Shield className="h-4 w-4 mr-2" />
                                    )}
                                    Verify KYC
                                  </DropdownMenuItem>
                                )}
                                {customer.status === 'pending' && (
                                  <DropdownMenuItem
                                    onClick={() => handleApprove(customer)}
                                    disabled={isActionLoading(customer.id, 'approve')}
                                  >
                                    {isActionLoading(customer.id, 'approve') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <CheckCircle2 className="h-4 w-4 mr-2" />
                                    )}
                                    Approve
                                  </DropdownMenuItem>
                                )}
                                {customer.status !== 'suspended' && customer.status !== 'blocked' && (
                                  <DropdownMenuItem
                                    onClick={() => handleSuspend(customer)}
                                    disabled={isActionLoading(customer.id, 'suspend')}
                                  >
                                    {isActionLoading(customer.id, 'suspend') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Ban className="h-4 w-4 mr-2" />
                                    )}
                                    Suspend
                                  </DropdownMenuItem>
                                )}
                                {customer.status !== 'blocked' && (
                                  <DropdownMenuItem
                                    onClick={() => handleBlock(customer)}
                                    disabled={isActionLoading(customer.id, 'block')}
                                    className="text-destructive"
                                  >
                                    {isActionLoading(customer.id, 'block') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <XCircle className="h-4 w-4 mr-2" />
                                    )}
                                    Block
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Add Customer Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Add New Customer
            </DialogTitle>
            <DialogDescription>
              Create a new customer account. The customer will receive login credentials via email.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="add-name">Full Name *</Label>
              <Input
                id="add-name"
                placeholder="Abebe Kebede"
                value={addForm.name}
                onChange={(e) => setAddForm({ ...addForm, name: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-email">Email *</Label>
              <Input
                id="add-email"
                type="email"
                placeholder="customer@example.com"
                value={addForm.email}
                onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-phone">Phone *</Label>
              <Input
                id="add-phone"
                placeholder="+251912345678"
                value={addForm.phone}
                onChange={(e) => setAddForm({ ...addForm, phone: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-country">Country *</Label>
              <Input
                id="add-country"
                placeholder="Ethiopia"
                value={addForm.country}
                onChange={(e) => setAddForm({ ...addForm, country: e.target.value })}
                className="rounded-2xl"
              />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0 btn-responsive-group">
            <Button
              variant="outline"
              onClick={() => setAddDialogOpen(false)}
              className="rounded-2xl"
            >
              Cancel
            </Button>
            <Button
              className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl gap-2"
              onClick={handleAddCustomer}
              disabled={addLoading}
            >
              {addLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Create Customer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-[550px] rounded-2xl max-h-[85vh] overflow-y-auto custom-scroll">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedCustomer && (
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold ${getAvatarColor(selectedCustomer.name)}`}
                >
                  {getInitials(selectedCustomer.name)}
                </div>
              )}
              Customer Details
            </DialogTitle>
            <DialogDescription>
              View and manage customer account information.
            </DialogDescription>
          </DialogHeader>

          {selectedCustomer && (
            <div className="space-y-6">
              {/* Info Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Full Name</p>
                  <p className="text-sm font-medium">{selectedCustomer.name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Username</p>
                  <p className="text-sm font-medium">{selectedCustomer.username || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Mail className="h-3 w-3" /> Email
                  </p>
                  <p className="text-sm font-medium">{selectedCustomer.email}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Phone className="h-3 w-3" /> Phone
                  </p>
                  <p className="text-sm font-medium">{selectedCustomer.phone || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Globe className="h-3 w-3" /> Country
                  </p>
                  <p className="text-sm font-medium">{selectedCustomer.country}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Role</p>
                  <p className="text-sm font-medium capitalize">
                    {selectedCustomer.role.replace('_', ' ')}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Risk Level</p>
                  <Badge className={`text-xs font-medium ${getRiskBadgeVariant(selectedCustomer.riskLevel)}`}>
                    {selectedCustomer.riskLevel || 'low'}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">2FA Enabled</p>
                  <p className="text-sm font-medium">
                    {selectedCustomer.twoFactorEnabled ? 'Yes' : 'No'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Verified</p>
                  <p className="text-sm font-medium">
                    {selectedCustomer.isVerified ? 'Yes' : 'No'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Joined</p>
                  <p className="text-sm font-medium">
                    <span className="datetime-badge date-only">{formatDate(selectedCustomer.createdAt)}</span>
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Last Login</p>
                  <p className="text-sm font-medium">
                    {selectedCustomer.lastLoginAt
                      ? <span className="datetime-badge full">{formatDateTime(selectedCustomer.lastLoginAt)}</span>
                      : 'Never'}
                  </p>
                </div>
              </div>

              {/* Status Badges */}
              <div className="flex items-center gap-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Account Status</p>
                  <Badge className={`text-xs font-medium ${getStatusBadgeVariant(selectedCustomer.status)}`}>
                    {selectedCustomer.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">KYC Status</p>
                  <Badge className={`text-xs font-medium ${getKycBadgeVariant(selectedCustomer.kycStatus)}`}>
                    {selectedCustomer.kycStatus}
                  </Badge>
                </div>
              </div>

              {/* Activity Stats */}
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-card rounded-2xl shadow-fin p-4 border border-border">
                  <CardContent className="p-0 text-center">
                    <p className="text-2xl font-bold text-primary">
                      {selectedCustomer._count.wallets}
                    </p>
                    <p className="text-xs text-muted-foreground">Wallets</p>
                  </CardContent>
                </Card>
                <Card className="bg-card rounded-2xl shadow-fin p-4 border border-border">
                  <CardContent className="p-0 text-center">
                    <p className="text-2xl font-bold text-success">
                      {selectedCustomer._count.transactions}
                    </p>
                    <p className="text-xs text-muted-foreground">Transactions</p>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2">
                <p className="text-sm font-semibold">Quick Actions</p>
                <div className="flex flex-wrap gap-2 btn-responsive-group">
                  {selectedCustomer.kycStatus !== 'verified' && (
                    <Button
                      size="sm"
                      className="bg-success hover:bg-success/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleVerifyKyc(selectedCustomer);
                        setSelectedCustomer({ ...selectedCustomer, kycStatus: 'verified' });
                      }}
                      disabled={isActionLoading(selectedCustomer.id, 'verify-kyc')}
                    >
                      {isActionLoading(selectedCustomer.id, 'verify-kyc') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Shield className="h-4 w-4" />
                      )}
                      Verify KYC
                    </Button>
                  )}
                  {selectedCustomer.status === 'pending' && (
                    <Button
                      size="sm"
                      className="bg-primary hover:bg-primary/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleApprove(selectedCustomer);
                        setSelectedCustomer({ ...selectedCustomer, status: 'active' });
                      }}
                      disabled={isActionLoading(selectedCustomer.id, 'approve')}
                    >
                      {isActionLoading(selectedCustomer.id, 'approve') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle2 className="h-4 w-4" />
                      )}
                      Approve
                    </Button>
                  )}
                  {selectedCustomer.status !== 'suspended' && selectedCustomer.status !== 'blocked' && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleSuspend(selectedCustomer);
                        setSelectedCustomer({ ...selectedCustomer, status: 'suspended' });
                      }}
                      disabled={isActionLoading(selectedCustomer.id, 'suspend')}
                    >
                      {isActionLoading(selectedCustomer.id, 'suspend') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Ban className="h-4 w-4" />
                      )}
                      Suspend
                    </Button>
                  )}
                  {selectedCustomer.status !== 'blocked' && (
                    <Button
                      size="sm"
                      className="bg-destructive hover:bg-destructive/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleBlock(selectedCustomer);
                        setSelectedCustomer({ ...selectedCustomer, status: 'blocked' });
                      }}
                      disabled={isActionLoading(selectedCustomer.id, 'block')}
                    >
                      {isActionLoading(selectedCustomer.id, 'block') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <XCircle className="h-4 w-4" />
                      )}
                      Block
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDetailDialogOpen(false)}
              className="rounded-2xl"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
