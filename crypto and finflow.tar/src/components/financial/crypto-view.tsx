'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Wallet, ArrowRightLeft, Shield, Link2, Search, Plus, Copy, Send, Download,
  RefreshCw, Eye, CheckCircle, XCircle, AlertTriangle, Clock, ArrowUpRight, ArrowDownLeft,
  QrCode, Lock, Activity, Zap, TrendingUp, Key, ShieldAlert, X, Loader2, Server,
  ChevronLeft, ChevronRight, Filter, ExternalLink, ToggleLeft, ToggleRight, Info,
  ChevronDown, Trash2, Upload
} from 'lucide-react';
import { apiFetch } from '@/lib/api-fetch';

// ==================== TYPES & CONSTANTS ====================

interface WalletUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface WalletData {
  id: string;
  userId: string;
  currency: string;
  balance: number;
  availableBalance: number;
  frozenBalance: number;
  depositAddress: string;
  network: string;
  walletType: string;
  status: string;
  createdAt: string;
  user?: WalletUser;
}

interface TxData {
  id: string;
  reference: string;
  type: string;
  status: string;
  amount: number;
  fee: number;
  feeCurrency: string;
  currency: string;
  fromCurrency?: string;
  toCurrency?: string;
  exchangeRate?: number;
  description?: string;
  toAddress?: string;
  fromAddress?: string;
  txHash?: string;
  network?: string;
  confirmations: number;
  requiredConfirmations: number;
  createdAt: string;
  completedAt?: string;
  user?: WalletUser;
  wallet?: { id: string; currency: string; network: string; depositAddress?: string };
}

interface BcTxData {
  id: string;
  txHash: string;
  network: string;
  fromAddress?: string;
  toAddress?: string;
  amount: number;
  currency: string;
  confirmations: number;
  requiredConfs: number;
  gasUsed?: number;
  gasPrice?: number;
  networkFee?: number;
  status: string;
  detectedAt: string;
  confirmedAt?: string;
}

interface RateData {
  id: string;
  fromCurrency: string;
  toCurrency: string;
  rate: number;
  fee: number;
  minAmount?: number;
  maxAmount?: number;
}

interface SecurityEvent {
  id: string;
  userId?: string;
  eventType: string;
  severity: string;
  title: string;
  description?: string;
  createdAt: string;
}

interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

const CRYPTO_COLORS: Record<string, string> = {
  BTC: '#f7931a', ETH: '#627eea', USDT: '#26a17b', USDC: '#2775ca',
  XRP: '#00aae4', SOL: '#9945ff', DOGE: '#c3a634', ADA: '#0033ad',
};

const CRYPTO_SYMBOLS: Record<string, string> = {
  BTC: '₿', ETH: 'Ξ', USDT: '₮', USDC: '$', XRP: '✕', SOL: '◎', DOGE: 'Ð', ADA: '₳',
};

const CRYPTO_DECIMALS: Record<string, number> = {
  BTC: 8, ETH: 8, USDT: 2, USDC: 2, XRP: 6, SOL: 9, DOGE: 8, ADA: 6,
};

const COLORS = {
  blue: '#61dafb', dark: '#20232a', darker: '#282c34',
  success: '#4caf50', danger: '#ef5350', warning: '#ffa726',
  info: '#29b6f6', purple: '#ab47bc', muted: '#6c757d', border: '#dee2e6',
};

const TABS = [
  { key: 'wallets', label: 'Wallets', icon: Wallet },
  { key: 'exchange', label: 'Exchange', icon: ArrowRightLeft },
  { key: 'blockchain', label: 'Blockchain', icon: Link2 },
  { key: 'security', label: 'Security', icon: Shield },
] as const;

type TabKey = typeof TABS[number]['key'];

// ==================== BOOTSTRAP-STYLE MINI COMPONENTS ====================

function Spinner({ size = 20, color = COLORS.blue }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ animation: 'spin 1s linear infinite' }}>
      <circle cx="12" cy="12" r="10" stroke={color} strokeWidth="3" strokeDasharray="50 50" strokeLinecap="round" />
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </svg>
  );
}

function BBtn({
  children, variant = 'primary', size = 'md', onClick, disabled, className = '', title,
}: {
  children: React.ReactNode; variant?: 'primary' | 'success' | 'danger' | 'warning' | 'info' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg'; onClick?: () => void; disabled?: boolean; className?: string; title?: string;
}) {
  const base = 'inline-flex items-center justify-center font-medium rounded transition-all duration-150 focus:outline-none';
  const sizes = { sm: 'px-2.5 py-1 text-xs gap-1', md: 'px-3.5 py-1.5 text-sm gap-1.5', lg: 'px-5 py-2 text-base gap-2' };
  const variants: Record<string, string> = {
    primary: `bg-[${COLORS.blue}] text-[${COLORS.dark}] hover:opacity-90`,
    success: `bg-[${COLORS.success}] text-white hover:opacity-90`,
    danger: `bg-[${COLORS.danger}] text-white hover:opacity-90`,
    warning: `bg-[${COLORS.warning}] text-[${COLORS.dark}] hover:opacity-90`,
    info: `bg-[${COLORS.info}] text-white hover:opacity-90`,
    outline: `border border-[${COLORS.border}] text-[${COLORS.muted}] hover:bg-[${COLORS.darker}] hover:text-white`,
    ghost: `text-[${COLORS.muted}] hover:bg-[${COLORS.darker}] hover:text-white`,
  };
  return (
    <button
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`${base} ${sizes[size]} ${variants[variant]} ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'} ${className}`}
    >
      {children}
    </button>
  );
}

function BCard({ children, className = '', header, footer }: {
  children: React.ReactNode; className?: string; header?: React.ReactNode; footer?: React.ReactNode;
}) {
  return (
    <div className={`rounded-lg border overflow-hidden ${className}`} style={{
      backgroundColor: COLORS.darker, borderColor: COLORS.border,
    }}>
      {header && (
        <div className="px-4 py-3 border-b" style={{ borderColor: COLORS.border, backgroundColor: COLORS.dark }}>
          {header}
        </div>
      )}
      <div className="p-4">{children}</div>
      {footer && (
        <div className="px-4 py-3 border-t" style={{ borderColor: COLORS.border, backgroundColor: COLORS.dark }}>
          {footer}
        </div>
      )}
    </div>
  );
}

function BBadge({ children, variant = 'info', className = '' }: {
  children: React.ReactNode; variant?: 'info' | 'success' | 'danger' | 'warning' | 'purple'; className?: string;
}) {
  const map: Record<string, { bg: string; color: string }> = {
    info: { bg: `${COLORS.info}22`, color: COLORS.info },
    success: { bg: `${COLORS.success}22`, color: COLORS.success },
    danger: { bg: `${COLORS.danger}22`, color: COLORS.danger },
    warning: { bg: `${COLORS.warning}22`, color: COLORS.warning },
    purple: { bg: `${COLORS.purple}22`, color: COLORS.purple },
  };
  const v = map[variant] ?? map.info;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${className}`} style={{ backgroundColor: v.bg, color: v.color }}>
      {children}
    </span>
  );
}

function BModal({ open, onClose, title, children, size = 'md' }: {
  open: boolean; onClose: () => void; title: string; children: React.ReactNode; size?: 'sm' | 'md' | 'lg';
}) {
  const sizeMap = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl' };
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`relative w-full ${sizeMap[size]} rounded-lg border shadow-2xl max-h-[85vh] flex flex-col`}
        style={{ backgroundColor: COLORS.darker, borderColor: COLORS.border }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: COLORS.border }}>
          <h3 className="text-base font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer">
            <X size={18} />
          </button>
        </div>
        <div className="p-5 overflow-y-auto flex-1">{children}</div>
      </motion.div>
    </div>
  );
}

function BInput({ label, value, onChange, placeholder, type = 'text', disabled, className = '' }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string;
  type?: string; disabled?: boolean; className?: string;
}) {
  return (
    <div className={`mb-3 ${className}`}>
      <label className="block text-xs font-medium mb-1" style={{ color: COLORS.muted }}>{label}</label>
      <input
        type={type} value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} disabled={disabled}
        className="w-full px-3 py-2 rounded border text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 transition-colors"
        style={{ backgroundColor: COLORS.dark, borderColor: COLORS.border, '--tw-ring-color': COLORS.blue } as React.CSSProperties}
      />
    </div>
  );
}

function BSelect({ label, value, onChange, options, className = '' }: {
  label: string; value: string; onChange: (v: string) => void;
  options: { value: string; label: string }[]; className?: string;
}) {
  return (
    <div className={`mb-3 ${className}`}>
      <label className="block text-xs font-medium mb-1" style={{ color: COLORS.muted }}>{label}</label>
      <select
        value={value} onChange={e => onChange(e.target.value)}
        className="w-full px-3 py-2 rounded border text-sm text-white focus:outline-none focus:ring-1 transition-colors cursor-pointer"
        style={{ backgroundColor: COLORS.dark, borderColor: COLORS.border, '--tw-ring-color': COLORS.blue } as React.CSSProperties}
      >
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function BCheckbox({ checked, onChange, className = '' }: { checked: boolean; onChange: (checked: boolean) => void; className?: string }) {
  return (
    <div className={`relative inline-flex items-center ${className}`} onClick={() => onChange(!checked)}>
      <input
        type="checkbox"
        checked={checked}
        onChange={e => e.stopPropagation()}
        className="peer sr-only"
      />
      <div
        className="w-4 h-4 rounded border flex items-center justify-center transition-colors cursor-pointer peer-checked:border-transparent"
        style={{
          backgroundColor: checked ? COLORS.blue : 'transparent',
          borderColor: checked ? COLORS.blue : COLORS.border,
        }}
      >
        {checked && (
          <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
            <path d="M2.5 6L5 8.5L9.5 3.5" stroke={COLORS.dark} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </div>
    </div>
  );
}

function BProgress({ value, max = 100, color }: { value: number; max?: number; color?: string }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: `${COLORS.dark}` }}>
      <motion.div
        className="h-full rounded-full"
        style={{ backgroundColor: color ?? COLORS.blue }}
        initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.5 }}
      />
    </div>
  );
}

// ==================== HELPERS ====================

function fmt(n: number, currency?: string): string {
  const d = currency ? (CRYPTO_DECIMALS[currency] ?? 4) : 4;
  return n.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: d });
}

function fmtDate(s?: string): string {
  if (!s) return '-';
  return new Date(s).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function addrShort(addr?: string): string {
  if (!addr) return '-';
  return addr.length > 16 ? `${addr.slice(0, 8)}...${addr.slice(-6)}` : addr;
}

function statusVariant(status: string): 'success' | 'danger' | 'warning' | 'info' | 'purple' {
  if (status === 'completed' || status === 'confirmed' || status === 'active') return 'success';
  if (status === 'failed' || status === 'reverted' || status === 'closed') return 'danger';
  if (status === 'pending' || status === 'processing') return 'warning';
  return 'info';
}

function severityVariant(s: string): 'info' | 'warning' | 'danger' {
  if (s === 'critical') return 'danger';
  if (s === 'warning') return 'warning';
  return 'info';
}

function eventTypeLabel(t: string): string {
  const m: Record<string, string> = {
    kyc_check: 'KYC Check', aml_screen: 'AML Screen', '2fa_toggle': '2FA Toggle',
    withdrawal_approval: 'Withdrawal Approval', limit_change: 'Limit Change',
    fraud_alert: 'Fraud Alert', cold_wallet_transfer: 'Cold Wallet Transfer', audit_log: 'Audit Log',
  };
  return m[t] ?? t;
}

function copyToClipboard(text: string) {
  navigator.clipboard?.writeText(text).then(() => toast.success('Copied to clipboard')).catch(() => toast.error('Copy failed'));
}

const CURRENCY_OPTIONS = Object.keys(CRYPTO_COLORS).map(c => ({ value: c, label: c }));

// ==================== MAIN COMPONENT ====================

export default function CryptoView() {
  const [activeTab, setActiveTab] = useState<TabKey>('wallets');

  return (
    <div className="min-h-screen" style={{ backgroundColor: COLORS.dark }}>
      {/* Header */}
      <div className="border-b relative" style={{ backgroundColor: COLORS.dark, borderColor: COLORS.border }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${COLORS.blue}22` }}>
              <Zap size={22} style={{ color: COLORS.blue }} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Crypto Dashboard</h1>
              <p className="text-xs" style={{ color: COLORS.muted }}>Manage wallets, exchanges & security</p>
            </div>
          </div>
          <div className="flex items-center gap-1 p-1 rounded-lg" style={{ backgroundColor: COLORS.darker }}>
            {TABS.map(tab => {
              const Icon = tab.icon;
              const active = activeTab === tab.key;
              return (
                <button
                  key={tab.key} onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-all cursor-pointer ${active ? 'text-white shadow-sm' : ''}`}
                  style={active ? { backgroundColor: COLORS.blue, color: COLORS.dark } : { color: COLORS.muted }}
                >
                  <Icon size={16} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <AnimatePresence mode="wait">
          {activeTab === 'wallets' && <WalletsTab key="wallets" />}
          {activeTab === 'exchange' && <ExchangeTab key="exchange" />}
          {activeTab === 'blockchain' && <BlockchainTab key="blockchain" />}
          {activeTab === 'security' && <SecurityTab key="security" />}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ==================== WALLETS TAB ====================

function WalletsTab() {
  const [wallets, setWallets] = useState<WalletData[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<'create' | 'send' | 'deposit' | 'details' | null>(null);
  const [selectedWallet, setSelectedWallet] = useState<WalletData | null>(null);
  const [showAddr, setShowAddr] = useState<Record<string, boolean>>({});
  const [form, setForm] = useState({ currency: 'BTC', network: 'mainnet', walletType: 'hot' });
  const [sendForm, setSendForm] = useState({ toAddress: '', amount: '', description: '' });
  const [submitting, setSubmitting] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    apiFetch('/api/crypto/wallets')
      .then(r => r.json())
      .then(data => { if (!cancelled) { if (Array.isArray(data)) setWallets(data); else toast.error('Failed to load wallets'); } })
      .catch(() => { if (!cancelled) toast.error('Network error loading wallets'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [refreshKey]);

  const fetchWallets = () => { setLoading(true); setRefreshKey(k => k + 1); };

  const filtered = wallets.filter(w => {
    const q = search.toLowerCase();
    return (
      w.currency?.toLowerCase().includes(q) ||
      w.walletType?.toLowerCase().includes(q) ||
      w.status?.toLowerCase().includes(q) ||
      w.user?.name?.toLowerCase().includes(q) ||
      w.depositAddress?.toLowerCase().includes(q)
    );
  });

  const totalBalance = wallets.reduce((s, w) => s + (w.balance ?? 0), 0);
  const totalFrozen = wallets.reduce((s, w) => s + (w.frozenBalance ?? 0), 0);
  const totalAvailable = wallets.reduce((s, w) => s + (w.availableBalance ?? 0), 0);

  const handleCreate = () => {
    setSubmitting(true);
    apiFetch('/api/crypto/wallets', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
      .then(r => r.json())
      .then(data => {
        if (data?.error) { toast.error(data.error); } else { toast.success(`${form.currency} wallet created`); setModal(null); setRefreshKey(k => k + 1); }
      })
      .catch(() => toast.error('Failed to create wallet'))
      .finally(() => setSubmitting(false));
  };

  const handleSend = () => {
    if (!selectedWallet) return;
    const amt = parseFloat(sendForm.amount);
    if (!amt || amt <= 0) { toast.error('Enter a valid amount'); return; }
    if (!sendForm.toAddress) { toast.error('Enter recipient address'); return; }
    setSubmitting(true);
    apiFetch('/api/crypto/transactions', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'send', currency: selectedWallet.currency, amount: amt, walletId: selectedWallet.id, toAddress: sendForm.toAddress, description: sendForm.description || undefined }),
    })
      .then(r => r.json())
      .then(data => {
        if (data?.error) { toast.error(data.error); } else { toast.success('Send transaction created'); setModal(null); setSendForm({ toAddress: '', amount: '', description: '' }); }
      })
      .catch(() => toast.error('Failed to create transaction'))
      .finally(() => setSubmitting(false));
  };

  const handleDeposit = () => {
    if (!selectedWallet) return;
    setSubmitting(true);
    apiFetch('/api/crypto/transactions', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'deposit', currency: selectedWallet.currency, amount: 0, walletId: selectedWallet.id, description: 'Deposit request' }),
    })
      .then(r => r.json())
      .then(data => {
        if (data?.error) { toast.error(data.error); } else { toast.success('Deposit request created'); setModal(null); }
      })
      .catch(() => toast.error('Failed to create deposit'))
      .finally(() => setSubmitting(false));
  };

  const openModal = (type: 'create' | 'send' | 'deposit' | 'details', wallet?: WalletData) => {
    setSelectedWallet(wallet ?? null);
    setModal(type);
  };

  if (loading) return <LoadingState />;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <SummaryCard icon={Wallet} label="Total Balance" value={fmt(totalBalance)} color={COLORS.blue} />
        <SummaryCard icon={TrendingUp} label="Available" value={fmt(totalAvailable)} color={COLORS.success} />
        <SummaryCard icon={Lock} label="Frozen" value={fmt(totalFrozen)} color={COLORS.danger} />
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: COLORS.muted }} />
          <input
            value={search} onChange={e => setSearch(e.target.value)} placeholder="Search wallets..."
            className="w-full pl-9 pr-3 py-2 rounded-md border text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1"
            style={{ backgroundColor: COLORS.darker, borderColor: COLORS.border, '--tw-ring-color': COLORS.blue } as React.CSSProperties}
          />
        </div>
        <BBtn variant="primary" size="sm" onClick={() => openModal('create')}>
          <Plus size={16} /> New Wallet
        </BBtn>
      </div>

      {/* Wallet Grid */}
      {filtered.length === 0 ? (
        <BCard><div className="text-center py-8" style={{ color: COLORS.muted }}><Wallet size={40} className="mx-auto mb-2 opacity-30" /><p>No wallets found</p></div></BCard>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(w => (
            <WalletCard
              key={w.id} wallet={w} showAddr={showAddr[w.id]}
              onToggleAddr={() => setShowAddr(p => ({ ...p, [w.id]: !p[w.id] }))}
              onSend={() => openModal('send', w)}
              onDeposit={() => openModal('deposit', w)}
              onDetails={() => openModal('details', w)}
            />
          ))}
        </div>
      )}

      {/* Create Wallet Modal */}
      <BModal open={modal === 'create'} onClose={() => setModal(null)} title="Create New Wallet">
        <BSelect label="Currency" value={form.currency} onChange={v => setForm(p => ({ ...p, currency: v }))} options={CURRENCY_OPTIONS} />
        <BSelect label="Network" value={form.network} onChange={v => setForm(p => ({ ...p, network: v }))}
          options={[{ value: 'mainnet', label: 'Mainnet' }, { value: 'testnet', label: 'Testnet' }, { value: 'erc20', label: 'ERC-20' }, { value: 'trc20', label: 'TRC-20' }, { value: 'bep20', label: 'BEP-20' }, { value: 'solana', label: 'Solana' }]} />
        <BSelect label="Wallet Type" value={form.walletType} onChange={v => setForm(p => ({ ...p, walletType: v }))}
          options={[{ value: 'hot', label: 'Hot Wallet' }, { value: 'cold', label: 'Cold Wallet' }]} />
        <div className="flex justify-end gap-2 mt-4">
          <BBtn variant="ghost" onClick={() => setModal(null)}>Cancel</BBtn>
          <BBtn variant="primary" onClick={handleCreate} disabled={submitting}>{submitting ? <Spinner size={16} /> : <><Plus size={16} /> Create</>}</BBtn>
        </div>
      </BModal>

      {/* Send Modal */}
      <BModal open={modal === 'send'} onClose={() => setModal(null)} title={`Send ${selectedWallet?.currency ?? ''}`}>
        <div className="mb-3 p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
          <span className="text-xs" style={{ color: COLORS.muted }}>Available: </span>
          <span className="text-sm font-semibold" style={{ color: COLORS.success }}>{fmt(selectedWallet?.availableBalance ?? 0, selectedWallet?.currency)} {selectedWallet?.currency}</span>
        </div>
        <BInput label="Recipient Address" value={sendForm.toAddress} onChange={v => setSendForm(p => ({ ...p, toAddress: v }))} placeholder="0x..." />
        <BInput label="Amount" value={sendForm.amount} onChange={v => setSendForm(p => ({ ...p, amount: v }))} placeholder="0.00" type="number" />
        <BInput label="Description (optional)" value={sendForm.description} onChange={v => setSendForm(p => ({ ...p, description: v }))} placeholder="Memo" />
        <div className="flex justify-end gap-2 mt-4">
          <BBtn variant="ghost" onClick={() => setModal(null)}>Cancel</BBtn>
          <BBtn variant="primary" onClick={handleSend} disabled={submitting}>{submitting ? <Spinner size={16} /> : <><Send size={16} /> Send</>}</BBtn>
        </div>
      </BModal>

      {/* Deposit Modal */}
      <BModal open={modal === 'deposit'} onClose={() => setModal(null)} title={`Deposit ${selectedWallet?.currency ?? ''}`}>
        <div className="text-center py-4">
          <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center text-2xl" style={{ backgroundColor: `${CRYPTO_COLORS[selectedWallet?.currency ?? 'BTC'] ?? COLORS.blue}22`, color: CRYPTO_COLORS[selectedWallet?.currency ?? 'BTC'] ?? COLORS.blue }}>
            {CRYPTO_SYMBOLS[selectedWallet?.currency ?? 'BTC'] ?? '?'}
          </div>
          <p className="text-xs mb-2" style={{ color: COLORS.muted }}>Your deposit address ({selectedWallet?.network})</p>
          <div className="p-3 rounded-md font-mono text-sm break-all" style={{ backgroundColor: COLORS.dark, color: COLORS.info }}>
            {selectedWallet?.depositAddress ?? '-'}
          </div>
          <BBtn variant="outline" size="sm" className="mt-3" onClick={() => copyToClipboard(selectedWallet?.depositAddress ?? '')}>
            <Copy size={14} /> Copy Address
          </BBtn>
        </div>
        <div className="flex justify-end gap-2 mt-2">
          <BBtn variant="ghost" onClick={() => setModal(null)}>Close</BBtn>
          <BBtn variant="success" onClick={handleDeposit} disabled={submitting}>{submitting ? <Spinner size={16} /> : <><Download size={16} /> Request Deposit</>}</BBtn>
        </div>
      </BModal>

      {/* Wallet Details Modal */}
      <BModal open={modal === 'details'} onClose={() => setModal(null)} title={`${selectedWallet?.currency ?? ''} Wallet Details`} size="lg">
        {selectedWallet && <WalletDetails wallet={selectedWallet} />}
      </BModal>
    </motion.div>
  );
}

function WalletCard({ wallet: w, showAddr, onToggleAddr, onSend, onDeposit, onDetails }: {
  wallet: WalletData; showAddr: boolean; onToggleAddr: () => void; onSend: () => void; onDeposit: () => void; onDetails: () => void;
}) {
  const color = CRYPTO_COLORS[w.currency] ?? COLORS.blue;
  return (
    <BCard className="hover:shadow-lg transition-shadow cursor-pointer group" header={
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: `${color}22`, color }}>
            {CRYPTO_SYMBOLS[w.currency] ?? w.currency?.[0]}
          </div>
          <div>
            <span className="text-sm font-semibold text-white">{w.currency}</span>
            <span className="text-xs ml-1" style={{ color: COLORS.muted }}>{w.network}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ backgroundColor: COLORS.dark, color: COLORS.muted }} title="Wallet ID">{w.id}</span>
          <BBadge variant={statusVariant(w.status)}>{w.status}</BBadge>
        </div>
      </div>
    }>  
      <div className="text-center mb-3">
        <p className="text-2xl font-bold text-white">{fmt(w.balance, w.currency)}</p>
        <p className="text-xs" style={{ color: COLORS.muted }}>{w.currency} Balance</p>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
        <div className="p-2 rounded" style={{ backgroundColor: COLORS.dark }}>
          <span style={{ color: COLORS.muted }}>Available</span>
          <p className="font-semibold" style={{ color: COLORS.success }}>{fmt(w.availableBalance, w.currency)}</p>
        </div>
        <div className="p-2 rounded" style={{ backgroundColor: COLORS.dark }}>
          <span style={{ color: COLORS.muted }}>Frozen</span>
          <p className="font-semibold" style={{ color: COLORS.danger }}>{fmt(w.frozenBalance, w.currency)}</p>
        </div>
      </div>
      <div className="flex items-center gap-1 text-xs mb-3 px-1" style={{ color: COLORS.muted }}>
        <span className="truncate flex-1 font-mono">{showAddr ? w.depositAddress : addrShort(w.depositAddress)}</span>
        <button onClick={e => { e.stopPropagation(); onToggleAddr(); }} className="p-0.5 hover:text-white transition-colors cursor-pointer" title="Toggle address">
          <Eye size={12} />
        </button>
        <button onClick={e => { e.stopPropagation(); copyToClipboard(w.depositAddress); }} className="p-0.5 hover:text-white transition-colors cursor-pointer" title="Copy">
          <Copy size={12} />
        </button>
      </div>
      <div className="flex items-center gap-1 text-xs mb-3 px-1" style={{ color: COLORS.muted }}>
        <span>Owner: {w.user?.name ?? 'Unknown'}</span>
        <BBadge variant="purple" className="ml-auto">{w.walletType}</BBadge>
      </div>
      <div className="flex gap-2">
        <BBtn variant="primary" size="sm" className="flex-1" onClick={e => { e.stopPropagation(); onSend(); }}><Send size={14} /> Send</BBtn>
        <BBtn variant="success" size="sm" className="flex-1" onClick={e => { e.stopPropagation(); onDeposit(); }}><Download size={14} /> Deposit</BBtn>
        <BBtn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); onDetails(); }} title="Details"><Eye size={14} /></BBtn>
      </div>
    </BCard>
  );
}

function WalletDetails({ wallet: w }: { wallet: WalletData }) {
  const color = CRYPTO_COLORS[w.currency] ?? COLORS.blue;
  const fields: [string, string][] = [
    ['Wallet ID', w.id], ['Currency', w.currency], ['Network', w.network], ['Type', w.walletType],
    ['Status', w.status], ['Created', fmtDate(w.createdAt)],
    ['Owner', w.user?.name ?? '-'], ['Email', w.user?.email ?? '-'],
  ];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4 text-center">
        <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
          <p className="text-lg font-bold text-white">{fmt(w.balance, w.currency)}</p>
          <p className="text-xs" style={{ color: COLORS.muted }}>Balance</p>
        </div>
        <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
          <p className="text-lg font-bold" style={{ color: COLORS.success }}>{fmt(w.availableBalance, w.currency)}</p>
          <p className="text-xs" style={{ color: COLORS.muted }}>Available</p>
        </div>
        <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
          <p className="text-lg font-bold" style={{ color: COLORS.danger }}>{fmt(w.frozenBalance, w.currency)}</p>
          <p className="text-xs" style={{ color: COLORS.muted }}>Frozen</p>
        </div>
      </div>
      <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
        <p className="text-xs mb-1" style={{ color: COLORS.muted }}>Deposit Address</p>
        <p className="font-mono text-sm break-all" style={{ color: COLORS.info }}>{w.depositAddress}</p>
        <BBtn variant="outline" size="sm" className="mt-2" onClick={() => copyToClipboard(w.depositAddress)}><Copy size={14} /> Copy</BBtn>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {fields.map(([label, value]) => (
          <div key={label} className="p-2 rounded" style={{ backgroundColor: COLORS.dark }}>
            <p className="text-xs" style={{ color: COLORS.muted }}>{label}</p>
            <p className="text-sm text-white font-medium">{value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== EXCHANGE TAB ====================

function ExchangeTab() {
  const [rates, setRates] = useState<RateData[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromCur, setFromCur] = useState('BTC');
  const [toCur, setToCur] = useState('ETH');
  const [amount, setAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedRateIds, setSelectedRateIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    apiFetch('/api/crypto/exchange-rates')
      .then(r => r.json())
      .then(data => { if (!cancelled) { if (Array.isArray(data)) setRates(data); else toast.error('Failed to load rates'); } })
      .catch(() => { if (!cancelled) toast.error('Network error'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [refreshKey]);

  const fetchRates = () => { setLoading(true); setRefreshKey(k => k + 1); };

  const allRatesSelected = rates.length > 0 && rates.every(r => selectedRateIds.has(r.id));
  const toggleAllRates = () => {
    if (allRatesSelected) { setSelectedRateIds(new Set()); }
    else { setSelectedRateIds(new Set(rates.map(r => r.id))); }
  };
  const toggleRate = (id: string) => {
    setSelectedRateIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectedRate = rates.find(r => r.fromCurrency === fromCur && r.toCurrency === toCur);
  const parsedAmount = parseFloat(amount) || 0;
  const receiveAmount = selectedRate ? parsedAmount * selectedRate.rate : 0;
  const feeAmount = selectedRate ? (selectedRate.fee > 0 && selectedRate.fee < 1 ? parsedAmount * selectedRate.fee : selectedRate.fee) : 0;

  const handleSwap = () => { setFromCur(toCur); setToCur(fromCur); };

  const handleExchange = () => {
    if (!parsedAmount || !selectedRate) return;
    if (selectedRate.minAmount && parsedAmount < selectedRate.minAmount) { toast.error(`Min: ${selectedRate.minAmount}`); return; }
    if (selectedRate.maxAmount && parsedAmount > selectedRate.maxAmount) { toast.error(`Max: ${selectedRate.maxAmount}`); return; }
    setShowConfirm(true);
  };

  const confirmExchange = () => {
    setShowConfirm(false);
    setSubmitting(true);
    const wallet = (window as Record<string, unknown>).__currentWallet as { id: string } | undefined;
    // Use the transactions API to perform exchange
    toast.info('Exchange requires a wallet — use the Wallets tab to send/exchange');
    setSubmitting(false);
  };

  if (loading) return <LoadingState />;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Exchange Form */}
        <BCard header={<div className="flex items-center gap-2"><ArrowRightLeft size={18} style={{ color: COLORS.blue }} /><span className="font-semibold text-white">Quick Exchange</span></div>}>
          <div className="space-y-3">
            <BSelect label="From" value={fromCur} onChange={setFromCur} options={CURRENCY_OPTIONS} />
            <div className="flex justify-center"><BBtn variant="ghost" size="sm" onClick={handleSwap} title="Swap currencies"><RefreshCw size={18} /></BBtn></div>
            <BSelect label="To" value={toCur} onChange={setToCur} options={CURRENCY_OPTIONS} />
            <BInput label="Amount" value={amount} onChange={setAmount} placeholder="0.00" type="number" />
            {selectedRate ? (
              <div className="p-3 rounded-md space-y-1 text-sm" style={{ backgroundColor: COLORS.dark }}>
                <div className="flex justify-between"><span style={{ color: COLORS.muted }}>Rate</span><span className="text-white">1 {fromCur} = {fmt(selectedRate.rate)} {toCur}</span></div>
                <div className="flex justify-between"><span style={{ color: COLORS.muted }}>You receive</span><span className="text-white font-semibold" style={{ color: COLORS.success }}>{fmt(receiveAmount, toCur)} {toCur}</span></div>
                <div className="flex justify-between"><span style={{ color: COLORS.muted }}>Fee</span><span className="text-white">{fmt(feeAmount)} {fromCur}</span></div>
                {selectedRate.minAmount && <div className="flex justify-between"><span style={{ color: COLORS.muted }}>Min</span><span className="text-white">{selectedRate.minAmount}</span></div>}
                {selectedRate.maxAmount && <div className="flex justify-between"><span style={{ color: COLORS.muted }}>Max</span><span className="text-white">{selectedRate.maxAmount}</span></div>}
              </div>
            ) : (
              <div className="text-center py-3 text-sm" style={{ color: COLORS.muted }}>No active rate for this pair</div>
            )}
            <BBtn variant="primary" className="w-full" onClick={handleExchange} disabled={!selectedRate || submitting}>
              {submitting ? <Spinner size={16} /> : <><ArrowRightLeft size={16} /> Exchange</>}
            </BBtn>
          </div>
        </BCard>

        {/* Rates Table */}
        <BCard header={
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2"><Activity size={18} style={{ color: COLORS.blue }} /><span className="font-semibold text-white">Exchange Rates</span>
              {selectedRateIds.size > 0 && <BBadge variant="info">{selectedRateIds.size} selected</BBadge>}
            </div>
            <div className="flex items-center gap-2">
              {selectedRateIds.size > 0 && <BBtn variant="ghost" size="sm" onClick={() => setSelectedRateIds(new Set())}><X size={14} /> Clear</BBtn>}
              <BBtn variant="ghost" size="sm" onClick={fetchRates}><RefreshCw size={14} /></BBtn>
            </div>
          </div>
        }>
          {rates.length === 0 ? (
            <div className="text-center py-8" style={{ color: COLORS.muted }}><Activity size={32} className="mx-auto mb-2 opacity-30" /><p>No exchange rates available</p></div>
          ) : (
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs" style={{ color: COLORS.muted }}>
                    <th className="pb-2 w-8"><BCheckbox checked={allRatesSelected} onChange={toggleAllRates} /></th>
                    <th className="pb-2 font-medium">From</th><th className="pb-2 font-medium">To</th><th className="pb-2 font-medium">Rate</th><th className="pb-2 font-medium">Fee</th><th className="pb-2 font-medium">Limits</th>
                  </tr>
                </thead>
                <tbody className="divide-y" style={{ borderColor: COLORS.border }}>
                  {rates.map(r => (
                    <tr key={r.id} className={`hover:bg-white/5 transition-colors cursor-pointer ${selectedRateIds.has(r.id) ? 'bg-white/5' : ''}`} onClick={() => { setFromCur(r.fromCurrency); setToCur(r.toCurrency); }}>
                      <td className="py-2" onClick={e => e.stopPropagation()}><BCheckbox checked={selectedRateIds.has(r.id)} onChange={() => toggleRate(r.id)} /></td>
                      <td className="py-2"><span className="flex items-center gap-1.5"><span className="w-5 h-5 rounded-full flex items-center justify-center text-xs" style={{ backgroundColor: `${CRYPTO_COLORS[r.fromCurrency] ?? COLORS.blue}22`, color: CRYPTO_COLORS[r.fromCurrency] ?? COLORS.blue }}>{CRYPTO_SYMBOLS[r.fromCurrency] ?? '?'}</span><span className="text-white">{r.fromCurrency}</span></span></td>
                      <td className="py-2"><span className="flex items-center gap-1.5"><span className="w-5 h-5 rounded-full flex items-center justify-center text-xs" style={{ backgroundColor: `${CRYPTO_COLORS[r.toCurrency] ?? COLORS.blue}22`, color: CRYPTO_COLORS[r.toCurrency] ?? COLORS.blue }}>{CRYPTO_SYMBOLS[r.toCurrency] ?? '?'}</span><span className="text-white">{r.toCurrency}</span></span></td>
                      <td className="py-2 text-white font-mono">{fmt(r.rate)}</td>
                      <td className="py-2" style={{ color: COLORS.warning }}>{r.fee}{r.fee < 1 ? '%' : ''}</td>
                      <td className="py-2 text-xs" style={{ color: COLORS.muted }}>{r.minAmount ? `Min ${r.minAmount}` : '-'} {r.maxAmount ? `/ Max ${r.maxAmount}` : ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </BCard>
      </div>

      {/* Confirm Modal */}
      <BModal open={showConfirm} onClose={() => setShowConfirm(false)} title="Confirm Exchange">
        <div className="space-y-3">
          <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
            <p className="text-sm" style={{ color: COLORS.muted }}>You are exchanging</p>
            <p className="text-xl font-bold text-white mt-1">{fmt(parsedAmount, fromCur)} {fromCur} → {fmt(receiveAmount, toCur)} {toCur}</p>
          </div>
          <p className="text-xs" style={{ color: COLORS.muted }}>This action requires a wallet. Please use the Send/Exchange feature from the Wallets tab.</p>
          <div className="flex justify-end gap-2">
            <BBtn variant="ghost" onClick={() => setShowConfirm(false)}>Cancel</BBtn>
            <BBtn variant="primary" onClick={confirmExchange} disabled={submitting}>{submitting ? <Spinner size={16} /> : 'Confirm'}</BBtn>
          </div>
        </div>
      </BModal>
    </motion.div>
  );
}

// ==================== BLOCKCHAIN TAB ====================

function BlockchainTab() {
  const [txs, setTxs] = useState<BcTxData[]>([]);
  const [pagination, setPagination] = useState<Pagination>({ page: 1, limit: 20, total: 0, totalPages: 0 });
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ network: '', currency: '', status: '' });
  const [detailTx, setDetailTx] = useState<BcTxData | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedTxIds, setSelectedTxIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    const params = new URLSearchParams({ page: '1', limit: '20' });
    if (filters.network) params.set('network', filters.network);
    if (filters.currency) params.set('currency', filters.currency);
    if (filters.status) params.set('status', filters.status);
    apiFetch(`/api/crypto/blockchain?${params}`)
      .then(r => r.json())
      .then(data => { if (!cancelled) { setTxs(data?.transactions ?? []); setPagination(data?.pagination ?? { page: 1, limit: 20, total: 0, totalPages: 0 }); } })
      .catch(() => { if (!cancelled) toast.error('Failed to load blockchain transactions'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [filters, refreshKey]);

  const changeFilters = (patch: Partial<typeof filters>) => { setLoading(true); setFilters(p => ({ ...p, ...patch })); setSelectedTxIds(new Set()); };
  const fetchBc = () => { setLoading(true); setRefreshKey(k => k + 1); setSelectedTxIds(new Set()); };

  const allTxSelected = txs.length > 0 && txs.every(t => selectedTxIds.has(t.id));
  const toggleAllTx = () => {
    if (allTxSelected) { setSelectedTxIds(new Set()); }
    else { setSelectedTxIds(new Set(txs.map(t => t.id))); }
  };
  const toggleTx = (id: string) => {
    setSelectedTxIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const goToPage = (page: number) => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), limit: '20' });
    if (filters.network) params.set('network', filters.network);
    if (filters.currency) params.set('currency', filters.currency);
    if (filters.status) params.set('status', filters.status);
    apiFetch(`/api/crypto/blockchain?${params}`)
      .then(r => r.json())
      .then(data => { setTxs(data?.transactions ?? []); setPagination(data?.pagination ?? { page: 1, limit: 20, total: 0, totalPages: 0 }); })
      .catch(() => toast.error('Failed to load blockchain transactions'))
      .finally(() => setLoading(false));
  };

  if (loading) return <LoadingState />;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <BSelect label="" value={filters.network} onChange={v => changeFilters({ network: v })}
          options={[{ value: '', label: 'All Networks' }, { value: 'mainnet', label: 'Mainnet' }, { value: 'erc20', label: 'ERC-20' }, { value: 'trc20', label: 'TRC-20' }, { value: 'solana', label: 'Solana' }]} />
        <BSelect label="" value={filters.currency} onChange={v => changeFilters({ currency: v })} options={[{ value: '', label: 'All Currencies' }, ...CURRENCY_OPTIONS]} />
        <BSelect label="" value={filters.status} onChange={v => changeFilters({ status: v })}
          options={[{ value: '', label: 'All Status' }, { value: 'pending', label: 'Pending' }, { value: 'confirmed', label: 'Confirmed' }, { value: 'failed', label: 'Failed' }]} />
        <BBtn variant="ghost" size="sm" onClick={fetchBc}><RefreshCw size={14} /></BBtn>
        {selectedTxIds.size > 0 && (
          <div className="flex items-center gap-2 ml-auto">
            <BBadge variant="info">{selectedTxIds.size} selected</BBadge>
            <BBtn variant="ghost" size="sm" onClick={() => setSelectedTxIds(new Set())}><X size={14} /> Clear</BBtn>
          </div>
        )}
      </div>

      {/* Table */}
      <BCard>
        {txs.length === 0 ? (
          <div className="text-center py-8" style={{ color: COLORS.muted }}><Link2 size={32} className="mx-auto mb-2 opacity-30" /><p>No blockchain transactions found</p></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs" style={{ color: COLORS.muted }}>
                  <th className="pb-2 w-8"><BCheckbox checked={allTxSelected} onChange={toggleAllTx} /></th>
                  <th className="pb-2 font-medium">TX Hash</th><th className="pb-2 font-medium">Currency</th>
                  <th className="pb-2 font-medium">Network</th><th className="pb-2 font-medium">Amount</th>
                  <th className="pb-2 font-medium">Confirmations</th><th className="pb-2 font-medium">Status</th>
                  <th className="pb-2 font-medium">Detected</th><th className="pb-2 font-medium"></th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: COLORS.border }}>
                {txs.map(tx => (
                  <tr key={tx.id} className={`hover:bg-white/5 transition-colors ${selectedTxIds.has(tx.id) ? 'bg-white/5' : ''}`}>
                    <td className="py-2.5" onClick={e => e.stopPropagation()}><BCheckbox checked={selectedTxIds.has(tx.id)} onChange={() => toggleTx(tx.id)} /></td>
                    <td className="py-2.5"><span className="font-mono text-xs cursor-pointer hover:underline" style={{ color: COLORS.info }} onClick={() => setDetailTx(tx)}>{addrShort(tx.txHash)}</span></td>
                    <td className="py-2.5"><span className="flex items-center gap-1"><span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]" style={{ backgroundColor: `${CRYPTO_COLORS[tx.currency] ?? COLORS.blue}22`, color: CRYPTO_COLORS[tx.currency] ?? COLORS.blue }}>{CRYPTO_SYMBOLS[tx.currency] ?? '?'}</span><span className="text-white">{tx.currency}</span></span></td>
                    <td className="py-2.5 text-white">{tx.network}</td>
                    <td className="py-2.5 text-white font-mono">{fmt(tx.amount, tx.currency)}</td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-2"><BProgress value={tx.confirmations} max={tx.requiredConfs} color={tx.confirmations >= tx.requiredConfs ? COLORS.success : COLORS.warning} /><span className="text-xs text-white whitespace-nowrap">{tx.confirmations}/{tx.requiredConfs}</span></div>
                    </td>
                    <td className="py-2.5"><BBadge variant={statusVariant(tx.status)}>{tx.status}</BBadge></td>
                    <td className="py-2.5 text-xs whitespace-nowrap" style={{ color: COLORS.muted }}>{fmtDate(tx.detectedAt)}</td>
                    <td className="py-2.5"><button onClick={() => setDetailTx(tx)} className="p-1 hover:bg-white/10 rounded transition-colors cursor-pointer"><Eye size={14} style={{ color: COLORS.muted }} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 pt-3 border-t" style={{ borderColor: COLORS.border }}>
            <span className="text-xs" style={{ color: COLORS.muted }}>Page {pagination.page} of {pagination.totalPages} ({pagination.total} total)</span>
            <div className="flex gap-1">
              <BBtn variant="outline" size="sm" disabled={pagination.page <= 1} onClick={() => goToPage(pagination.page - 1)}><ChevronLeft size={14} /></BBtn>
              <BBtn variant="outline" size="sm" disabled={pagination.page >= pagination.totalPages} onClick={() => goToPage(pagination.page + 1)}><ChevronRight size={14} /></BBtn>
            </div>
          </div>
        )}
      </BCard>

      {/* Detail Modal */}
      <BModal open={!!detailTx} onClose={() => setDetailTx(null)} title="Blockchain Transaction Details" size="lg">
        {detailTx && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {([
                ['TX Hash', detailTx.txHash], ['Network', detailTx.network],
                ['Currency', detailTx.currency], ['Amount', `${fmt(detailTx.amount, detailTx.currency)} ${detailTx.currency}`],
                ['From', detailTx.fromAddress ?? '-'], ['To', detailTx.toAddress ?? '-'],
                ['Gas Used', detailTx.gasUsed ? String(detailTx.gasUsed) : '-'],
                ['Gas Price', detailTx.gasPrice ? String(detailTx.gasPrice) : '-'],
                ['Network Fee', detailTx.networkFee ? String(detailTx.networkFee) : '-'],
                ['Detected', fmtDate(detailTx.detectedAt)], ['Confirmed', fmtDate(detailTx.confirmedAt)],
              ] as [string, string][]).map(([label, value]) => (
                <div key={label} className="p-2 rounded" style={{ backgroundColor: COLORS.dark }}>
                  <p className="text-xs" style={{ color: COLORS.muted }}>{label}</p>
                  <p className="text-sm text-white font-mono break-all">{value}</p>
                </div>
              ))}
            </div>
            <div className="p-3 rounded-md" style={{ backgroundColor: COLORS.dark }}>
              <p className="text-xs mb-2" style={{ color: COLORS.muted }}>Confirmations</p>
              <BProgress value={detailTx.confirmations} max={detailTx.requiredConfs} color={detailTx.confirmations >= detailTx.requiredConfs ? COLORS.success : COLORS.warning} />
              <p className="text-xs mt-1 text-right" style={{ color: COLORS.muted }}>{detailTx.confirmations} / {detailTx.requiredConfs}</p>
            </div>
          </div>
        )}
      </BModal>
    </motion.div>
  );
}

// ==================== SECURITY TAB ====================

function SecurityTab() {
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ eventType: '', severity: '' });
  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState({ eventType: 'kyc_check', severity: 'info', title: '', description: '' });
  const [submitting, setSubmitting] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedEventIds, setSelectedEventIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    const params = new URLSearchParams();
    if (filter.eventType) params.set('eventType', filter.eventType);
    if (filter.severity) params.set('severity', filter.severity);
    apiFetch(`/api/crypto/security?${params}`)
      .then(r => r.json())
      .then(data => { if (!cancelled) { if (Array.isArray(data)) setEvents(data); else toast.error('Failed to load events'); } })
      .catch(() => { if (!cancelled) toast.error('Network error'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [filter, refreshKey]);

  const changeFilter = (patch: Partial<typeof filter>) => { setLoading(true); setFilter(p => ({ ...p, ...patch })); setSelectedEventIds(new Set()); };
  const fetchEvents = () => { setLoading(true); setRefreshKey(k => k + 1); setSelectedEventIds(new Set()); };

  const allEventsSelected = events.length > 0 && events.every(e => selectedEventIds.has(e.id));
  const toggleAllEvents = () => {
    if (allEventsSelected) { setSelectedEventIds(new Set()); }
    else { setSelectedEventIds(new Set(events.map(e => e.id))); }
  };
  const toggleEvent = (id: string) => {
    setSelectedEventIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleCreate = () => {
    if (!createForm.title) { toast.error('Title is required'); return; }
    setSubmitting(true);
    apiFetch('/api/crypto/security', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(createForm),
    })
      .then(r => r.json())
      .then(data => {
        if (data?.error) { toast.error(data.error); } else { toast.success('Security event logged'); setShowCreate(false); setCreateForm({ eventType: 'kyc_check', severity: 'info', title: '', description: '' }); setRefreshKey(k => k + 1); }
      })
      .catch(() => toast.error('Failed to create event'))
      .finally(() => setSubmitting(false));
  };

  const severityCounts = { info: 0, warning: 0, critical: 0 };
  events.forEach(e => { if (severityCounts[e.severity as keyof typeof severityCounts] !== undefined) severityCounts[e.severity as keyof typeof severityCounts]++; });

  if (loading) return <LoadingState />;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <SummaryCard icon={Info} label="Info Events" value={String(severityCounts.info)} color={COLORS.info} />
        <SummaryCard icon={AlertTriangle} label="Warnings" value={String(severityCounts.warning)} color={COLORS.warning} />
        <SummaryCard icon={ShieldAlert} label="Critical Alerts" value={String(severityCounts.critical)} color={COLORS.danger} />
      </div>

      {/* Filters + Create */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <BSelect label="" value={filter.eventType} onChange={v => changeFilter({ eventType: v })}
          options={[{ value: '', label: 'All Types' },
            { value: 'kyc_check', label: 'KYC Check' }, { value: 'aml_screen', label: 'AML Screen' },
            { value: '2fa_toggle', label: '2FA Toggle' }, { value: 'withdrawal_approval', label: 'Withdrawal Approval' },
            { value: 'limit_change', label: 'Limit Change' }, { value: 'fraud_alert', label: 'Fraud Alert' },
            { value: 'cold_wallet_transfer', label: 'Cold Wallet Transfer' }, { value: 'audit_log', label: 'Audit Log' },
          ]} />
        <BSelect label="" value={filter.severity} onChange={v => changeFilter({ severity: v })}
          options={[{ value: '', label: 'All Severities' }, { value: 'info', label: 'Info' }, { value: 'warning', label: 'Warning' }, { value: 'critical', label: 'Critical' }]} />
        <BBtn variant="ghost" size="sm" onClick={fetchEvents}><RefreshCw size={14} /></BBtn>
        {selectedEventIds.size > 0 && (
          <div className="flex items-center gap-2">
            <BBadge variant="info">{selectedEventIds.size} selected</BBadge>
            <BBtn variant="ghost" size="sm" onClick={() => setSelectedEventIds(new Set())}><X size={14} /> Clear</BBtn>
          </div>
        )}
        <div className="ml-auto">
          <BBtn variant="primary" size="sm" onClick={() => setShowCreate(true)}><Plus size={14} /> Log Event</BBtn>
        </div>
      </div>

      {/* Select All Bar */}
      {events.length > 0 && (
        <div className="flex items-center gap-3 mb-3 px-1">
          <BCheckbox checked={allEventsSelected} onChange={toggleAllEvents} />
          <span className="text-xs cursor-pointer" style={{ color: COLORS.muted }} onClick={toggleAllEvents}>Select All ({events.length})</span>
        </div>
      )}

      {/* Events List */}
      {events.length === 0 ? (
        <BCard><div className="text-center py-8" style={{ color: COLORS.muted }}><Shield size={40} className="mx-auto mb-2 opacity-30" /><p>No security events found</p></div></BCard>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
          {events.map(e => (
            <BCard key={e.id} className={`hover:shadow-md transition-shadow ${selectedEventIds.has(e.id) ? 'ring-1 ring-[#61dafb]/40' : ''}`}>
              <div className="flex items-start gap-3">
                <div className="pt-1 flex-shrink-0" onClick={ev => { ev.stopPropagation(); toggleEvent(e.id); }}>
                  <BCheckbox checked={selectedEventIds.has(e.id)} onChange={() => toggleEvent(e.id)} />
                </div>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0`} style={{ backgroundColor: `${({ info: COLORS.info, warning: COLORS.warning, critical: COLORS.danger })[e.severity] ?? COLORS.info}22` }}>
                  {e.severity === 'critical' ? <ShieldAlert size={18} style={{ color: COLORS.danger }} /> : e.severity === 'warning' ? <AlertTriangle size={18} style={{ color: COLORS.warning }} /> : <Shield size={18} style={{ color: COLORS.info }} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-sm font-semibold text-white">{e.title}</span>
                    <BBadge variant={severityVariant(e.severity)}>{e.severity}</BBadge>
                    <BBadge variant="purple">{eventTypeLabel(e.eventType)}</BBadge>
                  </div>
                  {e.description && <p className="text-xs mb-1" style={{ color: COLORS.muted }}>{e.description}</p>}
                  <p className="text-xs" style={{ color: COLORS.muted }}>{fmtDate(e.createdAt)}</p>
                </div>
              </div>
            </BCard>
          ))}
        </div>
      )}

      {/* Create Event Modal */}
      <BModal open={showCreate} onClose={() => setShowCreate(false)} title="Log Security Event">
        <BSelect label="Event Type" value={createForm.eventType} onChange={v => setCreateForm(p => ({ ...p, eventType: v }))}
          options={[
            { value: 'kyc_check', label: 'KYC Check' }, { value: 'aml_screen', label: 'AML Screen' },
            { value: '2fa_toggle', label: '2FA Toggle' }, { value: 'withdrawal_approval', label: 'Withdrawal Approval' },
            { value: 'limit_change', label: 'Limit Change' }, { value: 'fraud_alert', label: 'Fraud Alert' },
            { value: 'cold_wallet_transfer', label: 'Cold Wallet Transfer' }, { value: 'audit_log', label: 'Audit Log' },
          ]} />
        <BSelect label="Severity" value={createForm.severity} onChange={v => setCreateForm(p => ({ ...p, severity: v }))}
          options={[{ value: 'info', label: 'Info' }, { value: 'warning', label: 'Warning' }, { value: 'critical', label: 'Critical' }]} />
        <BInput label="Title" value={createForm.title} onChange={v => setCreateForm(p => ({ ...p, title: v }))} placeholder="Event title" />
        <BInput label="Description (optional)" value={createForm.description} onChange={v => setCreateForm(p => ({ ...p, description: v }))} placeholder="Details..." />
        <div className="flex justify-end gap-2 mt-4">
          <BBtn variant="ghost" onClick={() => setShowCreate(false)}>Cancel</BBtn>
          <BBtn variant="primary" onClick={handleCreate} disabled={submitting}>{submitting ? <Spinner size={16} /> : <><Plus size={16} /> Log Event</>}</BBtn>
        </div>
      </BModal>
    </motion.div>
  );
}

// ==================== SHARED COMPONENTS ====================

function SummaryCard({ icon: Icon, label, value, color }: { icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>; label: string; value: string; color: string }) {
  return (
    <BCard>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}22` }}>
          <Icon size={20} style={{ color }} />
        </div>
        <div>
          <p className="text-xs" style={{ color: COLORS.muted }}>{label}</p>
          <p className="text-lg font-bold text-white">{value}</p>
        </div>
      </div>
    </BCard>
  );
}

function LoadingState() {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <Spinner size={32} color={COLORS.blue} />
      <p className="mt-3 text-sm" style={{ color: COLORS.muted }}>Loading...</p>
    </div>
  );
}
