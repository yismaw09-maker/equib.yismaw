'use client';

import { useState, useEffect, useCallback, useTransition, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Eye,
  EyeOff,
  Loader2,
  ShieldCheck,
  Wallet,
  Globe,
  Lock,
  Building2,
  Check,
  Clock,
  TrendingUp,
  Users,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAppStore, type UserInfo } from '@/lib/store';
import { useT, useI18n } from '@/lib/i18n';
import { useFormattedDate } from '@/hooks/use-formatted-date';

type ViewMode = 'login' | 'signup' | 'forgot';

const COUNTRY_OPTIONS = ['Ethiopia', 'Kenya', 'Uganda', 'Tanzania', 'Djibouti', 'Somalia', 'Sudan', 'South Sudan', 'Eritrea', 'Other'];

/* ── Live Clock ──────────────────────────────────────── */
function LiveClock() {
  const [now, setNow] = useState(new Date());
  const { formatTime, formatDate, formatDateTime } = useFormattedDate();

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const dateStr = formatDate(now);
  const timeStr = formatTime(now);

  return (
    <div className="hidden sm:flex items-center gap-2.5 text-xs font-medium bg-muted/60 px-3.5 py-2 rounded-lg border border-border/50">
      <Clock className="h-3.5 w-3.5 text-muted-foreground" />
      <span className="text-muted-foreground">{dateStr}</span>
      <span className="datetime-separator">|</span>
      <span className="time-display tabular-nums font-semibold text-foreground/80">{timeStr}</span>
    </div>
  );
}

/* ── Left Branding Panel ──────────────────────────────── */
function BrandingPanel({ t }: { t: (key: string) => string }) {
  return (
    <div
      className="hidden lg:flex lg:w-[420px] xl:w-[480px] text-white flex-col justify-between p-8 relative overflow-hidden"
      style={{ background: 'linear-gradient(160deg, #0B6E4F 0%, #094d38 40%, #062e22 100%)' }}
    >
      {/* Decorative shapes */}
      <div className="absolute top-[-80px] right-[-80px] w-72 h-72 rounded-full bg-white/[0.04]" />
      <div className="absolute bottom-[-60px] left-[-60px] w-56 h-56 rounded-full bg-white/[0.04]" />
      <div className="absolute top-1/2 left-1/4 w-40 h-40 rounded-full bg-white/[0.02]" />
      <div className="absolute top-[20%] right-[10%] w-24 h-24 rounded-full bg-white/[0.03]" />
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-11 w-11 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center border border-white/10">
            <Globe className="h-6 w-6" />
          </div>
          <div>
            <span className="text-2xl font-bold tracking-tight">FinFlow</span>
            <span className="block text-[10px] text-emerald-200/60 font-medium tracking-widest uppercase">Enterprise v3.0</span>
          </div>
        </div>
      </div>

      <div className="relative z-10 space-y-6">
        <h2 className="text-3xl font-bold leading-tight">
          {t('header.enterprisePlatform')}
        </h2>
        <p className="text-emerald-100/80 text-sm leading-relaxed max-w-sm">
          Secure, scalable, enterprise-grade financial transaction management for Ethiopian businesses and beyond.
        </p>

        <div className="space-y-3">
          {[
            { icon: ShieldCheck, text: 'Bank-grade security & encryption' },
            { icon: Globe, text: 'Multi-currency support (ETB, USD, EUR)' },
            { icon: Wallet, text: 'Real-time transaction monitoring' },
            { icon: Building2, text: 'NBE regulated & compliant' },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-3 text-sm">
              <div className="h-7 w-7 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center flex-shrink-0 border border-white/5">
                <Check className="h-3.5 w-3.5" strokeWidth={3} />
              </div>
              <span className="text-emerald-50/90">{text}</span>
            </div>
          ))}
        </div>

        {/* Stats section */}
        <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white/10">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <TrendingUp className="h-3.5 w-3.5 text-emerald-300/60" />
            </div>
            <p className="text-xl font-bold tabular-nums">99.9%</p>
            <p className="text-[10px] text-emerald-200/50 uppercase tracking-wide">Uptime</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Users className="h-3.5 w-3.5 text-emerald-300/60" />
            </div>
            <p className="text-xl font-bold tabular-nums">256-bit</p>
            <p className="text-[10px] text-emerald-200/50 uppercase tracking-wide">Encryption</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Lock className="h-3.5 w-3.5 text-emerald-300/60" />
            </div>
            <p className="text-xl font-bold tabular-nums">SOC2</p>
            <p className="text-[10px] text-emerald-200/50 uppercase tracking-wide">Compliant</p>
          </div>
        </div>
      </div>

      <div className="relative z-10 text-xs text-emerald-200/40">
        {t('footer.regulated')}
      </div>
    </div>
  );
}

/* ── Slide variants ────────────────────────────────────── */
const slideVariants = {
  initial: (direction: number) => ({ x: direction > 0 ? 40 : -40, opacity: 0 }),
  animate: { x: 0, opacity: 1 },
  exit: (direction: number) => ({ x: direction > 0 ? -40 : 40, opacity: 0 }),
};

/* ── Login View ────────────────────────────────────────── */
function LoginView({
  t,
  onNavigate,
  onLogin,
  loading,
}: {
  t: (key: string) => string;
  onNavigate: (v: ViewMode) => void;
  onLogin: (email: string, password: string) => void;
  loading: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [focused, setFocused] = useState<string | null>(null);

  const busy = loading || isPending;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    startTransition(() => onLogin(email, password));
  };

  return (
    <div className="space-y-6">
      <div className="space-y-1.5 text-center">
        <div className="mx-auto h-12 w-12 rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mb-3 border border-emerald-100 dark:border-emerald-800/30">
          <Lock className="h-6 w-6 text-emerald-600" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight">{t('login.title')}</h2>
        <p className="text-sm text-muted-foreground">{t('login.subtitle')}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="login-email" className="text-sm font-medium">{t('login.emailOrUsernameLabel')}</Label>
          <div className="relative">
            <Input
              id="login-email"
              type="text"
              placeholder={t('login.emailOrUsernamePlaceholder')}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onFocus={() => setFocused('email')}
              onBlur={() => setFocused(null)}
              required
              autoComplete="username"
              className={`h-11 rounded-lg border-input bg-background text-sm transition-all duration-200 placeholder:text-muted-foreground ${focused === 'email' ? 'border-emerald-500 ring-2 ring-emerald-500/20' : ''}`}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="login-password" className="text-sm font-medium">{t('login.passwordLabel')}</Label>
          <div className="relative">
            <Input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              placeholder={t('login.passwordPlaceholder')}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onFocus={() => setFocused('password')}
              onBlur={() => setFocused(null)}
              required
              autoComplete="current-password"
              className={`h-11 rounded-lg border-input bg-background text-sm pr-10 transition-all duration-200 placeholder:text-muted-foreground ${focused === 'password' ? 'border-emerald-500 ring-2 ring-emerald-500/20' : ''}`}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-0.5"
              tabIndex={-1}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Checkbox
              id="remember"
              checked={remember}
              onCheckedChange={(v) => setRemember(v === true)}
            />
            <Label htmlFor="remember" className="text-sm cursor-pointer">
              {t('login.rememberMe')}
            </Label>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('forgot')}
            className="text-sm font-medium text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors whitespace-nowrap"
          >
            {t('login.forgotPassword')}
          </button>
        </div>

        <Button
          type="submit"
          className="w-full h-12 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-[15px] transition-all duration-200 shadow-sm hover:shadow-md active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 disabled:opacity-60 disabled:pointer-events-none"
          disabled={busy}
        >
          {busy ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              {t('login.signingIn')}
            </>
          ) : (
            t('login.signIn')
          )}
        </Button>
      </form>

      {/* Sign Up Link */}
      <div className="text-center text-sm text-muted-foreground">
        {t('login.noAccount')}{' '}
        <button
          type="button"
          onClick={() => onNavigate('signup')}
          className="font-medium text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors"
        >
          {t('login.signUp')}
        </button>
      </div>

      {/* Copyright */}
      <p className="text-center text-[11px] text-muted-foreground/50 pt-2">
        {t('login.copyright', { year: String(new Date().getFullYear()) })}
      </p>
    </div>
  );
}

/* ── Sign Up View ──────────────────────────────────────── */
function SignUpView({
  t,
  onNavigate,
  onRegister,
  loading,
}: {
  t: (key: string) => string;
  onNavigate: (v: ViewMode) => void;
  onRegister: (data: { name: string; username: string; email: string; phone: string; country: string; password: string }) => void;
  loading: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('Ethiopia');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const busy = loading || isPending;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error(t('signup.passwordTooShort'));
      return;
    }
    if (password !== confirmPassword) {
      toast.error(t('signup.passwordMismatch'));
      return;
    }
    startTransition(() => onRegister({ name, username, email, phone, country, password }));
  };

  const inputCls = 'h-11 rounded-lg border-input bg-background text-sm transition-all duration-200 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/20 focus-visible:border-emerald-500';

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <button
          type="button"
          onClick={() => onNavigate('login')}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-2 min-h-[44px]"
        >
          <ArrowLeft className="h-4 w-4" />
          {t('common.back')}
        </button>
        <h2 className="text-2xl font-bold tracking-tight">{t('signup.title')}</h2>
        <p className="text-sm text-muted-foreground">{t('signup.subtitle')}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="space-y-1.5">
            <Label htmlFor="signup-name" className="text-sm font-medium">{t('signup.fullNameLabel')}</Label>
            <Input
              id="signup-name"
              placeholder={t('signup.fullNamePlaceholder')}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              autoComplete="name"
              className={inputCls}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="signup-username" className="text-sm font-medium">{t('signup.usernameLabel')}</Label>
            <Input
              id="signup-username"
              placeholder={t('signup.usernamePlaceholder')}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              className={inputCls}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="space-y-1.5">
            <Label htmlFor="signup-email" className="text-sm font-medium">{t('signup.emailLabel')}</Label>
            <Input
              id="signup-email"
              type="email"
              placeholder={t('signup.emailPlaceholder')}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              className={inputCls}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="signup-phone" className="text-sm font-medium">{t('signup.phoneLabel')}</Label>
            <Input
              id="signup-phone"
              type="tel"
              placeholder={t('signup.phonePlaceholder')}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
              className={inputCls}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="signup-country" className="text-sm font-medium">{t('signup.countryLabel')}</Label>
          <select
            id="signup-country"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className={`flex h-11 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/20 focus-visible:border-emerald-500`}
          >
            {COUNTRY_OPTIONS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="space-y-1.5">
            <Label htmlFor="signup-password" className="text-sm font-medium">{t('signup.passwordLabel')}</Label>
            <div className="relative">
              <Input
                id="signup-password"
                type={showPassword ? 'text' : 'password'}
                placeholder={t('signup.passwordPlaceholder')}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="new-password"
                className={inputCls + ' pr-10'}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-0.5"
                tabIndex={-1}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="signup-confirm" className="text-sm font-medium">{t('signup.confirmPasswordLabel')}</Label>
            <div className="relative">
              <Input
                id="signup-confirm"
                type={showConfirm ? 'text' : 'password'}
                placeholder={t('signup.confirmPasswordPlaceholder')}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                autoComplete="new-password"
                className={inputCls + ' pr-10'}
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-0.5"
                tabIndex={-1}
                aria-label={showConfirm ? 'Hide password' : 'Show password'}
              >
                {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>

        <Button
          type="submit"
          className="w-full h-12 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-[15px] transition-all duration-200 shadow-sm hover:shadow-md active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 disabled:opacity-60 disabled:pointer-events-none"
          disabled={busy}
        >
          {busy ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              {t('signup.creating')}
            </>
          ) : (
            t('signup.createAccount')
          )}
        </Button>
      </form>

      <div className="text-center text-sm text-muted-foreground">
        {t('signup.haveAccount')}{' '}
        <button
          type="button"
          onClick={() => onNavigate('login')}
          className="font-medium text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors"
        >
          {t('signup.signIn')}
        </button>
      </div>
    </div>
  );
}

/* ── Forgot Password View ──────────────────────────────── */
function ForgotPasswordView({
  t,
  onNavigate,
  onForgotSendCode,
  onForgotReset,
  loading,
  codeSent,
  setCodeSent,
}: {
  t: (key: string) => string;
  onNavigate: (v: ViewMode) => void;
  onForgotSendCode: (email: string) => void;
  onForgotReset: (email: string, code: string, password: string) => void;
  loading: boolean;
  codeSent: boolean;
  setCodeSent: (v: boolean) => void;
}) {
  const [isPending, startTransition] = useTransition();
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const busy = loading || isPending;

  const handleSendCode = (e: FormEvent) => {
    e.preventDefault();
    if (!email) return;
    startTransition(() => onForgotSendCode(email));
  };

  const handleResendCode = () => {
    if (!email) return;
    startTransition(() => onForgotSendCode(email));
  };

  const handleReset = (e: FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      toast.error(t('forgot.passwordTooShort'));
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error(t('forgot.passwordMismatch'));
      return;
    }
    startTransition(() => onForgotReset(email, code, newPassword));
  };

  const inputCls = 'h-11 rounded-lg border-input bg-background text-sm transition-all duration-200 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/20 focus-visible:border-emerald-500';

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <button
          type="button"
          onClick={() => { onNavigate('login'); setCodeSent(false); }}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-2 min-h-[44px]"
        >
          <ArrowLeft className="h-4 w-4" />
          {t('common.back')}
        </button>
        <h2 className="text-2xl font-bold tracking-tight">{t('forgot.title')}</h2>
        <p className="text-sm text-muted-foreground">
          {codeSent ? t('forgot.enterCode') : t('forgot.subtitle')}
        </p>
      </div>

      {!codeSent ? (
        <form onSubmit={handleSendCode} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="forgot-email" className="text-sm font-medium">{t('forgot.emailLabel')}</Label>
            <Input
              id="forgot-email"
              type="email"
              placeholder={t('forgot.emailPlaceholder')}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              className={inputCls}
            />
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-[15px] transition-all duration-200 shadow-sm hover:shadow-md active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 disabled:opacity-60 disabled:pointer-events-none"
            disabled={busy}
          >
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                {t('forgot.sending')}
              </>
            ) : (
              t('forgot.sendCode')
            )}
          </Button>
        </form>
      ) : (
        <form onSubmit={handleReset} className="space-y-3.5">
          <div className="rounded-lg border border-emerald-500/20 bg-emerald-50 dark:bg-emerald-900/20 p-3 text-sm flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
            <ShieldCheck className="h-4 w-4 flex-shrink-0" />
            <span>{t('forgot.codeSent')}</span>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="forgot-code" className="text-sm font-medium">{t('forgot.codeLabel')}</Label>
            <Input
              id="forgot-code"
              placeholder={t('forgot.codePlaceholder')}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
              maxLength={6}
              className={inputCls + ' font-mono tracking-widest text-center'}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="forgot-new-pw" className="text-sm font-medium">{t('forgot.newPasswordLabel')}</Label>
            <div className="relative">
              <Input
                id="forgot-new-pw"
                type={showPassword ? 'text' : 'password'}
                placeholder={t('forgot.newPasswordPlaceholder')}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                autoComplete="new-password"
                className={inputCls + ' pr-10'}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-0.5"
                tabIndex={-1}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="forgot-confirm-pw" className="text-sm font-medium">{t('forgot.confirmPasswordLabel')}</Label>
            <div className="relative">
              <Input
                id="forgot-confirm-pw"
                type={showConfirm ? 'text' : 'password'}
                placeholder={t('forgot.confirmPasswordPlaceholder')}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                autoComplete="new-password"
                className={inputCls + ' pr-10'}
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-0.5"
                tabIndex={-1}
                aria-label={showConfirm ? 'Hide password' : 'Show password'}
              >
                {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-[15px] transition-all duration-200 shadow-sm hover:shadow-md active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 disabled:opacity-60 disabled:pointer-events-none"
            disabled={busy}
          >
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                {t('forgot.resetting')}
              </>
            ) : (
              t('forgot.resetPassword')
            )}
          </Button>

          <Button
            type="button"
            variant="ghost"
            className="w-full h-10 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/80 transition-all duration-200 active:scale-[0.98]"
            disabled={busy}
            onClick={handleResendCode}
          >
            {t('forgot.resendCode')}
          </Button>
        </form>
      )}
    </div>
  );
}

/* ── Main Login Screen ─────────────────────────────────── */
export default function LoginScreen() {
  const t = useT();
  const { locale, setLocale } = useI18n();
  const { setUser, setToken } = useAppStore();

  const [view, setView] = useState<ViewMode>('login');
  const [direction, setDirection] = useState(0);
  const [loading, setLoading] = useState(false);
  const [forgotCodeSent, setForgotCodeSent] = useState(false);

  const navigate = useCallback((to: ViewMode) => {
    const order: ViewMode[] = ['login', 'signup', 'forgot'];
    const fromIdx = order.indexOf(view);
    const toIdx = order.indexOf(to);
    setDirection(toIdx > fromIdx ? 1 : -1);
    setView(to);
    if (to !== 'forgot') setForgotCodeSent(false);
  }, [view]);

  /* ── Login handler ──────────────────── */
  const handleLogin = useCallback(async (email: string, password: string) => {
    if (!email || !password) return;
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        const errorMap: Record<number, string> = {
          400: t('login.invalidCredentials'),
          401: t('login.invalidCredentials'),
          403: data.error?.includes('blocked')
            ? t('login.accountBlocked')
            : data.error?.includes('pending')
              ? t('login.accountPending')
              : t('login.accountUnavailable'),
          500: t('login.loginFailed'),
        };
        toast.error(errorMap[res.status] || data.error || t('login.loginFailed'));
        return;
      }

      if (data.success && data.user) {
        toast.success(`Welcome back, ${data.user.name}!`);
        if (data.token) setToken(data.token);
        setUser(data.user as UserInfo);
      }
    } catch {
      toast.error(t('login.loginFailed'));
    } finally {
      setLoading(false);
    }
  }, [t, setUser, setToken]);

  /* ── Register handler ───────────────── */
  const handleRegister = useCallback(async (payload: {
    name: string; username: string; email: string; phone: string; country: string; password: string;
  }) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'Registration failed');
        return;
      }

      toast.success(t('signup.registrationSuccess'));
      navigate('login');
    } catch {
      toast.error('Registration failed');
    } finally {
      setLoading(false);
    }
  }, [t, navigate]);

  /* ── Forgot send code handler ───────── */
  const handleForgotSendCode = useCallback(async (email: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'Failed to send code');
        return;
      }

      setForgotCodeSent(true);
      if (data.code) {
        toast.info(`Demo reset code: ${data.code}`);
      } else {
        toast.success(t('forgot.codeSent'));
      }
    } catch {
      toast.error('Failed to send code');
    } finally {
      setLoading(false);
    }
  }, [t]);

  /* ── Forgot reset handler ──────────── */
  const handleForgotReset = useCallback(async (email: string, code: string, password: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'Password reset failed');
        return;
      }

      toast.success(t('forgot.resetSuccess'));
      navigate('login');
    } catch {
      toast.error('Password reset failed');
    } finally {
      setLoading(false);
    }
  }, [t, navigate]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* ── Header ──────────────────── */}
      <header className="w-full bg-white dark:bg-card border-b flex items-center justify-between px-4 md:px-6 h-14 flex-shrink-0">
        {/* Left: Logo */}
        <div className="flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-xl bg-emerald-600 flex items-center justify-center shadow-sm">
            <Globe className="h-5 w-5 text-white" />
          </div>
          <div className="hidden xs:flex flex-col">
            <span className="text-base font-bold tracking-tight text-foreground leading-tight">FinFlow</span>
            <span className="text-[10px] text-muted-foreground -mt-0.5">Enterprise</span>
          </div>
        </div>

        {/* Center: Live Clock */}
        <div className="hidden md:flex">
          <LiveClock />
        </div>

        {/* Right: Language Toggle */}
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex">
            <LiveClock />
          </div>
          <button
            type="button"
            onClick={() => setLocale(locale === 'en' ? 'am' : 'en')}
            className="flex items-center gap-1.5 text-xs font-medium h-9 px-2.5 rounded-lg border border-border hover:bg-muted/50 transition-colors"
          >
            🌐 {locale === 'en' ? '🇪🇹 አማርኛ' : '🇺🇸 English'}
          </button>
        </div>
      </header>

      {/* ── Body ────────────────────── */}
      <div className="flex flex-1 min-h-0">
        {/* Left branding panel (desktop) */}
        <BrandingPanel t={t} />

        {/* Right form panel */}
        <div className="flex-1 flex items-center justify-center p-4 sm:p-6 md:p-8">
          <motion.div
            className="w-full max-w-md"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          >
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={view}
                custom={direction}
                variants={slideVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeInOut' }}
              >
                {view === 'login' && (
                  <LoginView
                    t={t}
                    onNavigate={navigate}
                    onLogin={handleLogin}
                    loading={loading}
                  />
                )}
                {view === 'signup' && (
                  <SignUpView
                    t={t}
                    onNavigate={navigate}
                    onRegister={handleRegister}
                    loading={loading}
                  />
                )}
                {view === 'forgot' && (
                  <ForgotPasswordView
                    t={t}
                    onNavigate={navigate}
                    onForgotSendCode={handleForgotSendCode}
                    onForgotReset={handleForgotReset}
                    loading={loading}
                    codeSent={forgotCodeSent}
                    setCodeSent={setForgotCodeSent}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      {/* ── Footer ──────────────────── */}
      <footer className="w-full border-t bg-white dark:bg-card px-4 md:px-6 py-3 flex-shrink-0 mt-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-1 text-[11px] text-muted-foreground/50">
          <span>{t('login.copyright', { year: String(new Date().getFullYear()) })}</span>
          <span>{t('footer.regulated')}</span>
        </div>
      </footer>
    </div>
  );
}
