'use client';

import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { toast } from 'sonner';
import {
  Building2,
  Smartphone,
  Globe,
  CreditCard,
  Wallet,
  QrCode,
  Plus,
  ShieldCheck,
  Star,
  Trash2,
  CheckCircle2,
  ArrowRightLeft,
  Clock,
  Banknote,
  Loader2,
  User,
  Landmark,
  Send,
  BanknoteArrowUp,
  CircleDollarSign,
  ChevronDown,
  Settings,
  Eye,
  Link2,
  Unlink,
  Zap,
  Search,
  Filter,
  X,
  ToggleLeft,
  Check,
  Info,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useT } from '@/lib/i18n';
import { apiFetch } from '@/lib/api-fetch';

// --- Types ---

interface MasterBank {
  id: string;
  bankName: string;
  shortName: string;
  bankCode: string;
  swiftCode: string | null;
  status: string;
  supportsIfb: boolean;
  supportsFx: boolean;
  supportsTransfer: boolean;
  bankType: string;
  foundedYear: number | null;
  headOffice: string | null;
  _count: { bankAccounts: number };
}

interface BankAccount {
  id: string;
  userId: string;
  bankName: string;
  masterBankId: string | null;
  accountNumber: string;
  accountName: string;
  accountType: string;
  branch: string | null;
  swiftCode: string | null;
  currency: string;
  isVerified: boolean;
  isDefault: boolean;
  status: string;
  createdAt: string;
  updatedAt: string;
  user: { id: string; name: string; email: string };
  masterBank: {
    id: string;
    shortName: string;
    bankCode: string;
    swiftCode: string | null;
    bankType: string;
    supportsIfb: boolean;
    supportsFx: boolean;
    supportsTransfer: boolean;
  } | null;
}

interface UserItem {
  id: string;
  name: string;
  email: string;
}

// --- Color utilities ---

const BANK_COLORS = [
  'bg-emerald-600', 'bg-teal-600', 'bg-amber-600', 'bg-rose-600',
  'bg-cyan-600', 'bg-orange-600', 'bg-lime-600', 'bg-pink-600',
  'bg-violet-600', 'bg-fuchsia-600', 'bg-sky-600', 'bg-red-600',
];

const BORDER_COLORS = [
  'border-l-emerald-500', 'border-l-teal-500', 'border-l-amber-500', 'border-l-rose-500',
  'border-l-cyan-500', 'border-l-orange-500', 'border-l-lime-500', 'border-l-pink-500',
  'border-l-violet-500', 'border-l-fuchsia-500', 'border-l-sky-500', 'border-l-red-500',
];

function getBankColor(index: number) {
  return BANK_COLORS[index % BANK_COLORS.length];
}

function getBankBorder(index: number) {
  return BORDER_COLORS[index % BORDER_COLORS.length];
}

// --- Constants ---

const MOBILE_PROVIDERS = [
  { id: 'telebirr', name: 'Telebirr', icon: '📱', color: 'from-teal-500 to-emerald-500' },
  { id: 'mpesa', name: 'M-PESA', icon: '📲', color: 'from-emerald-500 to-teal-500' },
  { id: 'hellocash', name: 'HelloCash', icon: '💰', color: 'from-amber-500 to-orange-500' },
];

const INTL_PROVIDERS = [
  { id: 'swift', name: 'SWIFT Transfer', icon: Send, color: 'from-teal-500 to-cyan-500' },
  { id: 'moneygram', name: 'MoneyGram', icon: BanknoteArrowUp, color: 'from-amber-500 to-orange-500' },
  { id: 'western_union', name: 'Western Union', icon: CircleDollarSign, color: 'from-rose-500 to-pink-500' },
  { id: 'binance', name: 'Binance', icon: Globe, color: 'from-yellow-500 to-amber-500' },
];

const PAYMENT_METHODS = [
  { key: 'paymentBankAccount', icon: Landmark, gradient: 'from-emerald-500 to-teal-500', active: true },
  { key: 'paymentDebitCard', icon: CreditCard, gradient: 'from-teal-500 to-cyan-500', active: true },
  { key: 'paymentMobileMoney', icon: Smartphone, gradient: 'from-emerald-500 to-green-500', active: true },
  { key: 'paymentQRCode', icon: QrCode, gradient: 'from-violet-500 to-purple-500', active: false, comingSoon: true },
  { key: 'paymentDigitalWallet', icon: Wallet, gradient: 'from-amber-500 to-orange-500', active: true },
  { key: 'paymentIntlTransfer', icon: ArrowRightLeft, gradient: 'from-rose-500 to-pink-500', active: true },
];

// --- Main Component ---

export default function BankingView() {
  const t = useT();
  const tableRef = useRef<HTMLDivElement>(null);

  // Data
  const [masterBanks, setMasterBanks] = useState<MasterBank[]>([]);
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Mobile money status
  const [mobileStatus, setMobileStatus] = useState<Record<string, 'connected' | 'disconnected' | 'pending'>>({
    telebirr: 'connected',
    mpesa: 'connected',
    hellocash: 'pending',
  });

  // Payment method status
  const [paymentStatus, setPaymentStatus] = useState<Record<string, boolean>>(() => {
    const s: Record<string, boolean> = {};
    PAYMENT_METHODS.forEach((m) => { if (!m.comingSoon) s[m.key] = m.active; });
    return s;
  });

  // Tabs
  const [activeTab, setActiveTab] = useState('banks');

  // Filters
  const [bankSearch, setBankSearch] = useState('');
  const [bankFilter, setBankFilter] = useState('all');
  const [accountSearch, setAccountSearch] = useState('');
  const [accountBankFilter, setAccountBankFilter] = useState('all');

  // Link account dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formUserId, setFormUserId] = useState('');
  const [formBankId, setFormBankId] = useState('');
  const [formBankName, setFormBankName] = useState('');
  const [formSwiftCode, setFormSwiftCode] = useState('');
  const [formAccountNumber, setFormAccountNumber] = useState('');
  const [formAccountName, setFormAccountName] = useState('');
  const [formAccountType, setFormAccountType] = useState('');
  const [formBranch, setFormBranch] = useState('');
  const [formCurrency, setFormCurrency] = useState('ETB');

  // Mobile connect dialog
  const [mobileDialogOpen, setMobileDialogOpen] = useState(false);
  const [mobileProvider, setMobileProvider] = useState('');
  const [mobilePhone, setMobilePhone] = useState('');
  const [mobileSubmitting, setMobileSubmitting] = useState(false);

  // International transfer dialog
  const [intlDialogOpen, setIntlDialogOpen] = useState(false);
  const [intlProvider, setIntlProvider] = useState('');
  const [intlAmount, setIntlAmount] = useState('');
  const [intlRecipientName, setIntlRecipientName] = useState('');
  const [intlRecipientCountry, setIntlRecipientCountry] = useState('');
  const [intlRecipientAccount, setIntlRecipientAccount] = useState('');
  const [intlPurpose, setIntlPurpose] = useState('');
  const [intlSubmitting, setIntlSubmitting] = useState(false);

  // Remove dialog
  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);
  const [removingAccount, setRemovingAccount] = useState<BankAccount | null>(null);
  const [removing, setRemoving] = useState(false);

  // Bank details dialog
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [detailsBank, setDetailsBank] = useState<MasterBank | null>(null);

  // Action loading
  const [actionLoading, setActionLoading] = useState<Record<string, string | null>>({});

  // --- Data fetching ---

  const fetchMasterBanks = useCallback(async () => {
    try {
      const res = await apiFetch('/api/master-banks');
      if (!res.ok) throw new Error();
      const data = await res.json();
      setMasterBanks(data);
    } catch {
      // Silent - fallback to empty
    }
  }, []);

  const fetchAccounts = useCallback(async () => {
    try {
      const res = await apiFetch('/api/bank-accounts');
      if (!res.ok) throw new Error();
      const data = await res.json();
      setAccounts(data);
    } catch {
      toast.error(t('banking.failedLoadAccounts'));
    } finally {
      setLoading(false);
    }
  }, [t]);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await apiFetch('/api/users?limit=100');
      if (!res.ok) throw new Error();
      const data = await res.json();
      setUsers(data.users || []);
    } catch {
      toast.error(t('banking.failedLoadUsers'));
    }
  }, [t]);

  useEffect(() => {
    fetchMasterBanks();
    fetchAccounts();
    fetchUsers();
  }, [fetchMasterBanks, fetchAccounts, fetchUsers]);

  // --- Computed data ---

  const bankIndex = useMemo(() => {
    const idx: Record<string, number> = {};
    masterBanks.forEach((b, i) => { idx[b.id] = i; });
    return idx;
  }, [masterBanks]);

  const bankAccountsMap = useMemo(() => {
    const map: Record<string, number> = {};
    accounts.filter((a) => a.status === 'active').forEach((a) => {
      const key = a.masterBankId || a.bankName;
      map[key] = (map[key] || 0) + 1;
    });
    return map;
  }, [accounts]);

  const filteredBanks = useMemo(() => {
    let banks = masterBanks;
    if (bankFilter === 'govt') banks = banks.filter((b) => b.bankType === 'government');
    else if (bankFilter === 'private') banks = banks.filter((b) => b.bankType === 'private');
    else if (bankFilter === 'ifb') banks = banks.filter((b) => b.supportsIfb);
    else if (bankFilter === 'fx') banks = banks.filter((b) => b.supportsFx);
    else if (bankFilter === 'transfer') banks = banks.filter((b) => b.supportsTransfer);
    if (bankSearch.trim()) {
      const q = bankSearch.toLowerCase();
      banks = banks.filter((b) =>
        b.bankName.toLowerCase().includes(q) ||
        b.shortName.toLowerCase().includes(q) ||
        b.bankCode.toLowerCase().includes(q)
      );
    }
    return banks;
  }, [masterBanks, bankFilter, bankSearch]);

  const activeAccountCount = accounts.filter((a) => a.status === 'active').length;
  const verifiedCount = accounts.filter((a) => a.isVerified).length;
  const inactiveCount = accounts.filter((a) => a.status === 'inactive').length;

  const filteredAccounts = useMemo(() => {
    let accs = accounts;
    if (accountBankFilter !== 'all') {
      accs = accs.filter((a) => a.bankName === accountBankFilter);
    }
    if (accountSearch.trim()) {
      const q = accountSearch.toLowerCase();
      accs = accs.filter((a) =>
        a.bankName.toLowerCase().includes(q) ||
        a.accountName.toLowerCase().includes(q) ||
        a.accountNumber.includes(q)
      );
    }
    return accs;
  }, [accounts, accountBankFilter, accountSearch]);

  const uniqueBankNames = useMemo(() => {
    const names = new Set(accounts.map((a) => a.bankName));
    return Array.from(names).sort();
  }, [accounts]);

  const intlFee = useMemo(() => {
    const amt = parseFloat(intlAmount) || 0;
    return Math.max(amt * 0.001, 200);
  }, [intlAmount]);

  // --- Handlers ---

  const resetForm = () => {
    setFormUserId('');
    setFormBankId('');
    setFormBankName('');
    setFormSwiftCode('');
    setFormAccountNumber('');
    setFormAccountName('');
    setFormAccountType('');
    setFormBranch('');
    setFormCurrency('ETB');
  };

  const handleBankSelect = (bankId: string) => {
    setFormBankId(bankId);
    const bank = masterBanks.find((b) => b.id === bankId);
    if (bank) {
      setFormBankName(bank.bankName);
      if (bank.swiftCode) setFormSwiftCode(bank.swiftCode);
    }
  };

  const handleCreateAccount = async () => {
    if (!formUserId || !formBankName || !formAccountNumber || !formAccountName || !formAccountType) {
      toast.error(t('banking.fillRequiredFields'));
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiFetch('/api/bank-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: formUserId,
          bankName: formBankName,
          accountNumber: formAccountNumber,
          accountName: formAccountName,
          accountType: formAccountType,
          branch: formBranch || null,
          swiftCode: formSwiftCode || null,
          currency: formCurrency || 'ETB',
        }),
      });
      if (!res.ok) throw new Error();
      toast.success(t('banking.accountLinked'));
      setDialogOpen(false);
      resetForm();
      fetchAccounts();
    } catch {
      toast.error(t('banking.failedLinkAccount'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerify = async (acc: BankAccount) => {
    setActionLoading((p) => ({ ...p, [acc.id]: 'verify' }));
    try {
      const res = await apiFetch('/api/bank-accounts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: acc.id, isVerified: true }),
      });
      if (!res.ok) throw new Error();
      toast.success(`${acc.bankName} ${t('banking.accountVerified')}`);
      fetchAccounts();
    } catch {
      toast.error(t('banking.failedVerifyAccount'));
    } finally {
      setActionLoading((p) => ({ ...p, [acc.id]: null }));
    }
  };

  const handleSetDefault = async (acc: BankAccount) => {
    setActionLoading((p) => ({ ...p, [acc.id]: 'default' }));
    try {
      const res = await apiFetch('/api/bank-accounts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: acc.id, isDefault: true }),
      });
      if (!res.ok) throw new Error();
      toast.success(`${acc.bankName} ${t('banking.setAsDefault')}`);
      fetchAccounts();
    } catch {
      toast.error(t('banking.failedSetDefaultAccount'));
    } finally {
      setActionLoading((p) => ({ ...p, [acc.id]: null }));
    }
  };

  const openRemoveDialog = (acc: BankAccount) => {
    setRemovingAccount(acc);
    setRemoveDialogOpen(true);
  };

  const handleRemove = async () => {
    if (!removingAccount) return;
    setRemoving(true);
    try {
      const res = await apiFetch('/api/bank-accounts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: removingAccount.id, status: 'inactive' }),
      });
      if (!res.ok) throw new Error();
      toast.success(`${removingAccount.bankName} ${t('banking.accountRemoved')}`);
      setRemoveDialogOpen(false);
      setRemovingAccount(null);
      fetchAccounts();
    } catch {
      toast.error(t('banking.failedRemoveAccount'));
    } finally {
      setRemoving(false);
    }
  };

  const handleMobileToggle = (providerId: string) => {
    setMobileStatus((prev) => {
      const curr = prev[providerId];
      if (curr === 'connected') return { ...prev, [providerId]: 'disconnected' };
      if (curr === 'disconnected') return { ...prev, [providerId]: 'connected' };
      return { ...prev, [providerId]: 'connected' };
    });
  };

  const handleMobileConnect = async () => {
    if (!mobilePhone || mobilePhone.length < 10) {
      toast.error(t('banking.enterPhone'));
      return;
    }
    setMobileSubmitting(true);
    // Simulate connection
    await new Promise((r) => setTimeout(r, 1000));
    setMobileStatus((prev) => ({ ...prev, [mobileProvider]: 'connected' }));
    toast.success(`${MOBILE_PROVIDERS.find((p) => p.id === mobileProvider)?.name} ${t('banking.connected')}`);
    setMobileDialogOpen(false);
    setMobilePhone('');
    setMobileSubmitting(false);
  };

  const handleIntlSubmit = async () => {
    if (!intlProvider || !intlAmount || parseFloat(intlAmount) <= 0 || !intlRecipientName || !intlRecipientCountry) {
      toast.error(t('banking.fillRequiredFields'));
      return;
    }
    setIntlSubmitting(true);
    try {
      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'international_transfer',
          amount: parseFloat(intlAmount),
          currency: 'ETB',
          fee: intlFee,
          description: `${intlProvider} transfer to ${intlRecipientName}`,
          recipientName: intlRecipientName,
          metadata: JSON.stringify({
            provider: intlProvider,
            recipientCountry: intlRecipientCountry,
            recipientAccount: intlRecipientAccount,
            purpose: intlPurpose,
          }),
        }),
      });
      if (!res.ok) throw new Error();
      toast.success(t('banking.intlSubmitted'));
      setIntlDialogOpen(false);
      resetIntlForm();
    } catch {
      toast.error(t('banking.intlFailed'));
    } finally {
      setIntlSubmitting(false);
    }
  };

  const resetIntlForm = () => {
    setIntlProvider('');
    setIntlAmount('');
    setIntlRecipientName('');
    setIntlRecipientCountry('');
    setIntlRecipientAccount('');
    setIntlPurpose('');
  };

  const maskAccountNumber = (num: string) => {
    if (num.length <= 4) return num;
    return '*'.repeat(num.length - 4) + num.slice(-4);
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'inactive': return 'bg-gray-100 text-gray-600 border-gray-200';
      case 'suspended': return 'bg-rose-50 text-rose-700 border-rose-200';
      default: return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  const scrollToTable = () => {
    setActiveTab('banks');
    setTimeout(() => { tableRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 100);
  };

  const openLinkDialogForBank = (bank: MasterBank) => {
    setFormBankId(bank.id);
    setFormBankName(bank.bankName);
    if (bank.swiftCode) setFormSwiftCode(bank.swiftCode);
    setDialogOpen(true);
    fetchUsers();
  };

  const openBankDetails = (bank: MasterBank) => {
    setDetailsBank(bank);
    setDetailsDialogOpen(true);
  };

  // --- Render ---

  return (
    <div className="space-y-6">
      {/* ===== Page Header ===== */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-900">{t('banking.title')}</h2>
          <p className="text-sm text-gray-500 mt-1">{t('banking.pageDesc')}</p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm" onClick={() => { fetchUsers(); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />{t('banking.linkNew')}
        </Button>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (open) fetchUsers(); if (!open) resetForm(); }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader className="border-b pb-4">
              <DialogTitle className="text-lg">{t('banking.linkBankAccountTitle')}</DialogTitle>
              <DialogDescription>{t('banking.linkBankAccountDesc')}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('common.user')} <span className="text-rose-500">*</span></Label>
                <Select value={formUserId} onValueChange={setFormUserId}>
                  <SelectTrigger className="border-gray-300"><SelectValue placeholder={t('banking.selectUser')} /></SelectTrigger>
                  <SelectContent>
                    {users.map((u) => (<SelectItem key={u.id} value={u.id}>{u.name} ({u.email})</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('banking.bankName')} <span className="text-rose-500">*</span></Label>
                {masterBanks.length > 0 ? (
                  <Select value={formBankId} onValueChange={handleBankSelect}>
                    <SelectTrigger className="border-gray-300"><SelectValue placeholder={t('banking.selectBank')} /></SelectTrigger>
                    <SelectContent className="max-h-60">
                      {masterBanks.filter((b) => b.status === 'active').map((b) => (
                        <SelectItem key={b.id} value={b.id}>{b.bankName} ({b.shortName})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input value={formBankName} onChange={(e) => setFormBankName(e.target.value)} placeholder={t('banking.selectBank')} />
                )}
              </div>
              {formSwiftCode && (
                <p className="text-xs text-gray-400 flex items-center gap-1"><Info className="h-3 w-3" />{t('banking.autoPopulated')}</p>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-1.5">
                  <Label className="text-sm font-medium">{t('banking.accountNumber')} <span className="text-rose-500">*</span></Label>
                  <Input value={formAccountNumber} onChange={(e) => setFormAccountNumber(e.target.value)} placeholder={t('banking.accountNumberPlaceholder')} className="border-gray-300" />
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-sm font-medium">{t('banking.accountType')} <span className="text-rose-500">*</span></Label>
                  <Select value={formAccountType} onValueChange={setFormAccountType}>
                    <SelectTrigger className="border-gray-300"><SelectValue placeholder={t('banking.selectAccountType')} /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="savings">{t('banking.savings')}</SelectItem>
                      <SelectItem value="checking">{t('banking.checking')}</SelectItem>
                      <SelectItem value="current">{t('banking.current')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('banking.accountName')} <span className="text-rose-500">*</span></Label>
                <Input value={formAccountName} onChange={(e) => setFormAccountName(e.target.value)} placeholder={t('banking.accountNamePlaceholder')} className="border-gray-300" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-1.5">
                  <Label className="text-sm font-medium">{t('banking.branch')}</Label>
                  <Input value={formBranch} onChange={(e) => setFormBranch(e.target.value)} placeholder={t('banking.branchPlaceholder')} className="border-gray-300" />
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-sm font-medium">{t('banking.swiftCode')}</Label>
                  <Input value={formSwiftCode} onChange={(e) => setFormSwiftCode(e.target.value)} placeholder={t('banking.swiftPlaceholder')} className="border-gray-300" />
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('common.currency')}</Label>
                <Select value={formCurrency} onValueChange={setFormCurrency}>
                  <SelectTrigger className="border-gray-300"><SelectValue placeholder={t('banking.selectCurrency')} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ETB">ETB</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter className="border-t pt-4">
              <Button variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>{t('common.cancel')}</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleCreateAccount} disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{submitting ? t('banking.linking') : t('banking.linkAccount')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* ===== Stats Cards ===== */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-lg border border-gray-200 bg-white border-l-4 border-l-emerald-500 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700">{t('banking.activeAccounts')}</p>
          <p className="text-3xl font-bold mt-1 text-gray-900">{activeAccountCount}</p>
          <p className="text-xs text-gray-500 mt-1">{t('banking.activeAccountsDesc')}</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white border-l-4 border-l-teal-500 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-teal-700">{t('banking.verifiedAccounts')}</p>
          <p className="text-3xl font-bold mt-1 text-gray-900">{verifiedCount}</p>
          <p className="text-xs text-gray-500 mt-1">{t('banking.verifiedAccountsDesc')}</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white border-l-4 border-l-rose-500 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-rose-700">{t('banking.inactiveRemoved')}</p>
          <p className="text-3xl font-bold mt-1 text-gray-900">{inactiveCount}</p>
          <p className="text-xs text-gray-500 mt-1">{t('banking.inactiveRemovedDesc')}</p>
        </div>
      </div>

      {/* ===== Tabs ===== */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0 h-auto gap-0 overflow-x-auto">
          <TabsTrigger value="banks" className="rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5 text-sm font-medium text-gray-500 data-[state=active]:text-emerald-700 transition-colors">
            <Building2 className="h-4 w-4 mr-2" />{t('banking.banksAndAccounts')}
          </TabsTrigger>
          <TabsTrigger value="mobile" className="rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5 text-sm font-medium text-gray-500 data-[state=active]:text-emerald-700 transition-colors">
            <Smartphone className="h-4 w-4 mr-2" />{t('banking.mobileMoney')}
          </TabsTrigger>
          <TabsTrigger value="international" className="rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5 text-sm font-medium text-gray-500 data-[state=active]:text-emerald-700 transition-colors">
            <Globe className="h-4 w-4 mr-2" />{t('banking.internationalTab')}
          </TabsTrigger>
          <TabsTrigger value="payment" className="rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5 text-sm font-medium text-gray-500 data-[state=active]:text-emerald-700 transition-colors">
            <CreditCard className="h-4 w-4 mr-2" />{t('banking.paymentMethods')}
          </TabsTrigger>
        </TabsList>

        {/* ===== Tab 1: Banks & Accounts ===== */}
        <TabsContent value="banks" className="mt-6 space-y-6">
          {/* Ethiopian Banks Section */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-semibold text-gray-900">{t('banking.ethiopianBanks')}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{masterBanks.length} {t('banking.banksAvailable')}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                  <Input
                    value={bankSearch}
                    onChange={(e) => setBankSearch(e.target.value)}
                    placeholder={t('banking.masterBankSearch')}
                    className="pl-8 h-8 text-xs w-48 border-gray-300"
                  />
                  {bankSearch && (
                    <button onClick={() => setBankSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2">
                      <X className="h-3 w-3 text-gray-400 hover:text-gray-600" />
                    </button>
                  )}
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8 text-xs border-gray-300">
                      <Filter className="h-3 w-3 mr-1" />
                      {bankFilter === 'all' ? t('banking.filterAll') : bankFilter === 'govt' ? t('banking.filterGovt') : bankFilter === 'private' ? t('banking.filterPrivate') : bankFilter === 'ifb' ? t('banking.filterIfb') : bankFilter === 'fx' ? t('banking.filterFx') : t('banking.filterTransfer')}
                      <ChevronDown className="h-3 w-3 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-44">
                    <DropdownMenuItem onClick={() => setBankFilter('all')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'all' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterAll')}</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setBankFilter('govt')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'govt' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterGovt')}</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setBankFilter('private')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'private' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterPrivate')}</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setBankFilter('ifb')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'ifb' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterIfb')}</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setBankFilter('fx')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'fx' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterFx')}</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setBankFilter('transfer')}><Check className={`h-3.5 w-3.5 mr-2 ${bankFilter === 'transfer' ? 'text-emerald-600' : 'invisible'}`} />{t('banking.filterTransfer')}</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="rounded-lg border border-gray-200 bg-white p-4"><Skeleton className="h-10 w-10 rounded-lg mb-3" /><Skeleton className="h-4 w-32 mb-2" /><Skeleton className="h-3 w-20" /></div>
                ))}
              </div>
            ) : filteredBanks.length === 0 ? (
              <div className="rounded-lg border border-gray-200 bg-white p-12 text-center">
                <Landmark className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-500">{t('banking.noBankMatch')}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {filteredBanks.map((bank, idx) => {
                  const count = bankAccountsMap[bank.id] || 0;
                  const colorIdx = bankIndex[bank.id] ?? idx;
                  const hasAccounts = count > 0;

                  return (
                    <div key={bank.id} className={`rounded-lg border border-gray-200 bg-white border-l-4 ${getBankBorder(colorIdx)} p-4 hover:shadow-md transition-all group`}>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`${getBankColor(colorIdx)} text-white h-10 w-10 rounded-lg flex items-center justify-center font-bold text-sm shrink-0`}>
                            {bank.shortName.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-gray-900 truncate" title={bank.bankName}>{bank.bankName}</p>
                            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                              {bank.supportsIfb && <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-50 text-cyan-700 font-medium">IFB</span>}
                              {bank.supportsFx && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 font-medium">FX</span>}
                              {hasAccounts ? (
                                <span className="text-xs text-emerald-600 font-medium">{count} {t('banking.accountsCount')}</span>
                              ) : (
                                <span className="text-xs text-gray-400">{t('banking.noAccountsLinked')}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity">
                              <ChevronDown className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-52">
                            <DropdownMenuLabel className="text-xs font-semibold">{bank.bankName}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openBankDetails(bank)}>
                              <Eye className="h-4 w-4 mr-2 text-gray-500" />{t('banking.viewBankDetails')}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openLinkDialogForBank(bank)}>
                              <Link2 className="h-4 w-4 mr-2 text-emerald-600" />{t('banking.linkToThisBank')}
                            </DropdownMenuItem>
                            {hasAccounts && (
                              <DropdownMenuItem onClick={scrollToTable}>
                                <Building2 className="h-4 w-4 mr-2 text-gray-500" />{t('banking.viewAccounts')}
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Linked Bank Accounts Table */}
          <div ref={tableRef}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-semibold text-gray-900">{t('banking.linkedBankAccounts')}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{filteredAccounts.length} {t('banking.recordsShown')}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                  <Input value={accountSearch} onChange={(e) => setAccountSearch(e.target.value)} placeholder={t('banking.searchAccounts')} className="pl-8 h-8 text-xs w-48 border-gray-300" />
                  {accountSearch && (
                    <button onClick={() => setAccountSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2"><X className="h-3 w-3 text-gray-400 hover:text-gray-600" /></button>
                  )}
                </div>
                <Select value={accountBankFilter} onValueChange={setAccountBankFilter}>
                  <SelectTrigger className="h-8 text-xs w-44 border-gray-300"><SelectValue placeholder={t('banking.filterByBank')} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('banking.allBanksFilter')}</SelectItem>
                    {uniqueBankNames.map((name) => (<SelectItem key={name} value={name}>{name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="rounded-lg border border-gray-200 bg-white overflow-hidden">
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 hover:bg-gray-50 border-b border-gray-200">
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-gray-600">{t('common.bank')}</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-gray-600">{t('banking.accountNumber')}</TableHead>
                      <TableHead className="hidden md:table-cell text-xs font-semibold uppercase tracking-wider text-gray-600">{t('banking.accountName')}</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-gray-600">{t('common.status')}</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-gray-600">{t('banking.verifiedColumn')}</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-gray-600 text-right">{t('common.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i} className="border-b border-gray-100">
                          <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-8 ml-auto" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredAccounts.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="py-16">
                          <div className="flex flex-col items-center gap-3">
                            <div className="h-14 w-14 rounded-full bg-gray-100 flex items-center justify-center"><Landmark className="h-7 w-7 text-gray-400" /></div>
                            <div className="text-center">
                              <p className="font-medium text-gray-500">{t('banking.noAccountsFound')}</p>
                              <p className="text-xs text-gray-400 mt-1">{t('banking.noAccountsFoundDesc')}</p>
                            </div>
                            <Button variant="outline" size="sm" className="mt-1" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-2" />{t('banking.linkNew')}</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredAccounts.map((acc) => {
                        const isLoading = actionLoading[acc.id];
                        return (
                          <TableRow key={acc.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${acc.status === 'inactive' ? 'opacity-60' : ''}`}>
                            <TableCell className="font-medium text-gray-900">
                              <div className="flex items-center gap-2">
                                {acc.isDefault && <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />}
                                {acc.bankName}
                                {acc.masterBank && (
                                  <span className="text-[10px] px-1 py-0.5 rounded bg-gray-100 text-gray-500 font-mono">{acc.masterBank.bankCode}</span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="font-mono text-sm text-gray-700">{maskAccountNumber(acc.accountNumber)}</TableCell>
                            <TableCell className="hidden md:table-cell">
                              <div className="flex items-center gap-1.5 text-gray-600"><User className="h-3.5 w-3.5 text-gray-400" />{acc.user?.name || '-'}</div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={`text-xs ${statusColor(acc.status)}`}>{acc.status}</Badge>
                            </TableCell>
                            <TableCell>
                              {acc.isVerified ? (
                                <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 text-xs"><ShieldCheck className="h-3 w-3 mr-1" />{t('common.verified')}</Badge>
                              ) : (
                                <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 text-xs"><Clock className="h-3 w-3 mr-1" />{t('common.pending')}</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" disabled={!!isLoading}>
                                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><span className="text-xs">{t('common.actions')}</span><ChevronDown className="h-3 w-3 ml-1" /></>}
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-48">
                                  {!acc.isVerified && acc.status === 'active' && (
                                    <DropdownMenuItem onClick={() => handleVerify(acc)}><ShieldCheck className="h-4 w-4 mr-2 text-emerald-600" />{t('banking.verify')}</DropdownMenuItem>
                                  )}
                                  {!acc.isDefault && acc.status === 'active' && (
                                    <DropdownMenuItem onClick={() => handleSetDefault(acc)}><Star className="h-4 w-4 mr-2 text-amber-500" />{t('banking.setDefault')}</DropdownMenuItem>
                                  )}
                                  {acc.status === 'active' && (
                                    <><DropdownMenuSeparator /><DropdownMenuItem className="text-rose-600 focus:text-rose-600" onClick={() => openRemoveDialog(acc)}><Trash2 className="h-4 w-4 mr-2" />{t('banking.remove')}</DropdownMenuItem></>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* ===== Tab 2: Mobile Money ===== */}
        <TabsContent value="mobile" className="mt-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-base font-semibold text-gray-900">{t('banking.mobileTitle')}</h3>
              <p className="text-xs text-gray-500 mt-0.5">{t('banking.mobileDesc')}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {MOBILE_PROVIDERS.map((provider) => {
              const status = mobileStatus[provider.id] || 'pending';
              const isConnected = status === 'connected';
              const isPending = status === 'pending';
              return (
                <div key={provider.id} className="rounded-lg border border-gray-200 bg-white p-5 hover:shadow-md transition-all">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${provider.color} text-white flex items-center justify-center text-2xl shrink-0`}>
                        {provider.icon}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{provider.name}</p>
                        <Badge variant="outline" className={`mt-1.5 text-xs ${isConnected ? 'text-emerald-600 border-emerald-200 bg-emerald-50' : isPending ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-gray-600 border-gray-200 bg-gray-50'}`}>
                          {isConnected ? <><CheckCircle2 className="h-3 w-3 mr-1" />{t('banking.mobileConnected')}</> : isPending ? <><Clock className="h-3 w-3 mr-1" />{t('banking.mobilePending')}</> : <><X className="h-3 w-3 mr-1" />{t('banking.mobileDisconnected')}</>}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-gray-400 hover:text-gray-600"><ChevronDown className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuLabel>{provider.name}</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {isConnected ? (
                          <>
                            <DropdownMenuItem onClick={() => { setMobileProvider(provider.id); setMobileDialogOpen(true); }}><Eye className="h-4 w-4 mr-2 text-gray-500" />{t('banking.viewDetails')}</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-rose-600 focus:text-rose-600" onClick={() => handleMobileToggle(provider.id)}><Unlink className="h-4 w-4 mr-2" />{t('banking.disconnectProvider')}</DropdownMenuItem>
                          </>
                        ) : (
                          <DropdownMenuItem onClick={() => { setMobileProvider(provider.id); setMobileDialogOpen(true); }}><Link2 className="h-4 w-4 mr-2 text-emerald-600" />{t('banking.connectProvider')}</DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        {/* ===== Tab 3: International Transfers ===== */}
        <TabsContent value="international" className="mt-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-base font-semibold text-gray-900">{t('banking.intlTitle')}</h3>
              <p className="text-xs text-gray-500 mt-0.5">{t('banking.intlDesc')}</p>
            </div>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm" onClick={() => setIntlDialogOpen(true)}>
              <Send className="h-4 w-4 mr-2" />{t('banking.intlInitiate')}
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {INTL_PROVIDERS.map((provider) => {
              const IconComp = provider.icon;
              return (
                <div key={provider.id} className="rounded-lg border border-gray-200 bg-white p-5 hover:shadow-md transition-all group">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${provider.color} text-white flex items-center justify-center shrink-0`}><IconComp className="h-5 w-5" /></div>
                      <div>
                        <p className="font-semibold text-sm text-gray-900 truncate">{provider.name}</p>
                        <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 text-xs mt-1">{t('status.active')}</Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity"><ChevronDown className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuLabel>{provider.name}</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => { setIntlProvider(provider.id); setIntlDialogOpen(true); }}><Send className="h-4 w-4 mr-2 text-emerald-600" />{t('banking.intlInitiate')}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <div className="space-y-2 text-sm border-t border-gray-100 pt-3">
                    <div className="flex items-center gap-2 text-gray-500"><Banknote className="h-3.5 w-3.5 shrink-0" /><span>{t('common.fee')}: {t('banking.intlFee')}</span></div>
                    <div className="flex items-center gap-2 text-gray-500"><Clock className="h-3.5 w-3.5 shrink-0" /><span>{t('banking.processing')}: {t('banking.intlProcessingTime')}</span></div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 flex items-start gap-2">
            <Info className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
            <p className="text-xs text-amber-700">{t('banking.intlNote')}</p>
          </div>
        </TabsContent>

        {/* ===== Tab 4: Payment Methods ===== */}
        <TabsContent value="payment" className="mt-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-base font-semibold text-gray-900">{t('banking.paymentTitle')}</h3>
              <p className="text-xs text-gray-500 mt-0.5">{t('banking.paymentDesc')}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {PAYMENT_METHODS.map((method) => {
              const IconComp = method.icon;
              const enabled = paymentStatus[method.key] ?? method.active;
              return (
                <div key={method.key} className={`rounded-lg border bg-white p-5 hover:shadow-md transition-all ${method.comingSoon ? 'border-gray-200 opacity-75' : 'border-gray-200'}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${method.gradient} text-white flex items-center justify-center shrink-0`}><IconComp className="h-6 w-6" /></div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-sm text-gray-900">{t(`banking.${method.key}`)}</p>
                          {method.comingSoon ? (
                            <Badge variant="outline" className="text-xs text-amber-600 border-amber-200 bg-amber-50"><Clock className="h-3 w-3 mr-1" />{t('banking.comingSoon')}</Badge>
                          ) : (
                            <Badge variant="outline" className={`text-xs ${enabled ? 'text-emerald-600 border-emerald-200 bg-emerald-50' : 'text-gray-500 border-gray-200 bg-gray-50'}`}>
                              {enabled ? <><CheckCircle2 className="h-3 w-3 mr-1" />{t('banking.paymentEnabled')}</> : <><X className="h-3 w-3 mr-1" />{t('banking.paymentDisabled')}</>}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 mt-1.5 leading-relaxed">{t(`banking.${method.key}Desc`)}</p>
                      </div>
                    </div>
                    {!method.comingSoon && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-gray-400 hover:text-gray-600"><ChevronDown className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuLabel>{t(`banking.${method.key}`)}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => setPaymentStatus((p) => ({ ...p, [method.key]: !p[method.key] }))}>
                            <ToggleLeft className="h-4 w-4 mr-2 text-emerald-600" />{t('banking.paymentToggle')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* ===== Footer ===== */}
      <div className="border-t border-gray-200 pt-6 mt-8 text-center text-xs text-gray-400">
        <p>© 2026 FinFlow Financial Platform. All rights reserved.</p>
        <p className="mt-0.5">Enterprise Edition v1.0</p>
      </div>

      {/* ===== Remove Confirmation Dialog ===== */}
      <AlertDialog open={removeDialogOpen} onOpenChange={setRemoveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('banking.removeAccountTitle')}</AlertDialogTitle>
            <AlertDialogDescription>{t('banking.removeAccountDesc')}{' '}<span className="font-mono font-semibold">{removingAccount?.accountNumber?.slice(-4)}</span>.{t('banking.removeAccountDesc2')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={removing}>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleRemove} disabled={removing} className="bg-rose-600 hover:bg-rose-700 text-white">
              {removing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{t('banking.removeAccountBtn')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Mobile Connect Dialog ===== */}
      <Dialog open={mobileDialogOpen} onOpenChange={setMobileDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader className="border-b pb-4">
            <DialogTitle className="text-lg">{t('banking.connectProvider')}</DialogTitle>
            <DialogDescription>{MOBILE_PROVIDERS.find((p) => p.id === mobileProvider)?.name}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-sm font-medium">{t('banking.phoneNumber')} <span className="text-rose-500">*</span></Label>
              <Input value={mobilePhone} onChange={(e) => setMobilePhone(e.target.value)} placeholder={t('banking.enterPhone')} className="border-gray-300" />
            </div>
          </div>
          <DialogFooter className="border-t pt-4">
            <Button variant="outline" onClick={() => setMobileDialogOpen(false)}>{t('common.cancel')}</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleMobileConnect} disabled={mobileSubmitting}>
              {mobileSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{t('banking.connectProvider')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== International Transfer Dialog ===== */}
      <Dialog open={intlDialogOpen} onOpenChange={(open) => { setIntlDialogOpen(open); if (!open) resetIntlForm(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="border-b pb-4">
            <DialogTitle className="text-lg">{t('banking.intlInitiate')}</DialogTitle>
            <DialogDescription>{t('banking.intlInitiateDesc')}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-sm font-medium">{t('banking.intlProvider')} <span className="text-rose-500">*</span></Label>
              <Select value={intlProvider} onValueChange={setIntlProvider}>
                <SelectTrigger className="border-gray-300"><SelectValue placeholder={t('banking.intlSelectProvider')} /></SelectTrigger>
                <SelectContent>
                  {INTL_PROVIDERS.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-sm font-medium">{t('banking.intlAmount')} <span className="text-rose-500">*</span></Label>
              <Input type="number" value={intlAmount} onChange={(e) => setIntlAmount(e.target.value)} placeholder="10000" className="border-gray-300" />
            </div>
            {parseFloat(intlAmount) > 0 && (
              <div className="rounded-lg bg-gray-50 p-3 space-y-1 text-xs">
                <div className="flex justify-between text-gray-500"><span>{t('banking.intlFeeCalc')}</span><span className="font-mono font-medium text-gray-900">{intlFee.toLocaleString()} ETB</span></div>
                <div className="flex justify-between text-gray-700 font-medium border-t border-gray-200 pt-1 mt-1"><span>{t('banking.intlNetAmount')}</span><span className="font-mono text-gray-900">{(parseFloat(intlAmount) - intlFee).toLocaleString()} ETB</span></div>
              </div>
            )}
            <div className="grid gap-1.5">
              <Label className="text-sm font-medium">{t('banking.intlRecipientName')} <span className="text-rose-500">*</span></Label>
              <Input value={intlRecipientName} onChange={(e) => setIntlRecipientName(e.target.value)} placeholder="John Doe" className="border-gray-300" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('banking.intlRecipientCountry')} <span className="text-rose-500">*</span></Label>
                <Select value={intlRecipientCountry} onValueChange={setIntlRecipientCountry}>
                  <SelectTrigger className="border-gray-300"><SelectValue placeholder="Country" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="US">United States</SelectItem>
                    <SelectItem value="GB">United Kingdom</SelectItem>
                    <SelectItem value="AE">UAE</SelectItem>
                    <SelectItem value="SA">Saudi Arabia</SelectItem>
                    <SelectItem value="KE">Kenya</SelectItem>
                    <SelectItem value="ZA">South Africa</SelectItem>
                    <SelectItem value="CN">China</SelectItem>
                    <SelectItem value="IN">India</SelectItem>
                    <SelectItem value="DE">Germany</SelectItem>
                    <SelectItem value="CA">Canada</SelectItem>
                    <SelectItem value="AU">Australia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-sm font-medium">{t('banking.intlPurpose')}</Label>
                <Select value={intlPurpose} onValueChange={setIntlPurpose}>
                  <SelectTrigger className="border-gray-300"><SelectValue placeholder="Purpose" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="family">{t('banking.intlPurposeFamily')}</SelectItem>
                    <SelectItem value="business">{t('banking.intlPurposeBusiness')}</SelectItem>
                    <SelectItem value="education">{t('banking.intlPurposeEducation')}</SelectItem>
                    <SelectItem value="medical">{t('banking.intlPurposeMedical')}</SelectItem>
                    <SelectItem value="investment">{t('banking.intlPurposeInvestment')}</SelectItem>
                    <SelectItem value="other">{t('banking.intlPurposeOther')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-sm font-medium">{t('banking.intlRecipientAccount')}</Label>
              <Input value={intlRecipientAccount} onChange={(e) => setIntlRecipientAccount(e.target.value)} placeholder="IBAN / Account Number" className="border-gray-300" />
            </div>
          </div>
          <DialogFooter className="border-t pt-4">
            <Button variant="outline" onClick={() => { setIntlDialogOpen(false); resetIntlForm(); }}>{t('common.cancel')}</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleIntlSubmit} disabled={intlSubmitting}>
              {intlSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{t('banking.intlSubmit')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Bank Details Dialog ===== */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader className="border-b pb-4">
            <DialogTitle className="text-lg">{detailsBank?.bankName}</DialogTitle>
            <DialogDescription>{detailsBank?.headOffice}</DialogDescription>
          </DialogHeader>
          {detailsBank && (
            <div className="space-y-3 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-gray-50 p-3"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.bankCode')}</p><p className="text-sm font-mono font-bold text-gray-900 mt-1">{detailsBank.bankCode}</p></div>
                <div className="rounded-lg bg-gray-50 p-3"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.swift')}</p><p className="text-sm font-mono font-bold text-gray-900 mt-1">{detailsBank.swiftCode || '-'}</p></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg bg-gray-50 p-3 text-center"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.ifb')}</p><p className={`text-sm font-bold mt-1 ${detailsBank.supportsIfb ? 'text-emerald-600' : 'text-gray-400'}`}>{detailsBank.supportsIfb ? '✓' : '✗'}</p></div>
                <div className="rounded-lg bg-gray-50 p-3 text-center"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.fx')}</p><p className={`text-sm font-bold mt-1 ${detailsBank.supportsFx ? 'text-emerald-600' : 'text-gray-400'}`}>{detailsBank.supportsFx ? '✓' : '✗'}</p></div>
                <div className="rounded-lg bg-gray-50 p-3 text-center"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.transferSupported')}</p><p className={`text-sm font-bold mt-1 ${detailsBank.supportsTransfer ? 'text-emerald-600' : 'text-gray-400'}`}>{detailsBank.supportsTransfer ? '✓' : '✗'}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-gray-50 p-3"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.founded')}</p><p className="text-sm font-bold text-gray-900 mt-1">{detailsBank.foundedYear || '-'}</p></div>
                <div className="rounded-lg bg-gray-50 p-3"><p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">{t('banking.linkedBankAccounts')}</p><p className="text-sm font-bold text-emerald-600 mt-1">{detailsBank._count?.bankAccounts || 0}</p></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
