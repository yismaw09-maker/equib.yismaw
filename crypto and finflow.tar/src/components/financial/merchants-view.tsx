'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useFormattedDate } from '@/hooks/use-formatted-date';
import { apiFetch } from '@/lib/api-fetch';
import {
  Store, UserPlus, Download, Search, CheckCircle, Clock, DollarSign,
  Eye, Shield, Ban, Unlock, Loader2, MoreHorizontal, Plus, X, Filter,
} from 'lucide-react';
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// --- Types ---

interface MerchantUser {
  id: string;
  email: string;
  username: string | null;
  name: string;
  phone: string | null;
  country: string;
  role: string;
  kycStatus: string;
  twoFactorEnabled: boolean;
  isVerified: boolean;
  riskLevel: string;
  status: string;
  lastLoginAt: string | null;
  createdAt: string;
  _count: { wallets: number; transactions: number };
}

// --- Helpers ---

const fadeIn = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function getAvatarColor(name: string): string {
  const colors = [
    'bg-primary text-white',
    'bg-success text-white',
    'bg-info text-black',
    'bg-warning text-black',
    'bg-destructive text-white',
    'bg-purple-600 text-white',
    'bg-pink-600 text-white',
    'bg-orange-600 text-white',
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

function getKycBadgeVariant(kycStatus: string) {
  switch (kycStatus) {
    case 'verified':
      return 'bg-success text-white';
    case 'pending':
      return 'bg-warning text-black';
    case 'rejected':
      return 'bg-destructive text-white';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

function getStatusBadgeVariant(status: string) {
  switch (status) {
    case 'active':
      return 'bg-success text-white';
    case 'pending':
    case 'approved':
      return 'bg-warning text-black';
    case 'suspended':
      return 'bg-info text-black';
    case 'blocked':
    case 'frozen':
    case 'closed':
      return 'bg-destructive text-white';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

// --- Component ---

export default function MerchantsView() {
  const { formatDate, formatDateTime } = useFormattedDate();

  // State
  const [merchants, setMerchants] = useState<MerchantUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [kycFilter, setKycFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  // Dialogs
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedMerchant, setSelectedMerchant] = useState<MerchantUser | null>(null);

  // Add merchant form
  const [addForm, setAddForm] = useState({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    businessType: 'retail',
    country: 'Ethiopia',
  });
  const [addLoading, setAddLoading] = useState(false);

  // Action loading
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [exportLoading, setExportLoading] = useState(false);

  // --- Fetch merchants ---
  const fetchMerchants = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ role: 'merchant' });
      const res = await apiFetch('/api/users?' + params.toString());
      if (!res.ok) throw new Error('Failed to fetch merchants');
      const data = await res.json();
      setMerchants(data.users || []);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load merchants');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMerchants();
  }, [fetchMerchants]);

  // --- Computed stats ---
  const stats = useMemo(() => {
    const total = merchants.length;
    const active = merchants.filter((m) => m.status === 'active').length;
    const pendingKyc = merchants.filter((m) => m.kycStatus === 'pending').length;
    const totalRevenue = merchants.reduce((sum, m) => sum + m._count.transactions * 150, 0);
    return { total, active, pendingKyc, totalRevenue };
  }, [merchants]);

  // --- Filtered & sorted merchants ---
  const filteredMerchants = useMemo(() => {
    let result = [...merchants];

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (m) =>
          m.name?.toLowerCase().includes(q) ||
          m.email?.toLowerCase().includes(q) ||
          m.phone?.includes(q) ||
          m.country?.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'all') {
      result = result.filter((m) => m.status === statusFilter);
    }

    if (kycFilter !== 'all') {
      result = result.filter((m) => m.kycStatus === kycFilter);
    }

    switch (sortBy) {
      case 'name':
        result.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
        break;
      case 'revenue':
        result.sort((a, b) => b._count.transactions - a._count.transactions);
        break;
      case 'newest':
      default:
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
    }

    return result;
  }, [merchants, search, statusFilter, kycFilter, sortBy]);

  // --- Merchant actions ---
  const handlePatchMerchant = async (id: string, data: Record<string, string>, label: string) => {
    setActionLoading(id + ':' + label);
    try {
      const res = await apiFetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...data }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }
      toast.success(label);
      fetchMerchants();
      if (selectedMerchant?.id === id) {
        const updated = await res.json();
        setSelectedMerchant({ ...selectedMerchant, ...updated });
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Action failed';
      toast.error(message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleVerifyKyc = (merchant: MerchantUser) => {
    handlePatchMerchant(merchant.id, { kycStatus: 'verified' }, 'KYC verified for ' + merchant.name);
  };

  const handleSuspend = (merchant: MerchantUser) => {
    handlePatchMerchant(merchant.id, { status: 'suspended' }, merchant.name + ' has been suspended');
  };

  const handleActivate = (merchant: MerchantUser) => {
    handlePatchMerchant(merchant.id, { status: 'active' }, merchant.name + ' has been activated');
  };

  const handleBlock = (merchant: MerchantUser) => {
    handlePatchMerchant(merchant.id, { status: 'blocked' }, merchant.name + ' has been blocked');
  };

  // --- Add merchant ---
  const handleAddMerchant = async () => {
    if (!addForm.name.trim() || !addForm.email.trim() || !addForm.phone.trim() ||
        !addForm.businessName.trim() || !addForm.country.trim()) {
      toast.error('All fields are required');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(addForm.email)) {
      toast.error('Invalid email format');
      return;
    }
    setAddLoading(true);
    try {
      const res = await apiFetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: addForm.businessName.trim(),
          email: addForm.email.trim(),
          phone: addForm.phone.trim(),
          country: addForm.country.trim(),
          role: 'merchant',
          password: 'Merchant@2024!',
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Registration failed');
      }
      toast.success('Merchant account created successfully');
      setAddDialogOpen(false);
      setAddForm({ name: '', email: '', phone: '', businessName: '', businessType: 'retail', country: 'Ethiopia' });
      fetchMerchants();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create merchant';
      toast.error(message);
    } finally {
      setAddLoading(false);
    }
  };

  // --- Export ---
  const handleExport = async () => {
    setExportLoading(true);
    try {
      const csvRows = [
        ['Name', 'Email', 'Phone', 'Country', 'KYC Status', 'Status', 'Wallets', 'Transactions', 'Joined'],
        ...filteredMerchants.map((m) => [
          m.name, m.email, m.phone || '', m.country, m.kycStatus, m.status,
          String(m._count.wallets), String(m._count.transactions),
          format(new Date(m.createdAt), 'yyyy-MM-dd'),
        ]),
      ];
      const csvContent = csvRows.map((r) => r.join(',')).join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'merchants-export.csv';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Merchants exported successfully');
    } catch {
      toast.error('Export failed');
    } finally {
      setExportLoading(false);
    }
  };

  // --- View details ---
  const handleViewDetails = (merchant: MerchantUser) => {
    setSelectedMerchant(merchant);
    setDetailDialogOpen(true);
  };

  const isActionLoading = (merchantId: string, action: string) => actionLoading === merchantId + ':' + action;

  // --- Render ---
  return (
    <>

      <div className="space-y-6">
        {/* Header */}
        <motion.div {...fadeIn} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Merchant Management</h1>
            <p className="text-muted-foreground">Manage merchant accounts, KYC verification, and business operations.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2 btn-responsive" onClick={handleExport} disabled={exportLoading}>
              {exportLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              Export
            </Button>
            <Button className="bg-primary hover:bg-primary/90 text-white gap-2 btn-responsive" onClick={() => setAddDialogOpen(true)}>
              <UserPlus className="h-4 w-4" />
              Add Merchant
            </Button>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
                  <Store className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Merchants</p>
                  <div className="text-2xl font-bold">{loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.total}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.1 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-success/10">
                  <CheckCircle className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Merchants</p>
                  <div className="text-2xl font-bold">{loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.active}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.2 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-warning/10">
                  <Clock className="h-6 w-6 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Pending KYC</p>
                  <div className="text-2xl font-bold">{loading ? <Skeleton className="h-8 w-12 inline-block" /> : stats.pendingKyc}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.3 }}>
            <Card className="bg-card rounded-2xl shadow-fin p-5 border border-border">
              <CardContent className="p-0 flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-info/10">
                  <DollarSign className="h-6 w-6 text-info" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                  <div className="text-2xl font-bold">
                    {loading ? <Skeleton className="h-8 w-20 inline-block" /> : `ETB ${stats.totalRevenue.toLocaleString()}`}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Filters Row */}
        <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.4 }}>
          <Card className="bg-card rounded-2xl shadow-bs border border-border">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search merchants..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 rounded-2xl"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full sm:w-[160px] rounded-2xl">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={kycFilter} onValueChange={setKycFilter}>
                  <SelectTrigger className="w-full sm:w-[160px] rounded-2xl">
                    <Shield className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="KYC" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All KYC</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full sm:w-[150px] rounded-2xl">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="revenue">Revenue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Merchants Table */}
        <motion.div {...fadeIn} transition={{ duration: 0.4, delay: 0.5 }}>
          <Card className="bg-card rounded-2xl shadow-bs border border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold">Merchants</CardTitle>
              <CardDescription>
                {filteredMerchants.length} of {merchants.length} merchants
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[500px] overflow-y-auto custom-scroll">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead>Merchant</TableHead>
                      <TableHead>Business Type</TableHead>
                      <TableHead className="hidden md:table-cell">Email</TableHead>
                      <TableHead className="hidden lg:table-cell">Phone</TableHead>
                      <TableHead>KYC Status</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="hidden md:table-cell">Wallets</TableHead>
                      <TableHead className="hidden lg:table-cell">Revenue</TableHead>
                      <TableHead className="hidden xl:table-cell">Joined</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 6 }).map((_, i) => (
                        <TableRow key={i} className="hover:bg-transparent">
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Skeleton className="h-9 w-9 rounded-full" />
                              <div className="space-y-1">
                                <Skeleton className="h-4 w-28" />
                                <Skeleton className="h-3 w-36" />
                              </div>
                            </div>
                          </TableCell>
                          <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                          <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-32" /></TableCell>
                          <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-8" /></TableCell>
                          <TableCell className="hidden lg:table-cell"><Skeleton className="h-4 w-20" /></TableCell>
                          <TableCell className="hidden xl:table-cell"><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredMerchants.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center py-16">
                          <div className="flex flex-col items-center gap-2 text-muted-foreground">
                            <Store className="h-10 w-10 opacity-40" />
                            <p className="text-sm font-medium">No merchants found</p>
                            <p className="text-xs">Try adjusting your search or filter criteria.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredMerchants.map((merchant) => (
                        <TableRow key={merchant.id} className="hover:bg-muted/30">
                          {/* Merchant column */}
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold ${getAvatarColor(merchant.name)}`}>
                                {getInitials(merchant.name)}
                              </div>
                              <div className="min-w-0">
                                <p className="font-medium truncate max-w-[180px]">{merchant.name}</p>
                                <p className="text-xs text-muted-foreground truncate max-w-[180px]">{merchant.email}</p>
                              </div>
                            </div>
                          </TableCell>

                          {/* Business Type */}
                          <TableCell>
                            <span className="text-sm capitalize">{merchant.riskLevel || 'General'}</span>
                          </TableCell>

                          {/* Email (md+) */}
                          <TableCell className="hidden md:table-cell">
                            <span className="text-sm text-muted-foreground">{merchant.email}</span>
                          </TableCell>

                          {/* Phone (lg+) */}
                          <TableCell className="hidden lg:table-cell">
                            <span className="text-sm text-muted-foreground">{merchant.phone || '—'}</span>
                          </TableCell>

                          {/* KYC Status */}
                          <TableCell>
                            <Badge className={`text-xs font-medium ${getKycBadgeVariant(merchant.kycStatus)}`}>
                              {merchant.kycStatus}
                            </Badge>
                          </TableCell>

                          {/* Status */}
                          <TableCell>
                            <Badge className={`text-xs font-medium ${getStatusBadgeVariant(merchant.status)}`}>
                              {merchant.status}
                            </Badge>
                          </TableCell>

                          {/* Wallets (md+) */}
                          <TableCell className="hidden md:table-cell">
                            <span className="text-sm font-medium">{merchant._count.wallets}</span>
                          </TableCell>

                          {/* Revenue (lg+) */}
                          <TableCell className="hidden lg:table-cell">
                            <span className="text-sm font-medium">ETB {(merchant._count.transactions * 150).toLocaleString()}</span>
                          </TableCell>

                          {/* Joined (xl+) */}
                          <TableCell className="hidden xl:table-cell">
                            <span className="datetime-badge date-only">{formatDate(merchant.createdAt)}</span>
                          </TableCell>

                          {/* Actions */}
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  {isActionLoading(merchant.id, 'any') ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <MoreHorizontal className="h-4 w-4" />
                                  )}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDetails(merchant)}>
                                  <Eye className="h-4 w-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                {merchant.kycStatus !== 'verified' && (
                                  <DropdownMenuItem
                                    onClick={() => handleVerifyKyc(merchant)}
                                    disabled={isActionLoading(merchant.id, 'verify-kyc')}
                                  >
                                    {isActionLoading(merchant.id, 'verify-kyc') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Shield className="h-4 w-4 mr-2" />
                                    )}
                                    Verify KYC
                                  </DropdownMenuItem>
                                )}
                                {merchant.status !== 'suspended' && merchant.status !== 'blocked' && (
                                  <DropdownMenuItem
                                    onClick={() => handleSuspend(merchant)}
                                    disabled={isActionLoading(merchant.id, 'suspend')}
                                  >
                                    {isActionLoading(merchant.id, 'suspend') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Ban className="h-4 w-4 mr-2" />
                                    )}
                                    Suspend
                                  </DropdownMenuItem>
                                )}
                                {merchant.status !== 'active' && merchant.status !== 'blocked' && (
                                  <DropdownMenuItem
                                    onClick={() => handleActivate(merchant)}
                                    disabled={isActionLoading(merchant.id, 'activate')}
                                  >
                                    {isActionLoading(merchant.id, 'activate') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Unlock className="h-4 w-4 mr-2" />
                                    )}
                                    Activate
                                  </DropdownMenuItem>
                                )}
                                {merchant.status !== 'blocked' && (
                                  <DropdownMenuItem
                                    onClick={() => handleBlock(merchant)}
                                    disabled={isActionLoading(merchant.id, 'block')}
                                    className="text-destructive"
                                  >
                                    {isActionLoading(merchant.id, 'block') ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <Ban className="h-4 w-4 mr-2" />
                                    )}
                                    Block
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Add Merchant Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Add New Merchant
            </DialogTitle>
            <DialogDescription>
              Create a new merchant account. The merchant will receive login credentials via email.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="add-name">Full Name *</Label>
              <Input
                id="add-name"
                placeholder="John Doe"
                value={addForm.name}
                onChange={(e) => setAddForm({ ...addForm, name: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-email">Email *</Label>
              <Input
                id="add-email"
                type="email"
                placeholder="merchant@example.com"
                value={addForm.email}
                onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-phone">Phone *</Label>
              <Input
                id="add-phone"
                placeholder="+251912345678"
                value={addForm.phone}
                onChange={(e) => setAddForm({ ...addForm, phone: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-business">Business Name *</Label>
              <Input
                id="add-business"
                placeholder="Acme Trading PLC"
                value={addForm.businessName}
                onChange={(e) => setAddForm({ ...addForm, businessName: e.target.value })}
                className="rounded-2xl"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-biz-type">Business Type *</Label>
              <Select
                value={addForm.businessType}
                onValueChange={(v) => setAddForm({ ...addForm, businessType: v })}
              >
                <SelectTrigger id="add-biz-type" className="rounded-2xl">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="wholesale">Wholesale</SelectItem>
                  <SelectItem value="service">Service</SelectItem>
                  <SelectItem value="ecommerce">E-Commerce</SelectItem>
                  <SelectItem value="restaurant">Restaurant</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="add-country">Country *</Label>
              <Input
                id="add-country"
                placeholder="Ethiopia"
                value={addForm.country}
                onChange={(e) => setAddForm({ ...addForm, country: e.target.value })}
                className="rounded-2xl"
              />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0 btn-responsive-group">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)} className="rounded-2xl">
              Cancel
            </Button>
            <Button
              className="btn-responsive bg-primary hover:bg-primary/90 text-white rounded-2xl gap-2"
              onClick={handleAddMerchant}
              disabled={addLoading}
            >
              {addLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Create Merchant
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Merchant Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-[550px] rounded-2xl max-h-[85vh] overflow-y-auto custom-scroll">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedMerchant && (
                <div className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold ${getAvatarColor(selectedMerchant.name)}`}>
                  {getInitials(selectedMerchant.name)}
                </div>
              )}
              Merchant Details
            </DialogTitle>
            <DialogDescription>View and manage merchant account information.</DialogDescription>
          </DialogHeader>

          {selectedMerchant && (
            <div className="space-y-6">
              {/* Info Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Full Name</p>
                  <p className="text-sm font-medium">{selectedMerchant.name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Username</p>
                  <p className="text-sm font-medium">{selectedMerchant.username || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Email</p>
                  <p className="text-sm font-medium">{selectedMerchant.email}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Phone</p>
                  <p className="text-sm font-medium">{selectedMerchant.phone || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Country</p>
                  <p className="text-sm font-medium">{selectedMerchant.country}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Role</p>
                  <p className="text-sm font-medium capitalize">{selectedMerchant.role.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Risk Level</p>
                  <p className="text-sm font-medium capitalize">{selectedMerchant.riskLevel || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">2FA Enabled</p>
                  <p className="text-sm font-medium">{selectedMerchant.twoFactorEnabled ? 'Yes' : 'No'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Verified</p>
                  <p className="text-sm font-medium">{selectedMerchant.isVerified ? 'Yes' : 'No'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Joined</p>
                  <p className="text-sm font-medium"><span className="datetime-badge date-only">{formatDate(selectedMerchant.createdAt)}</span></p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Last Login</p>
                  <p className="text-sm font-medium">
                    {selectedMerchant.lastLoginAt
                      ? <span className="datetime-badge full">{formatDateTime(selectedMerchant.lastLoginAt)}</span>
                      : 'Never'}
                  </p>
                </div>
              </div>

              {/* Status Badges */}
              <div className="flex items-center gap-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Account Status</p>
                  <Badge className={`text-xs font-medium ${getStatusBadgeVariant(selectedMerchant.status)}`}>
                    {selectedMerchant.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">KYC Status</p>
                  <Badge className={`text-xs font-medium ${getKycBadgeVariant(selectedMerchant.kycStatus)}`}>
                    {selectedMerchant.kycStatus}
                  </Badge>
                </div>
              </div>

              {/* Activity Stats */}
              <div className="grid grid-cols-3 gap-3">
                <Card className="bg-card rounded-2xl shadow-fin p-4 border border-border">
                  <CardContent className="p-0 text-center">
                    <p className="text-2xl font-bold text-primary">{selectedMerchant._count.wallets}</p>
                    <p className="text-xs text-muted-foreground">Wallets</p>
                  </CardContent>
                </Card>
                <Card className="bg-card rounded-2xl shadow-fin p-4 border border-border">
                  <CardContent className="p-0 text-center">
                    <p className="text-2xl font-bold text-success">{selectedMerchant._count.transactions}</p>
                    <p className="text-xs text-muted-foreground">Transactions</p>
                  </CardContent>
                </Card>
                <Card className="bg-card rounded-2xl shadow-fin p-4 border border-border">
                  <CardContent className="p-0 text-center">
                    <p className="text-2xl font-bold text-info">ETB {(selectedMerchant._count.transactions * 150).toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Revenue</p>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2">
                <p className="text-sm font-semibold">Quick Actions</p>
                <div className="flex flex-wrap gap-2 btn-responsive-group">
                  {selectedMerchant.kycStatus !== 'verified' && (
                    <Button
                      size="sm"
                      className="bg-success hover:bg-success/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleVerifyKyc(selectedMerchant);
                        setSelectedMerchant({ ...selectedMerchant, kycStatus: 'verified' });
                      }}
                      disabled={isActionLoading(selectedMerchant.id, 'verify-kyc')}
                    >
                      {isActionLoading(selectedMerchant.id, 'verify-kyc') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Shield className="h-4 w-4" />
                      )}
                      Verify KYC
                    </Button>
                  )}
                  {selectedMerchant.status !== 'suspended' && selectedMerchant.status !== 'blocked' && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleSuspend(selectedMerchant);
                        setSelectedMerchant({ ...selectedMerchant, status: 'suspended' });
                      }}
                      disabled={isActionLoading(selectedMerchant.id, 'suspend')}
                    >
                      {isActionLoading(selectedMerchant.id, 'suspend') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Ban className="h-4 w-4" />
                      )}
                      Suspend
                    </Button>
                  )}
                  {selectedMerchant.status !== 'active' && selectedMerchant.status !== 'blocked' && (
                    <Button
                      size="sm"
                      className="bg-primary hover:bg-primary/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleActivate(selectedMerchant);
                        setSelectedMerchant({ ...selectedMerchant, status: 'active' });
                      }}
                      disabled={isActionLoading(selectedMerchant.id, 'activate')}
                    >
                      {isActionLoading(selectedMerchant.id, 'activate') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Unlock className="h-4 w-4" />
                      )}
                      Activate
                    </Button>
                  )}
                  {selectedMerchant.status !== 'blocked' && (
                    <Button
                      size="sm"
                      variant="destructive"
                      className="bg-destructive hover:bg-destructive/90 text-white gap-2 rounded-2xl btn-responsive"
                      onClick={() => {
                        handleBlock(selectedMerchant);
                        setSelectedMerchant({ ...selectedMerchant, status: 'blocked' });
                      }}
                      disabled={isActionLoading(selectedMerchant.id, 'block')}
                    >
                      {isActionLoading(selectedMerchant.id, 'block') ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Ban className="h-4 w-4" />
                      )}
                      Block
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)} className="rounded-2xl">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
