// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Balance Manager
// ═══════════════════════════════════════════════════════════════

import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';

export interface BalanceCheckResult {
  walletId: string;
  balance: number;
  availableBalance: number;
  frozenBalance: number;
  isSufficient: boolean;
  shortfall?: number;
}

export interface BalanceChangeParams {
  walletId: string;
  previousBalance: number;
  newBalance: number;
  changeAmount: number;
  changeType: 'credit' | 'debit' | 'freeze' | 'unfreeze';
  reason?: string;
  transactionId?: string;
}

// ── Check Balance ──────────────────────────────────────────

export async function checkBalance(
  walletId: string,
  requiredAmount: number,
): Promise<BalanceCheckResult> {
  const wallet = await db.wallet.findUniqueOrThrow({ where: { id: walletId } });
  const isSufficient = wallet.availableBalance >= requiredAmount;

  return {
    walletId,
    balance: wallet.balance,
    availableBalance: wallet.availableBalance,
    frozenBalance: wallet.frozenBalance,
    isSufficient,
    shortfall: isSufficient ? undefined : requiredAmount - wallet.availableBalance,
  };
}

// ── Freeze Funds ───────────────────────────────────────────
// Moves amount from availableBalance to frozenBalance.

export async function freezeFunds(
  tx: Prisma.TransactionClient,
  walletId: string,
  amount: number,
  reason?: string,
) {
  const wallet = await tx.wallet.findUniqueOrThrow({ where: { id: walletId } });
  if (wallet.availableBalance < amount) {
    throw new Error('Insufficient available balance to freeze');
  }

  const updated = await tx.wallet.update({
    where: { id: walletId },
    data: {
      availableBalance: { decrement: amount },
      frozenBalance: { increment: amount },
    },
  });

  await recordBalanceChange(tx, {
    walletId,
    previousBalance: wallet.balance,
    newBalance: updated.balance,
    changeAmount: -amount,
    changeType: 'freeze',
    reason,
  });

  return updated;
}

// ── Unfreeze Funds ─────────────────────────────────────────

export async function unfreezeFunds(
  tx: Prisma.TransactionClient,
  walletId: string,
  amount: number,
  reason?: string,
) {
  const wallet = await tx.wallet.findUniqueOrThrow({ where: { id: walletId } });
  if (wallet.frozenBalance < amount) {
    throw new Error('Cannot unfreeze more than frozen balance');
  }

  const updated = await tx.wallet.update({
    where: { id: walletId },
    data: {
      availableBalance: { increment: amount },
      frozenBalance: { decrement: amount },
    },
  });

  await recordBalanceChange(tx, {
    walletId,
    previousBalance: wallet.balance,
    newBalance: updated.balance,
    changeAmount: amount,
    changeType: 'unfreeze',
    reason,
  });

  return updated;
}

// ── Record Balance Change ──────────────────────────────────

export async function recordBalanceChange(
  tx: Prisma.TransactionClient,
  params: BalanceChangeParams,
) {
  return tx.balanceHistory.create({
    data: {
      walletId: params.walletId,
      previousBalance: params.previousBalance,
      newBalance: params.newBalance,
      changeAmount: params.changeAmount,
      changeType: params.changeType,
      reason: params.reason ?? null,
      transactionId: params.transactionId ?? null,
    },
  });
}
