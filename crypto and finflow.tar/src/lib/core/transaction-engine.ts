// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Transaction Engine
// ═══════════════════════════════════════════════════════════════
// Handles the full transaction lifecycle:
//   INITIATED → PENDING → PROCESSING → COMPLETED → SETTLED → RECONCILED
//   Any stage can → FAILED, CANCELLED, or REVERSED
// ═══════════════════════════════════════════════════════════════

import { db } from '@/lib/db';
import { createLedgerEntry } from './ledger';
import { recordBalanceChange } from './balance';
import { assessRisk } from './risk-engine';
import { validateAmount, isValidCurrencyCode, isValidTransactionType } from '@/lib/shared/validators';

export interface TransactionParams {
  type: string;
  amount: number;
  currency?: string;
  description?: string;
  initiatorId: string;
  recipientId?: string;
  recipientName?: string;
  sourceWalletId?: string;
  destinationWalletId?: string;
  paymentMethod?: string;
  category?: string;
  subType?: string;
  senderAddress?: string;
  receiverAddress?: string;
  ipAddress?: string;
  skipRiskCheck?: boolean;
}

export interface TransactionResult {
  success: boolean;
  transaction?: Record<string, unknown>;
  error?: string;
  code?: string;
}

// ── Reference Generator ──────────────────────────────────────

function generateReference(type: string): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 100000)).padStart(5, '0');
  return `TXN-${y}${m}${d}-${rand}`;
}

// ── Fee Calculation ──────────────────────────────────────────

async function calculateFee(
  type: string,
  amount: number,
  paymentMethod?: string,
): Promise<number> {
  const feeConfig = await db.feeConfig.findFirst({
    where: {
      transactionType: type,
      paymentMethod: paymentMethod ?? null,
      isActive: true,
    },
  });

  if (!feeConfig) return 0;

  let fee = 0;
  if (feeConfig.feeType === 'flat') {
    fee = feeConfig.feeValue;
  } else if (feeConfig.feeType === 'percentage') {
    fee = (amount * feeConfig.feeValue) / 100;
    if (feeConfig.minFee && fee < feeConfig.minFee) fee = feeConfig.minFee;
    if (feeConfig.maxFee && fee > feeConfig.maxFee) fee = feeConfig.maxFee;
  }
  return fee;
}

// ── Main Transaction Processor ───────────────────────────────

export async function processTransaction(params: TransactionParams): Promise<TransactionResult> {
  // 1. Validate inputs
  const amountValidation = validateAmount(params.amount);
  if (!amountValidation.valid) {
    return { success: false, error: amountValidation.error, code: 'INVALID_AMOUNT' };
  }

  const currency = (params.currency ?? 'ETB').toUpperCase();
  if (!isValidCurrencyCode(currency)) {
    return { success: false, error: `Unsupported currency: ${currency}`, code: 'INVALID_CURRENCY' };
  }

  if (!isValidTransactionType(params.type)) {
    return { success: false, error: `Invalid transaction type: ${params.type}`, code: 'INVALID_TYPE' };
  }

  const reference = generateReference(params.type);
  const fee = await calculateFee(params.type, params.amount, params.paymentMethod);
  const totalDebit = params.amount + fee;

  // 2. Determine if this is a balance-moving transaction
  const balanceMovingTypes = ['transfer', 'payment', 'deposit', 'withdrawal'];
  const requiresSource = ['transfer', 'payment', 'withdrawal'].includes(params.type);
  const requiresDest = ['transfer', 'payment', 'deposit'].includes(params.type);

  if (requiresSource && !params.sourceWalletId) {
    return { success: false, error: `${params.type} requires sourceWalletId`, code: 'MISSING_SOURCE' };
  }
  if (requiresDest && !params.destinationWalletId) {
    return { success: false, error: `${params.type} requires destinationWalletId`, code: 'MISSING_DEST' };
  }

  // 3. Risk assessment
  let riskScore = 0.1;
  if (!params.skipRiskCheck) {
    const riskResult = await assessRisk({
      amount: params.amount,
      type: params.type,
      initiatorId: params.initiatorId,
      ipAddress: params.ipAddress,
    });
    riskScore = riskResult.score;
    if (riskResult.flagged) {
      // Create flagged transaction but don't auto-fail
      riskScore = riskResult.score;
    }
  }

  // 4. Process balance-moving transactions atomically
  if (balanceMovingTypes.includes(params.type)) {
    return processBalanceTransaction({
      ...params,
      reference,
      fee,
      totalDebit,
      currency,
      riskScore,
      requiresSource,
      requiresDest,
    });
  }

  // 5. Non-balance-moving: just record
  const transaction = await db.transaction.create({
    data: {
      reference,
      type: params.type,
      subType: params.subType ?? null,
      amount: params.amount,
      fee,
      currency,
      description: params.description ?? null,
      initiatorId: params.initiatorId,
      recipientId: params.recipientId ?? null,
      recipientName: params.recipientName ?? null,
      sourceWalletId: params.sourceWalletId ?? null,
      destinationWalletId: params.destinationWalletId ?? null,
      paymentMethod: params.paymentMethod ?? null,
      category: params.category ?? null,
      senderAddress: params.senderAddress ?? null,
      receiverAddress: params.receiverAddress ?? null,
      ipAddress: params.ipAddress ?? null,
      status: 'pending',
      riskScore,
    },
  });

  return { success: true, transaction: transaction as Record<string, unknown> };
}

// ── Balance-Moving Transaction ───────────────────────────────

interface BalanceTxParams extends TransactionParams {
  reference: string;
  fee: number;
  totalDebit: number;
  currency: string;
  riskScore: number;
  requiresSource: boolean;
  requiresDest: boolean;
}

async function processBalanceTransaction(params: BalanceTxParams): Promise<TransactionResult> {
  // Validate source wallet
  if (params.requiresSource && params.sourceWalletId) {
    const sourceWallet = await db.wallet.findUnique({ where: { id: params.sourceWalletId } });
    if (!sourceWallet) return { success: false, error: 'Source wallet not found', code: 'SOURCE_NOT_FOUND' };
    if (sourceWallet.status !== 'active') return { success: false, error: 'Source wallet is not active', code: 'SOURCE_INACTIVE' };
    if (sourceWallet.currency !== params.currency) return { success: false, error: 'Currency mismatch on source wallet', code: 'CURRENCY_MISMATCH' };
    if (sourceWallet.availableBalance < params.totalDebit) return { success: false, error: 'Insufficient balance', code: 'INSUFFICIENT_BALANCE' };
  }

  // Validate destination wallet
  if (params.requiresDest && params.destinationWalletId) {
    const destWallet = await db.wallet.findUnique({ where: { id: params.destinationWalletId } });
    if (!destWallet) return { success: false, error: 'Destination wallet not found', code: 'DEST_NOT_FOUND' };
    if (destWallet.status !== 'active') return { success: false, error: 'Destination wallet is not active', code: 'DEST_INACTIVE' };
    if (destWallet.currency !== params.currency) return { success: false, error: 'Currency mismatch on destination wallet', code: 'CURRENCY_MISMATCH' };
  }

  // Atomic balance movement + transaction + ledger
  const result = await db.$transaction(async (tx) => {
    // Debit source
    if (params.requiresSource && params.sourceWalletId) {
      const wallet = await tx.wallet.findUniqueOrThrow({ where: { id: params.sourceWalletId } });
      await tx.wallet.update({
        where: { id: params.sourceWalletId },
        data: {
          balance: { decrement: params.totalDebit },
          availableBalance: { decrement: params.totalDebit },
        },
      });

      await recordBalanceChange(tx, {
        walletId: params.sourceWalletId,
        previousBalance: wallet.balance,
        newBalance: wallet.balance - params.totalDebit,
        changeAmount: -params.totalDebit,
        changeType: 'debit',
        reason: `Transaction ${params.reference}`,
      });
    }

    // Credit destination
    if (params.requiresDest && params.destinationWalletId) {
      const wallet = await tx.wallet.findUniqueOrThrow({ where: { id: params.destinationWalletId } });
      await tx.wallet.update({
        where: { id: params.destinationWalletId },
        data: {
          balance: { increment: params.amount },
          availableBalance: { increment: params.amount },
        },
      });

      await recordBalanceChange(tx, {
        walletId: params.destinationWalletId,
        previousBalance: wallet.balance,
        newBalance: wallet.balance + params.amount,
        changeAmount: params.amount,
        changeType: 'credit',
        reason: `Transaction ${params.reference}`,
      });
    }

    // Create transaction record
    const txn = await tx.transaction.create({
      data: {
        reference: params.reference,
        type: params.type,
        subType: params.subType ?? null,
        amount: params.amount,
        fee: params.fee,
        currency: params.currency,
        description: params.description ?? null,
        initiatorId: params.initiatorId,
        recipientId: params.recipientId ?? null,
        recipientName: params.recipientName ?? null,
        sourceWalletId: params.sourceWalletId ?? null,
        destinationWalletId: params.destinationWalletId ?? null,
        paymentMethod: params.paymentMethod ?? null,
        category: params.category ?? null,
        senderAddress: params.senderAddress ?? null,
        receiverAddress: params.receiverAddress ?? null,
        ipAddress: params.ipAddress ?? null,
        status: 'completed',
        completedAt: new Date(),
        riskScore: params.riskScore,
      },
    });

    // Create ledger entries (double-entry)
    if (params.requiresSource) {
      await createLedgerEntry(tx, {
        transactionId: txn.id,
        accountId: `LIABILITY:USER_BALANCES:${params.currency}`,
        entryType: 'credit',
        amount: params.amount,
        currency: params.currency,
        description: `Debit for ${params.reference}`,
      });
    }

    if (params.fee > 0) {
      await createLedgerEntry(tx, {
        transactionId: txn.id,
        accountId: 'REVENUE:FEE',
        entryType: 'credit',
        amount: params.fee,
        currency: params.currency,
        description: `Fee for ${params.reference}`,
      });
    }

    return txn;
  });

  return { success: true, transaction: result as Record<string, unknown> };
}
