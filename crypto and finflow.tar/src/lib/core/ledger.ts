// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Double-Entry Ledger
// ═══════════════════════════════════════════════════════════════
// Every financial movement creates balanced debit/credit entries.
// Debits increase asset accounts, credits increase liability/revenue.
// ═══════════════════════════════════════════════════════════════

import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import type { LedgerAccountId, LedgerEntryType } from '@/lib/shared/types';

export interface LedgerEntryParams {
  transactionId?: string;
  accountId: string;
  entryType: LedgerEntryType;
  amount: number;
  currency?: string;
  description?: string;
  userId?: string;
}

// ── Create Ledger Entry ──────────────────────────────────────
// Can be called standalone or within a Prisma transaction (tx).

export async function createLedgerEntry(
  tx: Prisma.TransactionClient,
  params: LedgerEntryParams,
) {
  return tx.ledgerEntry.create({
    data: {
      transactionId: params.transactionId ?? null,
      accountId: params.accountId,
      entryType: params.entryType,
      amount: params.amount,
      currency: params.currency ?? 'ETB',
      description: params.description ?? null,
      userId: params.userId ?? null,
    },
  });
}

// ── Get Account Balance ─────────────────────────────────────
// Calculates balance for a ledger account by summing debits - credits.

export async function getAccountBalance(accountId: string, currency = 'ETB') {
  const entries = await db.ledgerEntry.groupBy({
    by: ['entryType'],
    where: { accountId, currency },
    _sum: { amount: true },
  });

  let debitTotal = 0;
  let creditTotal = 0;

  for (const entry of entries) {
    if (entry.entryType === 'debit') {
      debitTotal += entry._sum.amount ?? 0;
    } else {
      creditTotal += entry._sum.amount ?? 0;
    }
  }

  return {
    accountId,
    currency,
    debitTotal,
    creditTotal,
    balance: debitTotal - creditTotal,
    entryCount: entries.reduce((sum, e) => sum + 1, 0),
  };
}
