// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Reconciliation Engine
// ═══════════════════════════════════════════════════════════════
// Matches internal transactions against external records
// (bank statements, mobile money, payment gateways).
// ═══════════════════════════════════════════════════════════════

import { db } from '@/lib/db';

export interface ReconciliationParams {
  sourceType: string;
  sourceRef: string;
  amount: number;
  currency?: string;
  notes?: string;
}

export async function recordReconciliation(params: ReconciliationParams) {
  // Try to find a matching transaction
  const currency = params.currency ?? 'ETB';
  const matchingTx = await db.transaction.findFirst({
    where: {
      amount: params.amount,
      currency,
      status: 'completed',
      createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
    },
    orderBy: { createdAt: 'desc' },
  });

  const status = matchingTx ? 'matched' : 'unmatched';

  const record = await db.reconciliationRecord.create({
    data: {
      sourceType: params.sourceType,
      sourceRef: params.sourceRef,
      transactionId: matchingTx?.id ?? null,
      amount: params.amount,
      currency,
      status,
      notes: params.notes ?? null,
    },
  });

  // If matched, update transaction status to reconciled
  if (matchingTx && status === 'matched') {
    await db.transaction.update({
      where: { id: matchingTx.id },
      data: { status: 'reconciled', reconciledAt: new Date() },
    });
  }

  return record;
}
