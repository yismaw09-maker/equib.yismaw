// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Risk Engine
// ═══════════════════════════════════════════════════════════════
// Scores transactions for fraud risk based on multiple factors.
// ═══════════════════════════════════════════════════════════════

import { db } from '@/lib/db';
import { RISK_THRESHOLDS, DEFAULT_LIMITS } from '@/lib/shared/constants';

export interface RiskAssessmentParams {
  amount: number;
  type: string;
  initiatorId: string;
  ipAddress?: string;
}

export interface RiskAssessmentResult {
  score: number; // 0.0 - 1.0
  level: 'low' | 'medium' | 'high' | 'critical';
  flagged: boolean;
  factors: string[];
  recommendation: string;
}

export async function assessRisk(params: RiskAssessmentParams): Promise<RiskAssessmentResult> {
  const factors: string[] = [];
  let score = 0.1; // base score

  // 1. Check user's existing risk level
  const user = await db.user.findUnique({
    where: { id: params.initiatorId },
    select: { riskLevel: true, role: true, status: true, createdAt: Date },
  });

  if (user?.riskLevel === 'high') {
    score += 0.2;
    factors.push('User has high risk level');
  } else if (user?.riskLevel === 'medium') {
    score += 0.1;
    factors.push('User has medium risk level');
  }

  // 2. Amount-based risk
  const roleLimits = DEFAULT_LIMITS[user?.role as keyof typeof DEFAULT_LIMITS] ?? DEFAULT_LIMITS.user;
  if (params.amount > roleLimits.singleMax * 0.8) {
    score += 0.2;
    factors.push('Amount close to single transaction limit');
  } else if (params.amount > roleLimits.singleMax * 0.5) {
    score += 0.1;
    factors.push('Amount is moderately large');
  }

  // 3. Transaction type risk
  const highRiskTypes = ['withdrawal', 'refund', 'chargeback'];
  if (highRiskTypes.includes(params.type)) {
    score += 0.1;
    factors.push(`Higher risk transaction type: ${params.type}`);
  }

  // 4. Check for rapid succession (many transactions in last hour)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentCount = await db.transaction.count({
    where: {
      initiatorId: params.initiatorId,
      createdAt: { gte: oneHourAgo },
    },
  });

  if (recentCount > 10) {
    score += 0.15;
    factors.push(`High transaction velocity: ${recentCount} in last hour`);
  } else if (recentCount > 5) {
    score += 0.05;
    factors.push(`Elevated transaction velocity: ${recentCount} in last hour`);
  }

  // 5. New account risk (less than 7 days old)
  if (user?.createdAt) {
    const ageMs = Date.now() - new Date(user.createdAt).getTime();
    if (ageMs < 7 * 24 * 60 * 60 * 1000) {
      score += 0.1;
      factors.push('New account (less than 7 days)');
    }
  }

  // Cap score at 1.0
  score = Math.min(1.0, score);

  // Determine level
  let level: RiskAssessmentResult['level'] = 'low';
  if (score >= RISK_THRESHOLDS.critical) level = 'critical';
  else if (score >= RISK_THRESHOLDS.high) level = 'high';
  else if (score >= RISK_THRESHOLDS.medium) level = 'medium';

  // Flag if high or critical
  const flagged = level === 'high' || level === 'critical';

  // Recommendation
  let recommendation = 'Proceed normally';
  if (level === 'critical') recommendation = 'Block transaction and escalate immediately';
  else if (level === 'high') recommendation = 'Require manual approval before processing';
  else if (level === 'medium') recommendation = 'Apply additional verification (OTP/2FA)';

  return { score, level, flagged, factors, recommendation };
}
