// ── Server-side Auth Helpers ─────────────────────────────────────
// HMAC-signed session tokens, role-based authorization, audit logging.

import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from './db';
import { getRoleLevel } from './role-permissions';
export { getRoleLevel };

// ── Session Token ───────────────────────────────────────────────

const HMAC_KEY = process.env.SESSION_SECRET || 'finflow-dev-hmac-key-change-in-production';
const SESSION_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  username: string | null;
  phone: string | null;
  country: string;
  role: string;
  status: string;
  iat?: number; // issued-at timestamp (ms)
}

/**
 * Create an HMAC-signed session token.
 * Format: base64url( payload ) . base64url( hmac-sha256( payload ) )
 */
export function signSession(user: SessionUser): string {
  const payload = JSON.stringify({ ...user, iat: Date.now() });
  const payloadB64 = Buffer.from(payload).toString('base64url');
  const sig = crypto.createHmac('sha256', HMAC_KEY).update(payloadB64).digest('base64url');
  return `${payloadB64}.${sig}`;
}

/**
 * Verify and decode an HMAC-signed session token.
 * Returns null if invalid, expired, or tampered.
 */
export function verifySession(token: string): SessionUser | null {
  try {
    const dotIdx = token.lastIndexOf('.');
    if (dotIdx === -1) return null;
    const payloadB64 = token.substring(0, dotIdx);
    const sig = token.substring(dotIdx + 1);
    const expectedSig = crypto.createHmac('sha256', HMAC_KEY).update(payloadB64).digest('base64url');

    // Timing-safe comparison to prevent timing attacks
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) {
      return null;
    }

    const data = JSON.parse(Buffer.from(payloadB64, 'base64url').toString()) as SessionUser;

    // Check expiry
    if (data.iat && Date.now() - data.iat > SESSION_MAX_AGE_MS) {
      return null;
    }

    return data;
  } catch {
    return null;
  }
}

// ── Request Helpers ─────────────────────────────────────────────

/** Extract session from request cookie OR Authorization header (returns null if missing/invalid) */
export function getSession(request: NextRequest): SessionUser | null {
  // 1. Try cookie first (same-origin)
  const cookieToken = request.cookies.get('finflow-token')?.value;
  if (cookieToken) {
    const user = verifySession(cookieToken);
    if (user) return user;
  }

  // 2. Try Authorization: Bearer <token> header (cross-origin fallback)
  const authHeader = request.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) {
    const token = authHeader.slice(7);
    const user = verifySession(token);
    if (user) return user;
  }

  return null;
}

/** Return 401 if not authenticated */
export function requireAuth(request: NextRequest): { user: SessionUser } | NextResponse {
  const user = getSession(request);
  if (!user) {
    return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
  }
  return { user };
}

/** Extract the raw session token from a request (cookie or Authorization header) */
export function extractToken(request: NextRequest): string | null {
  const cookieToken = request.cookies.get('finflow-token')?.value;
  if (cookieToken) return cookieToken;

  const authHeader = request.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) return authHeader.slice(7);

  return null;
}

/** Return 403 if user doesn't meet minimum role level */
export function requireMinLevel(request: NextRequest, minLevel: number): { user: SessionUser } | NextResponse {
  const auth = requireAuth(request);
  if (auth instanceof NextResponse) return auth;
  if (getRoleLevel(auth.user.role) < minLevel) {
    return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 });
  }
  return auth;
}

/** Return 403 if user is not at least admin-level (level >= 45) */
export function requireAdmin(request: NextRequest): { user: SessionUser } | NextResponse {
  return requireMinLevel(request, 45);
}

/** Return 403 if user is not at least super_admin (level >= 100) */
export function requireSuperAdmin(request: NextRequest): { user: SessionUser } | NextResponse {
  return requireMinLevel(request, 100);
}

/** Check if auth result is a NextResponse (error) */
export function isErrorResponse(result: unknown): result is NextResponse {
  return result instanceof NextResponse;
}

// ── Audit Logging ───────────────────────────────────────────────

export async function createAuditLog(params: {
  userId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  details?: string;
  request?: NextRequest;
}) {
  try {
    await db.auditLog.create({
      data: {
        userId: params.userId,
        action: params.action,
        resource: params.resource,
        resourceId: params.resourceId,
        details: params.details,
        ipAddress: params.request?.headers.get('x-forwarded-for') ?? params.request?.headers.get('x-real-ip') ?? null,
        userAgent: params.request?.headers.get('user-agent') ?? null,
      },
    });
  } catch {
    // Audit logging should never break the main flow
  }
}

// ── Pagination Helper ───────────────────────────────────────────

export function parsePagination(searchParams: URLSearchParams) {
  const page = Math.max(1, parseInt(searchParams.get('page') ?? '1') || 1);
  const limit = Math.min(200, Math.max(1, parseInt(searchParams.get('limit') ?? '20') || 20));
  return { page, limit, skip: (page - 1) * limit };
}

export function paginatedResponse<T>(data: T[], total: number, page: number, limit: number) {
  return {
    data,
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
  };
}

// ── PII Redaction for non-admin users ───────────────────────────

export function redactPII(user: SessionUser, target: Record<string, unknown>): Record<string, unknown> {
  const isAdmin = getRoleLevel(user.role) >= 45;
  if (isAdmin) return target;
  // Non-admins should not see emails/phones of other users
  const redacted = { ...target };
  delete (redacted as Record<string, unknown>).email;
  delete (redacted as Record<string, unknown>).phone;
  return redacted;
}
