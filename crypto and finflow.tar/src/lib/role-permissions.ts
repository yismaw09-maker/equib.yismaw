// ── Role Definitions ─────────────────────────────────────────────

export const ROLES = {
  super_admin: {
    label: 'Super Admin',
    level: 100,
    accessLevel: 'full',
    description: 'Full system control. Can manage all users, admins, settings, and data.',
    canManage: ['super_admin', 'administrator', 'finance_manager', 'compliance_auditor', 'merchant', 'buyer', 'agent', 'customer_support', 'warehouse_manager', 'delivery', 'user', 'seller'],
  },
  administrator: {
    label: 'Administrator',
    level: 80,
    accessLevel: 'administrative',
    description: 'Manages users, transactions, and operations. Controlled by Super Admin.',
    canManage: ['finance_manager', 'compliance_auditor', 'merchant', 'buyer', 'agent', 'customer_support', 'warehouse_manager', 'delivery', 'user', 'seller'],
  },
  finance_manager: {
    label: 'Finance Manager',
    level: 60,
    accessLevel: 'operational',
    description: 'Manages financial operations, settlements, and reports.',
    canManage: ['merchant', 'buyer', 'user', 'seller'],
  },
  compliance_auditor: {
    label: 'Compliance Auditor',
    level: 55,
    accessLevel: 'operational',
    description: 'Reviews compliance, KYC, AML, and audit logs.',
    canManage: [],
  },
  customer_support: {
    label: 'Customer Support',
    level: 45,
    accessLevel: 'operational',
    description: 'Handles user inquiries, disputes, and notifications.',
    canManage: [],
  },
  merchant: {
    label: 'Merchant',
    level: 30,
    accessLevel: 'business',
    description: 'Business account for receiving payments and managing inventory.',
    canManage: [],
  },
  seller: {
    label: 'Seller',
    level: 28,
    accessLevel: 'business',
    description: 'Seller account for marketplace transactions.',
    canManage: [],
  },
  buyer: {
    label: 'Buyer',
    level: 25,
    accessLevel: 'business',
    description: 'Buyer account for purchasing and payments.',
    canManage: [],
  },
  agent: {
    label: 'Agent',
    level: 20,
    accessLevel: 'business',
    description: 'Agent for facilitating transactions on behalf of others.',
    canManage: [],
  },
  warehouse_manager: {
    label: 'Warehouse Manager',
    level: 15,
    accessLevel: 'operational',
    description: 'Manages warehouse operations and delivery tracking.',
    canManage: [],
  },
  delivery: {
    label: 'Delivery',
    level: 10,
    accessLevel: 'operational',
    description: 'Delivery personnel for order fulfillment.',
    canManage: [],
  },
  user: {
    label: 'User',
    level: 5,
    accessLevel: 'customer',
    description: 'Standard user with basic transaction capabilities.',
    canManage: [],
  },
} as const;

export type RoleKey = keyof typeof ROLES;

// ── Permission Checks ──────────────────────────────────────────

const ADMIN_ROLES = new Set(['super_admin', 'administrator', 'finance_manager', 'compliance_auditor', 'customer_support']);

export function isAdminRole(role: string): boolean {
  return ADMIN_ROLES.has(role);
}

export function isSuperAdmin(role: string): boolean {
  return role === 'super_admin';
}

export function isAdministrator(role: string): boolean {
  return role === 'administrator';
}

/** Can `actorRole` manage `targetRole`? */
export function canManageRole(actorRole: string, targetRole: string): boolean {
  const actor = ROLES[actorRole as RoleKey];
  if (!actor) return false;
  return actor.canManage.includes(targetRole as RoleKey);
}

/** Get the access level label for a role */
export function getAccessLevel(role: string): string {
  return ROLES[role as RoleKey]?.accessLevel || 'customer';
}

/** Get the numeric level for comparison */
export function getRoleLevel(role: string): number {
  return ROLES[role as RoleKey]?.level || 0;
}

/** Can this role view the admin/security panels? */
export function canViewAdmin(role: string): boolean {
  const level = getRoleLevel(role);
  return level >= 45;
}

/** Can this role view security panel? */
export function canViewSecurity(role: string): boolean {
  const level = getRoleLevel(role);
  return level >= 55;
}

/** Can this role approve/reject KYC? */
export function canManageKYC(role: string): boolean {
  return ['super_admin', 'administrator', 'compliance_auditor'].includes(role);
}

/** Can this role manage transaction limits? */
export function canManageLimits(role: string): boolean {
  return ['super_admin', 'administrator', 'finance_manager'].includes(role);
}

/** Can this role manage bank accounts of other users? */
export function canManageBankAccounts(role: string): boolean {
  return getRoleLevel(role) >= 60;
}

/** Get all role keys */
export function getAllRoles(): RoleKey[] {
  return Object.keys(ROLES) as RoleKey[];
}

/** Get role display info */
export function getRoleInfo(role: string) {
  return ROLES[role as RoleKey] || { label: role, level: 0, accessLevel: 'customer', description: '', canManage: [] };
}
