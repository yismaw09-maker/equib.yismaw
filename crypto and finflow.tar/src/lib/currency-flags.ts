/**
 * Currency → Country Flag Emoji mapping
 * Covers 80+ currencies across East Africa, West Africa, Southern Africa, North Africa,
 * Middle East, Americas, Europe, Asia, and Oceania
 */
export const CURRENCY_FLAGS: Record<string, string> = {
  // East Africa
  ETB: '\u{1F1EA}\u{1F1F9}', // Ethiopia
  KES: '\u{1F1F0}\u{1F1EA}', // Kenya
  TZS: '\u{1F1F9}\u{1F1FF}', // Tanzania
  UGX: '\u{1F1FA}\u{1F1EC}', // Uganda
  RWF: '\u{1F1F7}\u{1F1FC}', // Rwanda
  BIF: '\u{1F1E7}\u{1F1EE}', // Burundi
  SOS: '\u{1F1F8}\u{1F1F4}', // Somalia
  DJF: '\u{1F1E9}\u{1F1EF}', // Djibouti
  ERN: '\u{1F1EA}\u{1F1F7}', // Eritrea
  SDG: '\u{1F1F8}\u{1F1E9}', // Sudan
  SSP: '\u{1F1F8}\u{1F1F0}', // South Sudan
  
  // West Africa
  NGN: '\u{1F1F3}\u{1F1EC}', // Nigeria
  GHS: '\u{1F1EC}\u{1F1ED}', // Ghana
  XOF: '\u{1F1EB}\u{1F1F7}', // West African CFA (Senegal)
  XAF: '\u{1F1E8}\u{1F1F2}', // Central African CFA (Cameroon)
  GMD: '\u{1F1EC}\u{1F1F2}', // Gambia
  SLL: '\u{1F1F1}\u{1F1F8}', // Sierra Leone
  LRD: '\u{1F1F1}\u{1F1F7}', // Liberia
  CVE: '\u{1F1E8}\u{1F1FB}', // Cape Verde
  MRO: '\u{1F1F2}\u{1F1F3}', // Mauritania
  GNF: '\u{1F1EC}\u{1F1F3}', // Guinea
  BDT: '\u{1F1E7}\u{1F1E9}', // Bangladesh
  
  // Southern Africa
  ZAR: '\u{1F1FF}\u{1F1E6}', // South Africa
  BWP: '\u{1F1E7}\u{1F1FC}', // Botswana
  NAD: '\u{1F1F3}\u{1F1E6}', // Namibia
  ZMW: '\u{1F1FF}\u{1F1F2}', // Zambia
  MWK: '\u{1F1F2}\u{1F1FC}', // Malawi
  MZN: '\u{1F1F2}\u{1F1FF}', // Mozambique
  SZL: '\u{1F1F8}\u{1F1FF}', // Eswatini
  LSL: '\u{1F1F1}\u{1F1F8}', // Lesotho
  AOA: '\u{1F1E6}\u{1F1F4}', // Angola
  
  // North Africa
  EGP: '\u{1F1EA}\u{1F1EC}', // Egypt
  MAD: '\u{1F1F2}\u{1F1E6}', // Morocco
  TND: '\u{1F1F9}\u{1F1F3}', // Tunisia
  DZD: '\u{1F1E9}\u{1F1FF}', // Algeria
  LYD: '\u{1F1F1}\u{1F1FE}', // Libya
  
  // Middle East
  AED: '\u{1F1E6}\u{1F1EA}', // UAE
  SAR: '\u{1F1F8}\u{1F1E6}', // Saudi Arabia
  QAR: '\u{1F1F6}\u{1F1E6}', // Qatar
  KWD: '\u{1F1F0}\u{1F1FC}', // Kuwait
  BHD: '\u{1F1E7}\u{1F1ED}', // Bahrain
  OMR: '\u{1F1F4}\u{1F1F2}', // Oman
  JOD: '\u{1F1EF}\u{1F1F4}', // Jordan
  IQD: '\u{1F1EE}\u{1F1F6}', // Iraq
  LBP: '\u{1F1F1}\u{1F1E7}', // Lebanon
  SYP: '\u{1F1F8}\u{1F1FE}', // Syria
  YER: '\u{1F1FE}\u{1F1EA}', // Yemen
  ILS: '\u{1F1EE}\u{1F1F1}', // Israel
  
  // Americas
  USD: '\u{1F1FA}\u{1F1F8}', // United States
  CAD: '\u{1F1E8}\u{1F1E6}', // Canada
  MXN: '\u{1F1F2}\u{1F1FD}', // Mexico
  BRL: '\u{1F1E7}\u{1F1F7}', // Brazil
  ARS: '\u{1F1E6}\u{1F1F7}', // Argentina
  CLP: '\u{1F1E8}\u{1F1F1}', // Chile
  COP: '\u{1F1E8}\u{1F1F4}', // Colombia
  PEN: '\u{1F1F5}\u{1F1EA}', // Peru
  
  // Europe
  EUR: '\u{1F1EA}\u{1F1FA}', // European Union
  GBP: '\u{1F1EC}\u{1F1E7}', // United Kingdom
  CHF: '\u{1F1E8}\u{1F1ED}', // Switzerland
  SEK: '\u{1F1F8}\u{1F1EA}', // Sweden
  NOK: '\u{1F1F3}\u{1F1F4}', // Norway
  DKK: '\u{1F1E9}\u{1F1F0}', // Denmark
  PLN: '\u{1F1F5}\u{1F1F1}', // Poland
  CZK: '\u{1F1E8}\u{1F1FF}', // Czech Republic
  HUF: '\u{1F1ED}\u{1F1FA}', // Hungary
  RON: '\u{1F1F7}\u{1F1F4}', // Romania
  RUB: '\u{1F1F7}\u{1F1FA}', // Russia
  UAH: '\u{1F1FA}\u{1F1E6}', // Ukraine
  TRY: '\u{1F1F9}\u{1F1F7}', // Turkey
  
  // Asia
  CNY: '\u{1F1E8}\u{1F1F3}', // China
  JPY: '\u{1F1EF}\u{1F1F5}', // Japan
  INR: '\u{1F1EE}\u{1F1F3}', // India
  PKR: '\u{1F1F5}\u{1F1F0}', // Pakistan
  BDT: '\u{1F1E7}\u{1F1E9}', // Bangladesh
  THB: '\u{1F1F9}\u{1F1ED}', // Thailand
  VND: '\u{1F1FB}\u{1F1F3}', // Vietnam
  MYR: '\u{1F1F2}\u{1F1FE}', // Malaysia
  IDR: '\u{1F1EE}\u{1F1E9}', // Indonesia
  PHP: '\u{1F1F5}\u{1F1EC}', // Philippines
  KRW: '\u{1F1F0}\u{1F1F7}', // South Korea
  TWD: '\u{1F1F9}\u{1F1FC}', // Taiwan
  SGD: '\u{1F1F8}\u{1F1EC}', // Singapore
  HKD: '\u{1F1ED}\u{1F1F0}', // Hong Kong
  LKR: '\u{1F1F1}\u{1F1F0}', // Sri Lanka
  NPR: '\u{1F1F3}\u{1F1F5}', // Nepal
  
  // Oceania
  AUD: '\u{1F1E6}\u{1F1FA}', // Australia
  NZD: '\u{1F1F3}\u{1F1FF}', // New Zealand
  PGK: '\u{1F1F5}\u{1F1EC}', // Papua New Guinea
  FJD: '\u{1F1EB}\u{1F1EF}', // Fiji
  WST: '\u{1F1FC}\u{1F1F8}', // Samoa
  TOP: '\u{1F1F9}\u{1F1F4}', // Tonga
  VUV: '\u{1F1FB}\u{1F1FA}', // Vanuatu
  SBD: '\u{1F1F8}\u{1F1E7}', // Solomon Islands
  
  // Others / Special
  BTC: '\u{20BF}',          // Bitcoin symbol
  USDT: '\u{1F1FA}\u{1F1F8}', // Tether (USD-backed)
};

/** Get flag emoji for a currency code, fallback to globe */
export function getCurrencyFlag(code: string): string {
  return CURRENCY_FLAGS[code] ?? '\u{1F310}';
}
