/**
 * Convert a number to English words (supports up to trillions).
 * Used for financial transaction advice/receipts.
 */

const ONES = [
  '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
  'Seventeen', 'Eighteen', 'Nineteen',
];

const TENS = [
  '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety',
];

const SCALES = ['', 'Thousand', 'Million', 'Billion', 'Trillion'];

function convertChunk(n: number): string {
  if (n === 0) return '';
  const words: string[] = [];

  const hundreds = Math.floor(n / 100);
  const remainder = n % 100;

  if (hundreds > 0) {
    words.push(`${ONES[hundreds]} Hundred`);
  }

  if (remainder > 0) {
    if (remainder < 20) {
      words.push(ONES[remainder]);
    } else {
      const ten = Math.floor(remainder / 10);
      const one = remainder % 10;
      if (one > 0) {
        words.push(`${TENS[ten]}-${ONES[one]}`);
      } else {
        words.push(TENS[ten]);
      }
    }
  }

  return words.join(' ');
}

/** Convert integer to words (internal, no currency suffix) */
function integerToWords(n: number): string {
  if (n === 0) return 'Zero';

  const words: string[] = [];
  let remaining = n;
  let scaleIdx = 0;

  while (remaining > 0) {
    const chunk = remaining % 1000;
    remaining = Math.floor(remaining / 1000);

    if (chunk > 0) {
      const chunkWords = convertChunk(chunk);
      if (SCALES[scaleIdx]) {
        words.unshift(`${chunkWords} ${SCALES[scaleIdx]}`);
      } else {
        words.unshift(chunkWords);
      }
    }
    scaleIdx++;
  }

  return words.join(' ');
}

export function numberToWords(amount: number, currency: string = 'ETB'): string {
  if (amount === 0) return `Zero ${currency === 'ETB' ? 'Birr' : currency} Only`;

  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);

  const integerPart = Math.floor(absAmount);
  const decimalPart = Math.round((absAmount - integerPart) * 100);

  const words: string[] = [];

  if (isNegative) words.push('Minus');

  // Integer part
  if (integerPart > 0) {
    const currencyName = currency === 'ETB' ? 'Birr' : currency;
    words.push(`${integerToWords(integerPart)} ${currencyName}`);
  }

  // Cents/santim
  if (decimalPart > 0) {
    const centWord = currency === 'ETB' ? 'Santim' : 'Cents';
    words.push(`and ${integerToWords(decimalPart)} ${centWord}`);
  }

  words.push('Only');
  return words.join(' ');
}

/** Format amount with commas for figures display */
export function formatAmountFigures(amount: number, currency: string = 'ETB'): string {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency === 'ETB' ? 'ETB' : currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
}
