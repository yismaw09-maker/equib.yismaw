import { create } from 'zustand';

// ── Enterprise View IDs ──────────────────────────────────────────
// Organized to match the FinFlow Enterprise architecture.
// Each ViewId maps to a top-level view component.
// Sub-sections within each area are handled via internal tabs.

type ViewId =
  // MAIN
  | 'dashboard'
  | 'activity-center'
  | 'notifications'
  // WALLET & ACCOUNTS
  | 'wallets'
  | 'transfers'
  | 'crypto'
  // TRANSACTIONS
  | 'transactions'
  // BANKING
  | 'banking'
  // CURRENCIES & FX
  | 'currencies'
  // SEND & RECEIVE
  | 'send-receive'
  // PAYMENTS & COMMERCE
  | 'payments'
  | 'merchants'
  | 'customers'
  // SECURITY & COMPLIANCE
  | 'security'
  | 'compliance'
  // ADMINISTRATION
  | 'admin'
  | 'approvals'
  | 'integrations'
  // REPORTS & ANALYTICS
  | 'reports'
  // AI & AUTOMATION
  | 'ai-assistant'
  // AUDIT & LEDGER
  | 'ledger'
  // SETTINGS
  | 'settings';

export interface UserInfo {
  id: string;
  email: string;
  name: string;
  username: string | null;
  phone: string | null;
  country: string | null;
  role: string;
  status: string;
}

interface AppState {
  activeView: ViewId;
  sidebarOpen: boolean;
  searchQuery: string;
  user: UserInfo | null;
  token: string | null;
  authLoading: boolean;
  setActiveView: (view: ViewId) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  setSearchQuery: (q: string) => void;
  setUser: (user: UserInfo | null) => void;
  setToken: (token: string | null) => void;
  setAuthLoading: (loading: boolean) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  activeView: 'dashboard',
  sidebarOpen: false,
  searchQuery: '',
  user: null,
  token: null,
  authLoading: true,
  setActiveView: (view) => set({ activeView: view, sidebarOpen: false }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setUser: (user) => set({ user, authLoading: false }),
  setToken: (token) => set({ token }),
  setAuthLoading: (loading) => set({ authLoading: loading }),
  logout: () => {
    fetch('/api/auth/session', { method: 'POST' }).catch(() => {});
    set({ user: null, token: null, authLoading: false, activeView: 'dashboard' });
  },
}));

export type { ViewId };
