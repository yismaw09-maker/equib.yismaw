/**
 * Authenticated fetch wrapper.
 * Reads the Bearer token from Zustand store and attaches it as an Authorization header.
 * Falls back to cookie-based auth (same-origin).
 */

import { useAppStore } from './store';

/**
 * Like global `fetch()` but injects the FinFlow auth token automatically.
 * Usage: replace `fetch('/api/dashboard')` with `apiFetch('/api/dashboard')`
 */
export function apiFetch(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  const token = useAppStore.getState().token;
  const headers = new Headers(init?.headers);

  // Only set Authorization if we have a token and there isn't one already
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  return fetch(input, { ...init, headers });
}
