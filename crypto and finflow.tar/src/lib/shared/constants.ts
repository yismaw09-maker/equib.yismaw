// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Constants
// ═══════════════════════════════════════════════════════════════

// ── Platform ──────────────────────────────────────────────────

export const PLATFORM_NAME = 'FinFlow';
export const PLATFORM_VERSION = '1.0';
export const PLATFORM_EDITION = 'Enterprise';

// ── Session & Auth ─────────────────────────────────────────────

export const SESSION_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
export const SESSION_COOKIE_NAME = 'finflow-token';

// ── Pagination ──────────────────────────────────────────────────

export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 200;

// ── Risk Scoring ────────────────────────────────────────────────

export const RISK_THRESHOLDS = {
  low: 0.3,
  medium: 0.6,
  high: 0.8,
  critical: 1.0,
} as const;

// ── Transaction Limits (defaults) ──────────────────────────────

export const DEFAULT_LIMITS = {
  user: { daily: 100000, monthly: 1000000, singleMax: 50000 },
  buyer: { daily: 500000, monthly: 5000000, singleMax: 200000 },
  merchant: { daily: 5000000, monthly: 50000000, singleMax: 1000000 },
  agent: { daily: 2000000, monthly: 20000000, singleMax: 500000 },
} as const;

// ── Ethiopian Banks ─────────────────────────────────────────────

export const ETHIOPIAN_BANKS = [
  { code: 'CBE', name: 'Commercial Bank of Ethiopia', swift: 'CBETETAA' },
  { code: 'AWASH', name: 'Awash International Bank', swift: 'AWABETAA' },
  { code: 'DASHEN', name: 'Dashen Bank', swift: 'DBETETAA' },
  { code: 'ABYSSINIA', name: 'Bank of Abyssinia', swift: 'ABYSETAA' },
  { code: 'NIB', name: 'Nib International Bank', swift: 'NIBTETAA' },
  { code: 'UNITED', name: 'United Bank', swift: 'UBTETAA' },
  { code: 'HIBRET', name: 'Hibret Bank', swift: 'HBBTETAA' },
  { code: 'WOCH', name: 'Wegagen Bank', swift: 'WGBTETAA' },
  { code: 'ZAMEN', name: 'ZamZam Bank', swift: 'ZZBTETAA' },
  { code: 'GIBE', name: 'Gibe Bank', swift: 'GIBTETAA' },
  { code: 'SIDAMA', name: 'Sidama Bank', swift: 'SDBTETAA' },
  { code: 'OROMIA', name: 'Oromia International Bank', swift: 'OIBTETAA' },
  { code: 'AHADU', name: 'Ahadu Bank', swift: 'AHBTETAA' },
  { code: 'GOGO', name: 'GoGo Birr', swift: 'GBRTETAA' },
] as const;

// ── Mobile Money Providers ──────────────────────────────────────

export const MOBILE_MONEY_PROVIDERS = [
  { code: 'TELEBIRR', name: 'telebirr', color: '#00A651' },
  { code: 'MPESA', name: 'M-Pesa', color: '#4FC3F7' },
  { code: 'HELLO_CASH', name: 'HelloCash', color: '#FF6F00' },
] as const;

// ── Crypto Currencies ───────────────────────────────────────────

export const CRYPTO_CURRENCIES = [
  { code: 'BTC', name: 'Bitcoin', decimals: 8, networks: ['mainnet', 'testnet'] },
  { code: 'ETH', name: 'Ethereum', decimals: 18, networks: ['mainnet', 'erc20', 'testnet'] },
  { code: 'USDT', name: 'Tether USD', decimals: 6, networks: ['erc20', 'trc20', 'bep20'] },
  { code: 'USDC', name: 'USD Coin', decimals: 6, networks: ['erc20', 'trc20', 'bep20'] },
  { code: 'XRP', name: 'Ripple', decimals: 6, networks: ['mainnet'] },
  { code: 'SOL', name: 'Solana', decimals: 9, networks: ['mainnet', 'devnet'] },
  { code: 'DOGE', name: 'Dogecoin', decimals: 8, networks: ['mainnet'] },
  { code: 'ADA', name: 'Cardano', decimals: 6, networks: ['mainnet'] },
] as const;

// ── Currencies ──────────────────────────────────────────────────

export const SUPPORTED_CURRENCIES = [
  { code: 'ETB', name: 'Ethiopian Birr', symbol: 'Br', flag: '🇪🇹' },
  { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸' },
  { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺' },
  { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧' },
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', flag: '🇦🇪' },
  { code: 'SAR', name: 'Saudi Riyal', symbol: '﷼', flag: '🇸🇦' },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', flag: '🇨🇳' },
  { code: 'KES', name: 'Kenyan Shilling', symbol: 'KSh', flag: '🇰🇪' },
] as const;

// ── Integration Types ──────────────────────────────────────────

export const INTEGRATION_TYPES = [
  'bank', 'payment_gateway', 'sms', 'email',
  'fx_provider', 'kyc_provider', 'fraud_detection', 'analytics',
] as const;

// ── Approval Types with Required Levels ─────────────────────────

export const APPROVAL_REQUIREMENTS: Record<string, { minLevel: number; description: string }> = {
  kyc_approval: { minLevel: 55, description: 'KYC Verification Approval' },
  transaction_approval: { minLevel: 60, description: 'Large Transaction Approval' },
  withdrawal_approval: { minLevel: 60, description: 'Withdrawal Approval' },
  limit_change: { minLevel: 80, description: 'Transaction Limit Change' },
  merchant_onboarding: { minLevel: 60, description: 'Merchant Onboarding' },
  refund_approval: { minLevel: 60, description: 'Refund Approval' },
  role_change: { minLevel: 100, description: 'Role Change Approval' },
};
