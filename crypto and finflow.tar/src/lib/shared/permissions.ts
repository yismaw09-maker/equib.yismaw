// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Permission Definitions
// ═══════════════════════════════════════════════════════════════

import { getRoleLevel } from '@/lib/role-permissions';

// ── Permission Matrix ────────────────────────────────────────
// Maps resource:action to minimum role level required.

const PERMISSION_MATRIX: Record<string, number> = {
  // Users & Customers
  'users:list': 45,
  'users:view': 5,
  'users:create': 45,
  'users:update': 5,       // own profile
  'users:delete': 80,
  'users:change_role': 100,

  // Wallets
  'wallets:list': 5,       // own wallets
  'wallets:list_all': 45,  // all wallets
  'wallets:create': 45,
  'wallets:freeze': 60,
  'wallets:close': 60,

  // Transactions
  'transactions:list': 5,       // own
  'transactions:list_all': 45, // all
  'transactions:create': 5,
  'transactions:approve': 60,
  'transactions:reverse': 60,
  'transactions:delete': 60,

  // Banking
  'banking:list': 5,
  'banking:list_all': 45,
  'banking:create': 45,
  'banking:reconcile': 60,

  // Currencies & FX
  'currencies:list': 5,
  'currencies:manage': 60,
  'fx:trade': 5,
  'fx:manage_rates': 60,

  // Merchants
  'merchants:list': 25,
  'merchants:manage': 45,
  'merchants:approve': 60,

  // Payments
  'payments:list': 5,
  'payments:list_all': 45,
  'payments:refund': 60,

  // Security & Compliance
  'security:view': 55,
  'security:manage': 80,
  'compliance:view': 55,
  'compliance:manage': 55,
  'compliance:resolve': 60,

  // Approvals
  'approvals:list': 5,
  'approvals:manage': 45,
  'approvals:approve': 45,

  // Audit & Ledger
  'audit:view': 55,
  'audit:export': 60,
  'ledger:view': 60,
  'ledger:manage': 80,

  // Reports
  'reports:view': 45,
  'reports:export': 45,
  'reports:financial': 60,

  // Settings
  'settings:view': 5,        // own profile
  'settings:manage': 80,
  'settings:system': 100,

  // Integrations
  'integrations:view': 60,
  'integrations:manage': 80,

  // AI
  'ai:use': 5,
  'ai:manage': 80,
};

// ── Permission Check ──────────────────────────────────────────

export function hasPermission(role: string, permission: string): boolean {
  const requiredLevel = PERMISSION_MATRIX[permission];
  if (requiredLevel === undefined) return false;
  return getRoleLevel(role) >= requiredLevel;
}

export function getRequiredLevel(permission: string): number | undefined {
  return PERMISSION_MATRIX[permission];
}

export function getAllPermissions(): Record<string, number> {
  return { ...PERMISSION_MATRIX };
}
