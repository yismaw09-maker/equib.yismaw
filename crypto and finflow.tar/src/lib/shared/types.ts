// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Shared Type Definitions
// ═══════════════════════════════════════════════════════════════

// ── Transaction Lifecycle ──────────────────────────────────────

export const TRANSACTION_STATUSES = [
  'pending', 'processing', 'completed', 'failed',
  'cancelled', 'reversed', 'settled', 'reconciled',
] as const;

export type TransactionStatus = (typeof TRANSACTION_STATUSES)[number];

export const TRANSACTION_TYPES = [
  'deposit', 'withdrawal', 'transfer', 'payment',
  'refund', 'chargeback', 'reversal', 'escrow',
  'commission', 'split_payment',
] as const;

export type TransactionType = (typeof TRANSACTION_TYPES)[number];

export const TRANSACTION_SUB_TYPES = [
  'p2p', 'wallet_to_wallet', 'bank_to_bank', 'merchant',
  'customer', 'online', 'bill', 'subscription', 'scheduled',
  'recurring', 'referral_bonus',
] as const;

export type TransactionSubType = (typeof TRANSACTION_SUB_TYPES)[number];

export const PAYMENT_METHODS = [
  'bank_account', 'debit_card', 'credit_card', 'mobile_money',
  'qr_code', 'digital_wallet', 'crypto',
] as const;

export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

// ── Wallet ─────────────────────────────────────────────────────

export const WALLET_TYPES = ['digital', 'merchant', 'escrow'] as const;
export type WalletType = (typeof WALLET_TYPES)[number];

export const WALLET_STATUSES = ['active', 'frozen', 'closed'] as const;
export type WalletStatus = (typeof WALLET_STATUSES)[number];

// ── User ────────────────────────────────────────────────────────

export const USER_STATUSES = [
  'pending', 'approved', 'active', 'blocked',
  'inactive', 'suspended', 'frozen', 'closed',
] as const;

export const KYC_STATUSES = ['pending', 'verified', 'rejected'] as const;

export const RISK_LEVELS = ['low', 'medium', 'high'] as const;

// ── Compliance ─────────────────────────────────────────────────

export const COMPLIANCE_CASE_TYPES = [
  'kyc_review', 'aml_alert', 'fraud_investigation',
  'suspicious_activity', 'sanction_match', 'high_risk_transaction',
] as const;

export const COMPLIANCE_CASE_SEVERITIES = ['low', 'medium', 'high', 'critical'] as const;

export const COMPLIANCE_CASE_STATUSES = [
  'open', 'under_review', 'escalated', 'resolved', 'closed',
] as const;

// ── Approvals ──────────────────────────────────────────────────

export const APPROVAL_TYPES = [
  'kyc_approval', 'transaction_approval', 'withdrawal_approval',
  'limit_change', 'merchant_onboarding', 'refund_approval', 'role_change',
] as const;

export const APPROVAL_STATUSES = [
  'pending', 'approved', 'rejected', 'cancelled', 'expired',
] as const;

// ── Ledger ─────────────────────────────────────────────────────

export const LEDGER_ACCOUNTS = {
  // Assets
  CASH_ETB: 'CASH:ETB',
  CASH_USD: 'CASH:USD',
  BANK_ETB: 'BANK:ETB',
  BANK_USD: 'BANK:USD',
  RECEIVABLES: 'ASSET:RECEIVABLES',
  // Liabilities
  USER_BALANCES: 'LIABILITY:USER_BALANCES',
  PAYABLES: 'LIABILITY:PAYABLES',
  ESCROW: 'LIABILITY:ESCROW',
  // Revenue
  FEE_REVENUE: 'REVENUE:FEE',
  FX_GAIN: 'REVENUE:FX_GAIN',
  COMMISSION_REVENUE: 'REVENUE:COMMISSION',
  // Expenses
  BANK_CHARGES: 'EXPENSE:BANK_CHARGES',
  FX_LOSS: 'EXPENSE:FX_LOSS',
} as const;

export type LedgerAccountId = (typeof LEDGER_ACCOUNTS)[keyof typeof LEDGER_ACCOUNTS];

export type LedgerEntryType = 'debit' | 'credit';

// ── Notifications ───────────────────────────────────────────────

export const NOTIFICATION_TYPES = [
  'deposit', 'withdrawal', 'payment', 'transfer',
  'security', 'balance', 'system', 'approval', 'compliance',
] as const;

export const NOTIFICATION_CHANNELS = ['in_app', 'sms', 'email', 'push'] as const;

// ── Pagination ──────────────────────────────────────────────────

export interface PaginationParams {
  page: number;
  limit: number;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: PaginationMeta;
}

// ── API Response ────────────────────────────────────────────────

export interface ApiError {
  error: string;
  code?: string;
  details?: string;
}

export interface ApiSuccess<T = unknown> {
  data?: T;
  success?: boolean;
  message?: string;
}
