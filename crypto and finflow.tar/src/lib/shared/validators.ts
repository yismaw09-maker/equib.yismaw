// ═══════════════════════════════════════════════════════════════
// FinFlow Enterprise — Input Validators
// ═══════════════════════════════════════════════════════════════

import {
  TRANSACTION_TYPES, TRANSACTION_SUB_TYPES, PAYMENT_METHODS,
  WALLET_TYPES, WALLET_STATUSES, USER_STATUSES, KYC_STATUSES,
  COMPLIANCE_CASE_TYPES, COMPLIANCE_CASE_SEVERITIES, COMPLIANCE_CASE_STATUSES,
  APPROVAL_TYPES, APPROVAL_STATUSES, NOTIFICATION_TYPES,
} from './types';

// ── Generic Validators ────────────────────────────────────────

export function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

export function isPositiveNumber(value: unknown): value is number {
  return typeof value === 'number' && !isNaN(value) && value > 0;
}

export function isNonNegativeNumber(value: unknown): value is number {
  return typeof value === 'number' && !isNaN(value) && value >= 0;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function isValidPhone(phone: string): boolean {
  return /^\+?[1-9]\d{7,14}$/.test(phone.replace(/\s/g, ''));
}

export function isValidCuid(id: string): boolean {
  return /^c[a-z0-9]{20,}$/.test(id);
}

// ── Transaction Validators ────────────────────────────────────

export function isValidTransactionType(type: string): boolean {
  return (TRANSACTION_TYPES as readonly string[]).includes(type);
}

export function isValidTransactionSubType(subType: string): boolean {
  return (TRANSACTION_SUB_TYPES as readonly string[]).includes(subType);
}

export function isValidPaymentMethod(method: string): boolean {
  return (PAYMENT_METHODS as readonly string[]).includes(method);
}

export function isValidTransactionStatus(status: string): boolean {
  return ['pending', 'processing', 'completed', 'failed', 'cancelled', 'reversed', 'settled', 'reconciled'].includes(status);
}

// ── Wallet Validators ─────────────────────────────────────────

export function isValidWalletType(type: string): boolean {
  return (WALLET_TYPES as readonly string[]).includes(type);
}

export function isValidWalletStatus(status: string): boolean {
  return (WALLET_STATUSES as readonly string[]).includes(status);
}

// ── User Validators ───────────────────────────────────────────

export function isValidUserStatus(status: string): boolean {
  return (USER_STATUSES as readonly string[]).includes(status);
}

export function isValidKycStatus(status: string): boolean {
  return (KYC_STATUSES as readonly string[]).includes(status);
}

// ── Compliance Validators ─────────────────────────────────────

export function isValidComplianceCaseType(type: string): boolean {
  return (COMPLIANCE_CASE_TYPES as readonly string[]).includes(type);
}

export function isValidComplianceCaseSeverity(severity: string): boolean {
  return (COMPLIANCE_CASE_SEVERITIES as readonly string[]).includes(severity);
}

export function isValidComplianceCaseStatus(status: string): boolean {
  return (COMPLIANCE_CASE_STATUSES as readonly string[]).includes(status);
}

// ── Approval Validators ───────────────────────────────────────

export function isValidApprovalType(type: string): boolean {
  return (APPROVAL_TYPES as readonly string[]).includes(type);
}

export function isValidApprovalStatus(status: string): boolean {
  return (APPROVAL_STATUSES as readonly string[]).includes(status);
}

// ── Notification Validators ───────────────────────────────────

export function isValidNotificationType(type: string): boolean {
  return (NOTIFICATION_TYPES as readonly string[]).includes(type);
}

// ── Amount Validation ─────────────────────────────────────────

export function validateAmount(amount: unknown): { valid: true; value: number } | { valid: false; error: string } {
  if (typeof amount !== 'number' || isNaN(amount)) {
    return { valid: false, error: 'Amount must be a number' };
  }
  if (amount <= 0) {
    return { valid: false, error: 'Amount must be positive' };
  }
  if (!Number.isFinite(amount)) {
    return { valid: false, error: 'Amount must be finite' };
  }
  // Max precision: 8 decimal places (for crypto)
  if (amount.toString().split('.')[1]?.length > 8) {
    return { valid: false, error: 'Amount has too many decimal places (max 8)' };
  }
  return { valid: true, value: amount };
}

// ── Currency Validation ───────────────────────────────────────

const VALID_CURRENCY_CODES = new Set([
  'ETB', 'USD', 'EUR', 'GBP', 'AED', 'SAR', 'CNY', 'KES',
  'BTC', 'ETH', 'USDT', 'USDC', 'XRP', 'SOL', 'DOGE', 'ADA',
]);

export function isValidCurrencyCode(code: string): boolean {
  return VALID_CURRENCY_CODES.has(code.toUpperCase());
}
