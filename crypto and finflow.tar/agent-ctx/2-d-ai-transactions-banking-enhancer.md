# Task 2-d: AI Transaction Advice + Banking Enhancement

## Agent: ai-transactions-banking-enhancer

## Changes Made

### Part 1: Transactions View (`src/components/financial/transactions-view.tsx`)

**Imports Added:**
- `Sparkles` from lucide-react
- `Collapsible, CollapsibleContent, CollapsibleTrigger` from @/components/ui/collapsible

**New State Variables:**
- `aiAdvice` (string | null) — stores bulk AI advice text
- `aiAdviceLoading` (boolean) — loading state for bulk advice
- `showAdvicePanel` (boolean) — controls collapsible panel visibility
- `detailAiAdvice` (string | null) — stores per-transaction AI advice
- `detailAiLoading` (boolean) — loading state for per-transaction advice

**New Functions:**
- `handleAiAdvice()` — Takes top 5 visible/filtered transactions, maps to required fields (reference, type, amount, currency, status, riskScore, fraudFlag, initiatorName, recipientName, bankName, description), POSTs to `/api/ai/advice`
- `handleDetailAiAdvice()` — Sends single transaction to AI advice API
- `useEffect` to reset detail AI advice on dialog close or transaction change

**New UI Elements:**
1. "AI Advice" button in filter action bar (teal-themed, Sparkles icon, disabled when loading or no transactions)
2. Collapsible AI Advice Panel below filter card:
   - Teal/emerald left border (`border-l-4 border-l-teal-500`)
   - Sparkles icon + "AI Financial Advisor" header
   - "Analysis Complete" badge when advice received
   - Loading spinner during fetch
   - Advice text in teal-tinted container
   - Close button (X) to dismiss
   - AnimatePresence for smooth show/hide animation
3. "Get AI Advice for This Transaction" button in detail dialog (below admin actions)
4. Per-transaction advice display with teal-styled card and motion animation

### Part 2: Banking View (`src/components/financial/banking-view.tsx`)

**New State Variable:**
- `formCurrency` (string, default 'ETB')

**Changes:**
- Added Currency Select field to "Link Bank Account" dialog form (ETB, USD, EUR, GBP, CNY)
- Updated `resetForm()` to reset currency to 'ETB'
- Updated `handleCreateAccount()` POST body to include `currency` field

**Note:** Banking view already had all other required functionality:
- Verify button (`handleVerify` → PATCH with isVerified: true)
- Set Default button (`handleSetDefault` → PATCH with isDefault: true)
- Form validation (accountNumber, bankName required)
- Remove with confirmation dialog

### API Routes (Pre-existing, No Changes Needed)
- `/api/ai/advice` — Already existed, uses z-ai-web-dev-sdk LLM
- `/api/bank-accounts` — Already supports GET, POST, PATCH (verify, default, status)
