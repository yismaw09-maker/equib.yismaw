# Task ID: 3-resume - full-stack-developer

## Task
Complete i18n for the REMAINING tabs in `/home/z/my-project/src/components/financial/admin-view.tsx`

## Findings
- ALL 6 tabs and the main AdminView component already had `const t = useT()` and the vast majority of strings were already using t() calls from a previous agent's work
- Only 5 hardcoded English strings remained in the entire 1757-line file

## Changes Made

### admin-view.tsx (4 replacements)
1. **Edit User Dialog - Country select**: `placeholder="Select country"` → `placeholder={t('admin.selectCountry')}`
2. **Edit User Dialog - None option**: `>None<` → `>{t('admin.none')}`
3. **Edit User Dialog - KYC status select items**: `Pending/Verified/Rejected` → `t('common.pending')/t('common.verified')/t('common.rejected')`
4. **Fee table min/max labels**: `min {f.minFee}` → `{t('admin.minLabel')} {f.minFee}`, same for max

### translations.ts
- Added 6 new English keys: `admin.selectCountry`, `admin.none`, `admin.minLabel`, `admin.maxLabel`, `common.rejected`
- Fixed 53 Amharic translation values that were still in English (admin panel desc, fee config, commissions, settlements, dispute resolution keys)
- Added corresponding Amharic translations for the 6 new keys

## Verification
- `bun run lint` passes with zero errors
- Dev server compiles successfully (GET / 200)
