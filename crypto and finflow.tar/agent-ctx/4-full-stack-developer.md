# Task ID: 4 - full-stack-developer

## Task
Update `/home/z/my-project/src/components/financial/transactions-view.tsx` to replace ALL hardcoded English strings with i18n `t()` function calls and add role-based admin gating for Approve/Reject/Reverse/Delete actions.

## Changes Made

### Imports Added
- `useMemo` from React (for memoizing SORTABLE_COLUMNS)
- `useT` from `@/lib/i18n`
- `isAdminRole` from `@/lib/role-permissions`
- `useAppStore` from `@/lib/store`

### Hooks Added (inside component)
- `const t = useT()` - translation function
- `const currentUser = useAppStore(s => s.user)` - current user from store
- `const isAdmin = currentUser ? isAdminRole(currentUser.role) : false` - admin check

### i18n Replacements (30+ strings)
- Header/subtitle → `t('transactions.management')` / `t('transactions.viewManage')`
- Filter labels, badges, placeholders → various `t()` calls
- Summary cards (Total Count, Total Amount, Completed, Pending, Failed) → `t()` calls
- Table headers (Reference, Type, Amount, Fee, Status, Date, SubType, Currency, Initiator, Recipient, Payment Method, Actions) → `t()` calls
- Dropdown menu items (Open menu, View Details, Approve, Reject, Reverse) → `t()` calls
- Pagination (Showing, to, of, entries, First, Last) → `t()` calls
- Detail dialog title + 19 detail field labels → `t()` calls
- `detailField` helper Yes/No → `t('common.yes')` / `t('common.no')`

### Admin Gating
- Dropdown: Approve/Reject → `{isAdmin && txn.status === 'pending' && (...)}`
- Dropdown: Reverse → `{isAdmin && (txn.status === 'completed' || txn.status === 'processing') && (...)}`
- Detail dialog actions section → `{isAdmin && (status checks) && (...)}`

### Architecture Change
- Moved `SORTABLE_COLUMNS` from module-level constant to `useMemo` inside component so labels can use `t()`
- Removed standalone `SortableColumn` interface (inlined)

## Verification
- `bun run lint` passes with zero errors
- Dev server compiles successfully