import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()
async function main() {
  const users = await prisma.user.count()
  const transactions = await prisma.transaction.count()
  const bankAccounts = await prisma.bankAccount.count()
  const wallets = await prisma.wallet.count()
  const notifications = await prisma.notification.count()
  console.log(`Users: ${users}`)
  console.log(`Transactions: ${transactions}`)
  console.log(`BankAccounts: ${bankAccounts}`)
  console.log(`Wallets: ${wallets}`)
  console.log(`Notifications: ${notifications}`)
}
main().then(() => prisma.$disconnect())
